package com.discover.bank.api.creditcards;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.env.PropertyAccessor;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AccountNumberMixinTest {

    PropertyAccessor props = CreditCardsTestConfiguration.propertyAccessor();

    ObjectMapper mapper = CreditCardsTestConfiguration.objectMapper();

    //@Test
    public void testAccountNumberMixin_Output() throws JsonProcessingException {
        String output = mapper.writeValueAsString(AccountNumber.parse("6001234987"));

        Assert.assertNotNull(output);
        Assert.assertEquals(props.get("AccountNumber.Output"), output);
    }

    @Test
    public void accountNumberMixinInputTest()
                    throws JsonParseException, JsonMappingException, IOException {
        AccountNumber input =
                        mapper.readValue(props.get("AccountNumber.Input"), AccountNumber.class);

        Assert.assertNotNull(input);
        Assert.assertEquals(AccountNumber.parse("6001234987"), input);
    }
}
