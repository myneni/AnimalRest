package com.discover.bank.api.creditcards;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.env.PropertyAccessor;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CreditCardAccountMixinTest {

    PropertyAccessor props = CreditCardsTestConfiguration.propertyAccessor();

    ObjectMapper mapper = CreditCardsTestConfiguration.objectMapper();

    //@Test
    public void testCreditCardAccountMixin_Output() throws JsonProcessingException {
        String output = mapper.writeValueAsString(CreditCardAccount.newBuilder().withId("0")
                        .withNickName("Credit card account ending 1589")
                        .withAccountNumber(AccountNumber.parse("6001231589")).build());

        Assert.assertNotNull(output);
        Assert.assertEquals(props.get("CreditCardAccount.Output"), output);
    }

    @Test
    public void creditCardAccountMixinInputTest()
                    throws JsonParseException, JsonMappingException, IOException {
        CreditCardAccount input = mapper.readValue(props.get("CreditCardAccount.Input"),
                        CreditCardAccount.class);

        Assert.assertNotNull(input);
        Assert.assertEquals("0", input.getId());
        Assert.assertEquals(AccountNumber.parse("6001231589"), input.getAccountNumber());
    }

}
