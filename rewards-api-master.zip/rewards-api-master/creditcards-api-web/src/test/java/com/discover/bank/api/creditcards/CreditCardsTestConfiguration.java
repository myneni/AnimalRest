package com.discover.bank.api.creditcards;

import java.io.IOException;

import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.ClassPathResource;

import com.discover.bank.api.config.autoconfigure.JacksonAutoConfiguration;
import com.discover.bank.api.creditcards.config.CreditCardsHypermediaConfiguration;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.common.io.ReloadableBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * TODO: Once JUnit 4.9+ is available we can ignore all of this and move right into a Spring Managed
 * environment. From there we can create a PropertyAccessor from the provided environment.
 */
public class CreditCardsTestConfiguration {

    public static PropertyAccessor propertyAccessor() {
        StandardEnvironment env = new StandardEnvironment();
        PropertiesPropertySource ps;

        try {
            ps = new PropertiesPropertySource("mixins", ReloadableBuilder.FILE_TO_PROPERTIES
                            .apply(new ClassPathResource("mixins.properties").getFile()));

            env.getPropertySources().addFirst(ps);
        } catch (IOException e) {

        }

        return new PropertyAccessor(env);
    }

    public static ObjectMapper objectMapper() {
        ObjectMapper mapper = new JacksonAutoConfiguration().objectMapper();

        new CreditCardsHypermediaConfiguration().configureMixins(mapper);
        return mapper;
    }

}
