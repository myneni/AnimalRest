package com.discover.bank.api.creditcards;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.core.customers.CustomerNotFoundException;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.hateoas.Hypermedia;
import com.discover.bank.api.hateoas.Resource;
import com.discover.common.security.access.annotation.RequiresAuthentication;

@Controller
@RequestMapping(value = "", produces = {MediaType.APPLICATION_JSON_VALUE})
@RequiresAuthentication
public class CreditCardsController {

    private static final Logger LOG = LoggerFactory.getLogger(CreditCardsController.class);

    @Inject
    private CreditCardsBusinessObject application;

    @Inject
    private Hypermedia hypermedia;

    @RequestMapping(value = "", method = RequestMethod.GET)
    public @ResponseBody HttpEntity<Iterable<Resource<CreditCardAccount>>> lookupCreditCards(
                    CustomerIdentification customer)
                                    throws CustomerNotFoundException, CreditCardsException {

        LOG.info("Looking up credit cards for user: {}", customer);

        return hypermedia.ok(application.lookupRewardsTransferEligibleCreditCards(customer));
    }

}
