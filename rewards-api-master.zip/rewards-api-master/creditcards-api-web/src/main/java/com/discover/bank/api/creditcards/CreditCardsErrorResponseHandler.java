package com.discover.bank.api.creditcards;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.discover.bank.api.ErrorResolver;
import com.discover.bank.api.ErrorResponse;
import com.discover.bank.api.core.customers.CustomerNotFoundException;

@ControllerAdvice
public class CreditCardsErrorResponseHandler {

    private static final Logger LOG =
                    LoggerFactory.getLogger(CreditCardsErrorResponseHandler.class);

    private ErrorResolver errorResolver;

    @Inject
    public void setErrorResolver(ErrorResolver errorResolver) {
        this.errorResolver = errorResolver;
    }

    @ExceptionHandler({CreditCardsException.class, CustomerNotFoundException.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ErrorResponse handleException(Exception ex) {

        LOG.warn("Exception thrown with message {} : ", ex.getMessage(), ex);

        // Just show the general message until they want to display a specific one
        return ErrorResponse.of(errorResolver.resolve("General.TechnicalDifficulties"));
    }
}
