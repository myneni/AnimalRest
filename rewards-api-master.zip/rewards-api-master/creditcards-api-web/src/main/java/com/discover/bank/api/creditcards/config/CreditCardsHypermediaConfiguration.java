package com.discover.bank.api.creditcards.config;

import javax.inject.Inject;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.discover.amservice.bd.AMServiceBDFactory;
import com.discover.amservice.bd.AMServiceDelegate;
import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.config.EnableBankingSupport;
import com.discover.bank.api.creditcards.account.AccountNumberMixin;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.creditcards.account.CreditCardAccountMixin;
import com.discoverfinancial.ecc.customersearch.bd.CustomerSearchFactory;
import com.discoverfinancial.ecc.customersearch.bd.ICustomerSearchBD;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@EnableBankingSupport
@ComponentScan({"com.discover.bank.api.creditcards"})
public class CreditCardsHypermediaConfiguration {

    @Inject
    public void configureMixins(ObjectMapper objectMapper) {
        objectMapper.addMixIn(CreditCardAccount.class, CreditCardAccountMixin.class);
        objectMapper.addMixIn(AccountNumber.class, AccountNumberMixin.class);
        objectMapper.addMixIn(CreditCardAccount.Builder.class,
                        CreditCardAccountMixin.BuilderMixin.class);
    }

    @Bean
    public ICustomerSearchBD cardmemberSearchService() {
        return (ICustomerSearchBD) CustomerSearchFactory.getInstance().getBDInterface();
    }

    @Bean
    public AMServiceDelegate accountInfoService() {
        return (AMServiceDelegate) AMServiceBDFactory.getInstance().getBDInterface();
    }
}
