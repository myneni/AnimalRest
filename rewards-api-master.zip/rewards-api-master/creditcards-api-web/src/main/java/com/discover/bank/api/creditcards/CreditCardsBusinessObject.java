package com.discover.bank.api.creditcards;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.validation.Validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.discover.bank.api.core.customers.Customer;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.core.customers.CustomerManager;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.creditcards.account.CreditCardAccountRepository;
import com.discover.common.stereotype.BusinessObject;

/**
 * Used for credit card related business logic.
 */
@BusinessObject
public class CreditCardsBusinessObject {

    private static final Logger LOG = LoggerFactory.getLogger(CreditCardsBusinessObject.class);

    @Inject
    private CreditCardAccountRepository cardRepository;

    @Inject
    private CustomerManager customers;

    @Inject
    private Validator validator;

    /**
     * Looks up a List&lt;CreditCardAccount&gt; for which the customer is the primary or secondary
     * account holder and are eligible for a rewards transfer
     *
     * @param customer - The CustomerIdentification object which holds the CIF of the customer to
     *        look up
     * @return List&lt;CreditCardAccount&gt; - The list of eligible accounts
     * @throws CreditCardsException Thrown when there is an error with a service call
     */
    public List<CreditCardAccount> lookupRewardsTransferEligibleCreditCards(
                    CustomerIdentification customer) throws CreditCardsException {
        final Customer cardCustomer = customers.findCustomer(customer);

        List<CreditCardAccount> creditCardAccounts;
        try {
            creditCardAccounts = cardRepository
                            .lookupCreditCardAccounts(cardCustomer.getSocialSecurityNumber());
        } catch (CreditCardsException e) {
            LOG.error("Exception while looking up for credit card accounts", e);
            throw new UnrecoverableCreditCardException();
        }

        List<CreditCardAccount> rewardsTransferEligibleCreditCards =
                        new ArrayList<CreditCardAccount>();

        for (CreditCardAccount creditCardAccount : creditCardAccounts) {
            // The user must be either the primary or secondary on the account for it to show in the
            // list

            if ((creditCardAccount.getPrimarySocialSecurityNumber()
                            .equals(cardCustomer.getSocialSecurityNumber())
                            || creditCardAccount.getSecondarySocialSecurityNumber()
                                            .equals(cardCustomer.getSocialSecurityNumber()))
                            && validator.validate(creditCardAccount,
                                            CreditCardAccount.ValidForTransfer.class).isEmpty()) {

                rewardsTransferEligibleCreditCards.add(creditCardAccount);
            }
        }

        return rewardsTransferEligibleCreditCards;
    }


}
