package com.discover.bank.api.creditcards.config;

import com.discover.bank.api.config.HypermediaApplicationLauncher;
import com.discover.bank.api.config.HypermediaWebApplicationInitializer;

public class CreditCardsWebApplicationInitializer extends HypermediaWebApplicationInitializer {

    @Override
    protected HypermediaApplicationLauncher configure(HypermediaApplicationLauncher launcher) {
        launcher.sources(CreditCardsHypermediaConfiguration.class); // anything with a configuration
                                                                    // annotation
        // launchy.initializers(initializers); //happen before the spring context is loaded... dont
        // worry about this
        // launchy.listeners(listeners); //spring event listeners... probably not a thing to worry
        // about.
        return launcher;
    }
}
