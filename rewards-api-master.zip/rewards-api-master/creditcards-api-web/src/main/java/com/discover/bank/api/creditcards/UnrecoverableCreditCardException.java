package com.discover.bank.api.creditcards;

import com.discover.bank.api.exception.UnrecoverableResolvableError;

public class UnrecoverableCreditCardException extends RuntimeException
                implements UnrecoverableResolvableError {

    private static final long serialVersionUID = 1L;

    private final String[] codes;

    public UnrecoverableCreditCardException() {
        codes = new String[0];
    }

    public UnrecoverableCreditCardException(String... codes) {
        this.codes = codes;
    }

    @Override
    public String[] getCodes() {
        return codes;
    }
}
