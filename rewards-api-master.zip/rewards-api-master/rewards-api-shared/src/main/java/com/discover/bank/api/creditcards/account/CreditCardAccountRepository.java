package com.discover.bank.api.creditcards.account;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.discover.amservice.ao.AcctMgrInfo;
import com.discover.amservice.ao.AcctMgrInfoVO;
import com.discover.amservice.ao.AcctMgrRewardsInfoVO;
import com.discover.amservice.bd.AMServiceDelegate;
import com.discover.amservice.exception.AccountManagerServiceException;
import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.creditcards.CreditCardsException;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.common.stereotype.Repository;
import com.discoverfinancial.ecc.customersearch.bd.ICustomerSearchBD;
import com.discoverfinancial.ecc.customersearch.common.vo.AccountSummaryVO;
import com.discoverfinancial.ecc.customersearch.common.vo.CardmemberSearchInputVO;
import com.discoverfinancial.ecc.customersearch.common.vo.CardmemberSearchOutputVO;
import com.discoverfinancial.ecc.customersearch.common.vo.UserIdentificationVO;
import com.discoverfinancial.ecc.customersearch.exceptions.CustomerSearchException;

/**
 * Used to lookup CreditCardAccounts. Can perform a lookup based on the social security number of a
 * customer, or directly by a credit card number.
 */
@Repository
public class CreditCardAccountRepository {


    private static final Logger LOG = LoggerFactory.getLogger(CreditCardAccountRepository.class);

    private static final String CC_ANF_ERROR = "CC.ACCT.NOT.FOUND";
    private static final String BASIC_ERROR =
                    "CardmemberSearchServiceException thrown while looking up the customer's credit card accounts";

    private final ICustomerSearchBD searchDelegate;
    private final AMServiceDelegate accountDelegate;

    @Inject
    private PropertyAccessor props;

    @Inject
    public CreditCardAccountRepository(ICustomerSearchBD searchDelegate,
                    AMServiceDelegate accountDelegate) {
        this.searchDelegate = searchDelegate;
        this.accountDelegate = accountDelegate;
    }

    /**
     * Returns a List&lt;CreditCardAccounts&gt; related to the user with the given social security
     * number
     * 
     * @param ssn The social security number of the user for which to look up accounts
     * @return List&lt;CreditCardAccount&gt; - List of accounts related to this user.
     * @throws CreditCardsException
     */
    public List<CreditCardAccount> lookupCreditCardAccounts(String ssn)
                    throws CreditCardsException {
        CardmemberSearchInputVO input = buildSearchInput(ssn);
        CardmemberSearchOutputVO output = null;

        try {
            output = searchDelegate.searchCardmemberAccounts(input);
        } catch (CustomerSearchException e) {
            LOG.error(BASIC_ERROR, e);
            // throw new CreditCardsException(); // Just to log the situation, treat the customer
            // has no card accounts
        }

        if (output == null) {
            LOG.info("Output is null from the searchCardMemberAccounts() call.");
            return new ArrayList<CreditCardAccount>();
        }

        return transform(output.getAccountSummaryList());
    }

    /**
     * Returns a CreditCardAccount for the user with the provided SSN with the given ID
     *
     * @param ssn The social security number of the user for which to look up the account
     * @param id The ID of the account to look up
     * @return CreditCardAccount for the user with that SSN and ID
     * @throws CreditCardsException Thrown if there is an error returned from the service or if the
     *         output from the service call is null
     * @throws CreditCardAccountNotFoundException Thrown if no account could be found for the given
     *         ID
     */
    public CreditCardAccount lookupCreditCardAccountById(String ssn, String id)
                    throws CreditCardsException {
        List<CreditCardAccount> creditCards = this.lookupCreditCardAccounts(ssn);

        CreditCardAccount found = null;
        if (creditCards != null && !creditCards.isEmpty()) {
            for (CreditCardAccount creditCard : creditCards) {
                if (id.equalsIgnoreCase(creditCard.getId())) {
                    found = creditCard;
                    break;
                }
            }
        }

        if (found == null) {
            throw new CreditCardsException();
        }

        return found;
    }

    /**
     * Returns a CreditCardAccount with the given account number
     *
     * @param accountNumber The account number of the account to look up
     * @return CreditCardAccount with the given account number
     * @throws CreditCardsException Thrown if there is an error returned from the service or if the
     *         output from the service call is null
     * @throws CreditCardAccountNotFoundException Thrown if no account could be found for the given
     *         account number
     */
    public CreditCardAccount lookupCreditCardAccountByAccountNumber(String accountNumber)
                    throws CreditCardsException {
        AcctMgrInfo output = null;
        LOG.info("Checking the status, incentive type code and card type of the provided credit card number");

        try {
            output = accountDelegate.getAccountInfoFromBackend(accountNumber, null, false, false,
                            false);
        } catch (AccountManagerServiceException e) {
            LOG.error(BASIC_ERROR, e);
            String errorText = props.get(CC_ANF_ERROR, "ACTVFLE  REC NOT FND");


            if (e.getMessage().contains(errorText)) {
                throw new CreditCardsException("CreditCards.NotFoundException");
            } else {
                throw new CreditCardsException();
            }
        }

        if (output == null || output.getAccountInfoVO() == null
                        || output.getRewardsInfoVO() == null) {
            LOG.info("Output is null from the getAccountInfoFromBackend() call.");
            throw new CreditCardsException();
        }

        return transform(output);
    }

    /**
     * Builds the CardmemberSearchInputVO needed for looking up the list of accounts for a user
     *
     * @param ssn SSN of the user to look up
     * @return CardmemberSearchInputVO used for the lookup call
     */
    private CardmemberSearchInputVO buildSearchInput(String ssn) {

        UserIdentificationVO userVO = new UserIdentificationVO();
        userVO.setApplicationDataSourceCode("ib");
        userVO.setRacf("RW");

        CardmemberSearchInputVO result = new CardmemberSearchInputVO();
        result.setSsn(ssn);
        result.setUserVO(userVO);

        return result;
    }

    /**
     * Transforms the List&gt;AccountSummaryVO&lt; returned from the account search call into a
     * List&gt;CreditCardAccount&lt;
     *
     * @param list The list to transform
     * @return List&lt;CreditCardAccount&gt; - Transformed list
     */
    private List<CreditCardAccount> transform(List<AccountSummaryVO> list) {
        List<CreditCardAccount> result = new ArrayList<CreditCardAccount>();
        int index = 0;

        if (list != null && !list.isEmpty()) {
            for (AccountSummaryVO from : list) {
                LOG.info("Incentive code: {}, Incentive Type code: {}, ExternalStatus: {}, Card Type: {}, Product Name: {}",
                                new Object[] {from.getIncntvCode(), from.getIncntvTypeCode(),
                                                from.getExternalStatus(), from.getCardType(),
                                                from.getProductName()});

                result.add(CreditCardAccount.newBuilder().withId(String.valueOf(index))
                                .withAccountNumber(AccountNumber.parse(from.getAccountNumber()))
                                .withNickName(from.getProductName())
                                .withExternalStatus(from.getExternalStatus())
                                .withInternalStatus(from.getInternalStatus())
                                .withProductType(from.getIncntvTypeCode())
                                .withCardType(from.getCardType())
                                .withPrimarySocialSecurityNumber(from.getPrimarySSN())
                                .withSecondarySocialSecurityNumber(from.getSecondarySSN())
                                .withIncentiveCode(from.getIncntvCode())
                                .withIncentiveType(from.getIncntvTypeCode())
                                .withOptionCode(from.getOptionCode())
                                // These are not coming back from the service even though we kinda
                                // want them.
                                // .withCardLineGroup(from.get)
                                // .withTermsLevel(from.get)
                                .build());
                index++;
            }

        } else {
            LOG.info("List<AccountSummaryVO> is empty");
        }
        return result;
    }

    /**
     * Transforms the AccountInfo returned from the cardnumber lookup call to a CreditCardAccount
     * 
     * @param from AccountInfo to transform
     * @return CreditCardAccount with the transformed data
     */
    private CreditCardAccount transform(AcctMgrInfo from) {
        LOG.info("Incentive code: {}, Incentive Type code: {}, ExternalStatus: {}, Card Type: {}",
                        new Object[] {from.getRewardsInfoVO().getIncntvCde(),
                                        from.getRewardsInfoVO().getIncntvTypCde(),
                                        from.getAccountInfoVO().getExternalStatusCode(),
                                        from.getAccountInfoVO().getCardType()});

        StringBuilder nickname = new StringBuilder("Discover Credit Card");

        AcctMgrInfoVO acctInfo = from.getAccountInfoVO();
        AcctMgrRewardsInfoVO rewardInfo = from.getRewardsInfoVO();
        AccountNumber acctNbr = AccountNumber.parse(acctInfo.getAccountNumber());

        return CreditCardAccount.newBuilder().withAccountNumber(acctNbr)
                        .withNickName(nickname.toString())
                        .withExternalStatus(acctInfo.getExternalStatusCode())
                        .withInternalStatus(acctInfo.getInternalStatusCode())
                        .withProductType(rewardInfo.getIncntvTypCde())
                        .withCardType(acctInfo.getCardType())
                        .withIncentiveCode(rewardInfo.getIncntvCde())
                        .withIncentiveType(rewardInfo.getIncntvTypCde())
                        .withCardLineGroup(acctInfo.getCardLineGroupCode())
                        .withOptionCode(acctInfo.getOptionCode())
                        .withTermsLevel(acctInfo.getTermsLevel()).build();
    }
}
