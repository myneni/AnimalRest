package com.discover.bank.api.creditcards.account;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public abstract class AccountNumberMixin {

    @Override
    @JsonProperty("formatted")
    public abstract String toString();

    @JsonProperty
    public abstract String getEnding();

    @JsonCreator
    public static AccountNumber parse(@JsonProperty("unmasked") String value) {
        return AccountNumber.parse(value);
    }
}
