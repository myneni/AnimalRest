package com.discover.bank.api.creditcards.account;

import java.util.Arrays;
import java.util.List;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.creditcards.account.validation.RedeemableCreditCardAccount;
import com.discover.bank.api.hateoas.Identifiable;

@RedeemableCreditCardAccount(groups = CreditCardAccount.ValidForTransfer.class)
public class CreditCardAccount implements Identifiable<String> {

    public interface ValidForTransfer {
        // No-OP
    }

    private final String id;

    private final AccountNumber accountNumber;

    private final String nickName;

    private final String externalStatus;

    private final String internalStatus;

    private final String productType;

    private final String cardType;

    private final String primarySSN;

    private final String secondarySSN;

    private final String incentiveType;

    private final String incentiveCode;

    private final String cardLineGroup;

    private final String optionCode;

    private final String termsLevel;

    private CreditCardAccount(Params p) {
        this.id = p.id;
        this.accountNumber = p.accountNumber;
        this.nickName = p.nickName;
        this.externalStatus = p.externalStatus;
        this.internalStatus = p.internalStatus;
        this.productType = p.productType;
        this.cardType = p.cardType;
        this.primarySSN = p.primarySSN;
        this.secondarySSN = p.secondarySSN;
        this.incentiveType = p.incentiveType;
        this.incentiveCode = p.incentiveCode;
        this.cardLineGroup = p.cardLineGroup;
        this.optionCode = p.optionCode;
        this.termsLevel = p.termsLevel;
    }

    @Override
    public String getId() {
        return id;
    }

    public AccountNumber getAccountNumber() {
        return this.accountNumber;
    }

    public String getNickName() {
        return this.nickName;
    }

    public String getExternalStatus() {
        return this.externalStatus;
    }

    public String getInternalStatus() {
        return this.internalStatus;
    }

    public String getProductType() {
        return this.productType;
    }

    public String getCardType() {
        return this.cardType;
    }

    public String getPrimarySocialSecurityNumber() {
        return this.primarySSN;
    }

    public String getSecondarySocialSecurityNumber() {
        return this.secondarySSN;
    }

    public String getIncentiveType() {
        return incentiveType;
    }

    public String getIncentiveCode() {
        return incentiveCode;
    }

    public String getCardLineGroup() {
        return cardLineGroup;
    }

    public String getOptionCode() {
        return optionCode;
    }

    public String getTermsLevel() {
        return termsLevel;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder {

        private static final List<String> NORMAL_STATUS = Arrays.asList(new String[] {"", " "});

        private final Params p;

        private Builder() {
            this.p = new Params();
        }

        public Builder withId(String id) {
            this.p.id = id;
            return this;
        }

        public Builder withAccountNumber(AccountNumber accountNumber) {
            this.p.accountNumber = accountNumber;
            return this;
        }

        public Builder withNickName(String nickName) {
            this.p.nickName = nickName;
            return this;
        }

        public Builder withExternalStatus(String externalStatus) {
            if (NORMAL_STATUS.contains(externalStatus)) {
                this.p.externalStatus = "R";
            } else {
                this.p.externalStatus = externalStatus;
            }

            return this;
        }

        public Builder withInternalStatus(String internalStatus) {
            if (NORMAL_STATUS.contains(internalStatus)) {
                this.p.internalStatus = "N";
            } else {
                this.p.internalStatus = internalStatus;
            }

            return this;
        }

        public Builder withProductType(String productType) {
            this.p.productType = productType;
            return this;
        }

        public Builder withCardType(String cardType) {
            this.p.cardType = cardType;
            return this;
        }

        public Builder withIncentiveType(String incentiveType) {
            this.p.incentiveType = incentiveType;
            return this;
        }

        public Builder withIncentiveCode(String incentiveCode) {
            this.p.incentiveCode = incentiveCode;
            return this;
        }

        public Builder withCardLineGroup(String cardLineGroup) {
            this.p.cardLineGroup = cardLineGroup;
            return this;
        }

        public Builder withOptionCode(String optionCode) {
            this.p.optionCode = optionCode;
            return this;
        }

        public Builder withTermsLevel(String termsLevel) {
            this.p.termsLevel = termsLevel;
            return this;
        }

        public Builder withPrimarySocialSecurityNumber(String primarySSN) {
            this.p.primarySSN = primarySSN;
            return this;
        }

        public Builder withSecondarySocialSecurityNumber(String secondarySSN) {
            this.p.secondarySSN = secondarySSN;
            return this;
        }

        public CreditCardAccount build() {
            return new CreditCardAccount(p);
        }
    }

    private static final class Params {
        private String id;
        private AccountNumber accountNumber;
        private String nickName;
        private String externalStatus;
        private String internalStatus;
        private String productType;
        private String cardType;
        private String primarySSN;
        private String secondarySSN;
        private String incentiveType;
        private String incentiveCode;
        private String cardLineGroup;
        private String optionCode;
        private String termsLevel;
    }
}
