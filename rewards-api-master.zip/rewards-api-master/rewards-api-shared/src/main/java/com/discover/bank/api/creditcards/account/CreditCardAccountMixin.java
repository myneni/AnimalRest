package com.discover.bank.api.creditcards.account;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.creditcards.account.CreditCardAccount.Builder;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = CreditCardAccount.Builder.class)
public abstract class CreditCardAccountMixin {

    @JsonProperty
    public abstract String getId();

    @JsonProperty
    public abstract String getNickName();

    @JsonProperty
    public abstract AccountNumber getAccountNumber();

    public abstract static class BuilderMixin {

        @JsonProperty
        public abstract Builder withId(String id);

        @JsonProperty
        public abstract Builder withAccountNumber(AccountNumber accountNumber);
    }

}
