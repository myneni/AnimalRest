package com.discover.bank.api.creditcards;



public class CreditCardsException extends Exception {

    private static final long serialVersionUID = 1L;

    public CreditCardsException() {
        this("CreditCards.TechnicalDifficulties");
    }

    public CreditCardsException(String message) {
        super(message);
    }
}
