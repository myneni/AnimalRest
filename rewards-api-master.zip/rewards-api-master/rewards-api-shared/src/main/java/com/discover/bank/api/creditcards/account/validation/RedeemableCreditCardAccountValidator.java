package com.discover.bank.api.creditcards.account.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceAware;

import com.discover.bank.api.creditcards.account.CreditCardAccount;



public class RedeemableCreditCardAccountValidator
                implements ConstraintValidator<RedeemableCreditCardAccount, CreditCardAccount>,
                MessageSourceAware {

    private MessageSource messageSource;

    private static final Logger LOG =
                    LoggerFactory.getLogger(RedeemableCreditCardAccountValidator.class);

    private static final String DOT = ".";

    @Override
    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    @Override
    public void initialize(RedeemableCreditCardAccount arg0) {
        // No init needed.

    }

    /**
     * Helper method that will check if a CreditCardAccount is eligible to receive a rewards
     * transfer.
     *
     * @param account The CreditCardAccount for which to check the eligibility.
     * @return True if the account is eligible for rewards transfers, false otherwise.
     */
    @Override
    public boolean isValid(CreditCardAccount target, ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();
        boolean result = false;

        if (target != null) {
            StringBuilder cardString =
                            new StringBuilder("CCVALIDREWARDS.").append(target.getCardType())
                                            .append(DOT).append(target.getProductType()).append(DOT)
                                            .append(target.getExternalStatus()).append(DOT)
                                            .append(target.getInternalStatus());

            String ccValidProp = cardString.toString().toUpperCase();

            result = Boolean.valueOf(
                            messageSource.getMessage(ccValidProp, new Object[] {}, "false", null));
            LOG.info("Checking to see if CC is valid for redeemtion. CCValidRewards.CardType.ProductType.ExtStat.IntStat = {}, Result = {}",
                            new Object[] {ccValidProp, result});

            if (!result) {
                context.buildConstraintViolationWithTemplate(
                                "{RewardRedemption.ToCreditCardAccount.AccountIneligible}")
                                .addConstraintViolation();
            }
        }

        return result;
    }

}
