package com.discover.bank.api.rewards.account;

import com.discover.bank.api.core.accounts.BankAccount;

public interface RewardsAccountEnricher<T extends BankAccount> {

    T enrich(T account);

}
