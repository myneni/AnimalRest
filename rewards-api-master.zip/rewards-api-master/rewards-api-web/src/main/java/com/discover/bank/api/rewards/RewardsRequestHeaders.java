package com.discover.bank.api.rewards;

import java.util.Arrays;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.discover.bank.api.core.customers.CustomerIdentification;

public class RewardsRequestHeaders {
    private static final String CONSUMER_INFO_HEADER = "X-DFS-C-APP-INFO";
    private static final String CHANNEL_NAME = "MP";
    private static final String CHANNEL_AND_APP_NAME = "MOBILE";
    private static final String CHANNEL_ID = "WEB";

    private RewardsRequestHeaders() {
        throw new IllegalStateException();
    }

    public static HttpHeaders buildRequestHeaders(CustomerIdentification customer) {
        // populate header info
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(HttpHeaders.ACCEPT_LANGUAGE, "en-US");
        headers.set(CONSUMER_INFO_HEADER, getConsumerInfo(customer));
        return headers;
    }

    /**
     * return consumerInfo string with below info {App Name}|{Channel Id}|{Channel Name}|{Request
     * UUID}|{User Id}|{Login Security Token}|{Login Session Id}
     * 
     * @return consumer info in String
     */
    protected static String getConsumerInfo(CustomerIdentification customer) {
        StringBuilder sb = new StringBuilder();
        sb.append(CHANNEL_AND_APP_NAME).append("|");
        sb.append(CHANNEL_ID).append("|");
        sb.append(CHANNEL_NAME).append("|");
        sb.append(customer.getRequestIdentifier() != null
                        ? customer.getRequestIdentifier().getRequestId() : "")
          .append("|");
        sb.append(CHANNEL_AND_APP_NAME).append("|");
        sb.append("").append("|");
        sb.append("").append("|");

        return sb.toString();
    }
}
