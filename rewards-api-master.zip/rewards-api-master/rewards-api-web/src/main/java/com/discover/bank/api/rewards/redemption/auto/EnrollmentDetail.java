package com.discover.bank.api.rewards.redemption.auto;

public class EnrollmentDetail {

    private String customerId;
    private String sourceAccountNumber;
    private String targetAccountNumber;
    private String enrollmentStatus;


    public EnrollmentDetail() {}

    public EnrollmentDetail(String customerId, String sourceAccountNumber,
                    String targetAccountNumber, String enrollmentStatus) {
        this.customerId = customerId;
        this.sourceAccountNumber = sourceAccountNumber;
        this.targetAccountNumber = targetAccountNumber;
        this.enrollmentStatus = enrollmentStatus;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getSourceAccountNumber() {
        return sourceAccountNumber;
    }

    public String getTargetAccountNumber() {
        return targetAccountNumber;
    }

    public String getEnrollmentStatus() {
        return enrollmentStatus;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public void setSourceAccountNumber(String sourceAccountNumber) {
        this.sourceAccountNumber = sourceAccountNumber;
    }

    public void setTargetAccountNumber(String targetAccountNumber) {
        this.targetAccountNumber = targetAccountNumber;
    }

    public void setEnrollmentStatus(String enrollmentStatus) {
        this.enrollmentStatus = enrollmentStatus;
    }

}
