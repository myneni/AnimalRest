package com.discover.bank.api.rewards.config;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.MessageSourceAccessor;

import com.dfs.marketing.rewardearn.bd.RewardEarnSvcBDFactory;
import com.dfs.marketing.rewardearn.bd.RewardEarnSvcBDInterface;
import com.dfs.marketing.rewardredemptionsvc.bd.RewardRedemptionServiceBDFactory;
import com.dfs.marketing.rewardredemptionsvc.bd.RewardRedemptionServiceCommonDelegate;
import com.discover.amservice.bd.AMServiceBDFactory;
import com.discover.amservice.bd.AMServiceDelegate;
import com.discover.bank.api.bank.account.BankAccountMixin;
import com.discover.bank.api.config.ObjectMapperConfigurer;
import com.discover.bank.api.config.RuleSetSources;
import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.config.EnableBankingSupport;
import com.discover.bank.api.creditcards.account.AccountNumberMixin;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.creditcards.account.CreditCardAccountMixin;
import com.discover.bank.api.hateoas.LinkResourceAssembler;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.bank.api.rewards.account.RewardsAccountMixin;
import com.discover.bank.api.rewards.account.RewardsEligibileAccountMixin;
import com.discover.bank.api.rewards.account.RewardsEligibleAccount;
import com.discover.bank.api.rewards.earnings.Earnings;
import com.discover.bank.api.rewards.earnings.EarningsMixin;
import com.discover.bank.api.rewards.redemption.Redemption;
import com.discover.bank.api.rewards.redemption.RedemptionMixin;
import com.discover.bank.api.rewards.redemption.auto.AutoRedemptionAccount;
import com.discover.bank.api.rewards.redemption.auto.AutoRedemptionAccountMixin;
import com.discover.bank.api.rewards.redemption.auto.AutoRedemptionResponse;
import com.discover.bank.api.rewards.redemption.auto.EditAutoRedemptionResponse;
import com.discover.bank.api.rewards.redemption.auto.EnrollEditAutoRedemption;
import com.discover.common.decisioning.RuleSet;
import com.discover.common.stereotype.Component;
import com.discover.emsg.core.bd.EMessageDelegateFactory;
import com.discover.emsg.core.bd.EMessageWSDelegate;
import com.discoverfinancial.ecc.customersearch.bd.CustomerSearchFactory;
import com.discoverfinancial.ecc.customersearch.bd.ICustomerSearchBD;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@EnableBankingSupport
@ComponentScan({"com.discover.bank.api.rewards", "com.discover.bank.api.creditcards"})
@RuleSetSources({"redemption-limit-rules", "auto-redemption-links", "auto-redemption-enroll-links",
                "auto-redemption-account-links"})
public class RewardsHypermediaConfiguration implements ObjectMapperConfigurer {

    @Bean
    public RewardRedemptionServiceCommonDelegate rewardsService() {
        return (RewardRedemptionServiceCommonDelegate) RewardRedemptionServiceBDFactory
                        .getInstance().getBDInterface();
    }

    @Bean
    public RewardEarnSvcBDInterface rewardsEarnService() {
        return (RewardEarnSvcBDInterface) RewardEarnSvcBDFactory.getInstance().getBDInterface();
    }

    @Bean
    public AMServiceDelegate accountInfoService() {
        return (AMServiceDelegate) AMServiceBDFactory.getInstance().getBDInterface();
    }

    @Bean
    public EMessageWSDelegate eMessage() {
        return (EMessageWSDelegate) EMessageDelegateFactory.getInstance().getBDInterface();
    }

    @Component
    public static class RedemptionResourceAssembler
                    extends LinkResourceAssembler<AutoRedemptionResponse> {
        @Inject
        public RedemptionResourceAssembler(@Named("auto-redemption-links") RuleSet rules) {
            super(rules);
        }
    }

    @Component
    public static class EditRedemptionResourceAssembler
                    extends LinkResourceAssembler<EditAutoRedemptionResponse> {
        @Inject
        public EditRedemptionResourceAssembler(
                        @Named("auto-redemption-enroll-links") RuleSet rules) {
            super(rules);
        }
    }

    @Component
    public static class EnrollRedemptionResourceAssembler
                    extends LinkResourceAssembler<EnrollEditAutoRedemption> {
        @Inject
        public EnrollRedemptionResourceAssembler(
                        @Named("auto-redemption-enroll-links") RuleSet rules) {
            super(rules);
        }
    }

    @Component
    public static class RedemptionAccountResourceAssembler
                    extends LinkResourceAssembler<AutoRedemptionAccount> {

        @Inject
        public RedemptionAccountResourceAssembler(

                        @Named("auto-redemption-account-links") RuleSet rules) {
            super(rules);
        }
    }

    @Override
    @Inject
    public void configureObjectMapper(ObjectMapper objectMapper) {
        objectMapper.addMixIn(AccountNumber.class, AccountNumberMixin.class);
        objectMapper.addMixIn(CreditCardAccount.class, CreditCardAccountMixin.class);
        objectMapper.addMixIn(CreditCardAccount.Builder.class,
                        CreditCardAccountMixin.BuilderMixin.class);

        objectMapper.addMixIn(BankAccount.class, BankAccountMixin.class);
        objectMapper.addMixIn(BankAccountMixin.InputBuilder.class,
                        BankAccountMixin.InputBuilderMixin.class);

        objectMapper.addMixIn(RewardsAccount.class, RewardsAccountMixin.class);
        objectMapper.addMixIn(RewardsAccount.InputBuilder.class,
                        RewardsAccountMixin.InputBuilderMixin.class);

        objectMapper.addMixIn(RewardsEligibleAccount.class, RewardsEligibileAccountMixin.class);
        objectMapper.addMixIn(RewardsEligibleAccount.InputBuilder.class,
                        RewardsEligibileAccountMixin.InputBuilderMixin.class);

        objectMapper.addMixIn(Redemption.class, RedemptionMixin.class);
        objectMapper.addMixIn(Redemption.Builder.class,
                        RedemptionMixin.BuilderMixin.class);

        objectMapper.addMixIn(Earnings.class, EarningsMixin.class);
        objectMapper.addMixIn(Earnings.Type.class, EarningsMixin.TypeMixin.class);

        objectMapper.addMixIn(AutoRedemptionAccount.class,
                        AutoRedemptionAccountMixin.class);
    }

    @Bean
    @Inject
    public MessageSourceAccessor messageSourceAccessor(MessageSource messageSource) {
        return new MessageSourceAccessor(messageSource);
    }

    @Bean
    public ICustomerSearchBD cardmemberSearchService() {
        return (ICustomerSearchBD) CustomerSearchFactory.getInstance().getBDInterface();
    }
}
