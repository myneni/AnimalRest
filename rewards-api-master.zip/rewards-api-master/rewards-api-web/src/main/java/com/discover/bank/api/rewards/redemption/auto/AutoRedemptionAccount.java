package com.discover.bank.api.rewards.redemption.auto;

import java.math.BigInteger;
import java.util.Date;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.databind.Money;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.google.common.base.MoreObjects;

@JsonDeserialize(builder = AutoRedemptionAccount.Builder.class)
public class AutoRedemptionAccount extends BankAccount {

    private Boolean isEnrolled;

    private BankAccount toAccount;

    private BigInteger rewardsBalance;

    private Boolean hasRedeemed;

    private Date lastRedemptionDate;

    private BigInteger lastRedemptionAmount;

    private Boolean error;

    private String errorDescription;

    public AutoRedemptionAccount(BankAccount account, Boolean isEnrolled, BankAccount toAccount,
                    BigInteger rewardsBalance, Boolean hasRedeemed, Date lastRedemptionDate,
                    BigInteger lastRedemptionAmount) {
        super(account);
        this.isEnrolled = isEnrolled;
        this.toAccount = toAccount;
        this.rewardsBalance = rewardsBalance;
        this.hasRedeemed = hasRedeemed;
        this.lastRedemptionDate = lastRedemptionDate;
        this.lastRedemptionAmount = lastRedemptionAmount;
    }

    public void setError(Boolean error) {
        this.error = error;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    @JsonProperty
    public Boolean getIsEnrolled() {
        return isEnrolled;
    }

    @JsonProperty
    public BankAccount getToAccount() {
        return toAccount;
    }

    @JsonProperty
    @Money
    public BigInteger getRewardsBalance() {
        return rewardsBalance;
    }

    @JsonProperty
    public Boolean getHasRedeemed() {
        return hasRedeemed;
    }

    @JsonProperty
    public Date getLastRedemptionDate() {
        return lastRedemptionDate;
    }

    @JsonProperty
    @Money
    public BigInteger getLastRedemptionAmount() {
        return lastRedemptionAmount;
    }

    @JsonProperty
    public Boolean getError() {
        return error;
    }

    @JsonProperty
    public String getErrorDescription() {
        return errorDescription;
    }

    public static Builder getBuilder() {
        return new Builder();
    }

    public static Builder newBuilder(AutoRedemptionAccount autoRedemptionAccount) {
        return new Builder(autoRedemptionAccount);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                          .omitNullValues()
                          .add("rewardsBalance", rewardsBalance)
                          .add("isEnrolled", isEnrolled)
                          .add("toAccount", toAccount)
                          .add("hasRedeemed", hasRedeemed)
                          .add("lastRedemptionDate", lastRedemptionDate)
                          .add("lastRedemptionAmount", lastRedemptionAmount)
                          .add("error", error)
                          .add("errorDescription", errorDescription)
                          .toString();
    }

    public static class Builder {

        private final AutoRedemptionAccountParams p;

        public Builder() {
            this.p = new AutoRedemptionAccountParams();
        }

        public Builder(AutoRedemptionAccount P) {

            this.p = new AutoRedemptionAccountParams();

            this.p.id = P.getId();
            this.p.accountNumber = P.getAccountNumber();
            this.p.nickName = P.getNickName();
            this.p.isEnrolled = P.getIsEnrolled();
            this.p.toAccount = P.getToAccount();
            this.p.rewardsBalance = P.getRewardsBalance();
            this.p.hasRedeemed = P.getHasRedeemed();
            this.p.lastRedemptionDate = P.getLastRedemptionDate();
            this.p.lastRedemptionAmount = P.getLastRedemptionAmount();
            this.p.error = P.getError();
            this.p.errorDescription = P.getErrorDescription();
        }

        public Builder withBankAccount(BankAccount bankAccount) {
            p.id = bankAccount.getAlternateAccountNumber();
            p.accountNumber = bankAccount.getAccountNumber();
            p.nickName = bankAccount.getNickName();
            return this;
        }

        @JsonProperty
        public Builder withId(String id) {
            p.id = id;
            return this;
        }

        @JsonProperty
        public Builder withAccountNumber(AccountNumber accountNumber) {
            p.accountNumber = accountNumber;
            return this;
        }

        public Builder withNickName(String nickName) {
            p.nickName = nickName;
            return this;
        }

        @JsonProperty
        public Builder withIsEnrolled(Boolean isEnrolled) {
            this.p.isEnrolled = isEnrolled;
            return this;
        }

        public Builder withToAccount(BankAccount toAccount) {
            this.p.toAccount = toAccount;
            return this;
        }

        public Builder withHasRedeemed(Boolean hasRedeemed) {
            this.p.hasRedeemed = hasRedeemed;
            return this;
        }

        public Builder withLastRedemptionDate(Date lastRedemptionDate) {
            this.p.lastRedemptionDate = lastRedemptionDate;
            return this;
        }

        public Builder withLastRedemptionAmount(BigInteger lastRedemptionAmount) {
            this.p.lastRedemptionAmount = lastRedemptionAmount;
            return this;
        }

        public Builder withRewardsBalance(BigInteger rewardsBalance) {
            this.p.rewardsBalance = rewardsBalance;
            return this;
        }

        public Builder withError(Boolean error) {
            this.p.error = error;
            return this;
        }

        public Builder withErrorDescription(String errorDescription) {
            this.p.errorDescription = errorDescription;
            return this;
        }

        public AutoRedemptionAccount build() {
            AutoRedemptionAccount autoRedemptionAccount =
                            new AutoRedemptionAccount(BankAccount.newBuilder()
                                                                 .setId(p.id)
                                                                 .setAccountNumber(p.accountNumber)
                                                                 .setNickName(p.nickName)
                                                                 .build(),
                                            p.isEnrolled, p.toAccount, p.rewardsBalance,
                                            p.hasRedeemed, p.lastRedemptionDate,
                                            p.lastRedemptionAmount);

            autoRedemptionAccount.setError(p.error);
            autoRedemptionAccount.setErrorDescription(p.errorDescription);

            return autoRedemptionAccount;
        }
    }

    private static final class AutoRedemptionAccountParams {
        private String id;
        private AccountNumber accountNumber;
        private String nickName;
        private Boolean isEnrolled = null;
        private BankAccount toAccount;
        private BigInteger rewardsBalance;
        private Boolean hasRedeemed = null;
        private Date lastRedemptionDate;
        private BigInteger lastRedemptionAmount;
        private Boolean error = null;
        private String errorDescription;
    }
}
