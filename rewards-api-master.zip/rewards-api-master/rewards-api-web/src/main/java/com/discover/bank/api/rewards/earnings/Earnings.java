package com.discover.bank.api.rewards.earnings;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.discover.common.base.Dates;
import com.discover.common.base.Dates.Format;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/**
 * Holds data related to the rewards earned during a specified time period
 */
@JsonDeserialize(builder = Earnings.Builder.class)
public class Earnings {

    private final String intervalStart;
    private final String intervalEnd;
    private final BigInteger amount;
    private final List<Type> types;

    private Earnings(EarningsParams p) {
        this.intervalStart = p.intervalStart;
        this.intervalEnd = p.intervalEnd;
        this.amount = p.amount;
        this.types = p.types;
    }


    public String getIntervalStart() {
        return intervalStart;
    }

    public String getIntervalEnd() {
        return intervalEnd;
    }

    public BigInteger getAmount() {
        return amount;
    }

    public List<Type> getTypes() {
        return types;
    }

    /**
     * Inner class for the different types of earnings that could be passed back. Uses the enum to
     * standardize the names of the Types.
     *
     */
    public static final class Type {
        private final String name;
        private final BigInteger amount;

        protected Type(String name, BigInteger total) {
            this.name = name;
            this.amount = total;
        }

        public String getName() {
            return name;
        }

        public BigInteger getAmount() {
            return amount;
        }

        public Type add(BigInteger amt) {
            return new Type(this.name, this.amount.add(amt));
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((name == null) ? 0 : name.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || !(obj instanceof Type)) {
                return false;
            }
            Type other = (Type) obj;
            if (name == null) {
                if (other.name != null) {
                    return false;
                }
            } else if (!name.equals(other.name)) {
                return false;
            }
            return true;
        }


    }



    public static class Builder {
        private final EarningsParams p;

        public Builder() {
            this.p = new EarningsParams();
        }

        public Builder(Earnings earnings) {
            this.p = new EarningsParams();
            this.p.intervalStart = earnings.getIntervalStart();
            this.p.intervalEnd = earnings.getIntervalEnd();
            this.p.amount = earnings.getAmount();
            this.p.types = earnings.getTypes();
        }

        public Builder from(String intervalStart) {
            this.p.intervalStart = intervalStart;
            return this;
        }

        public Builder from(Date intervalStart) {
            if (intervalStart != null) {
                this.p.intervalStart = Dates.print(intervalStart, Format.BIG_ENDIAN_HYPHEN);
            }
            return this;
        }

        public Builder to(String intervalEnd) {
            this.p.intervalEnd = intervalEnd;
            return this;
        }

        public Builder to(Date intervalEnd) {
            if (intervalEnd != null) {
                this.p.intervalEnd = Dates.print(intervalEnd, Format.BIG_ENDIAN_HYPHEN);
            }
            return this;
        }

        public Builder add(String type, BigInteger total) {
            Type tn = new Type(type, total);
            return add(tn);
        }

        private Builder add(Type type) {

            int index = this.p.types.indexOf(type);
            if (index >= 0) {
                Type tp = this.p.types.remove(index);
                this.p.types.add(tp.add(type.getAmount()));
            } else {
                this.p.types.add(type);
            }

            this.p.amount = this.p.amount.add(type.getAmount());

            return this;
        }

        public Earnings build() {
            return new Earnings(this.p);
        }
    }

    private static class EarningsParams {
        private String intervalStart = null;
        private String intervalEnd = null;
        private BigInteger amount = BigInteger.ZERO;
        private List<Type> types = new ArrayList<Type>();
    }


}
