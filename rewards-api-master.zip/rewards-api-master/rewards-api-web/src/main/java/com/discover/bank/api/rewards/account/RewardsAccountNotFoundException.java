package com.discover.bank.api.rewards.account;

public class RewardsAccountNotFoundException extends Exception {

    private static final long serialVersionUID = 1L;

    public RewardsAccountNotFoundException() {
        super("Rewards.AccountNotFound");
    }

}
