package com.discover.bank.api.rewards.redemption.auto;

import com.discover.bank.api.hateoas.Resource;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AutoRedemptionAccountResource {

    private Iterable<Resource<AutoRedemptionAccount>> autoRedemptionAccounts;

    @JsonProperty("accounts")
    public Iterable<Resource<AutoRedemptionAccount>> getAutoRedemptionAccount() {
        return autoRedemptionAccounts;
    }

    public void setAutoRedemptionAccount(
                    Iterable<Resource<AutoRedemptionAccount>> autoRedemptionAccounts) {
        this.autoRedemptionAccounts = autoRedemptionAccounts;
    }
}
