package com.discover.bank.api.rewards.redemption;

import java.math.BigInteger;
import java.util.Date;

import javax.validation.constraints.NotNull;

import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.bank.api.rewards.redemption.Redemption.ValidRedemption;
import com.discover.bank.api.rewards.validation.ValidBankAccount;
import com.discover.bank.api.rewards.validation.ValidCreditCardAccountInput;
import com.discover.bank.api.rewards.validation.ValidRedemptionInput;
import com.discover.bank.api.rewards.validation.ValidRewardsAccount;

@ValidRedemptionInput(groups = ValidRedemption.class)
public class Redemption {

    public interface ValidForDepositRedemption {
        // No-OP
    }
    public interface ValidForTransferRedemption {
        // No-OP
    }
    public interface ValidRedemption {
        // No-OP
    }

    @ValidRewardsAccount(
                    groups = {ValidForTransferRedemption.class, ValidForDepositRedemption.class})
    private final RewardsAccount fromRewardsAccount;

    @ValidBankAccount(groups = ValidForDepositRedemption.class)
    private final BankAccount toAccount;

    @ValidCreditCardAccountInput(groups = ValidForTransferRedemption.class)
    private final CreditCardAccount toCreditCardAccount;

    @NotNull(groups = {ValidForTransferRedemption.class, ValidForDepositRedemption.class},
                    message = "{RewardsRedemption.RedemptionType.Empty}")
    private final String redemptionType;

    private final String redemptionTypeDesc;

    @NotNull(groups = {ValidForTransferRedemption.class, ValidForDepositRedemption.class},
                    message = "{RewardRedemption.Amount.NotEmpty}")
    private final BigInteger amount;

    private final String confirmationNumber;

    private final Date orderDate;

    private final RedemptionStatus status;

    private final BigInteger remainingBalance;

    private RedemptionLimit redemptionLimit;

    private Redemption(Params p) {
        this.fromRewardsAccount = p.fromRewardsAccount;
        this.toAccount = p.toAccount;
        this.toCreditCardAccount = p.toCreditCardAccount;
        this.redemptionType = p.redemptionType;
        this.amount = p.amount;
        this.confirmationNumber = p.confirmationNumber;
        this.orderDate = p.orderDate;
        this.status = p.status;
        this.remainingBalance = p.remainingBalance;
        this.redemptionTypeDesc = p.redemptionTypeDesc;
    }

    public RewardsAccount getFromRewardsAccount() {
        return this.fromRewardsAccount;
    }

    public BankAccount getToAccount() {
        return this.toAccount;
    }

    public CreditCardAccount getToCreditCardAccount() {
        return this.toCreditCardAccount;
    }

    public String getRedemptionType() {
        return this.redemptionType;
    }

    public String getRedemptionTypeDesc() {
        return this.redemptionTypeDesc;
    }

    public BigInteger getAmount() {
        return this.amount;
    }

    public String getConfirmationNumber() {
        return this.confirmationNumber;
    }

    public Date getOrderDate() {
        return this.orderDate != null ? new Date(this.orderDate.getTime()) : null;
    }

    public RedemptionStatus getStatus() {
        return this.status;
    }

    public BigInteger getRemainingBalance() {
        return this.remainingBalance;
    }

    public Class<?> getValidationGroup() {
        return Redemptions.isTransfer(this.getRedemptionType())
                        ? Redemption.ValidForTransferRedemption.class
                        : Redemption.ValidForDepositRedemption.class;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder {

        private final Params p;

        private Builder() {
            this.p = new Params();
        }

        public Builder from(Redemption red) {
            this.p.fromRewardsAccount = red.fromRewardsAccount;
            this.p.toAccount = red.toAccount;
            this.p.toCreditCardAccount = red.toCreditCardAccount;
            this.p.redemptionType = red.redemptionType;
            this.p.amount = red.amount;
            this.p.confirmationNumber = red.confirmationNumber;
            this.p.orderDate = red.orderDate;
            this.p.status = red.status;
            this.p.redemptionTypeDesc = red.redemptionTypeDesc;


            return this;
        }

        public Builder withFromRewardsAccount(RewardsAccount fromRewardsAccount) {
            this.p.fromRewardsAccount = fromRewardsAccount;
            return this;
        }

        public Builder withToAccount(BankAccount toAccount) {
            this.p.toAccount = toAccount;
            return this;
        }

        public Builder withToCreditCardAccount(CreditCardAccount toCreditCardAccount) {
            this.p.toCreditCardAccount = toCreditCardAccount;
            return this;
        }

        public Builder withRedemptionType(String redemptionType) {
            this.p.redemptionType = redemptionType;
            return this;
        }

        public Builder withRedemptionTypeDesc(String redemptionTypeDesc) {
            this.p.redemptionTypeDesc = redemptionTypeDesc;
            return this;
        }

        public Builder withStatus(RedemptionStatus status) {
            this.p.status = status;
            return this;
        }

        public Builder withAmount(BigInteger amount) {
            this.p.amount = amount;
            return this;
        }

        public Builder withRemainingBalance(BigInteger balance) {
            this.p.remainingBalance = balance;
            return this;
        }

        public Builder withConfirmationNumber(String confirmationNumber) {
            this.p.confirmationNumber = confirmationNumber;
            return this;
        }

        public Builder on(Date date) {
            this.p.orderDate = date;
            return this;
        }

        public Redemption build() {
            return new Redemption(p);
        }
    }

    private static final class Params {
        private RewardsAccount fromRewardsAccount;
        private BankAccount toAccount;
        private CreditCardAccount toCreditCardAccount;
        private String redemptionType;
        private String redemptionTypeDesc;
        private BigInteger amount;
        private String confirmationNumber;
        private Date orderDate;
        private RedemptionStatus status;
        private BigInteger remainingBalance;

    }

    // public enum RedemptionType {
    // DEPOSIT("DEPST"), TRANSFER("XTORW");
    //
    // private String code;
    //
    // private RedemptionType ( String code ){
    // this.code = code;
    // }
    //
    // public String getCode() {
    // return code;
    // }
    //
    // public static RedemptionType fromCode( String code ) {
    // for( RedemptionType candidate : RedemptionType.values() ) {
    // if( candidate.getCode().equalsIgnoreCase( code ) ){
    // return candidate;
    // }
    // }
    //
    // return null;
    // }
    //
    // @JsonCreator
    // public static RedemptionType fromString( String s ) {
    // for( RedemptionType candidate : RedemptionType.values() ) {
    // if( candidate.name().equalsIgnoreCase( s ) ){
    // return candidate;
    // }
    // }
    //
    // return null;
    // }
    //
    // public String toString() {
    // return name().toLowerCase();
    // }
    // }

    public enum RedemptionStatus {
        // SUCCESS("APL") --> but they want it to say completed.
        PENDING("PND"), COMPLETED("CMP|APL"), FAILED("NRD"), REVERSED("REV");

        private String code;

        private RedemptionStatus(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }

        public static RedemptionStatus fromCode(String s) {
            if (s != null) {
                for (RedemptionStatus candidate : RedemptionStatus.values()) {
                    if (candidate.getCode().contains(s.toUpperCase())) {
                        return candidate;
                    }
                }
            }

            return null;
        }

        @Override
        public String toString() {
            return name().toLowerCase();
        }
    }

    public RedemptionLimit getRedemptionLimit() {
        return redemptionLimit;
    }

    public void setRedemptionLimit(RedemptionLimit redemptionLimit) {
        this.redemptionLimit = redemptionLimit;
    }
}
