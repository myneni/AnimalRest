package com.discover.bank.api.rewards.earnings;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.discover.bank.api.databind.Money;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/**
 * Holds data related to the rewards earned during a specified time period
 */
@JsonDeserialize(builder = EarningsV2.Builder.class)
public class EarningsV2 {

    private final BigInteger totalEarnings;
    private final List<Earnings> earningsPeriods;

    private EarningsV2(EarningsV2Params p) {
        this.totalEarnings = p.totalEarnings;
        this.earningsPeriods = p.earningsPeriods;
    }

    @JsonProperty
    @Money
    public BigInteger getTotalEarnings() {
        return totalEarnings;
    }

    @JsonProperty
    public List<Earnings> getEarningsPeriods() {
        return earningsPeriods;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder {
        private final EarningsV2Params p;

        public Builder() {
            this.p = new EarningsV2Params();
        }

        public Builder(EarningsV2 earningsV2) {
            this.p = new EarningsV2Params();
            this.p.totalEarnings = earningsV2.getTotalEarnings();
            this.p.earningsPeriods = earningsV2.getEarningsPeriods();
        }

        public Builder withTotalEarnings(BigInteger totalEarnings) {
            this.p.totalEarnings = totalEarnings;
            return this;
        }

        public Builder withEarningsPeriods(List<Earnings> earningsPeriods) {
            this.p.earningsPeriods = earningsPeriods;
            return this;
        }

        public EarningsV2 build() {
            return new EarningsV2(this.p);
        }
    }

    private static class EarningsV2Params {

        private BigInteger totalEarnings = BigInteger.ZERO;
        private List<Earnings> earningsPeriods = new ArrayList<Earnings>();
    }


}
