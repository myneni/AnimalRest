package com.discover.bank.api.rewards.account;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsException;
import com.discover.bank.api.rewards.RewardsRequestHeaders;
import com.discover.bank.api.stereotype.Repository;

/**
 * @author vgaddam
 *
 */
@Repository
public class EligibleAccountsRepository {


    private static final Logger LOG = LoggerFactory.getLogger(EligibleAccountsRepository.class);

    private static final String REWARDS_BUCKET_DOMAIN = "rewards.bucket.api.domain";
    private static final String REWARDS_REDEMPTION_QUERY = "rewards.redemption.query.api.path";

    private RestTemplate restTemplate;

    private PropertyAccessor props;

    @Inject
    public EligibleAccountsRepository(RestTemplate restTemplate, PropertyAccessor props) {
        this.restTemplate = restTemplate;
        this.props = props;
    }

    public Map<String, List<String>> getEligibleAccounts(CustomerIdentification customer,
                    String type) throws RewardsException {
        Map<String, List<String>> accounts=new HashMap<String, List<String>>();
        ResponseEntity<RewardsEligibilityResponse> response = null;
        RewardsEligibilityInput input = RewardsEligibilityInput.newInstance()
                                                               .withCustomerId(customer.getCustomerNumber())
                                                               .withRedemptionType(type)
                                              .build();
        LOG.info("build input customer number {} and type {} ", input.getCustomerId(), input.getRedemptionType());
        HttpEntity<RewardsEligibilityInput> requestEntity = new HttpEntity<RewardsEligibilityInput>(
                        input, RewardsRequestHeaders.buildRequestHeaders(customer));
        LOG.info("requestEntity = {}", requestEntity);

        try {
            final String url = UriComponentsBuilder
                                                   .fromHttpUrl(props.get(REWARDS_BUCKET_DOMAIN)
                                                                   + props.get(REWARDS_REDEMPTION_QUERY))
                                                   .toUriString();

            LOG.info("making restTemplate call with endPointUri as: {} ", url);

            response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
                            RewardsEligibilityResponse.class);

            LOG.info("response: {}", response);
        } catch (HttpClientErrorException ce) {
            LOG.error("Caught HttpClientErrorException with status code as: {}, body as {}",
                            ce.getStatusCode(), ce.getResponseBodyAsString(), ce);
            if ((HttpStatus.BAD_REQUEST.equals(ce.getStatusCode())
                            || HttpStatus.NOT_FOUND.equals(ce.getStatusCode()))
                            && ("E003".contains(ce.getResponseBodyAsString())
                                            || "E102".contains(ce.getResponseBodyAsString()))) {
                LOG.error("Caught HttpClientErrorException with status code as: {}, body as {}",
                                ce.getStatusCode(), ce.getResponseBodyAsString(), ce);
                throw new RewardsException();
            }


        } catch (HttpServerErrorException hse) {
            LOG.error("Caught HttpServerErrorException with status code as: {}, body as {}",
                            hse.getStatusCode(), hse.getResponseBodyAsString(), hse);
            throw new RewardsException();
        } catch (Exception e) {
            LOG.error("Exception ocurred when calling Rewards Bucket Service", e);
            throw new RewardsException();
        }

        if (response != null && response.getBody() != null
                        && response.getBody().getSourceAccountDetails() != null
				&& !response.getBody().getSourceAccountDetails().isEmpty()) {

			accounts.put("Source", transform(response.getBody().getSourceAccountDetails()));
			if (response.getBody().getTargetAccountDetailsList() != null
					&& !response.getBody().getSourceAccountDetails().isEmpty()) {
				accounts.put("Target", transform(response.getBody().getTargetAccountDetailsList()));
			}

		} else {
            LOG.error("Error ocurred while getting the response from Bank Rewards Service for {}.",
                            customer.getCustomerNumber());
            throw new RewardsException();
        }

        return accounts;
    }

	/*
	 * This method extracts the list of eligible (alternate)AccountNumbers 
	 * from the list of accounts provided by Bank Rewards Service.
	 */
	private List<String> transform(List<EligibleAccount> eligibleAccounts) {
		List<String> result = new ArrayList<String>();
		for (EligibleAccount account : eligibleAccounts) {
			if (account != null && "Y".equalsIgnoreCase(account.getEligibilityStatus())) {
				result.add(account.getAlternateAccountNumber());
			}
		}
		return result;
	}
    
    

}
