package com.discover.bank.api.rewards.account;

import com.discover.bank.api.core.accounts.AccountProductGroup;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.hateoas.Identifiable;
import com.discover.bank.api.rewards.balance.RewardsBalance;

public class RewardsAccount extends BankAccount implements Identifiable<String> {

    private RewardsBalance rewardsBalance;

    public RewardsAccount(BankAccount account) {
        super(account);
    }

    public void setRewardsBalance(RewardsBalance rewardsBalance) {
        this.rewardsBalance = rewardsBalance;
    }

    public RewardsBalance getRewardsBalance() {
        return rewardsBalance;
    }

    public String getFinancialAgreementType() {
        return getFinancialAgreementType(getProduct().getProductGroup());
    }

    static public String getFinancialAgreementType(AccountProductGroup productGroup) {
        switch (productGroup) {
            case CHECKING:
                return "BCHK";

            case SAVINGS:
                return "BSAV";

            case MONEY_MARKET:
                return "BTRN";

            default:
                return "BTIM";
        }
    }

    public static class InputBuilder {

        RewardsAccountParams p;

        private InputBuilder() {
            this.p = new RewardsAccountParams();
        }

        public InputBuilder withId(String id) {
            this.p.id = id;
            return this;
        }

        public RewardsAccount build() {
            return new RewardsAccount(BankAccount.newBuilder().setId(p.id).build());
        }
    }

    private static class RewardsAccountParams {
        private String id;
    }

}

