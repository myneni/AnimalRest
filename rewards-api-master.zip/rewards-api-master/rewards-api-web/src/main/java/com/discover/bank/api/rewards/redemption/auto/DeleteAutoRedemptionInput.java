package com.discover.bank.api.rewards.redemption.auto;

public class DeleteAutoRedemptionInput {

    private String customerId;

    private String sourceAccountNumber;

    private String alternateAccountNumber;

    private String alertIndicator;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getSourceAccountNumber() {
        return sourceAccountNumber;
    }

    public void setSourceAccountNumber(String sourceAccountNumber) {
        this.sourceAccountNumber = sourceAccountNumber;
    }

    public String getAlternateAccountNumber() {
        return alternateAccountNumber;
    }

    public void setAlternateAccountNumber(String alternateAccountNumber) {
        this.alternateAccountNumber = alternateAccountNumber;
    }

    public String getAlertIndicator() {
        return alertIndicator;
    }

    public void setAlertIndicator(String alertIndicator) {
        this.alertIndicator = alertIndicator;
    }
}
