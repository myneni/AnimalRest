package com.discover.bank.api.rewards.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.discover.bank.api.creditcards.account.CreditCardAccount;

public class ValidCreditCardAccountInputValidator
                implements ConstraintValidator<ValidCreditCardAccountInput, CreditCardAccount> {

    @Override
    public void initialize(ValidCreditCardAccountInput constraintAnnotation) {}

    @Override
    public boolean isValid(CreditCardAccount target, ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();
        boolean result = true;

        if (target == null) {
            context.buildConstraintViolationWithTemplate(
                            "{RewardRedemption.ToCreditCardAccount.NotEmpty}")
                            .addConstraintViolation();
            result = false;
        } else if (target.getId() == null) {
            if (target.getAccountNumber() == null || target.getAccountNumber().getValue() == null) {
                context.buildConstraintViolationWithTemplate(
                                "{RewardRedemption.ToCreditCardAccount.Invalid}")
                                .addConstraintViolation();
                result = false;
            } else if (target.getAccountNumber().getValue().length() != 16
                            || !target.getAccountNumber().getValue().startsWith("6011")) {
                context.buildConstraintViolationWithTemplate(
                                "{RewardRedemption.ToCreditCardAccount.NonDiscoverAccount}")
                                .addConstraintViolation();
                result = false;
            } else {
                if (!luhnCheck(target.getAccountNumber().getValue())) {
                    // Need to check the Luhn test to see if it is a valid credit card number. Also
                    // known as the "Mod 10" check.
                    context.buildConstraintViolationWithTemplate(
                                    "{RewardRedemption.ToCreditCardAccount.InvalidAccountNumber}")
                                    .addConstraintViolation();
                    result = false;
                }
            }
        }

        return result;
    }

    private boolean luhnCheck(String account) {
        int s1 = 0, s2 = 0;
        String reverse = new StringBuffer(account).reverse().toString();
        for (int i = 0; i < reverse.length(); i++) {
            int digit = Character.digit(reverse.charAt(i), 10);
            if (i % 2 == 0) {
                // this is for odd digits, they are 1-indexed in the algorithm
                s1 += digit;
            } else {
                // add 2 * digit for 0-4, add 2 * digit - 9 for 5-9
                s2 += 2 * digit;
                if (digit >= 5) {
                    s2 -= 9;
                }
            }
        }
        return (s1 + s2) % 10 == 0;
    }
}
