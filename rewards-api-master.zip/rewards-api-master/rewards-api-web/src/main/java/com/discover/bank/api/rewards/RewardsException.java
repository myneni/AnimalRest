package com.discover.bank.api.rewards;


public class RewardsException extends Exception {

    private static final long serialVersionUID = 1L;

    public RewardsException() {
        this("Rewards.TechnicalDifficulties");
    }

    public RewardsException(String messageCode) {
        super(messageCode);
    }
}
