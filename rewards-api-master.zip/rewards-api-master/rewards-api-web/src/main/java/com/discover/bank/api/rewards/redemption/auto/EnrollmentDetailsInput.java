package com.discover.bank.api.rewards.redemption.auto;

import java.util.List;

public class EnrollmentDetailsInput {

    private List<String> sourceAccountNumbers;

    public List<String> getSourceAccountNumbers() {
        return sourceAccountNumbers;
    }

    public void setSourceAccountNumbers(List<String> sourceAccountNumbers) {
        this.sourceAccountNumbers = sourceAccountNumbers;
    }

}
