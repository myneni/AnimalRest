package com.discover.bank.api.rewards.redemption;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = SubmitRedepmtionOutputVO.Builder.class)
public class SubmitRedepmtionOutputVO {
    String orderId;
    String sourceAccountNumber;
    String targetAccountNumber;
    AmountVO requestAmount;
    AmountVO rewardsBalanceAmount;

    private SubmitRedepmtionOutputVO(Params p) {
        this.orderId = p.orderId;
        this.sourceAccountNumber = p.sourceAccountNumber;
        this.targetAccountNumber = p.targetAccountNumber;
        this.requestAmount = p.requestAmount;
        this.rewardsBalanceAmount = p.rewardsBalanceAmount;
    }

    public String getOrderId() {
        return orderId;
    }

    public String getSourceAccountNumber() {
        return sourceAccountNumber;
    }

    public String getTargetAccountNumber() {
        return targetAccountNumber;
    }

    public AmountVO getRequestAmount() {
        return requestAmount;
    }

    public AmountVO getRewardsBalanceAmount() {
        return rewardsBalanceAmount;
    }

    public static Builder newInstance() {
        return new Builder();
    }
    
    public static class Builder {

        private final Params p;
        
        public Builder() {
            this.p = new Params();
        }

        @JsonProperty
        public Builder withOrderId(String orderId) {
            this.p.orderId = orderId;
            return this;
        }

        @JsonProperty
        public Builder withSourceAccountNumber(String sourceAccountNumber) {
            this.p.sourceAccountNumber = sourceAccountNumber;
            return this;
        }

        @JsonProperty
        public Builder withTargetAccountNumber(String targetAccountNumber) {
            this.p.targetAccountNumber = targetAccountNumber;
            return this;
        }

        @JsonProperty
        public Builder withRequestAmount(AmountVO requestAmount) {
            this.p.requestAmount = requestAmount;
            return this;
        }

        @JsonProperty
        public Builder withRewardsBalanceAmount(AmountVO rewardsBalanceAmount) {
            this.p.rewardsBalanceAmount = rewardsBalanceAmount;
            return this;
        }

        public SubmitRedepmtionOutputVO build() {
            return new SubmitRedepmtionOutputVO(this.p);
        }
    }
    private static class Params {
        String orderId;
        String sourceAccountNumber;
        String targetAccountNumber;
        AmountVO requestAmount;
        AmountVO rewardsBalanceAmount;
    }


}
