package com.discover.bank.api.rewards.redemption.auto;

import com.discover.bank.api.core.accounts.BankAccount;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.google.common.base.MoreObjects;

@JsonDeserialize(builder = EditAutoRedemptionResponse.Builder.class)
public class EditAutoRedemptionResponse {

    private Boolean isEnrolled;

    private String message;

    private BankAccount toAccount;

    private BankAccount fromAccount;

    private EditAutoRedemptionResponse() {}

    private EditAutoRedemptionResponse(Params parms) {
        this.message = parms.message;
        this.isEnrolled = parms.isEnrolled;
        this.toAccount = parms.toAccount;
        this.fromAccount = parms.fromAccount;
    }

    @JsonProperty
    public Boolean getIsEnrolled() {
        return isEnrolled;
    }

    @JsonProperty
    public String getMessage() {
        return message;
    }

    @JsonProperty
    public BankAccount getToAccount() {
        return toAccount;
    }

    public BankAccount getFromAccount() {
        return fromAccount;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static Builder newBuilder(EditAutoRedemptionResponse editAutoRedemptionResponse) {
        return new Builder(editAutoRedemptionResponse);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                          .omitNullValues()
                          .add("toAccount", toAccount)
                          .add("fromAccount", fromAccount)
                          .add("message", message)
                          .add("isEnrolled", isEnrolled)
                          .toString();
    }

    public static class Builder {

        private final Params p;

        public Builder() {
            this.p = new Params();
        }

        public Builder(EditAutoRedemptionResponse p) {
            this.p = new Params();
            this.p.message = p.message;
            this.p.isEnrolled = p.isEnrolled;
            this.p.toAccount = p.toAccount;
            this.p.toAccount = p.fromAccount;
        }

        @JsonProperty
        public Builder withIsEnrolled(Boolean isEnrolled) {
            this.p.isEnrolled = isEnrolled;
            return this;
        }

        @JsonProperty
        public Builder withMessage(String message) {
            this.p.message = message;
            return this;
        }

        @JsonProperty
        public Builder withToAccount(BankAccount toAccount) {
            this.p.toAccount = toAccount;
            return this;
        }

        public Builder withFromAccount(BankAccount fromAccount) {
            this.p.fromAccount = fromAccount;
            return this;
        }

        public EditAutoRedemptionResponse build() {
            return new EditAutoRedemptionResponse(this.p);
        }
    }

    private static final class Params {
        private Boolean isEnrolled;
        private String message;
        private BankAccount toAccount;
        private BankAccount fromAccount;
    }
}
