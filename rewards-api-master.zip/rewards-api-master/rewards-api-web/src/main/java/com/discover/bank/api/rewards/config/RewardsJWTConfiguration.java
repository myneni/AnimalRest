package com.discover.bank.api.rewards.config;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.util.Collections;
import java.util.HashMap;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.dfs.ws.jwt.generator.WSJWTException;
import com.dfs.ws.jwt.generator.WSJWTGenerator;
import com.dfs.ws.jwt.generator.config.WSJWTGeneratorConfigurationReader;
import com.dfs.ws.jwt.generator.config.file.WSJWTGeneratorConfigurationFileReader;
import com.discover.bank.api.env.PropertyAccessor;

@Configuration
public class RewardsJWTConfiguration {

    private static final Logger LOG = LoggerFactory.getLogger(RewardsJWTConfiguration.class);

    private static final String APP_NAME = "ibank_rewards_api";

    @Inject
    PropertyAccessor props;

    public WSJWTGeneratorConfigurationReader configReader() throws WSJWTException {
        WSJWTGeneratorConfigurationReader reader = new WSJWTGeneratorConfigurationFileReader();
        try {

            // pass in the APP_NAME - the JWTGeneratorCofig info will be passed in as system
            // properties
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("APP_NAME", APP_NAME);

            reader.init(map);
            LOG.info("JWT Client Configuration Reader is generated successfully!");

        } catch (WSJWTException e) {
            LOG.error("JWT Client Configuration Reader can't be instantiated!", e);
            throw e;
        }
        return reader;
    }

    /**
     * configure JWT generator to call Bank Money Movement API Endpoint
     * 
     * @return JWTGenerator for generating the JWT token for calling rest services
     * @throws WSJWTException
     */
    @Bean
    public WSJWTGenerator jwtGenerator() throws WSJWTException {
        WSJWTGenerator jwtGenerator = null;
        try {
            jwtGenerator = new WSJWTGenerator();

            jwtGenerator.init(configReader());
            LOG.info("JWTGenerator is created successfully");

        } catch (WSJWTException e) {
            if (jwtGenerator != null) {
                jwtGenerator.destroy();
            }
            LOG.error("JWTGenerator can't be instantiated!", e);

            throw e;
        }

        return jwtGenerator;
    }


    @Bean
    public RestTemplate restTemplate() throws WSJWTException {
        final SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        final Proxy proxy = new Proxy(Type.HTTP,
                        new InetSocketAddress("proxy-app.discoverfinancial.com", 8080));

        LOG.info("Creating RestTemplate using Proxy={}", proxy);

        factory.setProxy(proxy);
        factory.setReadTimeout(7000);

        RestTemplate restTemplate = new RestTemplate(factory);

        ClientHttpRequestInterceptor interceptor;

        try {
            interceptor = rewardsRestHttpInterceptor();
        } catch (WSJWTException e) {
            LOG.error("Failed to create http Request Interceptor ", e);
            throw e;
        }

        // Set the interceptors
        restTemplate.setInterceptors(Collections.singletonList(interceptor));

        return restTemplate;

    }

    /**
     * Define the interceptor as a spring bean so that the autowired beans are loaded in that object
     *
     * @return ClientHttpRequestInterceptor
     * @throws WSJWTException
     */
    @Bean
    public ClientHttpRequestInterceptor rewardsRestHttpInterceptor() throws WSJWTException {
        return new RewardsRestHttpRequestInterceptor(jwtGenerator());
    }
}
