package com.discover.bank.api.rewards.email;

import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.customers.Customer;
import com.discover.bank.api.rewards.redemption.Redemption;

public interface EmailRepository {

    void sendConfirmationEmail(Customer customer, Redemption redemption);

    void sendConfirmationEmail(Customer customer, BankAccount fromAccount,BankAccount toAccount, String formCode);
}
