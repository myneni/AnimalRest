package com.discover.bank.api.rewards.account;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.rewards.account.RewardsAccount.InputBuilder;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = RewardsAccount.InputBuilder.class)
public abstract class RewardsAccountMixin {

    @JsonProperty
    public abstract String getId();

    @JsonProperty
    public abstract AccountNumber getAccountNumber();

    @JsonProperty
    public abstract String getNickName();

    public abstract static class InputBuilderMixin {

        @JsonProperty
        public abstract InputBuilder withId(String id);

    }

}
