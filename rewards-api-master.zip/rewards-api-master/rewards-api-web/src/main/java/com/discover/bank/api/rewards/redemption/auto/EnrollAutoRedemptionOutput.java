package com.discover.bank.api.rewards.redemption.auto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = EnrollAutoRedemptionOutput.Builder.class)
public class EnrollAutoRedemptionOutput {

    private String enrollmentStatus;

    private String statusCode;

    private String statusDescription;


    private EnrollAutoRedemptionOutput(Params params) {
        this.enrollmentStatus = params.enrollmentStatus;
        this.statusCode = params.statusCode;
        this.statusDescription = params.statusDescription;
    }

    public String getEnrollmentStatus() {
        return enrollmentStatus;
    }


    public String getStatusCode() {
        return statusCode;
    }


    public String getStatusDescription() {
        return statusDescription;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder {

        private final Params p;

        private Builder() {
            this.p = new Params();
        }

        @JsonProperty
        public Builder withEnrollmentStatus(String enrollmentStatus) {
            this.p.enrollmentStatus = enrollmentStatus;
            return this;
        }

        @JsonProperty
        public Builder withStatusCode(String statusCode) {
            this.p.statusCode = statusCode;
            return this;
        }

        @JsonProperty
        public Builder withStatusDescription(String statusDescription) {
            this.p.statusDescription = statusDescription;
            return this;
        }

        public EnrollAutoRedemptionOutput build() {
            return new EnrollAutoRedemptionOutput(this.p);
        }

    }

    private static final class Params {
        private String enrollmentStatus;
        private String statusCode;
        private String statusDescription;
    }
}
