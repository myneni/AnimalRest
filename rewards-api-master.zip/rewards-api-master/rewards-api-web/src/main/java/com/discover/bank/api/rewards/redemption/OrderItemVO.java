package com.discover.bank.api.rewards.redemption;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = OrderItemVO.Builder.class)
public class OrderItemVO {
    String productCode;
    String modeGroupCode;
    String categoryCode;
    AmountVO requestAmt;
    String targetAcctNumber;
    AmountVO disbursementActivityCashAmt;

    private OrderItemVO(Params p) {
        this.productCode = p.productCode;
        this.modeGroupCode = p.modeGroupCode;
        this.categoryCode = p.categoryCode;
        this.requestAmt = p.requestAmt;
        this.targetAcctNumber = p.targetAcctNumber;
        this.disbursementActivityCashAmt = p.disbursementActivityCashAmt;
    }
    
    
    
    public String getProductCode() {
        return productCode;
    }

    public String getModeGroupCode() {
        return modeGroupCode;
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public AmountVO getRequestAmt() {
        return requestAmt;
    }

    public String getTargetAcctNumber() {
        return targetAcctNumber;
    }
    public AmountVO getDisbursementActivityCashAmt() {
        return disbursementActivityCashAmt;
    }
    
    public static Builder newInstance() {
        return new Builder();
    }

    
    public static class Builder {

        private final Params p;

        public Builder() {
            this.p = new Params();
        }

        @JsonProperty
        public Builder withProductCode(String productCode) {
            this.p.productCode = productCode;
            return this;
        }

        @JsonProperty
        public Builder withModeGroupCode(String modeGroupCode) {
            this.p.modeGroupCode = modeGroupCode;
            return this;
        }

        @JsonProperty
        public Builder withCategoryCode(String categoryCode) {
            this.p.categoryCode = categoryCode;
            return this;
        }

        @JsonProperty
        public Builder withRequestAmt(AmountVO requestAmt) {
            this.p.requestAmt = requestAmt;
            return this;
        }

        @JsonProperty
        public Builder withTargetAcctNumber(String targetAcctNumber) {
            this.p.targetAcctNumber = targetAcctNumber;
            return this;
        }
        
        @JsonProperty
        public Builder withDisbursementActivityCashAmt(AmountVO disbursementActivityCashAmt) {
            this.p.disbursementActivityCashAmt = disbursementActivityCashAmt;
            return this;
        }



        public OrderItemVO build() {
            return new OrderItemVO(this.p);
        }
    }

    private static class Params {
        private String productCode;
        private String modeGroupCode;
        private String categoryCode;
        private AmountVO requestAmt;
        private String targetAcctNumber;
        private AmountVO disbursementActivityCashAmt;
    }

}
