package com.discover.bank.api.rewards.balance;

import java.math.BigInteger;

public class RewardsBalance {

    private final BigInteger currentBalance;
    private final BigInteger availableBalance;
    private final Boolean eligibleForRedemption;

    private RewardsBalance(Params p) {
        this.currentBalance = p.currentBalance;
        this.availableBalance = p.availableBalance;
        this.eligibleForRedemption = p.eligibleForRedemption;
    }

    public BigInteger getCurrentBalance() {
        return this.currentBalance;
    }

    public BigInteger getAvailableBalance() {
        return this.availableBalance;
    }

    public Boolean isEligibleForRedemption() {
        return this.eligibleForRedemption;
    }

    public static Builder initialize() {
        return new Builder();
    }

    public static class Builder {
        private final Params p;

        private Builder() {
            this.p = new Params();
        }

        public Builder withCurrentBalance(BigInteger currentBalance) {
            this.p.currentBalance = currentBalance;
            return this;
        }

        public Builder withAvailableBalance(BigInteger availableBalance) {
            this.p.availableBalance = availableBalance;
            return this;
        }

        public Builder withEligibleForRedemption(Boolean eligibleForRedemption) {
            this.p.eligibleForRedemption = eligibleForRedemption;
            return this;
        }

        public RewardsBalance build() {
            return new RewardsBalance(this.p);
        }
    }

    private static final class Params {
        private BigInteger currentBalance;
        private BigInteger availableBalance;
        private Boolean eligibleForRedemption;
    }

}
