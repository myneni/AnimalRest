package com.discover.bank.api.rewards.validation;

import javax.inject.Inject;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceAware;

import com.discover.bank.api.core.accounts.AccountFreeze;
import com.discover.bank.api.core.accounts.AccountStatus;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.bank.api.rewards.redemption.Redemption;
import com.discover.bank.api.rewards.redemption.Redemptions;

public class ValidRedemptionValidator implements
                ConstraintValidator<ValidRedemptionInput, Redemption>, MessageSourceAware {

    @Inject
    private MessageSource messageSource;

    private static final Logger LOG = LoggerFactory.getLogger(ValidRedemptionValidator.class);

    private static final String DOT = ".";

    @Override
    public void initialize(ValidRedemptionInput constraintAnnotation) {
        // ;
    }

    @Override
    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    public boolean isValid(Redemption target, ConstraintValidatorContext context) {

        context.disableDefaultConstraintViolation();
        boolean result = true;

        LOG.info("Start validating the redemption...");
        /**
         * This code has to be commented out due to the fact that there are limitation to display
         * dynamic error message. For temporary fix, the redemption amount validation will be moved
         * to BO, once the issue is resolved, then the below redemption amount validation will be
         * used.
         *
         * BigInteger highThreshold = new BigInteger (target.getRedemptionLimit().getMaximum());
         * BigInteger lowThreshold = new BigInteger (target.getRedemptionLimit().getMinimum());
         * BigInteger interval = new BigInteger (target.getRedemptionLimit().getIncrement());
         * 
         * // check that redemption amount is valid if ( target.getAmount() == null ) { LOG.info(
         * "Redemption amount can not be null"); context.buildConstraintViolationWithTemplate(
         * "{RewardRedemption.Amount.NotEmpty}" ).addNode("amount").addConstraintViolation(); result
         * = false;
         * 
         * } else if (
         * target.getFromRewardsAccount().getRewardsBalance().getAvailableBalance().compareTo(
         * target.getAmount() ) < 0 ) { //redeem amount can not exceed CBB balance - the account has
         * to have at least as much as they are trying to redeem LOG.info(
         * "redemption amout can not exceed CBB balance");
         * context.buildConstraintViolationWithTemplate(
         * "{RewardRedemption.Amount.Invalid.LessThanBalance}"
         * ).addNode("amount").addConstraintViolation(); result = false;
         * 
         * } else if ( target.getAmount().compareTo (highThreshold) > 0 ) { //redeem amount can not
         * exceed Maximum threshold LOG.info("redemption amout can not exceed Maximum threshold {} "
         * , highThreshold.toString()); String msg = getMessage(
         * "RewardRedemption.Amount.Invalid.Max", new MoneyImpl( highThreshold ).getFormatted());
         * context.buildConstraintViolationWithTemplate( msg
         * ).addNode("amount").addConstraintViolation(); result = false;
         * 
         * } else if ( target.getAmount().compareTo (lowThreshold) < 0 ) { //redeem amount can not
         * below Minimum threshold LOG.info("redemption amout can not below Minimum threshold {} ",
         * lowThreshold.toString()); String msg = getMessage( "RewardRedemption.Amount.Invalid.Min",
         * new MoneyImpl( lowThreshold ).getFormatted());
         * context.buildConstraintViolationWithTemplate( msg
         * ).addNode("amount").addConstraintViolation(); result = false;
         * 
         * } else { if ( interval != null && interval.compareTo( BigInteger.ZERO ) != 0) {
         * BigInteger rm[] = target.getAmount().divideAndRemainder(interval); // if reminder is not
         * 0, the amount does not meet interval if (rm[1].compareTo( BigInteger.ZERO ) != 0 ) {
         * //redeem amount needs to be specified interval LOG.info(
         * "Redemption amount has to be in increment {} ", interval.toString()); String msg =
         * getMessage( "RewardRedemption.Amount.Invalid.Increment", new MoneyImpl( interval
         * ).getFormatted()); LOG.info("error message - " + msg );
         * context.buildConstraintViolationWithTemplate( msg
         * ).addNode("amount").addConstraintViolation(); result = false; } } else { //no increment
         * requirement } }
         */
        // check to see if the from account is eligible reward account
        if (!isRedemptionEligible(target.getFromRewardsAccount())) {
            // From card account has to be eligible reward account
            LOG.info("From account is Not RedemptionEligible");
            context.buildConstraintViolationWithTemplate(
                            "{RewardRedemption.FromRewardsAccount.AccountIneligible}")
                            .addNode("fromRewardsAccount").addConstraintViolation();
            result = false;
        }

        // Check that the card account is eligible for reward transfers
        else if (Redemptions.isTransfer(target.getRedemptionType())) {
            LOG.info("check if credit card is redeemable");
            if (!isRedeemableCreditCardAccount(target.getToCreditCardAccount())) {
                LOG.info("To credit card is not redeemable");
                // TODO Once iOS is no longer looking at specific error codes this should be changed
                // to RewardRedemption.ToCreditCardAccount.AccountIneligible
                context.buildConstraintViolationWithTemplate(
                                "{RewardRedemption.ToCreditCardAccount.InvalidAccountNumber}")
                                .addNode("toCreditCardAccount").addConstraintViolation();
                result = false;
            }
        }

        return result;
    }


    /**
     * check if a RewardsAccount is eligible to make rewards redemptions.
     *
     * @param account The RewardsAccount for which to check the eligibility.
     * @return True if the account is eligible to make redemptions, False otherwise.
     */
    private boolean isRedemptionEligible(RewardsAccount account) {
        boolean result = true;
        if (account == null) {
            result = false;
        } else if (account.getStatus() == AccountStatus.CLOSED) {
            // The account cannot be closed
            LOG.info("Account ineligible for redemption due to account status being 'Closed'");
            result = false;
        } else if (account.getBalance().intValue() < 0) {
            // The account must have a zero or positive balance
            LOG.info("Account ineligible for redemption due to a negative balance: {}",
                            account.getBalance().intValue());
            result = false;
        } else if (account.getFreeze() == AccountFreeze.DEBIT
                        || account.getFreeze() == AccountFreeze.TOTAL) {
            // The account can't be confirmed as a fraud account
            LOG.info("Account ineligible for redemption because its confirmed frozen (fraud)");
            result = false;
        } else if (!account.getRewardsBalance().isEligibleForRedemption()) {
            // Check the flag on the rewards balance to make sure that it is redeemable
            LOG.info("Account ineligible for redemption due to status from rewards balance call");
            result = false;
        }

        return result;
    }

    /**
     * check if a CreditCardAccount is eligible to receive a rewards transfer.
     *
     * @param target The CreditCardAccount for which to check the eligibility.
     * @return True if the account is eligible for rewards transfers, false otherwise.
     */
    private boolean isRedeemableCreditCardAccount(CreditCardAccount target) {

        boolean result = false;

        if (target != null) {
            StringBuilder cardString =
                            new StringBuilder("CCVALIDREWARDS.").append(target.getCardType())
                                            .append(DOT).append(target.getProductType()).append(DOT)
                                            .append(target.getExternalStatus()).append(DOT)
                                            .append(target.getInternalStatus());

            String ccValidProp = cardString.toString().toUpperCase();

            result = Boolean.valueOf(
                            messageSource.getMessage(ccValidProp, new Object[] {}, "false", null));
            // result = Boolean.valueOf(messageSource.get(ccValidProp, "false"));
            LOG.info("Checking to see if CC is valid for redeemtion. CCValidRewards.CardType.ProductType.ExtStat.IntStat = {}, Result = {}",
                            new Object[] {ccValidProp, result});

        }

        return result;
    }

    // private String getMessage( String errorCode, Object... arguments ) {
    // String result = ( this.messageSource != null ) ? this.messageSource.get( errorCode,
    // arguments, "" ) : "";
    // return result;
    // }
}
