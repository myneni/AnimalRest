package com.discover.bank.api.rewards.redemption.auto;

import com.google.common.base.MoreObjects;

public class EnrollEditAutoRedemptionInput {

    private String customerId;

    private String sourceAccountNumber;

    private String targetAccountNumber;

    private EnrollEditAutoRedemptionInput() {}

    private EnrollEditAutoRedemptionInput(Builder params) {
        this.customerId = params.customerId;
        this.sourceAccountNumber = params.sourceAccountNumber;
        this.targetAccountNumber = params.targetAccountNumber;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getSourceAccountNumber() {
        return sourceAccountNumber;
    }

    public String getTargetAccountNumber() {
        return targetAccountNumber;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                          .omitNullValues()
                          .add("customerId", customerId)
                          .add("sourceAccountNumber", sourceAccountNumber)
                          .add("targetAccountNumber", targetAccountNumber)
                          .toString();

    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder {

        private String customerId;

        private String sourceAccountNumber;

        private String targetAccountNumber;

        private Builder() {}

        public Builder withCustomerId(String customerId) {
            this.customerId = customerId;
            return this;
        }

        public Builder withSourceAccountNumber(String sourceAccountNumber) {
            this.sourceAccountNumber = sourceAccountNumber;
            return this;
        }

        public Builder withTaretAccountNumber(String targetAccountNumber) {
            this.targetAccountNumber = targetAccountNumber;
            return this;
        }

        public EnrollEditAutoRedemptionInput build() {
            return new EnrollEditAutoRedemptionInput(this);
        }

    }
}
