package com.discover.bank.api.rewards.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.discover.bank.api.core.accounts.BankAccount;

public class ValidBankAccountValidator
                implements ConstraintValidator<ValidBankAccount, BankAccount> {

    @Override
    public void initialize(ValidBankAccount arg0) {
        // no initialization needed
    }

    @Override
    public boolean isValid(BankAccount target, ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();
        boolean result = true;

        if (target != null && target.getId() == null) {
            context.buildConstraintViolationWithTemplate(
                            "{RewardRedemption.ToAccount.Id.NotEmpty}")
                            .addConstraintViolation();
            result = false;
        }

        return result;
    }

}
