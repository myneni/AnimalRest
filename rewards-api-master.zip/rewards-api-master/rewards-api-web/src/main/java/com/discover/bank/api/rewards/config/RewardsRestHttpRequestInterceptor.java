package com.discover.bank.api.rewards.config;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import com.dfs.ws.jwt.generator.WSJWTException;
import com.dfs.ws.jwt.generator.WSJWTGenerator;

public class RewardsRestHttpRequestInterceptor implements ClientHttpRequestInterceptor {

    private static final Logger LOG =
                    LoggerFactory.getLogger(RewardsRestHttpRequestInterceptor.class);

    private static final String JWT_HEADER = "HTTP_AUTH_TOKEN";

    private final WSJWTGenerator jwtGenerator;

    /**
     * Constructor
     *
     * @param jwtGenerator
     */
    public RewardsRestHttpRequestInterceptor(WSJWTGenerator jwtGenerator) {
        this.jwtGenerator = jwtGenerator;
    }


    /**
     * this method adds HTTP_AUTH_TOKEN headers for every request
     */
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body,
                    ClientHttpRequestExecution execution) throws IOException {

        LOG.info("intercept the request for method: ", request.getMethod());
        HttpHeaders headers = request.getHeaders();

        try {

            if (jwtGenerator != null) {

                String token = jwtGenerator.getJWTToken();
                LOG.debug("jwtToken = {}", token);

                headers.add(JWT_HEADER, token);
            } else {
                LOG.error("Error while generating JWT Token - JWTGenerator is null");
            }

        } catch (WSJWTException e) {
            LOG.error("WSJWTException occurred while generating token", e);
        }

        return execution.execute(request, body);
    }

}
