package com.discover.bank.api.rewards.earnings.buckets;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.bank.api.rewards.earnings.Earnings;
import com.discover.bank.api.stereotype.Repository;
import com.discover.common.base.BigNumbers;
import com.discover.common.base.Dates;
import com.discover.common.base.Dates.Format;
import com.google.common.base.Strings;

/**
 * @author rsridha
 *
 */
@Repository
public class RewardsBucketRepository {


    private static final Logger LOG = LoggerFactory.getLogger(RewardsBucketRepository.class);

    private static String CONSUMER_INFO_HEADER = "X-DFS-C-APP-INFO";
    private static final String CHANNEL_NAME = "MP";
    private static final String CHANNEL_AND_APP_NAME = "MOBILE";
    private static final String CHANNEL_ID = "WEB";

    private static final String REWARDS_BUCKET_DOMAIN = "rewards.bucket.api.domain";
    private static final String REWARDS_BUCKET_PATH = "rewards.bucket.api.path";

    private RestTemplate restTemplate;

    private PropertyAccessor props;

    @Inject
    public RewardsBucketRepository(RestTemplate restTemplate, PropertyAccessor props) {
        this.restTemplate = restTemplate;
        this.props = props;
    }

    public Earnings getRewardsBucketEarnings(CustomerIdentification customer, RewardsAccount account, Date periodStartDate, Date periodEndDate) {
        
        ResponseEntity<RewardsEarnBucketOutput> response = null;

        String fromDate = Dates.print(periodStartDate, Format.BIG_ENDIAN_HYPHEN);
        String toDate = Dates.print(periodEndDate, Format.BIG_ENDIAN_HYPHEN);
        
        // populate header info
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(CONSUMER_INFO_HEADER, getConsumerInfo(customer));

        RewardsEarnBucketInput input = RewardsEarnBucketInput.newInstance()
                                                 .withAccountNumber(account.getAccountNumber().getValue())
                                                 .withFinancialAgreementType(RewardsAccount
                                                                 .getFinancialAgreementType(account.getProduct().getProductGroup()))
                                                 .withFromDate(fromDate)
                                                 .withToDate(toDate)
                                                 .build();


        HttpEntity<RewardsEarnBucketInput> requestEntity =
                        new HttpEntity<RewardsEarnBucketInput>(input, headers);

        LOG.info("requestEntity = {}", requestEntity);

        try {
            
           final String url = UriComponentsBuilder
                            .fromHttpUrl(props.get(REWARDS_BUCKET_DOMAIN)
                            + props.get(REWARDS_BUCKET_PATH))
                            .toUriString();

            LOG.info("making restTemplate call with endPointUri as: {} ", url);

            long startTime = System.currentTimeMillis();

            response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
                            RewardsEarnBucketOutput.class);

            long endTime = System.currentTimeMillis();

            LOG.info("Response time for GET {} >>>> {} ms", url, (endTime - startTime));

            LOG.info("response: {}", response);
        } catch (HttpClientErrorException ce) {
            LOG.debug("Caught HttpClientErrorException with Http status code as: {}, body as {}",
                            ce.getStatusCode(), ce.getResponseBodyAsString(), ce);
            LOG.warn("Caught HttpClientErrorException with Http status code as: {}, body as {} for Start Date {} and End Date {}",
                            ce.getStatusCode(), ce.getResponseBodyAsString(), fromDate, toDate);
            
            if ((HttpStatus.BAD_REQUEST.equals(ce.getStatusCode())
                            || HttpStatus.NOT_FOUND.equals(ce.getStatusCode()))
                            && ("E003".contains(ce.getResponseBodyAsString())
                                            || "E102".contains(ce.getResponseBodyAsString()))) {
                LOG.warn("Caught HttpClientErrorException with Http status code as: {}, body as {}",
                                ce.getStatusCode(), ce.getResponseBodyAsString(), ce);
            }


        } catch (HttpServerErrorException hse) {
            LOG.debug("Caught HttpServerErrorException with Http status code as: {}, body as {}",
                            hse.getStatusCode(), hse.getResponseBodyAsString(), hse);
            LOG.warn("Caught HttpServerErrorException with Http status code as: {}, body as {} for Start Date {} and End Date {}",
                            hse.getStatusCode(), hse.getResponseBodyAsString(), fromDate, toDate);


        } catch (Exception e) {
            LOG.debug("Exception ocurred when calling Rewards Bucket Service", e);
            LOG.warn("Exception ocurred when calling Rewards Bucket Service for Start Date {} and End Date {}.",
                            fromDate, toDate);
        }

        return validateAndTransform(response, periodStartDate, periodEndDate);
    }

    protected Earnings validateAndTransform(ResponseEntity<RewardsEarnBucketOutput> response,
                    Date periodStartDate, Date periodEndDate) {
        Earnings result = null;

        String fromDate = Dates.print(periodStartDate, Format.BIG_ENDIAN_HYPHEN);
        String toDate = Dates.print(periodEndDate, Format.BIG_ENDIAN_HYPHEN);

        if (response == null || response.getBody() == null || response.getBody().getEarnedRwdForDateRangeDtls() == null 
                        || response.getBody().getEarnedRwdForDateRangeDtls().isEmpty()) {
            LOG.warn("Error ocurred while getting the response from Rewards Bucket Service for Start Date {} and End Date {}.",
                            fromDate, toDate);
            //If response is null then set the default values for all rewards types
            return transform(getBucketOutputRespNull(), periodStartDate, periodEndDate);
        }

        if (response != null && response.getBody() != null  && response.getBody().getEarnedRwdForDateRangeDtls() != null 
                        && !response.getBody().getEarnedRwdForDateRangeDtls().isEmpty()) {
            result = transform(buildBucketOutput(response.getBody().getEarnedRwdForDateRangeDtls()),
                            periodStartDate, periodEndDate);
        }

        return result;
    }

    protected List<EarnedRwdForDateRangeDtls> modifyRewardTypes(
                    List<EarnedRwdForDateRangeDtls> earnedRwdDateRangeDetails) {

        List<EarnedRwdForDateRangeDtls> updatedEarnedRwdDateRangeDetails =
                        new ArrayList<EarnedRwdForDateRangeDtls>();

        for (EarnedRwdForDateRangeDtls earnedRwdForDateRangeDtl : earnedRwdDateRangeDetails) {

            updatedEarnedRwdDateRangeDetails.add(
                            EarnedRwdForDateRangeDtls.newInstance(earnedRwdForDateRangeDtl)
                                                     .withEarnedRwdType(
                                                                     removeSpecialCharAndCapitalize(
                                                                                     earnedRwdForDateRangeDtl.getEarnedRwdType()))
                                                     .build());
        }

        return updatedEarnedRwdDateRangeDetails;
    }

    protected Earnings transform(List<EarnedRwdForDateRangeDtls> earnedRwdDateRangeDetails, Date from, Date to) {
        final Earnings.Builder builder = new Earnings.Builder().from(from).to(to);
        
            // Go through the different types of rewards and add them to our own list.
            for (EarnedRwdForDateRangeDtls rewardDetail : earnedRwdDateRangeDetails) {
                if (rewardDetail != null && rewardDetail.getEarnedRwdAmt() != null
                                && rewardDetail.getEarnedRwdType() != null) {

                String typeName = props.get(rewardDetail.getEarnedRwdType());

                    if (Strings.isNullOrEmpty(typeName)) {
                        LOG.error("Error mapping RewardsEarnType: {}, Please check the rewards properties file. Defaulting to 'Other'",
                                        new Object[] {rewardDetail.getEarnedRwdType()});
                        typeName = "Other";
                    }

                    if (rewardDetail.getEarnedRwdAmt().getAmount() != null) {
                        builder.add(typeName, BigNumbers.toMoney(rewardDetail.getEarnedRwdAmt().getAmount()));
                    }
                }
            }

        return builder.build();
    }

    /**
     * @param earnedRwdDetails
     * 
     *        If BI doesn't return any one of the following rewards types DEBITCARDPURCHASES,
     *        PROMOTIONS, ADJUSTMENTSPOSITIVE and ADJUSTMENTSRETURNSREVERSALS for the given Account
     *        Number then this method returns default rewards bucket output for that reward types.
     * 
     */
    protected List<EarnedRwdForDateRangeDtls> buildBucketOutput(List<EarnedRwdForDateRangeDtls> earnedRwdDetails) {
        LOG.info("Building the Bucket Output for Mandatory Bucket Types");
        List<EarnedRwdForDateRangeDtls> bucketOutputList = new ArrayList<EarnedRwdForDateRangeDtls>();
        EarnedRwdForDateRangeDtls earnedRwdDetail = null;
        List<EarnedRwdForDateRangeDtls> updatedEarnedRwdDetails =
                        modifyRewardTypes(earnedRwdDetails);
        List<String> mandatoryBucketTypes = Arrays.asList(props.get("reward.types").split(","));
        for (String rewardType : mandatoryBucketTypes) {
            // If Mandatory Bucket Type is not available from service then add the bucket
            // type and assign default amount 0
            if (!isMandatoryBucketAvailable(rewardType, updatedEarnedRwdDetails)) {
                LOG.info("Mandatory Reward Type {} is not available from BI Service. So adding default value 0", rewardType);
                earnedRwdDetail = EarnedRwdForDateRangeDtls.newInstance()
                                                           .withEarnedRwdType(rewardType)
                                                           .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                             .withAmount(BigDecimal.ZERO)
                                                                             .build())
                                                           .build();
                bucketOutputList.add(earnedRwdDetail);
            }
        }
        //Add the rewards type from service to the final output list
        for (EarnedRwdForDateRangeDtls result : updatedEarnedRwdDetails) {
            bucketOutputList.add(result);
        }
        
        Collections.sort(bucketOutputList, new RewardsTypeComparator());

        return bucketOutputList;
    }
    
    private boolean isMandatoryBucketAvailable(String mandatoryBucket,
                    List<EarnedRwdForDateRangeDtls> earnedRwdDetails) {
        for (EarnedRwdForDateRangeDtls earnedRwdBuckets : earnedRwdDetails) {
            if (earnedRwdBuckets != null && earnedRwdBuckets.getEarnedRwdType() != null
                            && earnedRwdBuckets.getEarnedRwdType()
                                               .equalsIgnoreCase(mandatoryBucket)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 
     * If BI returns null response for the given Account Number then this method returns default
     * rewards bucket output for these reward types.
     * 
     */
    protected List<EarnedRwdForDateRangeDtls> getBucketOutputRespNull() {
        
        List<EarnedRwdForDateRangeDtls> earnedRwdLists = new ArrayList<EarnedRwdForDateRangeDtls>();
        
        RewardsEarnAmount rwdAmount = RewardsEarnAmount.newInstance()
                        .withAmount(BigDecimal.ZERO).build();
        EarnedRwdForDateRangeDtls earnedRwdDebit = EarnedRwdForDateRangeDtls.newInstance()
                                                                            .withEarnedRwdType(
                                                                                            "DEBITCARDPURCHASES")
                                                    .withEarnedRwdAmt(rwdAmount).build();
        EarnedRwdForDateRangeDtls earnedRwdPromotions = EarnedRwdForDateRangeDtls.newInstance()
                                                                                 .withEarnedRwdType(
                                                                                                 "PROMOTIONS")
                        .withEarnedRwdAmt(rwdAmount).build();
        EarnedRwdForDateRangeDtls earnedAdjPostive = EarnedRwdForDateRangeDtls.newInstance()
                                                                              .withEarnedRwdType(
                                                                                              "ADJUSTMENTSPOSITIVE")
                        .withEarnedRwdAmt(rwdAmount).build();
        EarnedRwdForDateRangeDtls earnedAdjReturns = EarnedRwdForDateRangeDtls.newInstance()
                                                                              .withEarnedRwdType(
                                                                                              "ADJUSTMENTSRETURNSREVERSALS")
                        .withEarnedRwdAmt(rwdAmount).build();
        
        earnedRwdLists.add(earnedRwdDebit);
        earnedRwdLists.add(earnedRwdPromotions);
        earnedRwdLists.add(earnedAdjPostive);
        earnedRwdLists.add(earnedAdjReturns);
        
        return earnedRwdLists;
    }
    
    /**
     * return consumerInfo string with below info {App Name}|{Channel Id}|{Channel Name}|{Request
     * UUID}|{User Id}|{Login Security Token}|{Login Session Id}
     * 
     * @return consumer info in String
     */
    protected String getConsumerInfo(CustomerIdentification customer) {
        StringBuilder sb = new StringBuilder();
        sb.append(CHANNEL_AND_APP_NAME).append("|");
        sb.append(CHANNEL_ID).append("|");
        sb.append(CHANNEL_NAME).append("|");
        sb.append(customer.getRequestIdentifier() != null
                        ? customer.getRequestIdentifier().getRequestId() : "")
          .append("|");
        sb.append(CHANNEL_AND_APP_NAME).append("|");
        sb.append("").append("|");
        sb.append("").append("|");

        return sb.toString();
    }

    protected String removeSpecialCharAndCapitalize(String rewardType) {

        String convertedRewardType = rewardType;

        if (!Strings.isNullOrEmpty(rewardType)) {
            convertedRewardType = rewardType.toUpperCase().replaceAll("[^\\w]", "");
        }

        return convertedRewardType;
    }
}
