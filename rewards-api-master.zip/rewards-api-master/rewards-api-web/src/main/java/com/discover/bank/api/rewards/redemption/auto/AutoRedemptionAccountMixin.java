package com.discover.bank.api.rewards.redemption.auto;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.fasterxml.jackson.annotation.JsonProperty;


public abstract class AutoRedemptionAccountMixin {

    @JsonProperty
    public abstract String getId();

    @JsonProperty
    public abstract AccountNumber getAccountNumber();

    @JsonProperty
    public abstract String getNickName();
}
