package com.discover.bank.api.rewards;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.MessageSourceAccessor;

import com.discover.bank.api.core.accounts.AccountNotFoundException;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.accounts.BankAccountManager;
import com.discover.bank.api.core.accounts.MockAccountBuilder;
import com.discover.bank.api.core.customers.Customer;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.core.customers.CustomerManager;
import com.discover.bank.api.core.customers.CustomerNotFoundException;
import com.discover.bank.api.creditcards.CreditCardsException;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.creditcards.account.CreditCardAccountRepository;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.account.EligibleAccounts;
import com.discover.bank.api.rewards.account.EligibleAccountsRepository;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.bank.api.rewards.account.RewardsAccountEnricher;
import com.discover.bank.api.rewards.account.RewardsAccountNotFoundException;
import com.discover.bank.api.rewards.account.RewardsEligibleAccount;
import com.discover.bank.api.rewards.balance.RewardsBalance;
import com.discover.bank.api.rewards.earnings.Earnings;
import com.discover.bank.api.rewards.earnings.EarningsDates;
import com.discover.bank.api.rewards.earnings.EarningsDates.EarningsDateGroup;
import com.discover.bank.api.rewards.earnings.EarningsFilter;
import com.discover.bank.api.rewards.earnings.EarningsRepository;
import com.discover.bank.api.rewards.earnings.EarningsV2;
import com.discover.bank.api.rewards.earnings.buckets.RewardsBucketRepository;
import com.discover.bank.api.rewards.email.EmailRepository;
import com.discover.bank.api.rewards.redemption.Redemption;
import com.discover.bank.api.rewards.redemption.RedemptionLimit;
import com.discover.bank.api.rewards.redemption.RedemptionRepository;
import com.discover.bank.api.rewards.redemption.Redemptions;
import com.discover.bank.api.rewards.redemption.UnrecoverableRedemptionException;
import com.discover.bank.api.rewards.redemption.auto.AutoRedemptionAccount;
import com.discover.bank.api.rewards.redemption.auto.AutoRedemptionRepository;
import com.discover.bank.api.rewards.redemption.auto.AutoRedemptionResponse;
import com.discover.bank.api.rewards.redemption.auto.EditAutoRedemptionResponse;
import com.discover.bank.api.rewards.redemption.auto.EnrollEditAutoRedemption;
import com.discover.bank.api.rewards.redemption.auto.EnrollmentDetailsInput;
import com.discover.bank.api.stereotype.BusinessObject;
import com.discover.common.base.BigNumbers;
import com.discover.common.base.Dates;
import com.discover.common.base.Dates.Format;
import com.discover.common.decisioning.RuleSet;
import com.discover.common.validation.ConstraintViolations;
import com.google.common.base.Objects;
import com.google.common.base.Strings;

/**
 * Organizes the service calls and business logic for the Rewards. Also performs validation on input
 * and send confirmation emails.
 *
 */
@BusinessObject
public class RewardsBusinessObject {

    private static final Logger LOG = LoggerFactory.getLogger(RewardsBusinessObject.class);

    private static final String FROM_REWARDS_ACCOUNT = "FromRewardsAccount";
    private static final String FROM_REWARDS_CODE =
                    "RewardRedemption.FromRewardsAccount.AccountNotFound";

    private static final String TO_CREDIT_CARD_ACCOUNT = "toCreditCardAccount";
    private static final String TO_ACCOUNT = "toAccount";
    private static final String AMOUNT = "amount";
    private static final String TO_ACCOUNT_CODE = "RewardRedemption.ToAccount.InvalidAccount";
    private static final String REDEMPTION_DISCLAIMER = "Redemption.Disclaimer";
    private static final String ONE_TIME = "onetime";
    private static final String ENROLL = "enroll";
    private static final String EDIT_ENROLL = "editEnroll";
    private static final String UN_ENROLL = "unEnroll";

    @Inject
    private RedemptionRepository rewardsRedemptionRepository;

    @Inject
    private EarningsRepository rewardsEarningsRepository;

    @Inject
    private PropertyAccessor props;

    @Inject
    private MessageSourceAccessor messages;

    @Inject
    private BankAccountManager accountManager;

    @Inject
    private CreditCardAccountRepository creditCardRepository;

    @Inject
    private CustomerManager customerManager;

    @Inject
    private EmailRepository emailRepository;

    @Inject
    private RewardsBucketRepository rewardsBucketsRepository;

    @Inject
    private EligibleAccountsRepository eligibleAccountsRepository;

    @Inject
    private AutoRedemptionRepository autoRedemptionRepository;

    @Inject
    private Validator validator;

    @Inject
    private List<RewardsAccountEnricher<RewardsAccount>> accountEnrichers;

    @Inject
    @Named("redemption-limit-rules")
    private RuleSet redemptionLimitRules;

    // wow that was a lot of injections...

    /**
     * Gathers the necessary information for making a rewards redemption. If the redemption is
     * successful then it will also send a confirmation email and return a RewardsRedemption object
     * that contains a confirmationNumber
     *
     * @param input The RewardsRedemption object that was submitted as input
     * @param customerId Holds the customer's CIF and registrationId
     * @param verify
     * @return The RewardsRedemption result which includes a confirmationNumber
     * @throws RewardsException Thrown if an error occurs while calling one of the repositories from
     *         this application
     */
    public Redemption verifyAndRedeemRewards(Redemption input, CustomerIdentification customerId,
                    boolean verifyOnly) throws RewardsException {
        LOG.info("Starting input validation for the RewardsRedemption");
        final Set<ConstraintViolation<Redemption>> violations =
                        this.validator.validate(input, input.getValidationGroup());

        ConstraintViolations.propagateIfPossible(violations);

        EligibleAccounts eligibleAccounts = getEligibleAccounts(customerId, ONE_TIME);

        // Look up the full data on the rewards account which we're making the redemption from
        final RewardsAccount rewardsAccount = new RewardsAccount(
                        findAccountById(eligibleAccounts.getSourceEligibleAccounts(),
                                        input.getFromRewardsAccount().getId(), input,
                                        FROM_REWARDS_ACCOUNT, FROM_REWARDS_CODE));

        // populate reward account's balance
        for (RewardsAccountEnricher<RewardsAccount> enricher : accountEnrichers) {
            enricher.enrich(rewardsAccount);
        }

        // Look up customer data since we might need the SSN to look up the credit card list and we
        // will also need it to send the confirmation email
        final Customer customer = customerManager.findCustomer(customerId);

        // Look up the credit card account. This will be null if we are not transferring rewards to
        // a card account
        final CreditCardAccount creditCardAccount = this.lookupCreditCardAccount(input, customer);

        // Look up the bank account, this will be null if we are transfering rewards to a card
        // account
        BankAccount toAccount = null;
        if (input.getToAccount() != null) {
            toAccount = findAccountById(eligibleAccounts.getTargetEligibleAccounts(),
                            input.getToAccount().getId(), input, TO_ACCOUNT, TO_ACCOUNT_CODE);
        }

        // Build a RewardsRedemption object with our finalized data to send to the service.
        Redemption redemption = Redemption.newBuilder()
                                          .withFromRewardsAccount(rewardsAccount)
                                          .withToAccount(toAccount)
                                          .withToCreditCardAccount(creditCardAccount)
                                          .withRedemptionType(input.getRedemptionType())
                                          .withAmount(input.getAmount())
                                          .build();

        LOG.info("All information gathered successfully. Calling the service to initiate the redemption.");

        // retrieve the redemption limit from rule file and set to redemption
        redemption.setRedemptionLimit(getRedemptionLimit(redemption));

        LOG.info("Validate the fully populated redemption with the redemtion limit rule.");

        // Do some final validation on the fully composed redemption
        violations.addAll(this.validator.validate(redemption, Redemption.ValidRedemption.class));

        // validate redemption amount - this is temporary fix to resolve dynamic error message issue
        // in ValidRedemptionValidator.
        // once the issue is resolved, the amount validation can be moved to
        // ValidRedemptionValidator
        ConstraintViolation<Redemption> vt = validateRedemptionAmount(redemption);
        if (vt != null)
            violations.add(vt);

        ConstraintViolations.propagateIfPossible(violations);

        LOG.info("Validation complete with no violations. Looking up information needed for the redemption.");

        if (verifyOnly)
            return redemption;

        return redeemRewards(redemption, customer);
    }

    private BankAccount findAccountById(List<RewardsEligibleAccount> eligibleAccounts, String id,
                    Redemption input, String field, String code) {

        BankAccount bankAccount = null;

        for (RewardsEligibleAccount eligibleAccount : eligibleAccounts) {
            if (id.equals(eligibleAccount.getId())) {
                bankAccount = eligibleAccount;
                break;
            }
        }

        if (bankAccount == null) {
            LOG.warn("The index they provided ID didn't result in an account.");
            // The index they provided ID didn't result in an account. Throw an
            // InvalidEntityException
            Set<ConstraintViolation<Redemption>> violations =
                            new HashSet<ConstraintViolation<Redemption>>();
            violations.add(ConstraintViolations.newBeanViolation(input)
                                               .withCode(code)
                                               .withField(field)
                                               .build());

            ConstraintViolations.propagateIfPossible(violations);
        }

        return bankAccount;
    }

    /**
     * Gathers the necessary information for making a rewards redemption. If the redemption is
     * successful then it will also send a confirmation email and return a RewardsRedemption object
     * that contains a confirmationNumber
     *
     * @param input The RewardsRedemption object that was submitted as input
     * @param customerId Holds the customer's CIF and registrationId
     * @param verify
     * @return The RewardsRedemption result which includes a confirmationNumber
     * @throws RewardsException Thrown if an error occurs while calling one of the repositories from
     *         this application
     */
    protected Redemption redeemRewards(Redemption redemption, Customer customer)
                    throws RewardsException {

        if (redemption.getAmount() != null
                        && redemption.getFromRewardsAccount().getBalance() != null) {
            LOG.info("Ready for redemption for amount={} and balance={} ",
                            redemption.getAmount().toString(),
                            redemption.getFromRewardsAccount().getBalance().toString());
        }

        final Redemption result = rewardsRedemptionRepository.redeemRewards(redemption, customer);

        LOG.info("Redemption complete, sending confirmation email.");
        emailRepository.sendConfirmationEmail(customer, result);

        return result;
    }

    /**
     * Perform redemption amount validation - this should be removed once the dynamic error message
     * issue in ValidRedemptionValidator if resolved and the redemption amount validation is moved
     * to ValidRedemptionValidator.
     *
     * @param target fully populated Redemption
     * @return ConstraintViolation<Redemption> null if no validation
     */
    protected ConstraintViolation<Redemption> validateRedemptionAmount(Redemption target) {

        ConstraintViolation<Redemption> violation = null;

        BigInteger highThreshold = new BigInteger(target.getRedemptionLimit().getMaximum());
        BigInteger lowThreshold = new BigInteger(target.getRedemptionLimit().getMinimum());
        BigInteger interval = new BigInteger(target.getRedemptionLimit().getIncrement());

        // check that redemption amount is valid
        if (target.getFromRewardsAccount()
                  .getRewardsBalance()
                  .getAvailableBalance()
                  .compareTo(target.getAmount()) < 0) {
            // redeem amount can not exceed CBB balance - the account has to have at least as much
            // as they are trying to redeem
            LOG.info("redemption amout can not exceed CBB balance");
            violation = ConstraintViolations.newBeanViolation(target)
                                            .withCode("{RewardRedemption.Amount.Invalid.LessThanBalance}")
                                            .withField(AMOUNT)
                                            .build();

        } else if (target.getAmount().compareTo(highThreshold) > 0) {
            // redeem amount can not exceed Maximum threshold
            LOG.info("redemption amout can not exceed Maximum threshold - {}. ",
                            highThreshold.toString());
            String strFormattedH = BigNumbers.MoneyFormat.NEGATIVE_WITH_CURRENCY.formatter().format(
                            new BigDecimal(highThreshold).divide(new BigDecimal("100")));
            violation = ConstraintViolations.newBeanViolation(target)
                                            .withCode("RewardRedemption.Amount.Invalid.Max")
                                            .withField(AMOUNT)
                                            .withMessage(messages.getMessage(
                                                            "RewardRedemption.Amount.Invalid.Max",
                                                            new Object[] {strFormattedH}))
                                            .build();

        } else if (target.getAmount().compareTo(lowThreshold) < 0) {
            // redeem amount can not below Minimum threshold
            LOG.info("redemption amout can not below Minimum threshold - {}. ",
                            lowThreshold.toString());
            String strFormattedL = BigNumbers.MoneyFormat.NEGATIVE_WITH_CURRENCY.formatter().format(
                            new BigDecimal(lowThreshold).divide(new BigDecimal("100")));
            violation = ConstraintViolations.newBeanViolation(target)
                                            .withCode("RewardRedemption.Amount.Invalid.Min")
                                            .withField(AMOUNT)
                                            .withMessage(messages.getMessage(
                                                            "RewardRedemption.Amount.Invalid.Min",
                                                            new Object[] {strFormattedL}))
                                            .build();

        } else {
            if (interval != null && interval.compareTo(BigInteger.ZERO) != 0) {
                BigInteger rm[] = target.getAmount().divideAndRemainder(interval);
                // if reminder is not 0, the amount does not meet interval
                if (rm[1].compareTo(BigInteger.ZERO) != 0) {
                    // redeem amount needs to be specified interval
                    LOG.info("Redemption amount has to be in increment - {}. ",
                                    interval.toString());
                    String strFormattedInv =
                                    BigNumbers.MoneyFormat.NEGATIVE_WITH_CURRENCY.formatter()
                                                                                 .format(new BigDecimal(
                                                                                                 interval).divide(
                                                                                                                 new BigDecimal("100")));
                    violation = ConstraintViolations.newBeanViolation(target)
                                                    .withCode("RewardRedemption.Amount.Invalid.Increment")
                                                    .withField(AMOUNT)
                                                    .withMessage(messages.getMessage(
                                                                    "RewardRedemption.Amount.Invalid.Increment",
                                                                    new Object[] {strFormattedInv}))
                                                    .build();
                }
            } else {
                LOG.warn("Redemption interval is not provided or 0. No interval validation performed.");
                // no increment requirement
            }
        }

        return violation;
    }

    /**
     * Helper method for looking up the CreditCardAccount based on either the index or credit card
     * number provided in the input. Will throw an InvalidEntityException if the account cannot be
     * found or if the account cannot receive rewards transfers.
     *
     * @param input The RewardsRedemption object that was submitted as input
     * @param customer The RewardsCustomer from the customerManager. Necessary for the SSN to look
     *        up a list of credit cards associated with the user
     * @return The CreditCardAccount based on the index or credit card number provided in the input
     */
    private CreditCardAccount lookupCreditCardAccount(Redemption input, Customer customer) {
        CreditCardAccount creditCardAccount = null;

        // If we're doing a rewards transfer to a card account, we need to look up information on
        // that account as well
        if (Redemptions.isTransfer(input.getRedemptionType())) {
            try {
                if (input.getToCreditCardAccount().getAccountNumber() != null) {
                    // Since they gave us a number, we need to look to see that the account is in
                    // good status and is eligible for the transfer
                    creditCardAccount = creditCardRepository.lookupCreditCardAccountByAccountNumber(
                                    input.getToCreditCardAccount()
                                         .getAccountNumber()
                                         .getValue());
                } else if (customer != null) {
                    // They didn't explicitly provide the account number, so look it up by id
                    creditCardAccount = creditCardRepository.lookupCreditCardAccountById(
                                    customer.getSocialSecurityNumber(),
                                    input.getToCreditCardAccount().getId());
                    // Check to make sure the customer is the primary or secondary on this account
                    if (!Redemptions.isPrimaryOrSecondaryAccountHolder(creditCardAccount,
                                    customer)) {
                        // The provided account is not eligible to receive rewards redemptions.
                        // Throw an invalid entity exception
                        Set<ConstraintViolation<Redemption>> violations =
                                        new HashSet<ConstraintViolation<Redemption>>();
                        violations.add(ConstraintViolations.newBeanViolation(input)
                                                           .withCode("RewardRedemption.ToCreditCardAccount.NotPrimaryOrSecondary")
                                                           .withField(TO_CREDIT_CARD_ACCOUNT)
                                                           .build());
                        ConstraintViolations.propagateIfPossible(violations);
                    }
                } else {
                    // We dont have an acct number or a customer, we cant find anything.
                    Set<ConstraintViolation<Redemption>> violations =
                                    new HashSet<ConstraintViolation<Redemption>>();
                    violations.add(ConstraintViolations.newBeanViolation(input)
                                                       .withCode("RewardRedemption.ToCreditCardAccount.AccountNotFound")
                                                       .withField(TO_CREDIT_CARD_ACCOUNT)
                                                       .build());
                    ConstraintViolations.propagateIfPossible(violations);
                }
            } catch (CreditCardsException e) {
                LOG.warn("We were not able to find a card account with the information provided. :: {}",
                                e);
                // We were not able to find a card account with the information provided. Throw an
                // InvalidEntityException
                Set<ConstraintViolation<Redemption>> violations =
                                new HashSet<ConstraintViolation<Redemption>>();
                violations.add(ConstraintViolations.newBeanViolation(input)
                                                   .withCode("RewardRedemption.ToCreditCardAccount.AccountNotFound")
                                                   .withField(TO_CREDIT_CARD_ACCOUNT)
                                                   .build());
                ConstraintViolations.propagateIfPossible(violations);

            }
        }

        return creditCardAccount;
    }

    public Iterable<Earnings> getEarnings(EarningsFilter filter, String id,
                    CustomerIdentification customerIdentification)
                    throws RewardsException, RewardsAccountNotFoundException {
        List<Earnings> earnings = new ArrayList<Earnings>();
        final String defRewardsStartDate = "01/01/2014";

        LOG.info("Starting getEarnings using filter " + filter);

        try {
            BankAccount account =
                            accountManager.findCustomerAccountById(customerIdentification, id);
            RewardsAccount rewardsAccount = new RewardsAccount(account);

            // Need to get the date that rewards started.
            Calendar rewardsStartDate = Calendar.getInstance();
            rewardsStartDate.setTime(Dates.parse(
                            props.get("General.RewardsEarningStartDate", defRewardsStartDate),
                            Format.BIG_ENDIAN_SLASH));

            // Can be found in /dynamic/api/config/global.properties

            // Validate that we have the best dates.
            final Calendar cal = Calendar.getInstance();
            Date openDate = rewardsAccount.getOpenDate();
            cal.setTime(openDate);

            Calendar earningsCuttoff = EarningsDates.getEarningsStartDate(cal, filter.getFromDate(),
                            rewardsStartDate);
            Calendar earningsEndDate = EarningsDates.getEarningsEndDate(filter.getToDate());

            List<EarningsDateGroup> earningsGroups = EarningsDates.getDateGroups(earningsCuttoff,
                            earningsEndDate, filter.getGroupBy());

            if (LOG.isDebugEnabled()) {
                LOG.debug("Getting earnings with Start: {}, End: {}, numGroups: {}",
                                new Object[] {earningsCuttoff.getTime(), earningsEndDate.getTime(),
                                                earningsGroups.size()});
            }

            for (EarningsDateGroup group : earningsGroups) {
                if (LOG.isDebugEnabled()) {
                    LOG.debug("Doing Earning lookup: Start {}, End: {}",
                                    new Object[] {group.getStartDate(), group.getEndDate()});
                }
                earnings.add(rewardsEarningsRepository.lookupRewardEarnings(rewardsAccount,
                                group.getStartDate(), group.getEndDate()));
            }
            LOG.info("Starting getEarnings");

        } catch (AccountNotFoundException e) {
            LOG.warn("AccountNotFoundException while trying to find the customer {} account by id:{}",
                            new Object[] {customerIdentification, id}, e);
            throw new RewardsAccountNotFoundException();
        }

        return earnings;
    }

    public EarningsV2 getEarningsV2(EarningsFilter filter, String id, int month,
                    CustomerIdentification customerIdentification)
                    throws RewardsException, RewardsAccountNotFoundException {
        List<Earnings> earnings = new ArrayList<Earnings>();

        LOG.info("Starting getEarnings using filter " + filter);

        try {
            BankAccount account =
                            accountManager.findCustomerAccountById(customerIdentification, id);
            RewardsAccount rewardsAccount = new RewardsAccount(account);

            // Need to get the date that rewards started.
            Calendar rewardsStartDate = Calendar.getInstance();

            Date now = Dates.now();
            rewardsStartDate.setTime(now);
            // display earning history of 13 months for default scenario
            int earningsDuration = (month == 12) ? (month + 1) * -1 : ((month) * -1);
            rewardsStartDate.add(Calendar.MONTH, earningsDuration);

            // Validate that we have the best dates.
            final Calendar cal = Calendar.getInstance();
            Date openDate = rewardsAccount.getOpenDate();
            cal.setTime(openDate);

            Calendar earningsCuttoff = EarningsDates.getEarningsStartDateV2(cal,
                            filter.getFromDate(), rewardsStartDate, earningsDuration);
            Calendar earningsEndDate = EarningsDates.getEarningsEndDate(filter.getToDate());

            List<EarningsDateGroup> earningsGroups = EarningsDates.getDateGroups(earningsCuttoff,
                            earningsEndDate, filter.getGroupBy());

            if (LOG.isDebugEnabled()) {
                LOG.debug("Getting earnings with Start: {}, End: {}, numGroups: {}",
                                new Object[] {earningsCuttoff.getTime(), earningsEndDate.getTime(),
                                                earningsGroups.size()});
            }

            for (EarningsDateGroup group : earningsGroups) {
                if (LOG.isDebugEnabled()) {
                    LOG.debug("Doing Earning lookup: Start {}, End: {}",
                                    new Object[] {group.getStartDate(), group.getEndDate()});
                }
                earnings.add(rewardsBucketsRepository.getRewardsBucketEarnings(
                                customerIdentification, rewardsAccount, group.getStartDate(),
                                group.getEndDate()));
            }
            LOG.info("Starting getEarnings");

        } catch (AccountNotFoundException e) {
            LOG.warn("AccountNotFoundException while trying to find the customer {} account by id:{}",
                            new Object[] {customerIdentification, id}, e);
            throw new RewardsAccountNotFoundException();
        }

        BigInteger total = BigInteger.ZERO;
        for (Earnings earning : earnings) {
            if (earning != null) {
                total = total.add(earning.getAmount());
            }
        }

        return EarningsV2.newBuilder()
                         .withTotalEarnings(total)
                         .withEarningsPeriods(earnings)
                         .build();
    }

    public List<Redemption> getHistory(String id, CustomerIdentification customerIdentification,
                    int months) throws RewardsException, RewardsAccountNotFoundException {
        List<Redemption> history = null;

        try {
            List<BankAccount> customerAccounts =
                            accountManager.findCustomerAccounts(customerIdentification);
            final BankAccount account = getAccountById(customerAccounts, id);

            history = rewardsRedemptionRepository.lookupRedemptionHistoryForAccount(
                            new RewardsAccount(account), months, customerAccounts);

            List<CreditCardAccount> creditCardAccounts = null;
            // go through the history to find if we have any transfers. If we do, we need to get the
            // acct data.
            for (ListIterator<Redemption> i = history.listIterator(); i.hasNext();) {
                final Redemption red = i.next();
                if (Redemptions.isTransfer(red.getRedemptionType())) {
                    try {
                        // This section will look up my accounts and try to match it.
                        if (creditCardAccounts == null) {
                            Customer cardCustomer =
                                            customerManager.findCustomer(customerIdentification);
                            creditCardAccounts = creditCardRepository.lookupCreditCardAccounts(
                                            cardCustomer.getSocialSecurityNumber());
                        }
                    } catch (CustomerNotFoundException e) {
                        LOG.warn("CustomerNotException while trying to find the customer to get their CC accounts. {}",
                                        e);
                    } catch (CreditCardsException e) {
                        LOG.warn("CreditCardsException while trying to get the CC accounts for a customer. {}",
                                        e);
                    }

                    matchCreditCardForRedemption(creditCardAccounts, i, red);
                } else if (Redemptions.isDeposit(red.getRedemptionType())) {
                    Redemption redemptionForDeposit = null;
                    // go through my accounts to see if we match anything...
                    for (BankAccount customerAccount : customerAccounts) {
                        if (Objects.equal(red.getToAccount().getAccountNumber(),
                                        customerAccount.getAccountNumber())) {
                            redemptionForDeposit =
                                            Redemption.newBuilder()
                                                      .from(red)
                                                      .withToAccount(customerAccount)
                                                      .build();
                            break;
                        }
                    }
                    if (redemptionForDeposit != null) {
                        i.set(redemptionForDeposit);
                    }
                }
            }
        } catch (AccountNotFoundException e) {
            LOG.warn("AccountNotFoundException while trying to find the customer {} account by id:{}",
                            new Object[] {customerIdentification, id}, e);
            throw new RewardsAccountNotFoundException();
        }


        return history;
    }

    private void matchCreditCardForRedemption(List<CreditCardAccount> creditCardAccounts,
                    ListIterator<Redemption> i, final Redemption red) {
        // redemption with card
        Redemption redWCard = null;
        // go through my accounts to see if we match anything...
        for (CreditCardAccount cc : creditCardAccounts) {
            if (Objects.equal(red.getToCreditCardAccount().getAccountNumber(),
                            cc.getAccountNumber())) {
                redWCard = Redemption.newBuilder().from(red).withToCreditCardAccount(cc).build();
                break;
            }
        }
        // end my accounts lookup.

        // If its not one of "my" accts then we dont really need to look it up. We can
        // totes just insert a standard nick name.
        if (redWCard == null) { // not our account... so we need to look it up?!!
            redWCard = Redemption.newBuilder()
                                 .from(red)
                                 .withToCreditCardAccount(CreditCardAccount.newBuilder()
                                                                           .withAccountNumber(
                                                                                           red.getToCreditCardAccount()
                                                                                              .getAccountNumber())
                                                                           .withNickName("Discover Credit Card")
                                                                           .build())
                                 // Note The way we get this CC --> the nickname is
                                 // different
                                 // the the above way. Just keep that in mind.
                                 .build();
        }
        // end not my account lookup

        // if after all that craziness we actually did change the CC then we should
        // probably set it.
        if (redWCard != null) {
            i.set(redWCard);
        }
    }


    protected BankAccount getAccountById(List<BankAccount> customerAccounts, String id)
                    throws RewardsAccountNotFoundException {
        if (Strings.isNullOrEmpty(id)) {
            LOG.error("Can not find acccount with null/bank id.");
            throw new RewardsAccountNotFoundException();
        }

        BankAccount account = null;
        for (BankAccount customerAccount : customerAccounts) {
            if (id.equalsIgnoreCase(customerAccount.getId())
                            || id.equalsIgnoreCase(customerAccount.getAlternateAccountNumber())) {
                account = customerAccount;
                break;
            }
        }

        if (account == null) {
            LOG.error("Could not find account {} for customer", id);
            throw new RewardsAccountNotFoundException();
        }

        return account;
    }

    /**
     * This method returns the list of eligible accounts for one time or auto redemption for the
     * given customer
     * 
     * @param customer -customer ID set
     * @param eligibilityType - auto/onetime
     */
    public EligibleAccounts getEligibleAccounts(CustomerIdentification customer,
                    String eligibilityType) throws RewardsException {
        EligibleAccounts eligibleAccounts = null;
        LOG.info("Calling the eligibleAccountsRepository");
        Map<String, List<String>> eligibleAccountIDs =
                        eligibleAccountsRepository.getEligibleAccounts(customer, eligibilityType);
        if (!eligibleAccountIDs.isEmpty()) {
            eligibleAccounts = prepareCustomerEligibleAccounts(customer, eligibleAccountIDs);
        }
        return eligibleAccounts;
    }

    private EligibleAccounts prepareCustomerEligibleAccounts(CustomerIdentification customer,
                    Map<String, List<String>> eligibleAccountIDs) {
        List<BankAccount> customerAccounts = accountManager.findCustomerAccounts(customer);
        List<RewardsEligibleAccount> redemptionSourceAccounts =
                        getAccountsList(eligibleAccountIDs.get("Source"), customerAccounts);
        List<RewardsEligibleAccount> redemptionTargetAccounts =
                        getAccountsList(eligibleAccountIDs.get("Target"), customerAccounts);
        return EligibleAccounts.newInstance()
                               .withSourceEligibleAccounts(redemptionSourceAccounts)
                               .withTargetEligibleAccounts(redemptionTargetAccounts)
                               .withDisclaimer(props.get(REDEMPTION_DISCLAIMER))
                               .build();
    }

    private List<RewardsEligibleAccount> getAccountsList(List<String> accountIDS,
                    List<BankAccount> customerAccounts) {
        List<RewardsEligibleAccount> redemptionAccounts = new ArrayList<RewardsEligibleAccount>();

        for (BankAccount custAccount : customerAccounts) {
            if (accountIDS.contains(custAccount.getAlternateAccountNumber())) {
                redemptionAccounts.add(new RewardsEligibleAccount(
                                BankAccount.newBuilder(custAccount).build()));
            }
        }
        return redemptionAccounts;
    }

    /**
     * Perform auto redemption enrollment for the specified account and the provided autoRedemption
     * info
     * 
     * @param customer
     * @param accountId rewardsAccount id
     * @param input - specified autoRedemption info
     * @return
     * @throws RewardsException
     * @throws CustomerNotFoundException
     */
    public EnrollEditAutoRedemption enrollAutoRedemption(final CustomerIdentification customerId,
                    final String accountId, final EnrollEditAutoRedemption input)
                    throws AccountNotFoundException, CustomerNotFoundException, RewardsException {

        // Basic Validation on Auto Redemption Input
        validateAutoRedemptionInput(accountId, input);

        // get eligibility accountIds
        EligibleAccounts eligibleAccounts = getEligibleAccounts(customerId, "auto");

        final Customer customer = customerManager.findCustomer(customerId);

        if (eligibleAccounts == null) {
            LOG.error("No eligibleAccounts. AccountId: {} provided is not eligible for enrolling Auto Redemption",
                            accountId);
            throw new UnrecoverableRedemptionException();
        }

        // check source account eligibility
        BankAccount fromAccount = validateSourceAccountInput(eligibleAccounts, accountId);

        // Validate input
        BankAccount toAccount = validateTargetAccountInput(eligibleAccounts, input.getToAccount());

        List<AutoRedemptionAccount> autoRedemptionAccounts = getValidateAutoRedemptionAccounts(
                        customerId, Arrays.asList(fromAccount.getAccountNumber().getValue()),
                        Arrays.asList(fromAccount));

        // Get the status of the account and throw an error If already enrolled
        if (autoRedemptionAccounts.get(0) != null
                        && autoRedemptionAccounts.get(0).getIsEnrolled()) {
            LOG.error("Account {} is already enrolled in auto redemption", accountId);
            throw new UnrecoverableRedemptionException("already.enrolled.autoredemption");
        }

        // check reward balance to determine if oneTimeRedemption should be called
        RewardsAccount updatedFromAccount =
                        populateRewardAccountBalance(new RewardsAccount(fromAccount));

        Redemption oneTimeRedemption = null;
        boolean oneTimeRedemptionPerformed = false;

        // check rewardsAccount rewards balance
        // one time redemption should be performed only when rewards available balance > 0
        BigInteger availableBalance = updatedFromAccount.getRewardsBalance().getAvailableBalance();

        if (availableBalance.compareTo(new BigInteger("0")) > 0) {

            LOG.info("Perform one time redemption for account {} with balance {}", accountId,
                            updatedFromAccount.getRewardsBalance().getAvailableBalance());

            // Build input redemption for onetime redemption call
            Redemption inputRedemption = Redemption.newBuilder()
                                                   .withFromRewardsAccount(updatedFromAccount)
                                                   .withToAccount(new RewardsAccount(toAccount))
                                                   .withToCreditCardAccount(null)
                                                   .withRedemptionType("deposit")
                                                   .withAmount(availableBalance)
                                                   .build();

            Redemption result = redeemRewards(inputRedemption,
                            customer);

            // Make repository call and get back the response
            oneTimeRedemption = Redemption.newBuilder()
                                          .withRedemptionType(result.getRedemptionType())
                                          .withConfirmationNumber(result.getConfirmationNumber())
                                          .withAmount(availableBalance)
                                          .build();

            oneTimeRedemptionPerformed = true;
        }

        // TODO - check if account has already enrolled once the operation is available
        LOG.info("Ready to enroll auto redemption for accountId {} and customer {} ", accountId,
                        customerId.getCustomerNumber());

        // perform enrollAutoRedemption
        autoRedemptionRepository.enrollOrEditAutoRedemption(customerId,
                        fromAccount.getAccountNumber().getValue(),
                        toAccount.getAccountNumber().getValue(), ENROLL);


        // trigger enrollment email
        emailRepository.sendConfirmationEmail(customer, fromAccount,toAccount, ENROLL);

        return EnrollEditAutoRedemption.newBuilder()
                                       .withFromAccount(fromAccount)
                                       // To remove 'type'(financialAgreementType) in response
                                       .withToAccount(BankAccount.newBuilder()
                                                                 .setId(toAccount.getId())
                                                                 .setAccountNumber(
                                                                                 toAccount.getAccountNumber())
                                                                 .setNickName(toAccount.getNickName())
                                                                 .build())
                                       .withDidOneTimeRedemption(oneTimeRedemptionPerformed)
                                       .withOneTimeRedemption(oneTimeRedemption)
                                       .withBannerText(oneTimeRedemptionPerformed
                                                       ? props.get("Redemption.Enroll.OnetimeDone")
                                                       : props.get("Redemption.Enroll.OnetimeNotDone"))
                                       .build();
    }

    /**
     * populate RewardAccount rewards balance
     * 
     * @param rewardsAccount
     * @return
     */
    protected RewardsAccount populateRewardAccountBalance(RewardsAccount rewardsAccount) {
        // populate reward account's balance
        for (RewardsAccountEnricher<RewardsAccount> enricher : accountEnrichers) {
            enricher.enrich(rewardsAccount);
        }

        return rewardsAccount;
    }

    /**
     * validate the from accountId for enroll/edit auto redemption
     * 
     * @param eligibleAccounts
     * @param accountId
     * @return
     */
    protected BankAccount validateSourceAccountInput(EligibleAccounts eligibleAccounts,
                    String accountId) {

        List<RewardsEligibleAccount> redemptionAccounts =
                        eligibleAccounts.getSourceEligibleAccounts();

        BankAccount fromAccount = null;
        for (BankAccount bankAccount : redemptionAccounts) {
            if (accountId.equals(bankAccount.getId())) {
                fromAccount = bankAccount;
                break;
            }
        }

        if (fromAccount == null) {
            LOG.warn("accountId:{} provided is not eligibile for enroll/edit AutoRedemption",
                            accountId);
            throw new UnrecoverableRedemptionException("account.not.found");
        }

        return fromAccount;

    }

    /**
     * validate the enroll/edit AutoRedemption input/toAccount eligibility
     * 
     * @param eligibleAccounts
     * @param input
     * @return
     */
    protected BankAccount validateTargetAccountInput(EligibleAccounts eligibleAccounts,
                    BankAccount input) {

        List<RewardsEligibleAccount> redemptionAccounts =
                        eligibleAccounts.getTargetEligibleAccounts();

        BankAccount toAccount = null;
        for (BankAccount bankAccount : redemptionAccounts) {
            if (input.getId().equals(bankAccount.getId())) {
                toAccount = bankAccount;
                break;
            }
        }

        if (toAccount == null) {

            LOG.warn("toAccount:{} is not eligible for autoRedemption", input.getId());

            Set<ConstraintViolation<BankAccount>> violations =
                            new HashSet<ConstraintViolation<BankAccount>>();

            violations.add(ConstraintViolations.newBeanViolation(input)
                                               .withCode("invalid.account")
                                               .withMessage(messages.getMessage(
                                                               "enroll.redemption.invalid.account"))
                                               .withField(TO_ACCOUNT)
                                               .build());

            ConstraintViolations.propagateIfPossible(violations);
        }

        return toAccount;

    }

    public EditAutoRedemptionResponse editAutoRedemption(CustomerIdentification customer,
                    String accountId, EnrollEditAutoRedemption input) throws RewardsException {

        // Basic Validation on Auto Redemption Input
        validateAutoRedemptionInput(accountId, input);

        // get eligibility accountIds
        EligibleAccounts eligibleAccounts = getEligibleAccounts(customer, "auto");

        if (eligibleAccounts == null) {
            LOG.error("No eligibleAccounts. AccountId: {} provided is not eligible for enrolling/edit Auto Redemption",
                            accountId);
            throw new UnrecoverableRedemptionException();
        }

        // check source account eligibility
        BankAccount fromAccount = validateSourceAccountInput(eligibleAccounts, accountId);

        // validate toAccount - input
        BankAccount toAccount = validateTargetAccountInput(eligibleAccounts, input.getToAccount());

        // Add target accounts and source account
        List<BankAccount> customerAccounts = convertRewardsTargetEligibleAccountToBankAccount(
                        eligibleAccounts.getTargetEligibleAccounts());
        customerAccounts.add(fromAccount);

        // Get the status of the account
        List<AutoRedemptionAccount> autoRedemptionAccounts = getValidateAutoRedemptionAccounts(
                        customer, Arrays.asList(fromAccount.getAccountNumber().getValue()),
                        customerAccounts);

        AutoRedemptionAccount autoRedemptionAccount = autoRedemptionAccounts.get(0);

        // If not enrolled then throw error
        if (autoRedemptionAccount == null || !autoRedemptionAccount.getIsEnrolled()) {
            LOG.error("The Source Account {} is not enrolled.", accountId);
            throw new UnrecoverableRedemptionException("auto.not.enabled");
        }

        // perform Edit AutoRedemption only if toAccount is not same as existing one
        if (!autoRedemptionAccount.getToAccount().getId().equalsIgnoreCase(toAccount.getId())) {
            autoRedemptionRepository.enrollOrEditAutoRedemption(customer,
                            fromAccount.getAccountNumber().getValue(),
                            toAccount.getAccountNumber().getValue(), EDIT_ENROLL);
        }

        // trigger enrollment email
        emailRepository.sendConfirmationEmail(customerManager.findCustomer(customer), fromAccount,toAccount, EDIT_ENROLL);
        
        return EditAutoRedemptionResponse.newBuilder()
                                         .withToAccount(toAccount)
                                         .withFromAccount(fromAccount)
                                         .build();
    }

    protected List<BankAccount> convertRewardsTargetEligibleAccountToBankAccount(
                    List<RewardsEligibleAccount> rewardsEligibleAccounts) {

        List<BankAccount> bankAccounts = new ArrayList<BankAccount>();

        for (RewardsEligibleAccount rewardsEligibleAccount : rewardsEligibleAccounts) {
            bankAccounts.add(rewardsEligibleAccount);
        }

        return bankAccounts;
    }

    /**
     * validate the Basic AutoRedemption input
     * 
     * @param accountId
     * @param input
     * @return
     */
    protected void validateAutoRedemptionInput(String accountId, EnrollEditAutoRedemption input) {

        LOG.info("Performing general validation on input {}", input);

        Set<ConstraintViolation<EnrollEditAutoRedemption>> violations =
                        new HashSet<ConstraintViolation<EnrollEditAutoRedemption>>();

        if (input == null || input.getToAccount().getId() == null
                        || input.getToAccount().getId().length() == 0) {
            LOG.info("Input {}  for Enroll/Edit AutoRedemption: is invalid", input);
            violations.add(ConstraintViolations.newBeanViolation(input)
                                               .withCode("invalid.account")
                                               .withMessage(messages.getMessage(
                                                               "enroll.redemption.invalid.account"))
                                               .withField(TO_ACCOUNT)
                                               .build());
        }

        ConstraintViolations.propagateIfPossible(violations);

        LOG.info("Input Enroll/Edit AutoRedemption: {} and accountId: {}", input, accountId);
    }

    public AutoRedemptionResponse getAutoRedemption(CustomerIdentification customerId, String accountId) {	
	
        LOG.info("Trying to get auto redemption for account {}, customer {}", accountId,	
                        customerId);	
	
        // Will be replaced once the code update is complete	
        return AutoRedemptionResponse.newBuilder()	
                                     .withIsEnrolled(false)	
                                     .withToAccount(BankAccount.newBuilder(	
                                                     MockAccountBuilder.newCheckingAccountBuilder()	
                                                                       .build())	
                                                               .setId(accountId)	
                                                               .build())	
                                     .build();	
    }
    
    public AutoRedemptionResponse deleteAutoRedemption(CustomerIdentification customerId,
                    String accountId) {

        // Get customer accounts
        List<BankAccount> customerAccounts = accountManager.findCustomerAccounts(customerId);

        BankAccount matchedAccount = findMatchingAccount(customerAccounts, accountId);

        // Throw error if it doesn't belong to customer
        if (matchedAccount == null) {
            LOG.error("Account {} does not belong to the customer {}", accountId, customerId);
            throw new UnrecoverableRedemptionException("invalid.account");
        }

        // Get the status of the account
        List<AutoRedemptionAccount> autoRedemptionAccounts = getValidateAutoRedemptionAccounts(
                        customerId, Arrays.asList(matchedAccount.getAccountNumber().getValue()),
                        customerAccounts);

        AutoRedemptionAccount autoRedemptionAccount = autoRedemptionAccounts.get(0);

        // If enrolled, proceed with delete operation
        if (autoRedemptionAccount.getIsEnrolled()) {
            autoRedemptionRepository.deleteAutoRedemption(customerId, autoRedemptionAccount);
        }

        // trigger enrollment email
        emailRepository.sendConfirmationEmail(customerManager.findCustomer(customerId),
        		matchedAccount,null,
                        UN_ENROLL);
        // Return this if it is not enrolled or successfully removed enrollment
        return AutoRedemptionResponse.newBuilder()
                                     .withId(accountId)
                                     .withMessage(props.get("remove.auto.enrollment.success.message"))
                                     .build();
    }

    public List<AutoRedemptionAccount> getAutoRedemptionAccountsStatus(
                    CustomerIdentification customerId, List<String> accountIds) {

        List<AutoRedemptionAccount> redemptionAccountList = new ArrayList<AutoRedemptionAccount>();

        // If no account id's are passed just give back empty response
        if (accountIds == null || accountIds.isEmpty()) {
            LOG.info("Input account List is null");
            return redemptionAccountList;
        }

        List<String> sourceAccountNumbers = new ArrayList<String>();

        // get customer accounts
        List<BankAccount> customerAccounts = accountManager.findCustomerAccounts(customerId);

        // loop through the ids
        for (String accountId : accountIds) {

            BankAccount matchedAccount = findMatchingAccount(customerAccounts, accountId);

            // If no match found for an account
            if (matchedAccount == null) {
                LOG.warn("Account {} doesn't exist or doesn't belong to the customer- {}",
                                accountId, customerId);

                // Add with an error code and description
                redemptionAccountList.add(AutoRedemptionAccount.getBuilder()
                                                               .withId(accountId)
                                                               .withError(true)
                                                               .withErrorDescription(
                                                                               "Account doesn't exist or doesn't belong to the customer")
                                                               .build());
                // Do not add this to BI call input
                continue;
            }

            sourceAccountNumbers.add(matchedAccount.getAccountNumber().getValue());
        }

        // If it is empty, there are no valid account to make repo call
        if (sourceAccountNumbers.isEmpty()) {
            return redemptionAccountList;
        }

        // Update the output to add redemption details and then add it to existing invalid accounts
        redemptionAccountList.addAll(
                        updateRedemptionDetails(
                                        getValidateAutoRedemptionAccounts(customerId,
                                                        sourceAccountNumbers, customerAccounts),
                                        customerId, customerAccounts));

        return redemptionAccountList;
    }

    protected BankAccount findMatchingAccount(List<BankAccount> customerAccounts,
                    String accountId) {

        BankAccount matchedAccount = null;

        // Match the input account id with customer accounts list
        for (BankAccount account : customerAccounts) {
            if (accountId.equalsIgnoreCase(account.getId())) {
                matchedAccount = account;
                break;
            }
        }

        return matchedAccount;
    }

    protected List<AutoRedemptionAccount> getValidateAutoRedemptionAccounts(
                    CustomerIdentification customerId, List<String> sourceAccountNumbers,
                    List<BankAccount> customerAccounts) {

        EnrollmentDetailsInput enrollmentDetailsInput = new EnrollmentDetailsInput();
        // Set input account numbers
        enrollmentDetailsInput.setSourceAccountNumbers(sourceAccountNumbers);

        List<AutoRedemptionAccount> autoRedemptionAccounts =
                        autoRedemptionRepository.getAutoRedemptionAccountsStatus(customerId,
                                        enrollmentDetailsInput, customerAccounts);

        if (autoRedemptionAccounts == null || autoRedemptionAccounts.isEmpty()) {
            LOG.error("Error while fetching auto redemption details");
            throw new UnrecoverableRedemptionException();
        }

        return autoRedemptionAccounts;
    }

    protected List<AutoRedemptionAccount> updateRedemptionDetails(
                    List<AutoRedemptionAccount> redemptionAccountList,
                    CustomerIdentification customerId, List<BankAccount> customerAccounts) {

        List<AutoRedemptionAccount> updatedRedemptionAccountList =
                        new ArrayList<AutoRedemptionAccount>();

        // Loop through the response accounts
        for (AutoRedemptionAccount autoRedemptionAccount : redemptionAccountList) {

            AutoRedemptionAccount updatedAutoRedemptionAccount = null;

            // Enrolled
            if (autoRedemptionAccount.getIsEnrolled()) {

                // Get history call for past year to get lastRedemptionDate and lastRedemptionAmount
                List<Redemption> redemptions = null;

                try {
                    redemptions = getHistory(autoRedemptionAccount.getId(), customerId, 12);
                } catch (Exception e) {
                    LOG.warn("Exception {} occured while fetching history for account {}",
                                    autoRedemptionAccount.getId(), e);
                }

                // If history is null, then redemption is not done
                if (redemptions == null || redemptions.isEmpty()) {

                    updatedAutoRedemptionAccount =
                                    AutoRedemptionAccount.newBuilder(autoRedemptionAccount)
                                                         .withHasRedeemed(false)
                                                         .build();
                } else {
                    // Get the lastRedemptionDate and lastRedemptionAmount from the sorted first
                    // item which is latest
                    updatedAutoRedemptionAccount =
                                    AutoRedemptionAccount.newBuilder(autoRedemptionAccount)
                                                         .withHasRedeemed(true)
                                                         .withLastRedemptionDate(
                                                                         redemptions.get(0)
                                                                                    .getOrderDate())
                                                         .withLastRedemptionAmount(
                                                                         redemptions.get(0)
                                                                                    .getAmount())
                                                         .build();
                }

                updatedRedemptionAccountList.add(updatedAutoRedemptionAccount);
            } else {

                // Get the corresponding bank account to fetch rewards balance
                BankAccount account = null;

                try {
                    account = getAccountById(customerAccounts, autoRedemptionAccount.getId());
                } catch (Exception e) {
                    LOG.warn("Account {} not found exception", autoRedemptionAccount.getId(), e);
                }

                updatedRedemptionAccountList.add(
                                AutoRedemptionAccount.newBuilder(autoRedemptionAccount)
                                                     .withRewardsBalance(getRewardsBalancePopulated(
                                                                     account))
                                                     .build());
            }
        }

        return updatedRedemptionAccountList;
    }

    protected BigInteger getRewardsBalancePopulated(BankAccount account) {

        BigInteger balance = null;

        if (account != null) {

            RewardsBalance rewardsBalance = populateRewardAccountBalance(
                            new RewardsAccount(account)).getRewardsBalance();

            // If balance available
            if (rewardsBalance != null) {

                balance = rewardsBalance.getAvailableBalance();
                LOG.info("Available balance {}, Current balance {} of the account {}",
                                rewardsBalance.getAvailableBalance(),
                                rewardsBalance.getCurrentBalance(), account.getId());
            }
        }

        return balance;
    }

    /**
     * retrieved the redemptionLimit per redemption info from redemption rules
     * 
     * @param redemption
     * @return RedemptionLimit
     */
    protected RedemptionLimit getRedemptionLimit(Redemption redemption) {

        LOG.info("Retrieving redemption limit for redemptionType as {}",
                        redemption.getRedemptionType());

        if (redemption.getToCreditCardAccount() != null) {
            if (redemption.getToCreditCardAccount().getId() != null) {
                LOG.info("******toAccount.id as {}", redemption.getToCreditCardAccount().getId());
            } else {
                LOG.info("******toAccount.id is null");
            }
        }

        RedemptionLimit limit = new RedemptionLimit();
        redemptionLimitRules.newContext()
                            .add("redemption", redemption)
                            .add("limit", limit)
                            .evaluate();

        LOG.info("Retrieved redemptionLimit - maximum={}, minimum={}, increment="
                        + limit.getIncrement(), limit.getMaximum(), limit.getMinimum());

        return limit;
    }

    /********************* Setters *********************/
    public void setRewardsRedemptionRepository(RedemptionRepository rewardsRedemptionRepository) {
        this.rewardsRedemptionRepository = rewardsRedemptionRepository;
    }

    public void setBankAccountManager(BankAccountManager accountManager) {
        this.accountManager = accountManager;
    }

    public void setCreditCardRepository(CreditCardAccountRepository creditCardRepository) {
        this.creditCardRepository = creditCardRepository;
    }

    public void setCustomerManager(CustomerManager customerManager) {
        this.customerManager = customerManager;
    }

    public void setEmailRepository(EmailRepository emailRepository) {
        this.emailRepository = emailRepository;
    }

    public void setValidator(Validator validator) {
        this.validator = validator;
    }

    public void setEarningsRepository(EarningsRepository rewardsEarningsRepository) {
        this.rewardsEarningsRepository = rewardsEarningsRepository;
    }

    public void setRewardsBucketsRepository(RewardsBucketRepository rewardsBucketsRepository) {
        this.rewardsBucketsRepository = rewardsBucketsRepository;
    }

    public void setEligibleAccountsRepository(
                    EligibleAccountsRepository eligibleAccountsRepository) {
        this.eligibleAccountsRepository = eligibleAccountsRepository;
    }

    public void setAutoRedemptionRepository(AutoRedemptionRepository autoRedemptionRepository) {
        this.autoRedemptionRepository = autoRedemptionRepository;
    }

    public void setPropertyAccessor(PropertyAccessor props) {
        this.props = props;
    }

    @Inject
    @Named("redemption-limit-rules")
    public void setRedemptionLimitRules(RuleSet limits) {
        this.redemptionLimitRules = limits;
    }
}
