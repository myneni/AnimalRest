package com.discover.bank.api.rewards.earnings;

import java.math.BigInteger;
import java.util.List;

import com.discover.bank.api.databind.Money;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = Earnings.Builder.class)
public abstract class EarningsMixin {

    @JsonProperty
    public abstract String getIntervalStart();

    @JsonProperty
    public abstract String getIntervalEnd();

    @JsonProperty
    @Money
    public abstract BigInteger getAmount();

    @JsonProperty
    public abstract List<TypeMixin> getTypes();

    public static abstract class TypeMixin {

        @JsonProperty
        public abstract String getName();

        @JsonProperty
        @Money
        public abstract BigInteger getAmount();


    }
}
