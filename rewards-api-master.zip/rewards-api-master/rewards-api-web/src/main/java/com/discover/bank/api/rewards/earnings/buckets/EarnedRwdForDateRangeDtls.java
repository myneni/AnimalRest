package com.discover.bank.api.rewards.earnings.buckets;

import com.discover.bank.api.rewards.earnings.buckets.EarnedRwdForDateRangeDtls.Builder;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/**
 * @author rsridha
 *
 */
@JsonDeserialize(builder = Builder.class)
public class EarnedRwdForDateRangeDtls {

    private String earnedRwdType;
    private RewardsEarnAmount earnedRwdAmt;

    private EarnedRwdForDateRangeDtls(EarnedRewards p) {
        this.earnedRwdType = p.earnedRwdType;
        this.earnedRwdAmt = p.earnedRwdAmt;
    }

    public String getEarnedRwdType() {
        return earnedRwdType;
    }

    public RewardsEarnAmount getEarnedRwdAmt() {
        return earnedRwdAmt;
    }

    public static Builder newInstance() {
        return new Builder();
    }

    public static Builder newInstance(EarnedRwdForDateRangeDtls earnedRwdForDateRangeDtls) {
        return new Builder(earnedRwdForDateRangeDtls);
    }

    public static class Builder {

        private final EarnedRewards p;

        private Builder() {
            this.p = new EarnedRewards();
        }

        public Builder(EarnedRwdForDateRangeDtls p) {
            this.p = new EarnedRewards();
            this.p.earnedRwdAmt = p.earnedRwdAmt;
            this.p.earnedRwdType = p.earnedRwdType;
        }

        @JsonProperty
        public Builder withEarnedRwdType(String earnedRwdType) {
            p.earnedRwdType = earnedRwdType;
            return this;
        }

        @JsonProperty
        public Builder withEarnedRwdAmt(RewardsEarnAmount earnedRwdAmt) {
            p.earnedRwdAmt = earnedRwdAmt;
            return this;
        }

        public EarnedRwdForDateRangeDtls build() {
            return new EarnedRwdForDateRangeDtls(p);
        }
    }

    private static class EarnedRewards {
        private String earnedRwdType;
        private RewardsEarnAmount earnedRwdAmt;
    }
}
