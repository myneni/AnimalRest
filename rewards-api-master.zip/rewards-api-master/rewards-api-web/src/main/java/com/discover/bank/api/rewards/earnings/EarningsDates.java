package com.discover.bank.api.rewards.earnings;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.discover.bank.api.rewards.earnings.EarningsFilter.GroupBy;
import com.discover.common.base.Dates;


public class EarningsDates {

    private static final Logger LOG = LoggerFactory.getLogger(EarningsDates.class);



    /*
     *
     * Refactor this to be able to do the below?
     * 
     * EarningsGroupCalculator calc = EarningsGroupCalculator .newInstance( MessageSource ) //
     * Optional.. if a message source is passed, we can use the date from it... if not pick a hard
     * date... .account( Account ) // this will be the account open date, or any other information
     * we might used from the account .min( date ) // min/max -or- the filter? .max( date )
     * .groupBy( ... ) .pairs() // compose
     * 
     * // get pairs by GroupBy List<Pair<Date, Date>> pairs = calc.getGroupsBy( GroupBy )
     * 
     */



    // You cant have me even if you wanted me.
    private EarningsDates() {

    }


    /**
     * We have a constraint such that we can only show earnings as far back as X.<br>
     * X is defined as the latest day in the group { 2 years ago, day rewards started, accountOpen,
     * fromDate }<br>
     * 
     * @param accountOpen The day the account opened.
     * @param fromDate The date in which we are looking to filter by.
     * @return The Latest date in the list { 2 years ago, day rewards started, accountOpen, fromDate
     *         }
     */
    public static Calendar getEarningsStartDate(Calendar accountOpen, Calendar fromDate,
                    Calendar rewardsStart) {
        Collection<Calendar> dates = new ArrayList<Calendar>();

        Date now = Dates.now();

        Calendar twoYears = Calendar.getInstance();
        twoYears.setTime(now);
        twoYears.add(Calendar.YEAR, -2);
        dates.add(twoYears);

        // We dont know much... but we know that you cant start rewards in the future...
        Calendar today = Calendar.getInstance();
        today.setTime(now);

        LOG.debug("Trying to determine what our start date is! Today is: {}", today.getTime());
        LOG.debug("Adding 2yearsAgo as an option: {}", twoYears.getTime());


        if (accountOpen != null && today.after(accountOpen)) {
            LOG.debug("Adding accountOpen as an option: {}", accountOpen.getTime());
            dates.add(accountOpen);
        }

        if (fromDate != null && today.after(fromDate)) {
            LOG.debug("Adding filter 'From Date' as an option: {}", fromDate.getTime());
            dates.add(fromDate);
        }

        if (rewardsStart != null && today.after(rewardsStart)) {
            LOG.debug("Adding rewards start date as an option: {}", rewardsStart.getTime());
            dates.add(rewardsStart);
        }
        Calendar start = Collections.max(dates);

        LOG.debug("Found start date to be {}.", start.getTime());
        return start;
    }

    public static Calendar getEarningsStartDateV2(Calendar accountOpen, Calendar fromDate,
                    Calendar rewardsStart, int month) {
        Collection<Calendar> dates = new ArrayList<Calendar>();

        Date now = Dates.now();

        Calendar oneYears = Calendar.getInstance();
        oneYears.setTime(now);
        oneYears.add(Calendar.MONTH, month);
        dates.add(oneYears);

        // We dont know much... but we know that you cant start rewards in the future...
        Calendar today = Calendar.getInstance();
        today.setTime(now);

        LOG.debug("Trying to determine what our start date is! Today is: {}", today.getTime());
        LOG.debug("Adding {} monthsAgo as an option: {}", month,oneYears.getTime());


        if (accountOpen != null && today.after(accountOpen)) {
            LOG.debug("Adding accountOpen as an option: {}", accountOpen.getTime());
            dates.add(accountOpen);
        }

        if (fromDate != null && today.after(fromDate)) {
            LOG.debug("Adding filter 'From Date' as an option: {}", fromDate.getTime());
            dates.add(fromDate);
        }

        if (rewardsStart != null && today.after(rewardsStart)) {
            LOG.debug("Adding rewards start date as an option: {}", rewardsStart.getTime());
            dates.add(rewardsStart);
        }
        
        return transformDate(dates, rewardsStart);
    }

    private static Calendar transformDate(Collection<Calendar> dates, Calendar rewardsStart) {

        Calendar start = Collections.max(dates);
        if (start != null && rewardsStart != null && rewardsStart.after(start)) {
            start = rewardsStart;
        }

        if (null != start) {
            start.set(Calendar.DAY_OF_MONTH, 1);
            LOG.debug("Found start date to be {}.", start.getTime());
        }

        return start;
    }

    /**
     * We want to make sure the end date is not further then today. OR after our from date.
     * 
     * @param toDate The last day the CM wants to be returned.
     * @param fromDate The first day the CM wants to be returned.
     * @return The date the meets the requirements.
     */
    public static Calendar getEarningsEndDate(Calendar toDate) {
        // Sanity Check... we need to have a fallback date!
        Calendar endOfLastMonth = Calendar.getInstance();
        endOfLastMonth.setTime(Dates.now());

        // Set the day of the month to the first
        endOfLastMonth.set(Calendar.DAY_OF_MONTH, 1);
        // remove 1 day so its the last day of last month.
        endOfLastMonth.add(Calendar.DAY_OF_MONTH, -1);


        if (toDate == null || endOfLastMonth.before(toDate)) {
            return endOfLastMonth;
        } else {
            return toDate;
        }
    }

    /**
     *
     * This methods intentions are to give you a list of grouped buckets that your start/end date
     * fit into.
     *
     * @param start The start date you want to get bucketed
     * @param end The last date you want bucketed.
     * @param group The way you want to group by. EarningsFilter.GroupBy.MONTH and YEAR are the only
     *        valid inputs. Anything else will likely give you something you dont want.
     * @return A list of Dates in buckets by group type.
     */
    public static List<EarningsDateGroup> getDateGroups(Calendar startDate, Calendar endDate,
                    GroupBy group) {
        List<EarningsDateGroup> interval = new ArrayList<EarningsDateGroup>();

        int calendarPivot = 0;
        GroupBy dateGroup = group;
        if (dateGroup == null) {
            dateGroup = GroupBy.FULL;
        }

        switch (dateGroup) {
            case MONTH:
                calendarPivot = Calendar.DAY_OF_MONTH;
                break;
            case YEAR:
                calendarPivot = Calendar.DAY_OF_YEAR;
                break;
            case FULL:
                // no break b/c we want to just return the default; Also part of me hopes this adds
                // technical debt!!
            default:
                // There is really no way to get here unless you are FULL... but i got spoken to
                // about it so...
                interval.add(new EarningsDateGroup(startDate.getTime(), endDate.getTime()));
                return interval;
        }

        // Hey look at me, I am a stupid calendar that cant replicate another calendar unless i use
        // clone().
        Calendar start = Calendar.getInstance();
        start.setTime(startDate.getTime());
        // I fear attack of the clones, so i refuse to use the object clone() method.

        while (start.before(endDate)) {
            // The min is going to be where we are now.
            Date min = start.getTime();

            // Move to the end of the month
            start.set(calendarPivot, start.getActualMaximum(calendarPivot));

            // max will be the last day of this "Group"
            // if the start date is past the end date now that we have moved to the end of the
            // month, set max as the end date.
            Date max = null;
            if (start.before(endDate)) {
                max = start.getTime();
            } else {
                // we want to make sure to end at the correct date.
                // If start is after our end we will get in here. This will truncate to end.
                max = endDate.getTime();
            }

            // Add our new bucket!
            interval.add(new EarningsDateGroup(min, max));

            // Add another day -- this will put us into the next "Group"
            start.add(calendarPivot, 1);
        }

        return interval;
    }

    /**
     * Helper class to hold the start and end date of the Groups
     *
     */
    public static class EarningsDateGroup {
        private final Date startDate;
        private final Date endDate;

        public EarningsDateGroup(Date start, Date end) {
            this.startDate = start != null ? new Date(start.getTime()) : null;
            this.endDate = end != null ? new Date(end.getTime()) : null;
        }

        public Date getStartDate() {
            return this.startDate != null ? new Date(this.startDate.getTime()) : null;
        }

        public Date getEndDate() {
            return this.endDate != null ? new Date(this.endDate.getTime()) : null;
        }

    }

}
