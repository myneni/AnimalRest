package com.discover.bank.api.rewards.earnings.buckets;

import java.util.List;

import com.discover.bank.api.rewards.earnings.buckets.RewardsEarnBucketOutput.Builder;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = Builder.class)
public class RewardsEarnBucketOutput {

    private String accountNumber;
    private List<EarnedRwdForDateRangeDtls> earnedRwdForDateRangeDtls;

    private RewardsEarnBucketOutput(RewardsEarnOutputResult p) {
        this.accountNumber = p.accountNumber;
        this.earnedRwdForDateRangeDtls = p.earnedRwdForDateRangeDtls;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public List<EarnedRwdForDateRangeDtls> getEarnedRwdForDateRangeDtls() {
        return earnedRwdForDateRangeDtls;
    }

    public static Builder newInstance() {
        return new Builder();
    }

    public static class Builder {

        private final RewardsEarnOutputResult p;

        private Builder() {
            this.p = new RewardsEarnOutputResult();
        }

        @JsonProperty
        public Builder withAccountNumber(String accountNumber) {
            p.accountNumber = accountNumber;
            return this;
        }

        @JsonProperty
        public Builder withEarnedRwdForDateRangeDtls(
                        List<EarnedRwdForDateRangeDtls> earnedRwdForDateRangeDtls) {
            p.earnedRwdForDateRangeDtls = earnedRwdForDateRangeDtls;
            return this;
        }

        public RewardsEarnBucketOutput build() {
            return new RewardsEarnBucketOutput(p);
        }
    }

    private static class RewardsEarnOutputResult {
        private String accountNumber;
        private List<EarnedRwdForDateRangeDtls> earnedRwdForDateRangeDtls;
    }
}
