package com.discover.bank.api.rewards.redemption;

import java.math.BigInteger;
import java.util.Date;

import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.databind.Money;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.bank.api.rewards.redemption.Redemption.Builder;
import com.discover.bank.api.rewards.redemption.Redemption.RedemptionStatus;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = Redemption.Builder.class)
public abstract class RedemptionMixin {

    @JsonProperty
    public abstract RewardsAccount getFromRewardsAccount();

    @JsonProperty
    public abstract BankAccount getToAccount();

    @JsonProperty
    public abstract CreditCardAccount getToCreditCardAccount();

    @JsonProperty
    public abstract String getRedemptionType();

    @JsonProperty
    public abstract String getRedemptionTypeDesc();

    @JsonProperty
    @Money
    public abstract BigInteger getAmount();

    @JsonProperty
    public abstract String getConfirmationNumber();

    @JsonProperty
    public abstract Date getOrderDate();

    @JsonProperty
    public abstract RedemptionStatus getStatus();

    @JsonProperty
    @Money
    public abstract BigInteger getRemainingBalance();


    public static abstract class BuilderMixin {

        @JsonProperty
        public abstract Builder withFromRewardsAccount(RewardsAccount fromRewardsAccount);

        @JsonProperty
        public abstract Builder withToAccount(BankAccount toAccount);

        @JsonProperty
        public abstract Builder withToCreditCardAccount(CreditCardAccount toCreditCardAccount);

        @JsonProperty
        public abstract Builder withRedemptionType(String redemptionType);

        @JsonProperty
        public abstract Builder withRedemptionTypeDesc(String redemptionTypeDesc);

        @JsonProperty
        @Money
        public abstract Builder withAmount(BigInteger amount);
    }
}
