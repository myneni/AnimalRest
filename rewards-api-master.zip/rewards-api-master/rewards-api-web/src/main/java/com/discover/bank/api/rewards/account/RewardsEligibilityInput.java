package com.discover.bank.api.rewards.account;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RewardsEligibilityInput {
    private String customerId;
    private String redemptionType;

    private RewardsEligibilityInput(Builder params) {
        this.customerId = params.customerId;
        this.redemptionType = params.redemptionType;
    }

    @JsonProperty
    public String getRedemptionType() {
        return redemptionType;
    }

    @JsonProperty
    public String getCustomerId() {
        return customerId;
    }

    public static Builder newInstance() {
        return new Builder();
    }

    public static class Builder {

        private String customerId;
        private String redemptionType;
        private Builder() {}

        public Builder withCustomerId(String customerId) {
            this.customerId = customerId;
            return this;
        }

        public Builder withRedemptionType(String redemptionType) {
            this.redemptionType = redemptionType;
            return this;
        }

        public RewardsEligibilityInput build() {
            return new RewardsEligibilityInput(this);
        }
    }
}
