package com.discover.bank.api.rewards.earnings;

import java.util.Date;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dfs.marketing.rewardearn.ao.RewardEarnForPeriodDetail;
import com.dfs.marketing.rewardearn.ao.RewardEarnInput;
import com.dfs.marketing.rewardearn.ao.RewardEarnOutput;
import com.dfs.marketing.rewardearn.ao.RewardsEarnSvcException_Exception;
import com.dfs.marketing.rewardearn.bd.RewardEarnSvcBDInterface;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsException;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.common.base.BigNumbers;
import com.discover.common.base.Dates;
import com.discover.common.base.Dates.Format;
import com.discover.common.stereotype.Repository;
import com.discoverfinancial.ecc.service.ServiceInvocationException;
import com.google.common.base.Strings;

@Repository
public class EarningsRepository {

    private static final Logger LOG = LoggerFactory.getLogger(EarningsRepository.class);

    private static final String OTHER = "Other";

    @Inject
    private RewardEarnSvcBDInterface delegate;

    @Inject
    private PropertyAccessor props;

    public Earnings lookupRewardEarnings(RewardsAccount account, Date from, Date to)
                    throws RewardsException {
        RewardEarnInput input = buildEarningsInput(account, from, to);
        RewardEarnOutput output = null;

        try {
            output = delegate.getRewardEarned(input);
        } catch (RewardsEarnSvcException_Exception e) {
            LOG.error("RewardsEarnSvcException thrown while looking up rewards earn", e);
            throw new RewardsException();
        } catch (ServiceInvocationException e) {
            LOG.error("ServiceInvocationException thrown while looking up rewards earn", e);
            throw new RewardsException();
        }

        return transform(output, from, to);
    }

    private RewardEarnInput buildEarningsInput(RewardsAccount account, Date from, Date to) {
        RewardEarnInput input = new RewardEarnInput();

        // BIG_ENDIAN_HYPHEN( "yyyy-MM-dd" )
        input.setAccountNumber(account.getAccountNumber().getValue());
        input.setFinancialAgreementType(RewardsAccount
                        .getFinancialAgreementType(account.getProduct().getProductGroup()));
        input.setPeriodStartDate(Dates.print(from, Format.BIG_ENDIAN_HYPHEN));
        input.setPeriodEndDate(Dates.print(to, Format.BIG_ENDIAN_HYPHEN));
        input.setNeedAccumulatedReward(false);

        // XXX Testing to see if we need this or not...
        // input.setActvySrcCde("MBB");

        return input;
    }

    private Earnings transform(RewardEarnOutput reo, Date from, Date to) {
        final Earnings.Builder builder = new Earnings.Builder().from(from).to(to);

        if (reo != null && reo.getRewardEarnForPeriodDetailList() != null
                        && reo.getRewardEarnForPeriodDetailList().size() > 0) {
            // Go through the different types of rewards and add them to our own list.
            for (RewardEarnForPeriodDetail red : reo.getRewardEarnForPeriodDetailList()) {
                if (red != null && red.getRewardEarnedForPeriod() != null
                                && red.getRewardEarnType() != null) {
                    String typeName = props.get(
                                    red.getRewardEarnType().toUpperCase().replaceAll("[^\\w]", ""),
                                    "");

                    if (Strings.isNullOrEmpty(typeName)) {
                        LOG.error("Error mapping RewardsEarnType: {}, Please check the rewards properties file. Defaulting to 'Other'",
                                        new Object[] {red.getRewardEarnType()});
                        typeName = OTHER;
                    }

                    builder.add(typeName, BigNumbers.toMoney(red.getRewardEarnedForPeriod()));
                }
            }
        }

        return builder.build();
    }

}
