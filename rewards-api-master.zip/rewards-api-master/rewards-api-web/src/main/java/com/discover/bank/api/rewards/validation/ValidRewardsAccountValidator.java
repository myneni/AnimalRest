package com.discover.bank.api.rewards.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.discover.bank.api.rewards.account.RewardsAccount;

public class ValidRewardsAccountValidator
                implements ConstraintValidator<ValidRewardsAccount, RewardsAccount> {

    @Override
    public void initialize(ValidRewardsAccount constraintAnnotation) {
        // no initialization needed
    }

    public boolean isValid(RewardsAccount target, ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();
        boolean result = true;
        if (target == null) {
            context.buildConstraintViolationWithTemplate(
                            "{RewardRedemption.FromRewardsAccount.NotEmpty}")
                            .addConstraintViolation();
            result = false;
        } else if (target.getId() == null) {
            context.buildConstraintViolationWithTemplate(
                            "{RewardRedemption.FromRewardsAccount.Id.NotEmpty}")
                            .addConstraintViolation();
            result = false;
        }

        return result;
    }
}
