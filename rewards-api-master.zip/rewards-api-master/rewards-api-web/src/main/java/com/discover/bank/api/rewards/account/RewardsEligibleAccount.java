package com.discover.bank.api.rewards.account;

import com.discover.bank.api.core.accounts.AccountProductGroup;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.hateoas.Identifiable;

public class RewardsEligibleAccount extends BankAccount implements Identifiable<String> {


    public RewardsEligibleAccount(BankAccount account) {
        super(account);
    }

   public String getFinancialAgreementType() {
        return getFinancialAgreementType(getProduct().getProductGroup());
    }

    public static String getFinancialAgreementType(AccountProductGroup productGroup) {
        switch (productGroup) {
            case CHECKING:
                return "checking";

            case SAVINGS:
                return "savings";

            case MONEY_MARKET:
                return "mma";

            default:
                return "BTIM";
        }
    }
    public static InputBuilder newInstance() {
        return  new InputBuilder();
    }
    
    public static class InputBuilder {

        RewardsAccountParams p;

        private InputBuilder() {
            this.p = new RewardsAccountParams();
        }

        public InputBuilder withId(String id) {
            this.p.id = id;
            return this;
        }

        public RewardsEligibleAccount build() {
            return new RewardsEligibleAccount(BankAccount.newBuilder().setId(p.id).build());
        }
    }

    private static class RewardsAccountParams {
        private String id;
    }

}

