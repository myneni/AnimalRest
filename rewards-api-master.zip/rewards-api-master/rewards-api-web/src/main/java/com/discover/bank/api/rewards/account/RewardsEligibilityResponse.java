package com.discover.bank.api.rewards.account;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = RewardsEligibilityResponse.Builder.class)
public class RewardsEligibilityResponse {
    private List<EligibleAccount> sourceAccountDetailsList;
    
    private String customerId ;
    
    private List<EligibleAccount> targetAccountDetailsList;

    private RewardsEligibilityResponse(Builder params) {
        this.sourceAccountDetailsList = params.sourceAccountDetailsList;
        this.customerId =   params.customerId;
        this.targetAccountDetailsList   = params.targetAccountDetailsList;
    }
    @JsonProperty
    public List<EligibleAccount> getSourceAccountDetails() {
        return sourceAccountDetailsList;
    }
    @JsonProperty
    public String getCustomerId() {
        return customerId;
    }
    @JsonProperty
    public List<EligibleAccount> getTargetAccountDetailsList() {
        return targetAccountDetailsList;
    }

    public static Builder newInstance() {
        return new Builder();
    }

    public static class Builder {

        private List<EligibleAccount> sourceAccountDetailsList;
        
        private String customerId ;
        
        private List<EligibleAccount> targetAccountDetailsList;

        public Builder withSourceAccountDetailsList(
                        List<EligibleAccount> sourceAccountDetailsList) {
            this.sourceAccountDetailsList = sourceAccountDetailsList;
            return this;
        }

        public Builder withCustomerId(String customerId) {
            this.customerId = customerId;
            return this;
        }

        public Builder withTargetAccountDetailsList(
                        List<EligibleAccount> targetAccountDetailsList) {
            this.targetAccountDetailsList = targetAccountDetailsList;
            return this;
        }

        public RewardsEligibilityResponse build() {
            return new RewardsEligibilityResponse(this);
        }

    }

}
