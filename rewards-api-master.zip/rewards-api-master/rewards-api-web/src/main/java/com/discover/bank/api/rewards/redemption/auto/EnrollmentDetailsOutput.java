package com.discover.bank.api.rewards.redemption.auto;

import java.util.List;

public class EnrollmentDetailsOutput {

    private List<EnrollmentDetail> enrollmentDetails;

    private String errorCode;

    private String errorDescription;

    public List<EnrollmentDetail> getEnrollmentDetails() {
        return enrollmentDetails;
    }

    public void setEnrollmentDetails(List<EnrollmentDetail> enrollmentDetails) {
        this.enrollmentDetails = enrollmentDetails;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }
}
