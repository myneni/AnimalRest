package com.discover.bank.api.rewards.account;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EligibleAccounts {
    private List<RewardsEligibleAccount> targetEligibleAccounts;
    private List<RewardsEligibleAccount> sourceEligibleAccounts;
    private String disclaimer;

    public static Builder newInstance() {
        return new Builder();
    }

    private EligibleAccounts(Builder params) {
        this.targetEligibleAccounts = params.targetEligibleAccounts;
        this.sourceEligibleAccounts = params.sourceEligibleAccounts;
        this.disclaimer = params.disclaimer;
    }

    @JsonProperty
    public List<RewardsEligibleAccount> getTargetEligibleAccounts() {
        return targetEligibleAccounts;
    }
    
    @JsonProperty
    public List<RewardsEligibleAccount> getSourceEligibleAccounts() {
        return sourceEligibleAccounts;
    }

    @JsonProperty
    public String getDisclaimer() {
        return disclaimer;
    }

    public static class Builder {

        private List<RewardsEligibleAccount> targetEligibleAccounts;
        private List<RewardsEligibleAccount> sourceEligibleAccounts;
        private String disclaimer;

        private Builder() {}

        public Builder withTargetEligibleAccounts(List<RewardsEligibleAccount> targetEligibleAccounts) {
            this.targetEligibleAccounts = targetEligibleAccounts;
            return this;
        }
        
        public Builder withSourceEligibleAccounts(List<RewardsEligibleAccount> sourceEligibleAccounts) {
            this.sourceEligibleAccounts = sourceEligibleAccounts;
            return this;
        }

        public Builder withDisclaimer(String disclaimer) {
            this.disclaimer = disclaimer;
            return this;
        }

        public EligibleAccounts build() {
            return new EligibleAccounts(this);
        }

    }
}
