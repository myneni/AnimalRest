package com.discover.bank.api.rewards.redemption;

import com.discover.bank.api.core.customers.Customer;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.google.common.base.Strings;

/**
 * Contains static helper methods that maintain the business logic for the RewardsRedemtpion
 * process.
 */
public class Redemptions {

    private static final String TYPE_TRANSFER = "XTORW|TRANSFER";

    private static final String TYPE_DEPOSIT = "DEPST|DEPOSIT|DEPSV|DEPMM";

    // No you can not have me.
    private Redemptions() {

    }

    /**
     * Static helper method that checks to the RewardsCustomer is the Primary or the Secondary
     * AccountHolder on the account
     *
     * @param account The CreditCardAccount for which to check the relation
     * @param customer The RewardsCustomer for which to check the relation
     * @return True if the customer is the primary or secondary on the given account, False
     *         otherwise
     */
    public static boolean isPrimaryOrSecondaryAccountHolder(CreditCardAccount account,
                    Customer customer) {
        if (account.getPrimarySocialSecurityNumber().equals(customer.getSocialSecurityNumber())
                        || account.getSecondarySocialSecurityNumber()
                                        .equals(customer.getSocialSecurityNumber())) {
            return true;
        }

        return false;
    }

    /**
     * Static helper method to find out if the redemption type is a transfer.
     *
     * @param s The redemption type.
     * @return True if the redemption type is XTROW or Transfer.
     */
    public static boolean isTransfer(String s) {
        return (!Strings.isNullOrEmpty(s) && TYPE_TRANSFER.contains(s.toUpperCase()));
    }

    /**
     * Static helper method to find out if the redemption type is a transfer.
     *
     * @param s The redemption type.
     * @return True if the redemption type is DEPST or Deposit.
     */
    public static boolean isDeposit(String s) {
        return (!Strings.isNullOrEmpty(s) && TYPE_DEPOSIT.contains(s.toUpperCase()));
    }


}
