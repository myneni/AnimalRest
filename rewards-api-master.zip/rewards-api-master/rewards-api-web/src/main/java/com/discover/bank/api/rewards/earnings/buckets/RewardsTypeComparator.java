package com.discover.bank.api.rewards.earnings.buckets;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class RewardsTypeComparator implements Comparator<EarnedRwdForDateRangeDtls> {

    List<String> rewardsTypeOrder =
                    Arrays.asList("DEBITCARDPURCHASES", "PROMOTIONS", "ADJUSTMENTSPOSITIVE",
                                    "ADJUSTMENTSRETURNSREVERSALS", "BILLPAY", "CHECK", "OTHER");

    @Override
    public int compare(EarnedRwdForDateRangeDtls earnedRwdRange1, EarnedRwdForDateRangeDtls earnedRwdRange2) {
        return Integer.valueOf(rewardsTypeOrder.indexOf(earnedRwdRange1.getEarnedRwdType())).compareTo(
                        Integer.valueOf(rewardsTypeOrder.indexOf(earnedRwdRange2.getEarnedRwdType())));
    }

}
