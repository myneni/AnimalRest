package com.discover.bank.api.rewards.earnings.buckets;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RewardsEarnBucketInput {

    private String accountNumber;
    private String financialAgreementType;
    private String lastCycleDate;
    private String fromDate;
    private String toDate;

    private RewardsEarnBucketInput(Builder params) {
        this.accountNumber = params.accountNumber;
        this.financialAgreementType = params.financialAgreementType;
        this.lastCycleDate = params.lastCycleDate;
        this.fromDate = params.fromDate;
        this.toDate = params.toDate;
    }

    @JsonProperty
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty
    public String getFinancialAgreementType() {
        return financialAgreementType;
    }

    @JsonProperty
    public String getLastCycleDate() {
        return lastCycleDate;
    }

    @JsonProperty
    public String getFromDate() {
        return fromDate;
    }

    @JsonProperty
    public String getToDate() {
        return toDate;
    }

    public static Builder newInstance() {
        return new Builder();
    }

    public static class Builder {

        private String accountNumber;
        private String financialAgreementType;
        private String lastCycleDate;
        private String fromDate;
        private String toDate;

        private Builder() {}

        public Builder withAccountNumber(String accountNumber) {
            this.accountNumber = accountNumber;
            return this;
        }

        public Builder withFinancialAgreementType(String financialAgreementType) {
            this.financialAgreementType = financialAgreementType;
            return this;
        }

        public Builder withLastCycleDate(String lastCycleDate) {
            this.lastCycleDate = lastCycleDate;
            return this;
        }

        public Builder withFromDate(String fromDate) {
            this.fromDate = fromDate;
            return this;
        }

        public Builder withToDate(String toDate) {
            this.toDate = toDate;
            return this;
        }

        public RewardsEarnBucketInput build() {
            return new RewardsEarnBucketInput(this);
        }
    }
}
