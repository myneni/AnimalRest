package com.discover.bank.api.rewards.earnings;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.hateoas.Hypermedia;
import com.discover.bank.api.hateoas.Resource;
import com.discover.bank.api.rewards.RewardsBusinessObject;
import com.discover.bank.api.rewards.RewardsException;
import com.discover.bank.api.rewards.account.RewardsAccountNotFoundException;
import com.discover.common.security.access.annotation.RequiresAuthentication;

@Controller
@RequestMapping(value = "", produces = {MediaType.APPLICATION_JSON_VALUE})
@RequiresAuthentication
public class EarningsController {

    private static final Logger LOG = LoggerFactory.getLogger(EarningsController.class);
    @Inject
    private RewardsBusinessObject rewards;

    @Inject
    private Hypermedia hypermedia;

    /**
     *
     * @param customerContext The Customer.
     * @param id The account ID of the request.
     * @param fromDate The start date of the request you want. default is 2 years ago.
     * @param toDate The end date of the request you want. default is now.
     * @param groupBy If you want them grouped. Default is FULL.
     */
    @RequestMapping(value = "/{id}/earnings", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody HttpEntity<Iterable<Resource<Earnings>>> earnings(
                    CustomerIdentification customer, @PathVariable("id") String id,
                    @RequestParam(value = "fromDate", defaultValue = "") String fromDate,
                    @RequestParam(value = "toDate", defaultValue = "") String toDate,
                    @RequestParam(value = "groupBy", defaultValue = "FULL") String groupBy)
                                    throws RewardsException, EarningsInvalidFilterException,
                                    RewardsAccountNotFoundException {

        final EarningsFilter.Builder builder =
                        EarningsFilter.initialize().from(fromDate).to(toDate).groupBy(groupBy);

        LOG.info("Starting rewards earning for customer: {}", customer.getCustomerNumber());
        return hypermedia.ok(rewards.getEarnings(builder.build(), id, customer));
    }

    /**
     *
     * @param customerContext The Customer.
     * @param id The account ID of the request.
     * @param fromDate The start date of the request you want. default is 1 years ago.
     * @param toDate The end date of the request you want. default is now.
     * @param groupBy If you want them grouped. Default is MONTH.
     */
    @RequestMapping(value = "/{id}/earnings/v2", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody HttpEntity<Resource<EarningsV2>> earningsV2(
                    CustomerIdentification customer, @PathVariable("id") String id,
                    @RequestParam(value = "fromDate", defaultValue = "") String fromDate,
                    @RequestParam(value = "toDate", defaultValue = "") String toDate,
                    @RequestParam(value = "month", defaultValue = "12") int month,
                    @RequestParam(value = "groupBy", defaultValue = "MONTH") String groupBy)
                    throws RewardsException, EarningsInvalidFilterException,
                    RewardsAccountNotFoundException {

        final EarningsFilter.Builder builder =
                        EarningsFilter.initialize().from(fromDate).to(toDate).groupBy(groupBy);

        LOG.info("Starting rewards earning for customer: {}", customer.getCustomerNumber());
        return hypermedia.ok(rewards.getEarningsV2(builder.build(), id,month, customer));
    }

}
