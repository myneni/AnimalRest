package com.discover.bank.api.rewards.email;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.customers.Customer;
import com.discover.bank.api.rewards.redemption.Redemption;
import com.discover.bank.api.rewards.redemption.Redemptions;
import com.discover.common.base.BigNumbers;
import com.discover.common.base.Dates;
import com.discover.common.base.Dates.Format;
import com.discover.common.stereotype.Repository;
import com.discover.emsg.core.ao.DeliverEMessageVO;
import com.discover.emsg.core.ao.EMessageAcctInfo;
import com.discover.emsg.core.ao.EMessageContentInfo;
import com.discover.emsg.core.ao.EMessageException;
import com.discover.emsg.core.ao.EMessageException_Exception;
import com.discover.emsg.core.ao.EMessageFormCodeInfo;
import com.discover.emsg.core.ao.EMessageRecipient;
import com.discover.emsg.core.ao.EMessageRequestInfo;
import com.discover.emsg.core.ao.RequestingClientInformation;
import com.discover.emsg.core.ao.TemplateField;
import com.discover.emsg.core.bd.EMessageWSDelegate;

@Repository
public class EMessageEmailRepository implements EmailRepository {

	private static final String MESSAGE_FORM_CODE = "BNKRWDSRDEMP";
	private static final String MESSAGE_FORM_CODE_GROUP = "BNK_TRIG";
	private static final Logger LOG = LoggerFactory.getLogger(EMessageEmailRepository.class);

	@Inject
	private EMessageWSDelegate bd;

	/**
	 * Sends the confirmation email for for a rewards redemption.
	 *
	 * @param customer
	 *            The RewardsCustomer from the CustomerRepository. Needed for
	 *            the email and things like the customer's name.
	 * @param redemption
	 *            The final result of the rewards redemption which includes the
	 *            confirmationNumber.
	 */
	@Override
	public void sendConfirmationEmail(Customer customer, Redemption redemption) {
		/*
		 * Message Group: DBankEmails Form group code: BNK_TRIG Form code:
		 * BNKRWDSRDEMP
		 */

		EMessageFormCodeInfo formCodeInfo = new EMessageFormCodeInfo();
		formCodeInfo.setEMsgFormCode(MESSAGE_FORM_CODE);
		formCodeInfo.setEMsgFormCodeGroup(MESSAGE_FORM_CODE_GROUP);

		DeliverEMessageVO deliverMsgVO = buildBasicEMessageVO(formCodeInfo);
		EMessageRecipient recipient = new EMessageRecipient();
		recipient.setEMsgRecipientAddress(customer.getEmail().getValue());

		deliverMsgVO.getEMsgRecipients().add(recipient);
		EMessageContentInfo content = new EMessageContentInfo();

		String type = null;
		if (Redemptions.isTransfer(redemption.getRedemptionType())) {
			type = "TRANSFER";
		} else if (Redemptions.isDeposit(redemption.getRedemptionType())) {
			type = "DEPOSIT";
		} else {
			type = "";
		}

		// Its probably a bad idea that we are doing dates.now as our rewds
		// date. However as of this
		// release time travel has not been invented.
		// Since time tavel is not possible (4/22/2014) we cant redeem in the
		// past or the future, so
		// it should be safe.
		Map<String, String> fields = new HashMap<String, String>();
		fields.put("First_Name", customer.getName().getGivenName());
		
		if (redemption.getToAccount() != null && redemption.getToAccount().getAccountNumber() != null)
			fields.put("ACCT_NUM", redemption.getToAccount().getAccountNumber().getValue());// to
																							// or
																							// destination
																							// bank
																							// account
		else if (redemption.getToCreditCardAccount() != null
				&& redemption.getToCreditCardAccount().getAccountNumber() != null)
			fields.put("ACCT_NUM", redemption.getToCreditCardAccount().getAccountNumber().getValue());// to
																										// or
																										// destination
																										// card
																										// account

		fields.put("RWD_DSCRP1", type);
		fields.put("RWDS_DATE", Dates.print(Dates.now(), Format.MIDDLE_ENDIAN_SLASH));
		fields.put("RWDS_CNF_NUM", redemption.getConfirmationNumber());
		fields.put("RDEMP_DSCRP2", type);
		fields.put("RDEMP_AMT", BigNumbers.MoneyFormat.NEGATIVE_WITHOUT_CURRENCY.formatter()
				.format(new BigDecimal(redemption.getAmount()).divide(new BigDecimal("100"))));
		fields.put("CLS_STMNT", type);
		fields.put("SRC_ACCT_NUM", redemption.getFromRewardsAccount().getAccountNumber().getValue());// from
																										// accaount

		for (Map.Entry<String, String> entry : fields.entrySet()) {

			TemplateField temp = new TemplateField();
			temp.setName(entry.getKey());
			temp.setValue(entry.getValue());

			content.getTemplateFields().add(temp);
		}
		
		deliverMsgVO.setEMsgContentInfo(content);

		try {
			boolean deliverMSg = bd.deliverEMessage(deliverMsgVO);
			LOG.info("Deliver Msg Result - " + deliverMSg);
		} catch (EMessageException_Exception e) {
			EMessageException ex = e.getFaultInfo();
			LOG.warn("Exception while trying to send an email, code - " + ex.getExceptionCode() + ", type - "
					+ ex.getExceptionType(), e);
			// Dont throw an exception. If we didnt send an email, we still want
			// to tell them we did
			// the redemption!
		}
	}

	/**
	 * send confirmation email for Auto Redemption Enrollment, Auto Redemption
	 * Modification and Auto Redemption Un-enroll
	 * 
	 */
	@Override
	public void sendConfirmationEmail(Customer customer, BankAccount fromAccount, BankAccount toAccount,
			String formCode) {

		try {
			boolean deliverMSg = bd.deliverEMessage(buildEMessageVO(customer, fromAccount, toAccount, formCode));
			LOG.info("Deliver Msg Result for {} :{} ", formCode, deliverMSg);
		} catch (EMessageException_Exception e) {
			EMessageException ex = e.getFaultInfo();
			LOG.warn("Exception while trying to send an email for {}, code: {} type: {}", formCode,
					ex.getExceptionCode(), ex.getExceptionType());
			// Don't throw an exception. Even if unable to send the email, the
			// flow should go fine.So log the error and proceed.
		}
	}

	private DeliverEMessageVO buildEMessageVO(Customer customer, BankAccount fromAccount, BankAccount toAccount,
			String formCode) {

		// check whether the call is from enroll/modify/delete, and set the
		// formCode
		String eMsgFormCode = ("enroll".equalsIgnoreCase(formCode)) ? "ATORDMENRLEML"
				: ("editEnroll".equalsIgnoreCase(formCode)) ? "ATORDMMODEML" : "ATORDMPUNENRLEML";

		EMessageFormCodeInfo formCodeInfo = new EMessageFormCodeInfo();
		formCodeInfo.setEMsgFormCode(eMsgFormCode);
		formCodeInfo.setEMsgFormCodeGroup(MESSAGE_FORM_CODE_GROUP);

		DeliverEMessageVO output = buildBasicEMessageVO(formCodeInfo);

		EMessageRecipient recipient = new EMessageRecipient();
		recipient.setEMsgRecipientAddress(customer.getEmail().getValue());
		output.getEMsgRecipients().add(recipient);
		output.setEMsgContentInfo(buildMessageContent(customer, fromAccount, toAccount, formCode));

		return output;
	}

	private EMessageContentInfo buildMessageContent(Customer customer, BankAccount fromAccount, BankAccount toAccount,
			String formCode) {
		EMessageContentInfo output = new EMessageContentInfo();

		Map<String, String> fields = new HashMap<String, String>();
		fields.put("FIRST_NAME", customer.getName().getGivenName());
		fields.put("SRC_ACCT_NUM", fromAccount.getAccountNumber().getValue());
		// for unenroll, Schema Description is not required
		if (!"unEnroll".equalsIgnoreCase(formCode)) {
			fields.put("ACCT_NUM", toAccount.getAccountNumber().getEnding());
			fields.put("SCHM_DESC", toAccount.getNickName());
		}else{
		 //for un-enroll, we need to add the same information in ACCT_NUM
		 //even though it is already available in SRC_ACCT_NUM
		    fields.put("ACCT_NUM", fromAccount.getAccountNumber().getEnding());
		}
		fields.put("RCPT_EMAIL_ADDRESS", customer.getEmail().getValue());

		for (Map.Entry<String, String> entry : fields.entrySet()) {

			TemplateField temp = new TemplateField();
			temp.setName(entry.getKey());
			temp.setValue(entry.getValue());

			output.getTemplateFields().add(temp);
		}
		return output;
	}

	private DeliverEMessageVO buildBasicEMessageVO(EMessageFormCodeInfo formCodeInfo) {
		DeliverEMessageVO output = new DeliverEMessageVO();
		output.setEMsgAcctInfo(new EMessageAcctInfo());
		output.setEMsgClientInfo(setClientInformation());
		EMessageRequestInfo request = new EMessageRequestInfo();
		request.setEMsgFormCodeInfo(formCodeInfo);
		output.setEMsgReqInfo(request);
		return output;
	}

	private RequestingClientInformation setClientInformation() {
		RequestingClientInformation clientInfo = new RequestingClientInformation();
		clientInfo.setMemoBuncIndicator("Y");
		clientInfo.setMemoSentIndicator("N");
		clientInfo.setApplicationSourceCode("IB");
		return clientInfo;
	}

}
