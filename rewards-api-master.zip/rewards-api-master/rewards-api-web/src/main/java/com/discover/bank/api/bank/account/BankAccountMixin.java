package com.discover.bank.api.bank.account;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.BankAccount;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = BankAccountMixin.InputBuilder.class)
public abstract class BankAccountMixin {

    @JsonProperty
    public abstract String getId();

    @JsonProperty
    public abstract AccountNumber getAccountNumber();

    @JsonProperty
    public abstract String getNickName();

    public abstract static class InputBuilderMixin {

        @JsonProperty
        public abstract InputBuilder withId(String id);
    }

    public static class InputBuilder {

        BankAccountParams p;

        private InputBuilder() {
            this.p = new BankAccountParams();
        }

        @JsonProperty
        public InputBuilder withId(String id) {
            this.p.id = id;
            return this;
        }

        public BankAccount build() {
            return BankAccount.newBuilder().setId(p.id).build();
        }
    }

    private static class BankAccountParams {
        private String id;
    }

}


