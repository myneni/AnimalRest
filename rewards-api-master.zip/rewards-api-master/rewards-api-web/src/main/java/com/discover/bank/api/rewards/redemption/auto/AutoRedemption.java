package com.discover.bank.api.rewards.redemption.auto;

import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.rewards.redemption.Redemption;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.google.common.base.MoreObjects;

@JsonDeserialize(builder = AutoRedemption.Builder.class)
public class AutoRedemption {

    private String isEnrolled;

    private String message;

    private BankAccount toAccount;

    private boolean didOneTimeRedemption = false;

    private Redemption oneTimeRedemption;

    private AutoRedemption() {}

    private AutoRedemption(Params parms) {
        this.message = parms.message;
        this.isEnrolled = parms.isEnrolled;
        this.toAccount = parms.toAccount;
        this.didOneTimeRedemption = parms.didOneTimeRedemption;
        this.oneTimeRedemption = parms.oneTimeRedemption;
    }

    @JsonProperty
    public String getIsEnrolled() {
        return isEnrolled;
    }

    @JsonProperty
    public String getMessage() {
        return message;
    }

    @JsonProperty
    public BankAccount getToAccount() {
        return toAccount;
    }

    @JsonProperty
    public boolean didOneTimeRedemption() {
        return didOneTimeRedemption;
    }

    @JsonProperty
    public Redemption getOneTimeRedemption() {
        return oneTimeRedemption;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static Builder newBuilder(AutoRedemption autoRedemption) {
        return new Builder(autoRedemption);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                          .omitNullValues()
                          .add("toAccount", toAccount)
                          .add("didOneTimeRedemption", didOneTimeRedemption)
                          .add("oneTimeRedemption", oneTimeRedemption)
                          .toString();
    }

    public static class Builder {

        private final Params p;

        public Builder() {
            this.p = new Params();
        }

        public Builder(AutoRedemption p) {
            this.p = new Params();
            this.p.message = p.message;
            this.p.isEnrolled = p.isEnrolled;
            this.p.toAccount = p.getToAccount();
            this.p.didOneTimeRedemption = p.didOneTimeRedemption;
            this.p.oneTimeRedemption = p.oneTimeRedemption;
        }

        @JsonProperty
        public Builder withIsEnrolled(String isEnrolled) {
            this.p.isEnrolled = isEnrolled;
            return this;
        }

        @JsonProperty
        public Builder withMessage(String message) {
            this.p.message = message;
            return this;
        }

        @JsonProperty
        public Builder withToAccount(BankAccount toAccount) {
            this.p.toAccount = toAccount;
            return this;
        }

        public Builder withDidOneTimeRedemption(boolean didOneTimeRedemption) {
            this.p.didOneTimeRedemption = didOneTimeRedemption;
            return this;
        }

        public Builder withOneTimeRedemption(Redemption oneTimeRedemption) {
            this.p.oneTimeRedemption = oneTimeRedemption;
            return this;
        }

        public AutoRedemption build() {
            return new AutoRedemption(this.p);
        }
    }

    private static final class Params {
        private String isEnrolled;
        private String message;
        private BankAccount toAccount;
        private boolean didOneTimeRedemption;
        private Redemption oneTimeRedemption;
    }

}
