package com.discover.bank.api.rewards.redemption;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.hateoas.Hypermedia;
import com.discover.bank.api.hateoas.Resource;
import com.discover.bank.api.rewards.RewardsBusinessObject;
import com.discover.bank.api.rewards.RewardsException;
import com.discover.bank.api.rewards.account.RewardsAccountNotFoundException;
import com.discover.bank.api.rewards.earnings.EarningsInvalidFilterException;
import com.discover.common.security.access.annotation.RequiresAuthentication;

@Controller
@RequestMapping(value = "", produces = {MediaType.APPLICATION_JSON_VALUE})
@RequiresAuthentication
public class RedemptionController {

    private static final Logger LOG = LoggerFactory.getLogger(RedemptionController.class);

    @Inject
    private RewardsBusinessObject rewards;

    @Inject
    private Hypermedia hypermedia;

    @RequestMapping(value = "/redemptions/verify", method = RequestMethod.POST,
                    consumes = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public HttpEntity<Resource<Redemption>> verifyRewardsRedemption(@RequestBody Redemption input,
                    CustomerIdentification customer)
                    throws RewardsException {
        LOG.info("Starting rewards redemption verification for customer: {}", customer);

        return hypermedia.ok(rewards.verifyAndRedeemRewards(input, customer, true));
    }
    
    @RequestMapping(value = "/redemptions", method = RequestMethod.POST,
                    consumes = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public HttpEntity<Resource<Redemption>> redeemRewards(@RequestBody Redemption input,
                    CustomerIdentification customer)
                    throws RewardsException {
        LOG.info("Starting rewards redemption for customer: {}", customer);

        // can this be hypermedia.created instead? and remove the @ResponseStatus above
        return hypermedia.ok(rewards.verifyAndRedeemRewards(input, customer, false));
    }

    @RequestMapping(value = "/{id}/history", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public HttpEntity<Iterable<Resource<Redemption>>> history(CustomerIdentification customer,
                    @PathVariable("id") String id,
                    @RequestParam(value = "month", defaultValue = "12") int month)
                                    throws RewardsException, EarningsInvalidFilterException,
                                    RewardsAccountNotFoundException {
        LOG.info("Starting rewards earning for customer: {}", customer);
        return hypermedia.ok(rewards.getHistory(id, customer, month));
    }

}
