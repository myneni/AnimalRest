package com.discover.bank.api.rewards.redemption.auto;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.discover.bank.api.core.accounts.AccountNotFoundException;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.core.customers.CustomerNotFoundException;
import com.discover.bank.api.hateoas.Hypermedia;
import com.discover.bank.api.hateoas.Resource;
import com.discover.bank.api.rewards.RewardsBusinessObject;
import com.discover.bank.api.rewards.RewardsException;

@Controller
@RequestMapping(value = "", produces = {MediaType.APPLICATION_JSON_VALUE})
public class AutoRedemptionController {

    private static final Logger LOG = LoggerFactory.getLogger(AutoRedemptionController.class);

    @Inject
    private RewardsBusinessObject rewards;

    @Inject
    private Hypermedia hypermedia;

    @RequestMapping(value = "/status", method = RequestMethod.GET,
                    produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public HttpEntity<Resource<AutoRedemptionAccountResource>> getAutoRedemptionAccountsStatus(
                    @RequestParam(value = "accounts", required = false) List<String> accountIds,
                    CustomerIdentification customer) {

        LOG.info("Get auto-redemption all for customer: {} and accounts: {}", customer, accountIds);
        return hypermedia.ok(
                        transform(rewards.getAutoRedemptionAccountsStatus(customer, accountIds)));
    }

    @RequestMapping(value = "/{accountId}/auto", method = RequestMethod.POST,
                    consumes = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public HttpEntity<Resource<EnrollEditAutoRedemption>> enrollAutoRedemption(
                    CustomerIdentification customer,
                    @PathVariable("accountId") final String accountId,
                    @RequestBody EnrollEditAutoRedemption input)
                    throws AccountNotFoundException, CustomerNotFoundException, RewardsException {

        LOG.info("Enroll auto redemption for customer: {} & input {}", customer, input);
        return hypermedia.ok(rewards.enrollAutoRedemption(customer, accountId, input));
    }

    @RequestMapping(value = "/{accountId}/auto", method = RequestMethod.GET,
                    produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public HttpEntity<Resource<AutoRedemptionResponse>> getAutoRedemption(
                    CustomerIdentification customer, @PathVariable("accountId") String accountId) {

        LOG.info("Get auto-redemption for customer: {} and account {}", customer, accountId);
        return hypermedia.ok(rewards.getAutoRedemption(customer, accountId));
    }

    @RequestMapping(value = "/{accountId}/auto", method = RequestMethod.PUT,
                    consumes = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public HttpEntity<Resource<EditAutoRedemptionResponse>> editAutoRedemption(
                    CustomerIdentification customer,
                    @PathVariable("accountId") final String accountId,
                    @RequestBody EnrollEditAutoRedemption input) throws RewardsException {

        LOG.info("Edit auto redemption for customer: {} and account {}", customer, accountId);
        return hypermedia.ok(rewards.editAutoRedemption(customer, accountId, input));
    }

    @RequestMapping(value = "/{accountId}/auto", method = RequestMethod.DELETE)
    @ResponseBody
    public HttpEntity<Resource<AutoRedemptionResponse>> deleteAutoRedemption(
                    CustomerIdentification customer,
                    @PathVariable("accountId") String accountId) {

        LOG.info("Delete Enrollment for customer: {} and account {}", customer, accountId);
        return hypermedia.ok(rewards.deleteAutoRedemption(customer, accountId));
    }

    protected AutoRedemptionAccountResource transform(
                    List<AutoRedemptionAccount> autoRedemptionAccounts) {

        AutoRedemptionAccountResource resource = new AutoRedemptionAccountResource();
        resource.setAutoRedemptionAccount(hypermedia.resource(autoRedemptionAccounts));

        return resource;
    }
}
