package com.discover.bank.api.rewards.earnings;

import java.util.Calendar;
import java.util.Date;

import com.discover.common.base.Dates;
import com.google.common.base.Strings;

/**
 * Earnings filter is the input from the request that filters out how much earnings data you want.
 * <br>
 * To create an earnings filter, you need to use the built in Builder innerclass. <br>
 *
 */
public class EarningsFilter {

    public static enum GroupBy {
        MONTH, YEAR, FULL;

        /**
         * Name and value are the same. Search for the correct enum based on what someone passed in.
         * 
         * @param groupBy The same name as the enum requested.
         * @return The enum with the same name as groupBy. If nothing was found, FULL is Default.
         */
        public static GroupBy forName(String groupBy) {
            GroupBy gb = FULL;
            if (!Strings.isNullOrEmpty(groupBy)) {
                for (final GroupBy candidate : GroupBy.values()) {
                    if (candidate.name().equalsIgnoreCase(groupBy)) {
                        gb = candidate;
                        break;
                    }
                }
            }
            return gb;
        }
    }

    private final Calendar fromDate;
    private final Calendar toDate;
    private final GroupBy groupBy;

    /**
     * Private constructor to prevent people from creating this as a normal object.
     * 
     * @param P Private inner class to hold the values of the class before its created.
     */
    private EarningsFilter(Calendar from, Calendar to, GroupBy group) {
        this.fromDate = from;
        this.toDate = to;
        this.groupBy = group;
    }

    public Calendar getFromDate() {
        return fromDate;
    }

    public Calendar getToDate() {
        return toDate;
    }

    public GroupBy getGroupBy() {
        return groupBy;
    }

    @Override
    public String toString() {
        // No new lines b/c we figure this to go into the log.
        StringBuilder tssb = new StringBuilder(" Earnings Filter").append("  From: ")
                        .append(getFromDate().getTime()).append("  To: ")
                        .append(getToDate().getTime()).append("  Group By: ").append(getGroupBy());

        return tssb.toString();
    }

    public static Builder initialize() {
        return new Builder();
    }

    /**
     * Inner class that creates a new filter. This is the only way to create an EarningsFilter
     *
     */
    public static class Builder {

        private Calendar fromDate;
        private Calendar toDate;
        private GroupBy groupBy;

        /**
         * This constructor will set the defaults for the Filter. The defaults are: fromDate: 2
         * years. The farthest possible date we would allow in a normal situation. toDate: Today.
         * groupBy: Full Grouping
         */
        private Builder() {
            Date now = Dates.now();
            this.fromDate = Calendar.getInstance();
            this.fromDate.setTime(now);
            this.fromDate.add(Calendar.YEAR, -2);
            this.toDate = Calendar.getInstance();
            this.toDate.setTime(now);
            this.groupBy = GroupBy.FULL;
        }



        /**
         * Creates a builder from an older EarningsFilter.
         * 
         * @param filter The filter you want to base this builder from.
         * @return The same builder you are using with the values of the older Filter.
         */
        public Builder basedOn(EarningsFilter filter) {
            this.fromDate = filter.getFromDate();
            this.toDate = filter.getToDate();
            this.groupBy = filter.getGroupBy();

            return this;
        }

        /**
         * Add a starting date to the Earnings filter you are building.<br>
         * Null and blank values are not allowed. Dates that don't fit the date format will not be
         * added.
         * 
         * @param fromDate The date you want to add to the filter.
         * @return The same builder with the added starting date.
         */
        public Builder from(String fromDate) {
            if (!Strings.isNullOrEmpty(fromDate)) {
                Date tmp = null;
                try {
                    tmp = Dates.parse(fromDate);
                } catch (Exception e) {
                    // no op
                }

                // If the date parsed successfully, add it.
                if (tmp != null) {
                    this.fromDate = Calendar.getInstance();
                    this.fromDate.setTime(tmp);
                }
            }
            return this;
        }

        /**
         * Add a starting date to the Earnings filter you are building.<br>
         * Null values are not allowed.
         * 
         * @param fromDate The date you want to add to the filter.
         * @return The same builder with the added starting date.
         */
        public Builder from(Calendar fromDate) {
            if (fromDate != null) {
                this.toDate = fromDate;
            }
            return this;
        }

        /**
         * Add an ending date to the Earnings filter you are building.<br>
         * Null and blank values are not allowed. Dates that don't fit the date format will not be
         * added.
         * 
         * @param toDate The date you want to add to the filter.
         * @return The same builder with the added ending date.
         */
        public Builder to(String toDate) {
            if (!Strings.isNullOrEmpty(toDate)) {
                Date tmp = null;
                try {
                    tmp = Dates.parse(toDate);
                } catch (Exception e) {
                    // no op
                }

                // If the date parsed successfully, add it.
                if (tmp != null) {
                    this.toDate = Calendar.getInstance();
                    this.toDate.setTime(tmp);
                }
            }
            return this;
        }

        /**
         * Add an ending date to the Earnings filter you are building.<br>
         * Null values are not allowed.
         * 
         * @param toDate The date you want to add to the filter.
         * @return The same builder with the added ending date.
         */
        public Builder to(Calendar toDate) {
            if (toDate != null) {
                this.toDate = toDate;
            }
            return this;
        }

        /**
         * Change the way you want to group the earnings.
         * 
         * @param groupBy Group by object of how you want to group the earnings. Default is FULL.
         * @return The same builder with the added grouping preference.
         */
        public Builder groupBy(GroupBy groupBy) {
            this.groupBy = groupBy;
            return this;
        }

        /**
         * Change the way you want to group the earnings.
         * 
         * @param groupBy String description of how you want to group the earnings. This must match
         *        a GroupBy type. Default is FULL.
         * @return The same builder with the added grouping preference.
         */
        public Builder groupBy(String groupBy) {
            this.groupBy = GroupBy.forName(groupBy);
            return this;
        }

        /**
         * You want an EarningsFilter Object? You have come to the right place.<br>
         * This is the only guy that will give you one. And if you asked his workers to customize
         * your EarningsFilter, he will make sure to give you the right one.
         * 
         * @return An immutable EarningsFilter. You get what you pay for.
         * @throws EarningsInvalidFilterException
         */
        public EarningsFilter build() throws EarningsInvalidFilterException {
            Calendar now = Calendar.getInstance();
            now.setTime(Dates.now());

            // We have 2 hard constraints.
            if (now.before(this.fromDate) || this.fromDate.after(this.toDate)) {
                throw new EarningsInvalidFilterException();
            }

            return new EarningsFilter(this.fromDate, this.toDate, this.groupBy);
        }

    }
}
