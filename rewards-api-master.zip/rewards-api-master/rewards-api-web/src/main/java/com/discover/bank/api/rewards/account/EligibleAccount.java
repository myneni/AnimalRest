package com.discover.bank.api.rewards.account;

import com.discover.bank.api.rewards.account.EligibleAccount.Builder;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = Builder.class)
public class EligibleAccount {

    private String accountNumber;
    
    private String alternateAccountNumber;

    private String eligibilityStatus;

    private EligibleAccount(Params params) {
        this.accountNumber = params.accountNumber;
        this.alternateAccountNumber = params.alternateAccountNumber;
        this.eligibilityStatus = params.eligbilityStatus;
    }

    public String getAccountNumber() {
        return accountNumber;
    }
    public String getAlternateAccountNumber() {
        return alternateAccountNumber;
    }

    public String getEligibilityStatus() {
        return eligibilityStatus;
    }

    public static Builder newInstance() {
        return new Builder();
    }

    public static class Builder {

        private final Params p;

        public Builder() {
            this.p = new Params();
        }

        @JsonProperty
        public Builder withAccountNumber(String accountNumber) {
            this.p.accountNumber = accountNumber;
            return this;
        }
        @JsonProperty
        public Builder withAlternateAccountNumber(String alternateAccountNumber) {
            this.p.alternateAccountNumber = alternateAccountNumber;
            return this;
        }

        @JsonProperty
        public Builder withEligibilityStatus(String eligibilityStatus) {
            this.p.eligbilityStatus = eligibilityStatus;
            return this;
        }
        
        

        public EligibleAccount build() {
            return new EligibleAccount(this.p);
        }
    }

    private static class Params {
        private String accountNumber;
        private String eligbilityStatus;
        private String alternateAccountNumber;
    }
}
