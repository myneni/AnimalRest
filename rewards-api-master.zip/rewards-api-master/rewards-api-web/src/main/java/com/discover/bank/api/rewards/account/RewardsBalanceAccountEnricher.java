package com.discover.bank.api.rewards.account;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dfs.marketing.rewardredemptionsvc.ao.BalanceDetail;
import com.dfs.marketing.rewardredemptionsvc.ao.BalanceInquiryInput;
import com.dfs.marketing.rewardredemptionsvc.ao.BalanceInquiryOutput;
import com.dfs.marketing.rewardredemptionsvc.ao.RewardRedemptionServiceException_Exception;
import com.dfs.marketing.rewardredemptionsvc.bd.RewardRedemptionServiceCommonDelegate;
import com.discover.bank.api.rewards.balance.RewardsBalance;
import com.discover.common.base.BigNumbers;
import com.discover.common.stereotype.Utility;

@Utility
public class RewardsBalanceAccountEnricher implements RewardsAccountEnricher<RewardsAccount> {

    private static final Logger LOG = LoggerFactory.getLogger(RewardsBalanceAccountEnricher.class);

    private RewardRedemptionServiceCommonDelegate delegate;

    @Inject
    RewardsBalanceAccountEnricher(RewardRedemptionServiceCommonDelegate delegate) {
        this.delegate = delegate;
    }

    /**
     * Populate the rewardsBalance to enrich the passed account
     * 
     * @see com.discover.bank.api.rewards.account.RewardsAccountEnricher#enrich(com.discover.bank.api.core.accounts.BankAccount)
     */
    @Override
    public RewardsAccount enrich(RewardsAccount account) {
        RewardsBalance balance = lookupRewardsBalanceForAccount(account);

        if (balance != null) {
            account.setRewardsBalance(balance);
        }

        return account;
    }

    private RewardsBalance lookupRewardsBalanceForAccount(RewardsAccount account) {

        final BalanceInquiryInput input = buildRewardsBalanceInput(account);

        BalanceInquiryOutput output = null;

        try {
            output = delegate.getRewardsBalance(input);
        } catch (RewardRedemptionServiceException_Exception e) {
            LOG.error("Could not find rewards balance for account {}.", account.getId());
        }

        if (output == null || output.getAccountBalanceDetail() == null
                        || output.getReturnCode() != 0) {
            LOG.error("Output is null from the getRewardsBalance call.");
            return null;
        }

        return transform(output.getAccountBalanceDetail());
    }

    private BalanceInquiryInput buildRewardsBalanceInput(RewardsAccount account) {
        BalanceInquiryInput input = new BalanceInquiryInput();

        // For MoBile Banking
        input.setActvySrcCde("MBB");
        input.setFinancialAgreementType(RewardsAccount
                        .getFinancialAgreementType(account.getProduct().getProductGroup()));
        input.setAccountNumber(account.getAccountNumber().getValue());
        input.setChannelCode("MP");

        return input;
    }

    /**
     * Transforms the BalanceDetail object from the service into our RewardsData object
     *
     * @param from The BalanceDetail object to be transformed
     * @return RewardsData object to be attached to the RewardsAccount
     */
    private RewardsBalance transform(BalanceDetail from) {
        LOG.info("Rewards Data - CurrentBalance: {}, Available Balance: {} EligibilityCode: {}",
                        new Object[] {from.getCurrentRewardBalance(),
                                        from.getAvailableToRedeemRwrdBal(),
                                        from.getRedemptionEligibleCode()});

        return RewardsBalance.initialize()
                        .withCurrentBalance(BigNumbers.parseMoney(from.getCurrentRewardBalance()))
                        .withAvailableBalance(
                                        BigNumbers.parseMoney(from.getAvailableToRedeemRwrdBal()))
                        .withEligibleForRedemption(from.getRedemptionEligibleCode() != null
                                        ? "Y".equalsIgnoreCase(from.getRedemptionEligibleCode())
                                        : false)
                        .build();
    }

}
