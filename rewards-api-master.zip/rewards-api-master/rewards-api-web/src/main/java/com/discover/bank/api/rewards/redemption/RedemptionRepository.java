package com.discover.bank.api.rewards.redemption;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.dfs.marketing.rewardredemptionsvc.ao.Order;
import com.dfs.marketing.rewardredemptionsvc.ao.OrderHistory;
import com.dfs.marketing.rewardredemptionsvc.ao.OrderHistoryInput;
import com.dfs.marketing.rewardredemptionsvc.ao.OrderHistoryOutput;
import com.dfs.marketing.rewardredemptionsvc.ao.OrderItem;
import com.dfs.marketing.rewardredemptionsvc.ao.OrderOutput;
import com.dfs.marketing.rewardredemptionsvc.ao.PastOrderItem;
import com.dfs.marketing.rewardredemptionsvc.ao.RewardRedemptionServiceException;
import com.dfs.marketing.rewardredemptionsvc.ao.RewardRedemptionServiceException_Exception;
import com.dfs.marketing.rewardredemptionsvc.bd.RewardRedemptionServiceBDInterface;
import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.customers.Customer;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsException;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.bank.api.rewards.redemption.Redemption.RedemptionStatus;
import com.discover.common.base.BigNumbers;
import com.discover.common.base.Dates;
import com.discover.common.base.Dates.Format;
import com.discover.common.stereotype.Repository;
import com.google.common.base.Strings;

@Repository
public class RedemptionRepository {

    private static final Logger LOG = LoggerFactory.getLogger(RedemptionRepository.class);

    private static final String RRS_DATE_FMT = "yyyy-MM-dd HH:mm:ss";

    private static final String MODECD_TRANSFER = "XTORW";

    private PropertyAccessor propertyFinder;

    private RestTemplate restTemplate;

    private RewardRedemptionServiceBDInterface delegate;
    private static String CONSUMER_INFO_HEADER = "X-DFS-C-APP-INFO";
    private static final String CHANNEL_NAME = "MP";
    private static final String CHANNEL_AND_APP_NAME = "MOBILE";
    private static final String CHANNEL_ID = "WEB";

    private static final String REWARDS_BUCKET_DOMAIN = "rewards.bucket.api.domain";
    private static final String REWARDS_BUCKET = "rewards.redemption";

    private static final String DEP_SAVINGS = "deposit.savings";
    private static final String DEP_CHECKING = "deposit.checking";
    private static final String DEP_MONEY_MARKET = "deposit.moneymarket";

    /**
     * Submits a rewards redemption to the service. The result will contain the confirmationNumber
     * of the redemption
     *
     * @return RewardsRedemption The resulting redemption which will contain a confirmationNumber
     * @param redemption The input for which to make a rewards redemption
     * @throws RewardsException Thrown if the service call results in an error or if the returnCode
     *         of the result is != 0
     */

    @Inject
    RedemptionRepository(RestTemplate restTemplate, PropertyAccessor propertyFinder,
                    RewardRedemptionServiceBDInterface delegate) {
        this.propertyFinder = propertyFinder;
        this.restTemplate = restTemplate;
        this.delegate = delegate;
    }

    public Redemption redeemRewards(Redemption redemption, Customer customerId)
                    throws RewardsException {

        if (Redemptions.isDeposit(redemption.getRedemptionType())) {
            return redeemDeposit(customerId, redemption);
        } else {
            Order input = buildSubmitOrderInput(redemption);
            return transformTransferRewards(redeemTransfer(input), redemption);
        }

    }

    public List<Redemption> lookupRedemptionHistoryForAccount(RewardsAccount account, int months, List<BankAccount> customerAccounts)
                    throws RewardsException {
        OrderHistoryInput input = buildOrderHistoryInput(account, months);
        OrderHistoryOutput output = null;

        try {
            output = delegate.getOrderHistory(input);
        } catch (RewardRedemptionServiceException_Exception e) {
            RewardRedemptionServiceException ex = e.getFaultInfo();
            LOG.error("RewardRedemptionServiceException thrown while looking up rewards history with exceptionCode:{}",
                            ex.getExceptionCode(), e);
            throw new RewardsException();
        }

        if (output == null) {
            LOG.error("Output is null from the getRewardsHistory call.");
            throw new RewardsException();
        }

        return transform(output, account, customerAccounts);
    }

    /**
     * Builds the input for the rewards redemption call
     *
     * @param redemption RewardsRedemption object to be transformed into the service input
     * @return Order the object to be submitted to the service
     */
    private Order buildSubmitOrderInput(Redemption redemption) {
        Order result = new Order();
        result.setActvySrcCde("MBB");
        result.setTraceLevel(0);
        result.setAccountNumber(redemption.getFromRewardsAccount().getAccountNumber().getValue());
        result.setFinancialAgreementType(RewardsAccount.getFinancialAgreementType(
                        redemption.getFromRewardsAccount().getProduct().getProductGroup()));
        result.setChannelCode("MP");
        result.setRequestInitDate(new SimpleDateFormat(RRS_DATE_FMT).format(Dates.now()));

        OrderItem orderItem = new OrderItem();
        final String formattedAmount =
                        BigNumbers.MoneyFormat.NEGATIVE_WITHOUT_CURRENCY_OR_GROUPING.formatter()
                                                                                    .format(new BigDecimal(
                                                                                                    redemption.getAmount()).setScale(
                                                                                                                    2).divide(BigDecimal.valueOf(
                                                                                                                                    100)));
        orderItem.setRequestAmt(formattedAmount);
        orderItem.setDisbActivityCashAmt(formattedAmount);
        // Currently we only allow 1 redemption at a time
        orderItem.setQuantity("1");
        orderItem.setCategoryCode("CSH");
        orderItem.setModeGroupCode("CSH");
        orderItem.setRacf("inet");

        orderItem.setModeCode(MODECD_TRANSFER);
        CreditCardAccount cc = redemption.getToCreditCardAccount();
        orderItem.setDestinationAccountNumber(cc.getAccountNumber().getValue());
        orderItem.setDestinationAccountIncentiveCode(cc.getIncentiveCode());
        orderItem.setDestinationAccountIncentiveType(cc.getIncentiveType());

        // These last 2 are optional
        orderItem.setDestinationAccountCardType(cc.getCardType());
        orderItem.setDestinationAccountOptionCode(cc.getOptionCode());

        result.getOrderItems().add(orderItem);

        LOG.info("Submitting rewards redemption on account ending {}, with financialAgreementType: {}, for amount: {}",
                        new Object[] {redemption.getFromRewardsAccount()
                                                .getAccountNumber()
                                                .getEnding(),
                                        result.getFinancialAgreementType(), formattedAmount});

        return result;
    }

    public OrderHistoryInput buildOrderHistoryInput(RewardsAccount account, int months) {
        OrderHistoryInput result = new OrderHistoryInput();

        Date end = Dates.now();

        Calendar date = Calendar.getInstance();
        date.setTime(end);

        date.add(Calendar.MONTH, -(months));

        date.set(Calendar.DAY_OF_MONTH, 1);
        Date start = date.getTime();

        result.setAccountNumber(account.getAccountNumber().getValue());
        result.setFinancialAgreementType(RewardsAccount.getFinancialAgreementType(
                        account.getProduct().getProductGroup()));
        result.setChannelCode("MP");
        result.setStartDate(Dates.print(start, Format.BIG_ENDIAN_HYPHEN));
        result.setEndDate(Dates.print(end, Format.BIG_ENDIAN_HYPHEN));

        return result;
    }

    protected List<Redemption> transform(OrderHistoryOutput from, RewardsAccount rAccount,
                    List<BankAccount> customerAccounts) {
        List<Redemption> result = new ArrayList<Redemption>();

        // If the user has no history, this object will be null... not empty... but just to make
        // sure we check both.
        if (from.getOrderHistory() == null || from.getOrderHistory().size() == 0) {
            return result;
        }

        for (OrderHistory historyItem : from.getOrderHistory()) {
            if (isValidBasicRedemption(historyItem)) {
                Order order = historyItem.getOrder();
                PastOrderItem orderItem = order.getPastOrderItems().get(0);
                // Create our builder and put in what we know.
                String redType = propertyFinder.get(orderItem.getModeCode());
                if (Strings.isNullOrEmpty(redType)) {
                    // if we dont have a redemption type that we know of, then we dont want to show
                    // it.
                    continue;
                }

                Date requestInitDate = null;
                SimpleDateFormat sdf = new SimpleDateFormat(RRS_DATE_FMT);
                try {
                    requestInitDate = sdf.parse(order.getRequestInitDate());
                } catch (ParseException ex) {
                    LOG.error("Experianced issue with request init date - ", ex);
                }

                Redemption.Builder redBuild = Redemption.newBuilder()
                                                        .withFromRewardsAccount(rAccount)
                                                        // Display the new description as default. If we 
                                                        // have to override, then set <modecode>.DESC in prop file.
                                                        .withRedemptionTypeDesc(propertyFinder.get(
                                                                        orderItem.getModeCode()
                                                                                        + ".DESC",
                                                                        getDefaultRedemptionTypeDesc(
                                                                                        orderItem, customerAccounts)))
                                                        // try to get a better description (based on
                                                        // the code). If we cant
                                                        // find one, return the description from the
                                                        // service.
                                                        .withRedemptionType(redType)
                                                        .withAmount(BigNumbers.toMoney(
                                                                        orderItem.getDisbursementAmount()))
                                                        .withStatus(RedemptionStatus.fromCode(
                                                                        orderItem.getStatusCode()))
                                                        .withConfirmationNumber(order.getOrderId())
                                                        .on(requestInitDate);

                // If we are a transfer, we would like to know whom we transfered it to.
                if (Redemptions.isTransfer(orderItem.getModeCode())) {
                    // If we dont know who we transferred it to then how can we be a transfer?
                    if (!Strings.isNullOrEmpty(orderItem.getDestinationAccountNumber())) {
                        redBuild.withToCreditCardAccount(
                                        CreditCardAccount.newBuilder()
                                                         .withAccountNumber(AccountNumber.parse(
                                                                         orderItem.getDestinationAccountNumber()))
                                                         .build());
                    } else {
                        // we dont have a destination account, but we transferred it somewhere?
                        // Nope!
                        LOG.warn("Transfer Redemption missing Destination Account!!! ConfNumber: "
                                        + order.getOrderId());

                        // break out of this iteration of the for loop.
                        continue;
                    }
                } else {

                    // If we dont know who we transferred it to then how can we be a deposit?
                    if (!Strings.isNullOrEmpty(orderItem.getDestinationAccountNumber())) {
                        redBuild.withToAccount(RewardsAccount.newBuilder()
                                                             .setAccountNumber(AccountNumber.parse(
                                                                             orderItem.getDestinationAccountNumber()))
                                                             .build());
                    } else {
                        // we dont have a destination account, but we transferred it somewhere?
                        // Nope!
                        LOG.warn("Deposit Redemption missing Destination Account!!! ConfNumber: "
                                        + order.getOrderId());

                        // break out of this iteration of the for loop.
                        continue;
                    }

                }

                // if we got here we should have a valid redemption.
                Redemption red = redBuild.build();
                result.add(red);
                LOG.debug(" Valid Redemption: Type: {}, Disbursment: {}, Status: {}, OrderDate: {}, Conf Num: {}, To: {}",
                                new Object[] {red.getRedemptionType(), red.getAmount(),
                                                red.getStatus(), red.getOrderDate(),
                                                red.getConfirmationNumber(),
                                                Redemptions.isTransfer(red.getRedemptionType())
                                                                ? red.getToCreditCardAccount()
                                                                     .getAccountNumber()
                                                                : ""});
            } else {
                // looks like we dont have a valid redemption
                LOG.warn(" Invalid History item found!! Something was missing!");
            }
        }

        return result;
    }
    
    /**
     * This method is to get the redemption type description for Deposit and Transfer to Credit
     * Card.
     * 
     * @param orderItem
     * @param customerAccounts
     * @return
     */
    protected String getDefaultRedemptionTypeDesc(PastOrderItem orderItem,
                    List<BankAccount> customerAccounts) {
        
        if (customerAccounts == null || orderItem == null) {
            return "";
        }
        
        if (Redemptions.isTransfer(orderItem.getModeCode())) { // Transfer to Credit Card
            StringBuilder redempTypeDescCreditCardBuilder = new StringBuilder();
            redempTypeDescCreditCardBuilder.append(propertyFinder.get("redeem.to.credit.card")).append(" ")
                                           .append(orderItem.getDestinationAccountNumber() != null 
                                           ? AccountNumber.parse(orderItem.getDestinationAccountNumber())
                                           : "").append(" ")
                                           .append(propertyFinder.get("redeem.to.credit.card.suffix"));
            return redempTypeDescCreditCardBuilder.toString();
        } else if (!customerAccounts.isEmpty() && Redemptions.isDeposit(orderItem.getModeCode())) { // Redeem To Deposit
            return buildRedempTypeDescDeposits(orderItem, customerAccounts);
        }

        return "";
    }

    /**
     * This method is to build the redemption type description for Deposits.
     * 
     * @param orderItem
     * @param customerAccounts
     * @return
     */
    protected String buildRedempTypeDescDeposits(PastOrderItem orderItem,
                    List<BankAccount> customerAccounts) {

        for (BankAccount custAccount : customerAccounts) {
            if (custAccount != null && custAccount.getAccountNumber() != null
                            && custAccount.getAccountNumber().getFormattedValue().equals(
                                            orderItem.getDestinationAccountNumber())) {
                StringBuilder redempTypeDescDepositsBuilder = new StringBuilder();
                redempTypeDescDepositsBuilder.append(propertyFinder.get("redeem.to.deposit"))
                                             .append(" ")
                                             .append(custAccount.getNickName())
                                             .append(" ")
                                             .append(AccountNumber.parse(
                                                             orderItem.getDestinationAccountNumber()));
                return redempTypeDescDepositsBuilder.toString();
            }
        }
        // Build default redemption type description if destination account doesn't match with
        // customer accounts.
        return buildDefaultRedempTypeDescDeposits(orderItem.getModeCode());
    }

    /**
     * This method is to build the default redemption type description for Deposit if the
     * destination account number from RRS doesn't match with customer accounts
     * 
     * @param modeCode
     * @return
     */
    protected String buildDefaultRedempTypeDescDeposits(String modeCode) {
        if (propertyFinder.get(DEP_CHECKING).equalsIgnoreCase(modeCode)) {
            return propertyFinder.get("redeem.desc.checking.empty");
        } else if (propertyFinder.get(DEP_SAVINGS).equalsIgnoreCase(modeCode)) {
            return propertyFinder.get("redeem.desc.savings.empty");
        } else if (propertyFinder.get(DEP_MONEY_MARKET).equalsIgnoreCase(modeCode)) {
            return propertyFinder.get("redeem.desc.moneymarket.empty");
        }
        return "";
    }

    /**
     * Private method to check if the returned object has all the stuff we want to make a
     * redemption.
     * 
     * @param historyItem
     * @return
     */
    private boolean isValidBasicRedemption(OrderHistory historyItem) {

        // if any of the items in the checks or checks2 object arrays are null then we are not
        // valid.
        // if any of the 'strings' in checks2 are null or empty we are not valid
        // further before we even validate checks2 we need to make sure we have a past order item.

        Object[] checks = new Object[] {historyItem, historyItem.getOrder(),
                        historyItem.getOrder().getPastOrderItems()};
        Object[] checks2 =
                        new Object[] {historyItem.getOrder().getOrderId(),
                                        historyItem.getOrder().getRequestInitDate(),
                                        historyItem.getOrder().getPastOrderItems().get(0),
                                        historyItem.getOrder()
                                                   .getPastOrderItems()
                                                   .get(0)
                                                   .getModeCode(),
                                        historyItem.getOrder()
                                                   .getPastOrderItems()
                                                   .get(0)
                                                   .getDisbursementAmount(),
                                        historyItem.getOrder()
                                                   .getPastOrderItems()
                                                   .get(0)
                                                   .getStatusCode()};
        if (!isNull(checks, false) && historyItem.getOrder().getPastOrderItems().size() > 0
                        && !isNull(checks2, true)) {
            return true;
        }

        return false;
    }

    private boolean isNull(Object[] objects, boolean checkStringEmpty) {
        final String empty = "";
        boolean result = false;

        if (objects != null && objects.length > 0) {
            for (Object obj : objects) {
                if (obj == null) {
                    result = true;
                    LOG.info("Found null object!");
                } else if (checkStringEmpty && obj instanceof String && empty.equals(obj)) {
                    result = true;
                }
                if (result) {
                    break;
                }
            }
        }

        return result;

    }

    public void setRewardRedemptionServiceBDInterface(RewardRedemptionServiceBDInterface delegate) {
        this.delegate = delegate;
    }

    private OrderOutput redeemTransfer(Order input) throws RewardsException {

        try {
            return delegate.submitOrder(input);
        } catch (RewardRedemptionServiceException_Exception e) {
            RewardRedemptionServiceException ex = e.getFaultInfo();
            LOG.error("RewardRedemptionServiceException thrown while redeeming rewards with exceptionCode:{}",
                            ex.getExceptionCode(), e);
            throw new RewardsException();
        }
    }

    private Redemption redeemDeposit(Customer customer, Redemption redem) throws RewardsException {

        ResponseEntity<SubmitRedepmtionOutputVO> response = null;
        SubmitRedepmtionInputVO submitRedepmtionInputVO = null;
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(CONSUMER_INFO_HEADER, getConsumerInfo(customer.getId()));

        submitRedepmtionInputVO = buildDepositRewardsInput(redem);

        HttpEntity<SubmitRedepmtionInputVO> requestEntity =
                        new HttpEntity<SubmitRedepmtionInputVO>(submitRedepmtionInputVO, headers);
        // TODO once tested, change to debug
        LOG.info("requestEntity  {}", requestEntity);
        try {

            final String url = UriComponentsBuilder.fromHttpUrl(
                            propertyFinder.get(REWARDS_BUCKET_DOMAIN)
                                            + propertyFinder.get(REWARDS_BUCKET)).toUriString();

            LOG.info("making restTemplate call with endPointUri as: {} ", url);

            long startTime = System.currentTimeMillis();

            response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
                            SubmitRedepmtionOutputVO.class);

            long endTime = System.currentTimeMillis();

            LOG.info("Response time for GET {} is  {} ms", url, (endTime - startTime));

            LOG.info("response: {}", response);
        } catch (HttpClientErrorException ce) {
            LOG.error("Caught HttpClientErrorException with status code as: {}, body as {}",
                            ce.getStatusCode(), ce.getResponseBodyAsString(), ce);
            if ((HttpStatus.BAD_REQUEST.equals(ce.getStatusCode())
                            || HttpStatus.NOT_FOUND.equals(ce.getStatusCode()))
                            && ("E003".contains(ce.getResponseBodyAsString())
                                            || "E102".contains(ce.getResponseBodyAsString()))) {
                LOG.error("Caught HttpClientErrorException with status code as: {}, body as {}",
                                ce.getStatusCode(), ce.getResponseBodyAsString(), ce);
                throw new RewardsException();
            }

        } catch (HttpServerErrorException hse) {
            LOG.error("Caught HttpServerErrorException with Http status code as: {}, body as {}",
                            hse.getStatusCode(), hse.getResponseBodyAsString(), hse);
            throw new RewardsException();

        } catch (Exception e) {
            LOG.error("Exception ocurred when calling Rewards Bucket Service", e);
            throw new RewardsException();
        }
        if (response == null || response.getBody() == null) {
            LOG.warn("Error ocurred while getting the response from Bank Rewards Service for {}.",
                            customer.getId());
            throw new RewardsException();
        }
        return transformDepositRewards(response.getBody(), redem);

    }

    private SubmitRedepmtionInputVO buildDepositRewardsInput(Redemption redem) {
        SubmitRedepmtionInputVO submitRedepmtionInputVO;
        final String formattedAmount =
                        BigNumbers.MoneyFormat.NEGATIVE_WITHOUT_CURRENCY_OR_GROUPING.formatter()
                                                                                    .format(new BigDecimal(
                                                                                                    redem.getAmount()).setScale(
                                                                                                                    2).divide(BigDecimal.valueOf(
                                                                                                                                    100)));
        String destinationAccntNumbr;
        String productCode = "002";
        if (redem.getToAccount() != null) {
            destinationAccntNumbr = redem.getToAccount().getAccountNumber().getValue();
            if ("SBSTD".equals(redem.getToAccount().getProduct().getProductCode()))
                productCode = "001";
            else if ("SBGMM".equals(redem.getToAccount().getProduct().getProductCode()))
                productCode = "003";
        } else {
            destinationAccntNumbr = redem.getFromRewardsAccount().getAccountNumber().getValue();
        }

        // Null Check to fix NullPointer Issue while redeeming to checking flow.
        if (redem.getToAccount() != null && redem.getToAccount().getProduct() != null) {
            LOG.info("The Redemption object details: ProductCode= {} ; Amount={}",
                            redem.getToAccount().getProduct().getProductCode(), formattedAmount);
        }
        LOG.info("product group={}", redem.getFromRewardsAccount().getProduct().getProductGroup());
        submitRedepmtionInputVO =
                        SubmitRedepmtionInputVO.newInstance()
                                               .withAccountNumber(redem.getFromRewardsAccount()
                                                                       .getAccountNumber()
                                                                       .getValue())
                                               .withActivitySourceCode("MBB")
                                               .withFinancialAgreementType(
                                                               RewardsAccount.getFinancialAgreementType(
                                                                               redem.getFromRewardsAccount()
                                                                                    .getProduct()
                                                                                    .getProductGroup()))
                                               .withInitialRequestDate(
                                                               DateTimeFormat.forPattern(
                                                                               "dd-MMM-yy")
                                                                             .print(LocalDateTime.fromDateFields(
                                                                                             Dates.now())))
                                               .withOrderItem(OrderItemVO.newInstance()
                                                                         .withCategoryCode("CSH")
                                                                         .withRequestAmt(AmountVO.newInstance()
                                                                                                 .withAmount(new BigDecimal(
                                                                                                                 formattedAmount))
                                                                                                 .withCurCode("USD")
                                                                                                 .build())
                                                                         .withDisbursementActivityCashAmt(
                                                                                         AmountVO.newInstance()
                                                                                                 .withAmount(new BigDecimal(
                                                                                                                 formattedAmount))
                                                                                                 .withCurCode("USD")
                                                                                                 .build())
                                                                         .withModeGroupCode("CSH")
                                                                         .withProductCode(
                                                                                         productCode)
                                                                         .withTargetAcctNumber(
                                                                                         destinationAccntNumbr)
                                                                         .build())
                                               .build();
        return submitRedepmtionInputVO;
    }

    /**
     * return consumerInfo string with below info {App Name}|{Channel Id}|{Channel Name}|{Request
     * UUID}|{User Id}|{Login Security Token}|{Login Session Id}
     * 
     * @return consumer info in String
     */
    protected String getConsumerInfo(CustomerIdentification customer) {
        StringBuilder sb = new StringBuilder();
        sb.append(CHANNEL_AND_APP_NAME).append("|");
        sb.append(CHANNEL_ID).append("|");
        sb.append(CHANNEL_NAME).append("|");
        sb.append(customer.getRequestIdentifier() != null
                        ? customer.getRequestIdentifier().getRequestId() : "")
          .append("|");
        sb.append(CHANNEL_AND_APP_NAME).append("|");
        sb.append("").append("|");
        sb.append("").append("|");

        return sb.toString();
    }

    private Redemption transformTransferRewards(OrderOutput output, Redemption redem)
                    throws RewardsException {
        if (output == null || output.getOrder() == null) {
            LOG.error("Output is null from the submitOrder call.");
            throw new RewardsException();
        }
        LOG.debug("Redemption successful with fromRewardsAccount: {}, toCreditCardAccount: {}, amount: {}, redemptionType: {}, confirmationNumber: {}",
                        redem.getFromRewardsAccount().getAccountNumber(),
                        redem.getToCreditCardAccount() == null ? null
                                        : redem.getToCreditCardAccount()
                                               .getAccountNumber()
                                               .getFormattedValue(),
                        redem.getAmount(), redem.getRedemptionType(),
                        output.getOrder().getOrderId());

        // Rebuild the request with a confirmation number
        return Redemption.newBuilder()
                         .from(redem)
                         .withConfirmationNumber(output.getOrder().getOrderId())
                         .withRemainingBalance(BigNumbers.parseMoney(
                                         output.getOrder().getRewardsBalance()))
                         .build();
    }


    private Redemption transformDepositRewards(SubmitRedepmtionOutputVO response, Redemption redem)
                    throws RewardsException {
        if (response.requestAmount == null || response.orderId == null) {
            LOG.warn("Error ocurred while transforming the response object");
            throw new RewardsException();
        }
        LOG.debug("Redemption successful with fromRewardsAccount: {}, toAccount: {}, amount: {}, redemptionType: {}, confirmationNumber: {}",
                        redem.getFromRewardsAccount().getAccountNumber().getFormattedValue(),
                        redem.getToAccount() != null
                                        && redem.getToAccount().getAccountNumber() != null
                                                        ? redem.getToAccount()
                                                               .getAccountNumber()
                                                               .getFormattedValue()
                                                        : "null",
                        response.getRequestAmount().getAmount(), redem.getRedemptionType(),
                        response.getOrderId());
        return Redemption.newBuilder()
                         .withConfirmationNumber(response.getOrderId())
                         .withFromRewardsAccount(redem.getFromRewardsAccount())
                         .withToAccount(redem.getToAccount())
                         .withAmount(BigNumbers.toMoney(response.getRequestAmount().getAmount()))
                         .withRedemptionType(redem.getRedemptionType())
                         .withRemainingBalance(BigNumbers.toMoney(
                                         response.getRewardsBalanceAmount().getAmount()))
                         .build();

    }

}
