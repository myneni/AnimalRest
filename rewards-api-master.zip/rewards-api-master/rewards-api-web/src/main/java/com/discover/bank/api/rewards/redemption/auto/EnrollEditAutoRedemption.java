package com.discover.bank.api.rewards.redemption.auto;

import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.rewards.redemption.Redemption;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.google.common.base.MoreObjects;

@JsonDeserialize(builder = EnrollEditAutoRedemption.Builder.class)
public class EnrollEditAutoRedemption {

    private BankAccount fromAccount;

    private BankAccount toAccount;

    private boolean didOneTimeRedemption = false;

    private Redemption oneTimeRedemption;

    private String bannerText;

    private EnrollEditAutoRedemption() {}

    private EnrollEditAutoRedemption(Params parms) {
        this.fromAccount = parms.fromAccount;
        this.toAccount = parms.toAccount;
        this.didOneTimeRedemption = parms.didOneTimeRedemption;
        this.oneTimeRedemption = parms.oneTimeRedemption;
        this.bannerText = parms.bannerText;
    }

    public BankAccount getFromAccount() {
        return fromAccount;
    }

    @JsonProperty
    public BankAccount getToAccount() {
        return toAccount;
    }

    @JsonProperty
    public boolean didOneTimeRedemption() {
        return didOneTimeRedemption;
    }

    @JsonProperty
    public Redemption getOneTimeRedemption() {
        return oneTimeRedemption;
    }

    @JsonProperty
    public String getBannerText() {
        return bannerText;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static Builder newBuilder(EnrollEditAutoRedemption autoRedemption) {
        return new Builder(autoRedemption);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                          .omitNullValues()
                          .add("fromAccount", fromAccount)
                          .add("toAccount", toAccount)
                          .add("didOneTimeRedemption", didOneTimeRedemption)
                          .add("oneTimeRedemption", oneTimeRedemption)
                          .add("bannerText", bannerText)
                          .toString();
    }

    public static class Builder {

        private final Params p;

        public Builder() {
            this.p = new Params();
        }

        public Builder(EnrollEditAutoRedemption p) {
            this.p = new Params();
            this.p.toAccount = p.getToAccount();
            this.p.didOneTimeRedemption = p.didOneTimeRedemption;
            this.p.oneTimeRedemption = p.oneTimeRedemption;
            this.p.bannerText = p.bannerText;
        }

        public Builder withFromAccount(BankAccount fromAccount) {
            this.p.fromAccount = fromAccount;
            return this;
        }

        @JsonProperty
        public Builder withToAccount(BankAccount toAccount) {
            this.p.toAccount = toAccount;
            return this;
        }

        public Builder withDidOneTimeRedemption(boolean didOneTimeRedemption) {
            this.p.didOneTimeRedemption = didOneTimeRedemption;
            return this;
        }

        public Builder withOneTimeRedemption(Redemption oneTimeRedemption) {
            this.p.oneTimeRedemption = oneTimeRedemption;
            return this;
        }

        public Builder withBannerText(String bannerText) {
            this.p.bannerText = bannerText;
            return this;
        }

        public EnrollEditAutoRedemption build() {
            return new EnrollEditAutoRedemption(this.p);
        }
    }

    private static final class Params {
        private BankAccount fromAccount;
        private BankAccount toAccount;
        private boolean didOneTimeRedemption;
        private Redemption oneTimeRedemption;
        private String bannerText;
    }
}
