package com.discover.bank.api.rewards.redemption;

import com.discover.bank.api.exception.UnrecoverableResolvableError;

public class UnrecoverableRedemptionException extends RuntimeException
                implements UnrecoverableResolvableError {

    private static final long serialVersionUID = 1L;

    private final String[] codes;

    public UnrecoverableRedemptionException() {
        codes = new String[0];
    }

    public UnrecoverableRedemptionException(String... codes) {
        this.codes = codes;
    }

    @Override
    public String[] getCodes() {
        return codes;
    }

}
