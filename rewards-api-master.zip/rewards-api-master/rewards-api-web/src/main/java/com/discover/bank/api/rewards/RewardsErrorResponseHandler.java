package com.discover.bank.api.rewards;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.discover.bank.api.ErrorResolver;
import com.discover.bank.api.ErrorResponse;
import com.discover.bank.api.creditcards.CreditCardsException;
import com.discover.bank.api.rewards.account.RewardsAccountNotFoundException;
import com.discover.bank.api.rewards.earnings.EarningsInvalidFilterException;

@ControllerAdvice
public class RewardsErrorResponseHandler {

    private static final Logger LOG = LoggerFactory.getLogger(RewardsErrorResponseHandler.class);
    private static final String WARN_MSG = "Exception thrown with message {} : ";

    private ErrorResolver errorResolver;

    @Inject
    public void setErrorResolver(ErrorResolver errorResolver) {
        this.errorResolver = errorResolver;
    }

    @ExceptionHandler({RewardsException.class, CreditCardsException.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ErrorResponse handleException(Exception ex) {

        LOG.warn(WARN_MSG, ex.getMessage(), ex);

        // Just show the general message until they want to display a specific one
        return ErrorResponse.of(errorResolver.resolve("General.TechnicalDifficulties"));
    }

    @ExceptionHandler({RewardsAccountNotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public ErrorResponse handleRewardsAccountNFException(Exception ex) {

        LOG.warn(WARN_MSG, ex.getMessage(), ex);

        // Just show the general message until they want to display a specific one
        return ErrorResponse.of(errorResolver.resolve("api.accounts.accountNotFound"));
    }

    @ExceptionHandler({EarningsInvalidFilterException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ErrorResponse earningsHandleException(Exception ex) {

        LOG.warn(WARN_MSG, ex.getMessage(), ex);

        // Just show the general message until they want to display a specific one
        return ErrorResponse.of(errorResolver.resolve(ex.getMessage()));
    }
}
