package com.discover.bank.api.rewards.redemption;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = AmountVO.Builder.class)
public class AmountVO {
    BigDecimal amount;
    String curCode;

    private AmountVO(Params p) {
        this.amount = p.amount;
        this.curCode = p.curCode;
    }



    public BigDecimal getAmount() {
        return amount;
    }


    public String getCurCode() {
        return curCode;
    }

    public static Builder newInstance() {
        return new Builder();
    }

    public static class Builder {

        private final Params p;

        public Builder() {
            this.p = new Params();
        }

        @JsonProperty
        public Builder withAmount(BigDecimal amount) {
            this.p.amount = amount;
            return this;
        }

        @JsonProperty
        public Builder withCurCode(String curCode) {
            this.p.curCode = curCode;
            return this;
        }


        public AmountVO build() {
            return new AmountVO(this.p);
        }
    }
    private static class Params {
        private BigDecimal amount;
        private String curCode;

    }
}
