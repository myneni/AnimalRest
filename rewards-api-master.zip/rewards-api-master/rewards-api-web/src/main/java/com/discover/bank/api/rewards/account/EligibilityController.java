package com.discover.bank.api.rewards.account;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.hateoas.Hypermedia;
import com.discover.bank.api.hateoas.Resource;
import com.discover.bank.api.rewards.RewardsBusinessObject;
import com.discover.bank.api.rewards.RewardsException;

@Controller
@RequestMapping(value = "", produces = {MediaType.APPLICATION_JSON_VALUE})
public class EligibilityController {

    private static final Logger LOG = LoggerFactory.getLogger(EligibilityController.class);

    @Inject
    private Hypermedia hypermedia;
    @Inject
    private RewardsBusinessObject rewards;

    /**
     *
     * @param customerContext The Customer.
     * @param type The rewards redemption type of the request.
     * @return
     */
    @RequestMapping(value = "/eligibility", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody HttpEntity<Resource<EligibleAccounts>> eligibleRewardAccounts(
                    CustomerIdentification customer,
                    @RequestParam(defaultValue = "onetime") String type)
                    throws RewardsException, RewardsAccountNotFoundException {
        LOG.info("Fetching {} redemption eligible accounts for customer: {}", type,
                        customer.getCustomerNumber());
        return hypermedia.ok(rewards.getEligibleAccounts(customer, type));
    }

}
