package com.discover.bank.api.rewards.redemption.auto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = EditAutoRedemptionOutput.Builder.class)
public class EditAutoRedemptionOutput {

    private String status;

    private EditAutoRedemptionOutput(Params params) {
        this.status = params.status;
    }

    public String getStatus() {
        return status;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder {

        private final Params p;

        private Builder() {
            this.p = new Params();
        }

        @JsonProperty
        public Builder withStatus(String status) {
            this.p.status = status;
            return this;
        }

        public EditAutoRedemptionOutput build() {
            return new EditAutoRedemptionOutput(this.p);
        }
    }

    private static final class Params {
        private String status;
    }
}
