package com.discover.bank.api.rewards.redemption.auto;

public class DeleteAutoRedemptionOutput {

    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
