package com.discover.bank.api.rewards.redemption.auto;

import com.discover.bank.api.core.accounts.BankAccount;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

public class AutoRedemptionResponse {

    private String id;

    private Boolean isEnrolled;

    private String message;

    private BankAccount toAccount;

    private AutoRedemptionResponse() {}

    private AutoRedemptionResponse(Params parms) {
        this.id = parms.id;
        this.message = parms.message;
        this.isEnrolled = parms.isEnrolled;
        this.toAccount = parms.toAccount;
    }

    public String getId() {
        return id;
    }
    
    @JsonProperty
    public Boolean getIsEnrolled() {
        return isEnrolled;
    }

    @JsonProperty
    public String getMessage() {
        return message;
    }

    public BankAccount getToAccount() {
        return toAccount;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static Builder newBuilder(AutoRedemptionResponse autoRedemptionResponse) {
        return new Builder(autoRedemptionResponse);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                          .omitNullValues()
                          .add("toAccount", toAccount)
                          .toString();
    }

    public static class Builder {

        private final Params p;

        public Builder() {
            this.p = new Params();
        }

        public Builder(AutoRedemptionResponse p) {
            this.p = new Params();
            this.p.message = p.id;;
            this.p.message = p.message;
            this.p.isEnrolled = p.isEnrolled;
            this.p.toAccount = p.toAccount;
        }

        public Builder withId(String id) {
            this.p.id = id;
            return this;
        }

        public Builder withIsEnrolled(Boolean isEnrolled) {
            this.p.isEnrolled = isEnrolled;
            return this;
        }

        public Builder withMessage(String message) {
            this.p.message = message;
            return this;
        }

        public Builder withToAccount(BankAccount toAccount) {
            this.p.toAccount = toAccount;
            return this;
        }

        public AutoRedemptionResponse build() {
            return new AutoRedemptionResponse(this.p);
        }
    }

    private static final class Params {
        private String id;
        private Boolean isEnrolled;
        private String message;
        private BankAccount toAccount;
    }
}