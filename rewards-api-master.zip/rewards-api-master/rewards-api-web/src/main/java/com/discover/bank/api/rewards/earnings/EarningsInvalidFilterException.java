package com.discover.bank.api.rewards.earnings;


public class EarningsInvalidFilterException extends Exception {

    private static final long serialVersionUID = 1L;

    public EarningsInvalidFilterException() {
        this("Rewards.InvalidFilter");
        // Can be found in /api/config/rewards/rewards-errors
    }

    public EarningsInvalidFilterException(String message) {
        super(message);
    }

}
