package com.discover.bank.api.rewards.redemption.auto;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsRequestHeaders;
import com.discover.bank.api.rewards.redemption.UnrecoverableRedemptionException;
import com.discover.bank.api.stereotype.Repository;

@Repository
public class AutoRedemptionRepository {

    private static final Logger LOG = LoggerFactory.getLogger(AutoRedemptionRepository.class);

    private static final String ENROLL = "enroll";
    private static final String SUCCESS = "success";

    private static final String BANK_REWARDS_DOMAIN = "rewards.bucket.api.domain";

    private static final String BANK_GET_AUTO_ENROLLMENT_STATUS_PATH =
                    "redemption.enrollment.status.path";

    private static final String BANK_ENROLL_EDIT_REDEMPTION_PATH = "redemption.enroll.edit.path";

    private static final String BANK_DISENROLL_REDEMPTION_PATH =
                    "redemption.disenrollment.api.path";

    private RestTemplate restTemplate;

    private PropertyAccessor props;

    @Inject
    public AutoRedemptionRepository(RestTemplate restTemplate, PropertyAccessor props) {
        this.restTemplate = restTemplate;
        this.props = props;
    }

    public void enrollOrEditAutoRedemption(CustomerIdentification customer,
                    String sourceAccountNumber, String targetAccountNumber, String operationType) {

        EnrollEditAutoRedemptionInput input =
                        EnrollEditAutoRedemptionInput.newBuilder()
                                                     .withCustomerId(customer.getCustomerNumber())
                                                     .withSourceAccountNumber(sourceAccountNumber)
                                                     .withTaretAccountNumber(targetAccountNumber)
                                                     .build();

        HttpHeaders headers = RewardsRequestHeaders.buildRequestHeaders(customer);

        HttpEntity<EnrollEditAutoRedemptionInput> requestEntity =
                        new HttpEntity<EnrollEditAutoRedemptionInput>(input, headers);

        ResponseEntity<EnrollAutoRedemptionOutput> enrollAutoRedempResponse = null;

        ResponseEntity<EditAutoRedemptionOutput> editAutoRedempResponse = null;

        final String url = UriComponentsBuilder
                                               .fromHttpUrl(props.get(BANK_REWARDS_DOMAIN)
                                                               + props.get(BANK_ENROLL_EDIT_REDEMPTION_PATH))
                                               .toUriString();

        LOG.info("Making restTemplate call for customerId {}  enroll redemption with endPointUri as: {} ",
                        customer.getCustomerNumber(), url);

        try {

            long startTime = System.currentTimeMillis();

            if (ENROLL.equalsIgnoreCase(operationType)) {
                LOG.info("Calling BI Enroll Auto Redemption Endpoint");
                enrollAutoRedempResponse = restTemplate.exchange(url, HttpMethod.POST,
                                requestEntity, EnrollAutoRedemptionOutput.class);
            } else {
                LOG.info("Calling BI Edit Auto Redemption Endpoint");
                editAutoRedempResponse = restTemplate.exchange(url, HttpMethod.PUT, requestEntity,
                                EditAutoRedemptionOutput.class);
            }

            long endTime = System.currentTimeMillis();
            LOG.info("Response time {} ms for POST {} ", (endTime - startTime), url);

        } catch (HttpClientErrorException ce) {

            LOG.error("Caught HttpClientErrorException for enrollment/edit call with Http status code as: {}, body as {} ",
                            ce.getStatusCode(), ce.getResponseBodyAsString(), ce);

            if (HttpStatus.NOT_FOUND.equals(ce.getStatusCode())
                            && (ce.getResponseBodyAsString() != null
                                            && ce.getResponseBodyAsString().contains("E002"))) {

                throw new UnrecoverableRedemptionException("enroll.redemption.invalid.account");

            } else if (HttpStatus.BAD_REQUEST.equals(ce.getStatusCode())
                            && (ce.getResponseBodyAsString() != null
                                            && ce.getResponseBodyAsString().contains("E102"))) {

                throw new UnrecoverableRedemptionException();
            } else {

                throw new UnrecoverableRedemptionException();
            }

        } catch (HttpServerErrorException se) {

            LOG.error("Caught HttpServerErrorException for enrollment/edit call with Http status code as: {}, body as {}",
                            se.getStatusCode(), se.getResponseBodyAsString(), se);
            throw new UnrecoverableRedemptionException();

        } catch (Exception e) {

            LOG.error("Caught Exception when Call Bank Rewards API", e);
            throw new UnrecoverableRedemptionException();
        }

        // Enroll validation
        if (ENROLL.equalsIgnoreCase(operationType)) {
            validateEnrollResponse(enrollAutoRedempResponse, url);
        } else { // Edit enroll validation
            validateEditEnrollResponse(editAutoRedempResponse, url);
        }
    }

    protected void validateEnrollResponse(
                    ResponseEntity<EnrollAutoRedemptionOutput> enrollAutoRedempResponse,
                    String endpoint) {

        if (enrollAutoRedempResponse == null || enrollAutoRedempResponse.getBody() == null) {
            LOG.error("Receive invalid response for this call {}.", endpoint);
            throw new UnrecoverableRedemptionException();
        } else if (!SUCCESS.equalsIgnoreCase(
                        enrollAutoRedempResponse.getBody().getEnrollmentStatus())) {
            LOG.error("Response with Enroll AutoRedemption Status as {}, it's not Success as expected.",
                            enrollAutoRedempResponse.getBody().getEnrollmentStatus());
            throw new UnrecoverableRedemptionException();
        } else {
            LOG.info("Enroll Auto Redemption Status is {} ",
                            enrollAutoRedempResponse.getBody().getEnrollmentStatus());
        }
    }

    protected void validateEditEnrollResponse(
                    ResponseEntity<EditAutoRedemptionOutput> editAutoRedempResponse,
                    String endpoint) {

        if (editAutoRedempResponse == null || editAutoRedempResponse.getBody() == null) {
            LOG.error("Receive invalid response for this call {}.", endpoint);
            throw new UnrecoverableRedemptionException();
        } else if (!SUCCESS.equalsIgnoreCase(editAutoRedempResponse.getBody().getStatus())) {
            LOG.error("Response with Edit AutoRedemption Status as {}, it's not Success as expected.",
                            editAutoRedempResponse.getBody().getStatus());
            throw new UnrecoverableRedemptionException();
        } else {
            LOG.info("Edit Auto Redemption Status is {} ",
                            editAutoRedempResponse.getBody().getStatus());
        }
    }

    public List<AutoRedemptionAccount> getAutoRedemptionAccountsStatus(
                    CustomerIdentification customerId,
                    EnrollmentDetailsInput enrollmentDetailsInput,
                    List<BankAccount> customerAccounts) {

        HttpHeaders headers = RewardsRequestHeaders.buildRequestHeaders(customerId);

        HttpEntity<EnrollmentDetailsInput> requestEntity =
                        new HttpEntity<EnrollmentDetailsInput>(enrollmentDetailsInput, headers);

        LOG.info("requestEntity: {}", requestEntity.getBody());

        ResponseEntity<EnrollmentDetailsOutput> response = null;

        final String url = UriComponentsBuilder
                                               .fromHttpUrl(props.get(BANK_REWARDS_DOMAIN)
                                                               + props.get(BANK_GET_AUTO_ENROLLMENT_STATUS_PATH))
                                               .toUriString();

        LOG.info("Making restTemplate call for customerId {} with endPointUri as: {} ",
                        customerId.getCustomerNumber(), url);

        try {

            long startTime = System.currentTimeMillis();

            response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
                            EnrollmentDetailsOutput.class);

            long endTime = System.currentTimeMillis();

            LOG.info("Response time {} ms for POST {} ", (endTime - startTime), url);


        } catch (HttpClientErrorException ce) {
            LOG.error("Caught HttpClientErrorException on calling getAutoRedemptionAccounts() with Http status code as: {}, body as {} ",
                            ce.getStatusCode(), ce.getResponseBodyAsString(), ce);
            throw new UnrecoverableRedemptionException();

        } catch (HttpServerErrorException hse) {
            LOG.error("Caught HttpServerErrorException on calling getAutoRedemptionAccounts() with Http status code as: {}, body as {} ",
                            hse.getStatusCode(), hse.getResponseBodyAsString(), hse);
            throw new UnrecoverableRedemptionException();

        } catch (Exception e) {
            LOG.error("Exception ocurred when calling getAutoRedemptionAccounts() for customer id {}.",
                            customerId, e);
            throw new UnrecoverableRedemptionException();
        }

        if (response == null || response.getBody() == null) {
            LOG.warn("Received invalid response for this call {}.", url);
            throw new UnrecoverableRedemptionException();
        }

        return transformAutoRedemptionAccounts(response.getBody(), customerAccounts);
    }

    protected List<AutoRedemptionAccount> transformAutoRedemptionAccounts(
                    EnrollmentDetailsOutput enrollmentDetailsOutput,
                    List<BankAccount> customerAccounts) {

        List<AutoRedemptionAccount> autoRedemptionAccountsDetails =
                        new ArrayList<AutoRedemptionAccount>();

        // BI error scenario
        if (enrollmentDetailsOutput.getEnrollmentDetails() == null
                        || enrollmentDetailsOutput.getEnrollmentDetails().isEmpty()) {

            // BI error scenario
            LOG.warn("Not Enrolled or Enrollment details not found");
            autoRedemptionAccountsDetails.add(AutoRedemptionAccount.getBuilder()
                                                                   .withError(true)
                                                                   .withErrorDescription(
                                                                                   enrollmentDetailsOutput.getErrorCode()
                                                                                                   + " - "
                                                                                                   + enrollmentDetailsOutput.getErrorDescription())
                                                                   .build());

            return autoRedemptionAccountsDetails;
        }

        // Loop through the response if it is not null
        for (EnrollmentDetail enrollmentDetail : enrollmentDetailsOutput.getEnrollmentDetails()) {

            AutoRedemptionAccount autoRedemptionAccount = null;

            // Match the account
            for (BankAccount sourceAccount : customerAccounts) {

                if (sourceAccount.getAccountNumber().getValue().equalsIgnoreCase(
                                enrollmentDetail.getSourceAccountNumber())) {

                    // Not Enrolled
                    if ("N".equalsIgnoreCase(enrollmentDetail.getEnrollmentStatus())) {
                        autoRedemptionAccount = AutoRedemptionAccount.getBuilder()
                                                                     .withId(sourceAccount.getAlternateAccountNumber())
                                                                     .withAccountNumber(
                                                                                     sourceAccount.getAccountNumber())
                                                                     .withNickName(sourceAccount.getNickName())
                                                                     .withIsEnrolled(false)
                                                                     .build();
                    } else if ("Y".equalsIgnoreCase(enrollmentDetail.getEnrollmentStatus())) {

                        // Match the toAccount from eligible
                        BankAccount toAccount = null;
                        for (BankAccount targetAccount : customerAccounts) {
                            if (targetAccount.getAccountNumber().getValue().equalsIgnoreCase(
                                            enrollmentDetail.getTargetAccountNumber())) {
                                toAccount = targetAccount;
                                break;
                            }
                        }

                        // Enrolled
                        autoRedemptionAccount =
                                        AutoRedemptionAccount.getBuilder()
                                                             .withId(sourceAccount.getId())
                                                             .withAccountNumber(
                                                                             sourceAccount.getAccountNumber())
                                                             .withNickName(sourceAccount.getNickName())
                                                             .withIsEnrolled(true)
                                                             .withToAccount(toAccount)
                                                             .build();
                    }

                    // Add to list if it is not null
                    if (autoRedemptionAccount != null) {
                        autoRedemptionAccountsDetails.add(autoRedemptionAccount);
                    }

                    break;
                }
            }
        }

        return autoRedemptionAccountsDetails;
    }

    public void deleteAutoRedemption(CustomerIdentification customerId,
                    AutoRedemptionAccount autoRedemptionAccount) {

        // Build input
        DeleteAutoRedemptionInput deleteAutoRedemptionInput = new DeleteAutoRedemptionInput();
        deleteAutoRedemptionInput.setCustomerId(customerId.getCustomerNumber());
        deleteAutoRedemptionInput.setSourceAccountNumber(
                        autoRedemptionAccount.getAccountNumber().getValue());
        deleteAutoRedemptionInput.setAlternateAccountNumber(
                        autoRedemptionAccount.getAlternateAccountNumber());
        deleteAutoRedemptionInput.setAlertIndicator("N");

        HttpHeaders headers = RewardsRequestHeaders.buildRequestHeaders(customerId);

        HttpEntity<DeleteAutoRedemptionInput> requestEntity =
                        new HttpEntity<DeleteAutoRedemptionInput>(deleteAutoRedemptionInput,
                                        headers);

        ResponseEntity<DeleteAutoRedemptionOutput> response = null;

        final String url = UriComponentsBuilder
                                               .fromHttpUrl(props.get(BANK_REWARDS_DOMAIN)
                                                               + props.get(BANK_DISENROLL_REDEMPTION_PATH))
                                               .toUriString();

        LOG.info("Making restTemplate call for customerId {}  disenroll redemption with endPointUri as: {} ",
                        customerId.getCustomerNumber(), url);

        try {

            long startTime = System.currentTimeMillis();

            response = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
                            DeleteAutoRedemptionOutput.class);

            long endTime = System.currentTimeMillis();

            LOG.info("Response time {} ms for POST {} ", (endTime - startTime), url);


        } catch (HttpClientErrorException e) {
            LOG.error("Caught HttpClientErrorException with Http status code as: {}, body as {} ",
                            e.getStatusCode(), e.getResponseBodyAsString(), e);
            throw new UnrecoverableRedemptionException();

        } catch (HttpServerErrorException e) {

            LOG.error("Caught HttpServerErrorException with Http status code as: {}, body as {} ",
                            e.getStatusCode(), e.getResponseBodyAsString(), e);
            throw new UnrecoverableRedemptionException();

        } catch (Exception e) {
            LOG.error("Exception ocurred when calling disenrollment call () for customer id {}.",
                            customerId, e);
            throw new UnrecoverableRedemptionException();
        }

        if (response == null || response.getBody() == null
                        || response.getBody().getStatus() == null) {
            LOG.error("Error ocurred while getting the response from Bank Rewards API for customer id {}.",
                            customerId);
            throw new UnrecoverableRedemptionException();
        }

        if (!SUCCESS.equalsIgnoreCase(response.getBody().getStatus())) {
            LOG.error("Response with status as {}, it's not Success as expected.",
                            response.getBody().getStatus());
            throw new UnrecoverableRedemptionException();
        }
    }
}
