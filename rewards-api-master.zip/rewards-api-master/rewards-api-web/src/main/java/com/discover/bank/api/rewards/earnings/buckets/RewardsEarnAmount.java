package com.discover.bank.api.rewards.earnings.buckets;

import java.math.BigDecimal;

import com.discover.bank.api.rewards.earnings.buckets.RewardsEarnAmount.Builder;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = Builder.class)
public class RewardsEarnAmount {

    private BigDecimal amount;
    private String curCode;

    private RewardsEarnAmount(RewardsEarnAmountResult p) {
        this.amount = p.amount;
        this.curCode = p.curCode;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getCurCode() {
        return curCode;
    }

    public static Builder newInstance() {
        return new Builder();
    }

    public static class Builder {

        private final RewardsEarnAmountResult p;

        private Builder() {
            this.p = new RewardsEarnAmountResult();
        }

        @JsonProperty
        public Builder withAmount(BigDecimal amount) {
            p.amount = amount;
            return this;
        }

        @JsonProperty
        public Builder withCurCode(String curCode) {
            p.curCode = curCode;
            return this;
        }

        public RewardsEarnAmount build() {
            return new RewardsEarnAmount(p);
        }
    }
    private static class RewardsEarnAmountResult {
        private BigDecimal amount;
        private String curCode;
    }
}
