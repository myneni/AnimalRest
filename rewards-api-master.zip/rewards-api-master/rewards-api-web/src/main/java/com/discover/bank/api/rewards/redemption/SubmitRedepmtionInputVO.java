package com.discover.bank.api.rewards.redemption;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(builder = SubmitRedepmtionInputVO.Builder.class)
public class SubmitRedepmtionInputVO {

    String accountNumber;
    String activitySourceCode;
    String financialAgreementType;
    String initialRequestDate;
    OrderItemVO orderItem;

    private SubmitRedepmtionInputVO(Params p) {
        this.accountNumber = p.accountNumber;
        this.activitySourceCode = p.activitySourceCode;
        this.financialAgreementType = p.financialAgreementType;
        this.initialRequestDate = p.initialRequestDate;
        this.orderItem = p.orderItem;
    }


    public String getAccountNumber() {
        return accountNumber;
    }


    public String getActivitySourceCode() {
        return activitySourceCode;
    }


    public String getFinancialAgreementType() {
        return financialAgreementType;
    }


    public String getInitialRequestDate() {
        return initialRequestDate;
    }

    public OrderItemVO getOrderItem() {
        return orderItem;
    }

    public static Builder newInstance() {
        return new Builder();
    }

    public static class Builder {

        private final Params p;

        public Builder() {
            this.p = new Params();
        }

        @JsonProperty
        public Builder withAccountNumber(String accountNumber) {
            this.p.accountNumber = accountNumber;
            return this;
        }

        @JsonProperty
        public Builder withActivitySourceCode(String activitySourceCode) {
            this.p.activitySourceCode = activitySourceCode;
            return this;
        }

        @JsonProperty
        public Builder withFinancialAgreementType(String financialAgreementType) {
            this.p.financialAgreementType = financialAgreementType;
            return this;
        }

        @JsonProperty
        public Builder withInitialRequestDate(String initialRequestDate) {
            this.p.initialRequestDate = initialRequestDate;
            return this;
        }

        @JsonProperty
        public Builder withOrderItem(OrderItemVO orderItem) {
            this.p.orderItem = orderItem;
            return this;
        }



        public SubmitRedepmtionInputVO build() {
            return new SubmitRedepmtionInputVO(this.p);
        }
    }

    private static class Params {
        private String accountNumber;
        private String activitySourceCode;
        private String financialAgreementType;
        private String initialRequestDate;
        private OrderItemVO orderItem;
    }

}
