package com.discover.bank.api.rewards.earnings.buckets;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.AccountProduct;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.core.customers.MockCustomerBuilder;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsTestConfiguration;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.bank.api.rewards.earnings.Earnings;

@RunWith(MockitoJUnitRunner.class)
public class RewardsBucketRepositoryTest {

    @InjectMocks
    private RewardsBucketRepository rewardsBucketRepository;

    @Mock
    private RestTemplate template;

    private CustomerIdentification id;

    private PropertyAccessor props;

    private BankAccount bankAccount;

    private RewardsAccount rewardsAccount;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        props = RewardsTestConfiguration.earningsPropAccessor();
        id = MockCustomerBuilder.mockCustomerIdentification();
        rewardsBucketRepository = new RewardsBucketRepository(template, props);
        bankAccount = RewardsAccount.newBuilder()
                                    .setAccountNumber(AccountNumber.parse("123456"))
                                    .setBalance(BigInteger.TEN)
                                    .defineDepositAccount(AccountProduct.of("CHECKING", "002"))
                                    .build();
        rewardsAccount = new RewardsAccount(bankAccount);
    }

    @Test
    public void test_getRewardsBucketTypes() {

        List<EarnedRwdForDateRangeDtls> earnedRwdDetails =
                        new ArrayList<EarnedRwdForDateRangeDtls>();
        EarnedRwdForDateRangeDtls earnedRwdRange =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Debit Card Purchases")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.TEN)
                                                                                    .build())
                                                 .build();
        earnedRwdDetails.add(earnedRwdRange);

        RewardsEarnBucketOutput output = RewardsEarnBucketOutput.newInstance()
                                                                .withAccountNumber("7105016529")
                                                                .withEarnedRwdForDateRangeDtls(
                                                                                earnedRwdDetails)
                                                                .build();

        ResponseEntity<RewardsEarnBucketOutput> response =
                        new ResponseEntity<RewardsEarnBucketOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(RewardsEarnBucketOutput.class)))
               .thenReturn(response);

        Earnings earnings = rewardsBucketRepository.getRewardsBucketEarnings(id, rewardsAccount,
                        new Date("03/01/2017"), new Date("03/31/2018"));

        Assert.assertNotNull(earnings);
    }

    @Test
    public void test_getRewardsBucketTypes_Success() {

        List<EarnedRwdForDateRangeDtls> earnedRwdDetails =
                        new ArrayList<EarnedRwdForDateRangeDtls>();
        EarnedRwdForDateRangeDtls debitPurchase =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Debit Card Purchases")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls promotions =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Promotions")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls adjPos =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Adjustments - Positive")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls adjNeg =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType(
                                                                 "Adjustments - Returns/Reversals")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        earnedRwdDetails.add(debitPurchase);
        earnedRwdDetails.add(promotions);
        earnedRwdDetails.add(adjPos);
        earnedRwdDetails.add(adjNeg);

        RewardsEarnBucketOutput output = RewardsEarnBucketOutput.newInstance()
                                                                .withAccountNumber("7105016529")
                                                                .withEarnedRwdForDateRangeDtls(
                                                                                earnedRwdDetails)
                                                                .build();

        ResponseEntity<RewardsEarnBucketOutput> response =
                        new ResponseEntity<RewardsEarnBucketOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(RewardsEarnBucketOutput.class)))
               .thenReturn(response);

        Earnings earnings = rewardsBucketRepository.getRewardsBucketEarnings(id, rewardsAccount,
                        new Date("03/01/2017"), new Date("03/31/2018"));

        Assert.assertNotNull(earnings);
        Assert.assertEquals("Debit Card Purchases", earnings.getTypes().get(0).getName());
        Assert.assertEquals(100, earnings.getTypes().get(0).getAmount().intValue());
        Assert.assertEquals("Promotions", earnings.getTypes().get(1).getName());
        Assert.assertEquals(100, earnings.getTypes().get(1).getAmount().intValue());
        Assert.assertEquals("Adjustments - Positive", earnings.getTypes().get(2).getName());
        Assert.assertEquals(100, earnings.getTypes().get(2).getAmount().intValue());
        Assert.assertEquals("Adjustments - Returns/Reversals",
                        earnings.getTypes().get(3).getName());
        Assert.assertEquals(100, earnings.getTypes().get(3).getAmount().intValue());
    }

    @Test
    public void test_validateAndTransform_BI_Response_Null() {

        Earnings earnings = rewardsBucketRepository.validateAndTransform(null,
                        new Date("03/01/2017"), new Date("03/31/2018"));

        Assert.assertEquals("Debit Card Purchases", earnings.getTypes().get(0).getName());
        Assert.assertEquals(0, earnings.getTypes().get(0).getAmount().intValue());
        Assert.assertEquals("Promotions", earnings.getTypes().get(1).getName());
        Assert.assertEquals(0, earnings.getTypes().get(1).getAmount().intValue());
        Assert.assertEquals("Adjustments - Positive", earnings.getTypes().get(2).getName());
        Assert.assertEquals(0, earnings.getTypes().get(2).getAmount().intValue());
        Assert.assertEquals("Adjustments - Returns/Reversals",
                        earnings.getTypes().get(3).getName());
        Assert.assertEquals(0, earnings.getTypes().get(3).getAmount().intValue());
    }

    @Test
    public void test_validateAndTransform_BI_Response_Empty() {

        RewardsEarnBucketOutput output = RewardsEarnBucketOutput.newInstance()
                                                                .withAccountNumber("7105016529")
                                                                .withEarnedRwdForDateRangeDtls(
                                                                                new ArrayList<EarnedRwdForDateRangeDtls>())
                                                                .build();

        ResponseEntity<RewardsEarnBucketOutput> response =
                        new ResponseEntity<RewardsEarnBucketOutput>(output, HttpStatus.OK);
        Earnings earnings = rewardsBucketRepository.validateAndTransform(response,
                        new Date("03/01/2017"), new Date("03/31/2018"));

        Assert.assertEquals("Debit Card Purchases", earnings.getTypes().get(0).getName());
        Assert.assertEquals(0, earnings.getTypes().get(0).getAmount().intValue());
        Assert.assertEquals("Promotions", earnings.getTypes().get(1).getName());
        Assert.assertEquals(0, earnings.getTypes().get(1).getAmount().intValue());
        Assert.assertEquals("Adjustments - Positive", earnings.getTypes().get(2).getName());
        Assert.assertEquals(0, earnings.getTypes().get(2).getAmount().intValue());
        Assert.assertEquals("Adjustments - Returns/Reversals",
                        earnings.getTypes().get(3).getName());
        Assert.assertEquals(0, earnings.getTypes().get(3).getAmount().intValue());
    }

    @Test
    public void test_validateAndTransform_BI_Response_Old_Buckets() {

        List<EarnedRwdForDateRangeDtls> rewardsBI = new ArrayList<EarnedRwdForDateRangeDtls>();
        EarnedRwdForDateRangeDtls billPay =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Bill Pay")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls check =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Check")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        rewardsBI.add(billPay);
        rewardsBI.add(check);

        RewardsEarnBucketOutput output =
                        RewardsEarnBucketOutput.newInstance()
                                               .withAccountNumber("7105016529")
                                               .withEarnedRwdForDateRangeDtls(rewardsBI)
                                               .build();

        ResponseEntity<RewardsEarnBucketOutput> response =
                        new ResponseEntity<RewardsEarnBucketOutput>(output, HttpStatus.OK);
        Earnings earnings = rewardsBucketRepository.validateAndTransform(response,
                        new Date("03/01/2017"), new Date("03/31/2018"));

        Assert.assertEquals("Debit Card Purchases", earnings.getTypes().get(0).getName());
        Assert.assertEquals(0, earnings.getTypes().get(0).getAmount().intValue());
        Assert.assertEquals("Promotions", earnings.getTypes().get(1).getName());
        Assert.assertEquals(0, earnings.getTypes().get(1).getAmount().intValue());
        Assert.assertEquals("Adjustments - Positive", earnings.getTypes().get(2).getName());
        Assert.assertEquals(0, earnings.getTypes().get(2).getAmount().intValue());
        Assert.assertEquals("Adjustments - Returns/Reversals",
                        earnings.getTypes().get(3).getName());
        Assert.assertEquals(0, earnings.getTypes().get(3).getAmount().intValue());
        Assert.assertEquals("Bill Pay", earnings.getTypes().get(4).getName());
        Assert.assertEquals(100, earnings.getTypes().get(4).getAmount().intValue());
        Assert.assertEquals("Check", earnings.getTypes().get(5).getName());
        Assert.assertEquals(100, earnings.getTypes().get(5).getAmount().intValue());
    }

    @Test
    public void test_validateAndTransform_BI_Response_New_And_Old_Buckets() {

        List<EarnedRwdForDateRangeDtls> rewardsBI = new ArrayList<EarnedRwdForDateRangeDtls>();
        EarnedRwdForDateRangeDtls billPay =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Bill Pay")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls check =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Check")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls debitPurchase =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Debit Card Purchases")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        rewardsBI.add(billPay);
        rewardsBI.add(check);
        rewardsBI.add(debitPurchase);

        RewardsEarnBucketOutput output =
                        RewardsEarnBucketOutput.newInstance()
                                               .withAccountNumber("7105016529")
                                               .withEarnedRwdForDateRangeDtls(rewardsBI)
                                               .build();

        ResponseEntity<RewardsEarnBucketOutput> response =
                        new ResponseEntity<RewardsEarnBucketOutput>(output, HttpStatus.OK);
        Earnings earnings = rewardsBucketRepository.validateAndTransform(response,
                        new Date("03/01/2017"), new Date("03/31/2018"));

        Assert.assertEquals("Debit Card Purchases", earnings.getTypes().get(0).getName());
        Assert.assertEquals(100, earnings.getTypes().get(0).getAmount().intValue());
        Assert.assertEquals("Promotions", earnings.getTypes().get(1).getName());
        Assert.assertEquals(0, earnings.getTypes().get(1).getAmount().intValue());
        Assert.assertEquals("Adjustments - Positive", earnings.getTypes().get(2).getName());
        Assert.assertEquals(0, earnings.getTypes().get(2).getAmount().intValue());
        Assert.assertEquals("Adjustments - Returns/Reversals",
                        earnings.getTypes().get(3).getName());
        Assert.assertEquals(0, earnings.getTypes().get(3).getAmount().intValue());
        Assert.assertEquals("Bill Pay", earnings.getTypes().get(4).getName());
        Assert.assertEquals(100, earnings.getTypes().get(4).getAmount().intValue());
        Assert.assertEquals("Check", earnings.getTypes().get(5).getName());
        Assert.assertEquals(100, earnings.getTypes().get(5).getAmount().intValue());
    }

    @Test
    public void test_transform() {
        List<EarnedRwdForDateRangeDtls> rewardsBI = new ArrayList<EarnedRwdForDateRangeDtls>();
        EarnedRwdForDateRangeDtls debitPurchase =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("DEBITCARDPURCHASES")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls promotions =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("PROMOTIONS")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls adjPos =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("ADJUSTMENTSPOSITIVE")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls adjNeg =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("ADJUSTMENTSRETURNSREVERSALS")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        rewardsBI.add(debitPurchase);
        rewardsBI.add(promotions);
        rewardsBI.add(adjPos);
        rewardsBI.add(adjNeg);

        Earnings earnings = rewardsBucketRepository.transform(rewardsBI, new Date("03/01/2017"),
                        new Date("03/31/2018"));

        Assert.assertEquals("Debit Card Purchases", earnings.getTypes().get(0).getName());
        Assert.assertEquals(100, earnings.getTypes().get(0).getAmount().intValue());
        Assert.assertEquals("Promotions", earnings.getTypes().get(1).getName());
        Assert.assertEquals(100, earnings.getTypes().get(1).getAmount().intValue());
        Assert.assertEquals("Adjustments - Positive", earnings.getTypes().get(2).getName());
        Assert.assertEquals(100, earnings.getTypes().get(2).getAmount().intValue());
        Assert.assertEquals("Adjustments - Returns/Reversals",
                        earnings.getTypes().get(3).getName());
        Assert.assertEquals(100, earnings.getTypes().get(3).getAmount().intValue());
    }

    @Test
    public void test_getEarningsV2_HttpClientError() {
        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(RewardsEarnBucketOutput.class)))
               .thenThrow(new RestClientException("error"));

        Earnings earnings = rewardsBucketRepository.getRewardsBucketEarnings(id, rewardsAccount,
                        new Date("03/01/2017"), new Date("03/31/2018"));

        Assert.assertEquals("Debit Card Purchases", earnings.getTypes().get(0).getName());
        Assert.assertEquals(0, earnings.getTypes().get(0).getAmount().intValue());
        Assert.assertEquals("Promotions", earnings.getTypes().get(1).getName());
        Assert.assertEquals(0, earnings.getTypes().get(1).getAmount().intValue());
        Assert.assertEquals("Adjustments - Positive", earnings.getTypes().get(2).getName());
        Assert.assertEquals(0, earnings.getTypes().get(2).getAmount().intValue());
        Assert.assertEquals("Adjustments - Returns/Reversals",
                        earnings.getTypes().get(3).getName());
        Assert.assertEquals(0, earnings.getTypes().get(3).getAmount().intValue());
    }

    @Test
    public void test_getEarningsV2_NoRecordsFound() {
        String sResponse =
                        "{\"errorCode\":\"E100\",\"errorDescription\":\"No Records Found in the Database for the given AccountNumber\"}";
        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(RewardsEarnBucketOutput.class)))
               .thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST, "400",
                               sResponse.getBytes(), Charset.forName("UTF-8")));

        Earnings earnings = rewardsBucketRepository.getRewardsBucketEarnings(id, rewardsAccount,
                        new Date("03/01/2017"), new Date("03/31/2018"));

        Assert.assertEquals("Debit Card Purchases", earnings.getTypes().get(0).getName());
        Assert.assertEquals(0, earnings.getTypes().get(0).getAmount().intValue());
        Assert.assertEquals("Promotions", earnings.getTypes().get(1).getName());
        Assert.assertEquals(0, earnings.getTypes().get(1).getAmount().intValue());
        Assert.assertEquals("Adjustments - Positive", earnings.getTypes().get(2).getName());
        Assert.assertEquals(0, earnings.getTypes().get(2).getAmount().intValue());
        Assert.assertEquals("Adjustments - Returns/Reversals",
                        earnings.getTypes().get(3).getName());
        Assert.assertEquals(0, earnings.getTypes().get(3).getAmount().intValue());
    }

    @Test
    public void test_MandatoryRewardsTypes_NotAvailable() {
        List<EarnedRwdForDateRangeDtls> rewardsBI = new ArrayList<EarnedRwdForDateRangeDtls>();
        List<EarnedRwdForDateRangeDtls> rewardsTypes = new ArrayList<EarnedRwdForDateRangeDtls>();
        EarnedRwdForDateRangeDtls billPay =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Bill Pay")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls check =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Check")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        rewardsBI.add(billPay);
        rewardsBI.add(check);

        rewardsTypes = rewardsBucketRepository.buildBucketOutput(rewardsBI);

        Assert.assertEquals("DEBITCARDPURCHASES", rewardsTypes.get(0).getEarnedRwdType());
        Assert.assertEquals(0, rewardsTypes.get(0).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("PROMOTIONS", rewardsTypes.get(1).getEarnedRwdType());
        Assert.assertEquals(0, rewardsTypes.get(1).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("ADJUSTMENTSPOSITIVE", rewardsTypes.get(2).getEarnedRwdType());
        Assert.assertEquals(0, rewardsTypes.get(2).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("ADJUSTMENTSRETURNSREVERSALS", rewardsTypes.get(3).getEarnedRwdType());
        Assert.assertEquals(0, rewardsTypes.get(3).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("BILLPAY", rewardsTypes.get(4).getEarnedRwdType());
        Assert.assertEquals(1, rewardsTypes.get(4).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("CHECK", rewardsTypes.get(5).getEarnedRwdType());
        Assert.assertEquals(1, rewardsTypes.get(5).getEarnedRwdAmt().getAmount().intValue());
    }

    @Test
    public void test_MandatoryRewardsTypes_Empty() {
        List<EarnedRwdForDateRangeDtls> rewardsBI = new ArrayList<EarnedRwdForDateRangeDtls>();
        List<EarnedRwdForDateRangeDtls> rewardsTypes = new ArrayList<EarnedRwdForDateRangeDtls>();

        rewardsTypes = rewardsBucketRepository.buildBucketOutput(rewardsBI);

        Assert.assertEquals("DEBITCARDPURCHASES", rewardsTypes.get(0).getEarnedRwdType());
        Assert.assertEquals(0, rewardsTypes.get(0).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("PROMOTIONS", rewardsTypes.get(1).getEarnedRwdType());
        Assert.assertEquals(0, rewardsTypes.get(1).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("ADJUSTMENTSPOSITIVE", rewardsTypes.get(2).getEarnedRwdType());
        Assert.assertEquals(0, rewardsTypes.get(2).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("ADJUSTMENTSRETURNSREVERSALS", rewardsTypes.get(3).getEarnedRwdType());
        Assert.assertEquals(0, rewardsTypes.get(3).getEarnedRwdAmt().getAmount().intValue());
    }

    @Test
    public void test_AllBucketTypesSuccess() {
        List<EarnedRwdForDateRangeDtls> rewardsBI = new ArrayList<EarnedRwdForDateRangeDtls>();
        List<EarnedRwdForDateRangeDtls> rewardsTypes = new ArrayList<EarnedRwdForDateRangeDtls>();
        EarnedRwdForDateRangeDtls billPay =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Bill Pay")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls check =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Check")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls promotions =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Promotions")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls debit =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Debit Card Purchases")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls adjPos =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Adjustments - Positive")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls adjNeg =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType(
                                                                 "Adjustments - Returns/Reversals")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        rewardsBI.add(billPay);
        rewardsBI.add(check);
        rewardsBI.add(promotions);
        rewardsBI.add(debit);
        rewardsBI.add(adjPos);
        rewardsBI.add(adjNeg);

        rewardsTypes = rewardsBucketRepository.buildBucketOutput(rewardsBI);

        Assert.assertEquals("DEBITCARDPURCHASES", rewardsTypes.get(0).getEarnedRwdType());
        Assert.assertEquals(1, rewardsTypes.get(0).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("PROMOTIONS", rewardsTypes.get(1).getEarnedRwdType());
        Assert.assertEquals(1, rewardsTypes.get(1).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("ADJUSTMENTSPOSITIVE", rewardsTypes.get(2).getEarnedRwdType());
        Assert.assertEquals(1, rewardsTypes.get(2).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("ADJUSTMENTSRETURNSREVERSALS", rewardsTypes.get(3).getEarnedRwdType());
        Assert.assertEquals(1, rewardsTypes.get(3).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("BILLPAY", rewardsTypes.get(4).getEarnedRwdType());
        Assert.assertEquals(1, rewardsTypes.get(4).getEarnedRwdAmt().getAmount().intValue());
        Assert.assertEquals("CHECK", rewardsTypes.get(5).getEarnedRwdType());
        Assert.assertEquals(1, rewardsTypes.get(5).getEarnedRwdAmt().getAmount().intValue());
    }

    @Test
    public void testRemoveSpecialCharAndCapitalize() {

        assertEquals("DEBITCARDPURCHASES", rewardsBucketRepository.removeSpecialCharAndCapitalize(
                        "Debit Card Purchases"));
        assertEquals("PROMOTIONS",
                        rewardsBucketRepository.removeSpecialCharAndCapitalize("Promotions"));
        assertEquals("ADJUSTMENTSPOSITIVE", rewardsBucketRepository.removeSpecialCharAndCapitalize(
                        "Adjustments - Positive"));
        assertEquals("ADJUSTMENTSRETURNSREVERSALS",
                        rewardsBucketRepository.removeSpecialCharAndCapitalize(
                                        "Adjustments - Returns/Reversals"));
        assertEquals("BILLPAY", rewardsBucketRepository.removeSpecialCharAndCapitalize("Bill Pay"));
        assertEquals("CHECK", rewardsBucketRepository.removeSpecialCharAndCapitalize("Check"));
        assertEquals("OTHER", rewardsBucketRepository.removeSpecialCharAndCapitalize("Other"));
        assertEquals("ADJUSTMENTSPOSITIVE", rewardsBucketRepository.removeSpecialCharAndCapitalize(
                        "Adjustments : Positive"));
        assertEquals("ADJUSTMENTSRETURNSREVERSALS",
                        rewardsBucketRepository.removeSpecialCharAndCapitalize(
                                        "Adjustments : Returns/Reversals"));
        assertEquals("XXXYYYZZZ",
                        rewardsBucketRepository.removeSpecialCharAndCapitalize("xxx : yyy - zzz"));
        assertEquals("AAABBBCCC",
                        rewardsBucketRepository.removeSpecialCharAndCapitalize("aaa / bbb * ccc"));
    }

    @Test
    public void testModifyRewardTypes() {

        List<EarnedRwdForDateRangeDtls> rewardsBI = new ArrayList<EarnedRwdForDateRangeDtls>();
        List<EarnedRwdForDateRangeDtls> rewardsTypes = new ArrayList<EarnedRwdForDateRangeDtls>();
        EarnedRwdForDateRangeDtls billPay =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Bill Pay")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls check =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Check")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls promotions =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Promotions")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls debit =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Debit Card Purchases")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls adjPos =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType("Adjustments - Positive")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        EarnedRwdForDateRangeDtls adjNeg =
                        EarnedRwdForDateRangeDtls.newInstance()
                                                 .withEarnedRwdType(
                                                                 "Adjustments - Returns/Reversals")
                                                 .withEarnedRwdAmt(RewardsEarnAmount.newInstance()
                                                                                    .withAmount(BigDecimal.ONE)
                                                                                    .build())
                                                 .build();
        rewardsBI.add(billPay);
        rewardsBI.add(check);
        rewardsBI.add(promotions);
        rewardsBI.add(debit);
        rewardsBI.add(adjPos);
        rewardsBI.add(adjNeg);

        rewardsTypes = rewardsBucketRepository.modifyRewardTypes(rewardsBI);

        Assert.assertEquals("BILLPAY", rewardsTypes.get(0).getEarnedRwdType());
        Assert.assertEquals("CHECK", rewardsTypes.get(1).getEarnedRwdType());
        Assert.assertEquals("PROMOTIONS", rewardsTypes.get(2).getEarnedRwdType());
        Assert.assertEquals("DEBITCARDPURCHASES", rewardsTypes.get(3).getEarnedRwdType());
        Assert.assertEquals("ADJUSTMENTSPOSITIVE", rewardsTypes.get(4).getEarnedRwdType());
        Assert.assertEquals("ADJUSTMENTSRETURNSREVERSALS", rewardsTypes.get(5).getEarnedRwdType());
    }
}
