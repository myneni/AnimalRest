package com.discover.bank.api.rewards.email;


import java.math.BigDecimal;
import java.math.BigInteger;

import org.junit.Assert;
import org.junit.Test;

import com.discover.common.base.BigNumbers;
import com.fasterxml.jackson.core.JsonProcessingException;


public class RewardsEmailMixinTest {

    @Test
    public void testRewardsEmailMixin_Output() throws JsonProcessingException {
        // Fix for US28843
        BigInteger amount = new BigInteger("10000");
        String oneHundred = BigNumbers.MoneyFormat.NEGATIVE_WITHOUT_CURRENCY.formatter()
                        .format(new BigDecimal(amount).divide(new BigDecimal("100")));
        Assert.assertNotNull(oneHundred);
        Assert.assertEquals(oneHundred, "100.00");

    }
}
