package com.discover.bank.api.rewards.redemption;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.dfs.marketing.rewardredemptionsvc.ao.Order;
import com.dfs.marketing.rewardredemptionsvc.ao.OrderHistoryInput;
import com.dfs.marketing.rewardredemptionsvc.ao.OrderOutput;
import com.dfs.marketing.rewardredemptionsvc.ao.PastOrderItem;
import com.dfs.marketing.rewardredemptionsvc.ao.RewardRedemptionServiceException;
import com.dfs.marketing.rewardredemptionsvc.ao.RewardRedemptionServiceException_Exception;
import com.dfs.marketing.rewardredemptionsvc.bd.RewardRedemptionServiceBDInterface;
import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.AccountProduct;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.customers.Customer;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.core.customers.MockCustomerBuilder;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsException;
import com.discover.bank.api.rewards.RewardsTestConfiguration;
import com.discover.bank.api.rewards.account.RewardsAccount;

@RunWith(MockitoJUnitRunner.class)
public class RedemptionRepositoryTest {

    private static final int months = 24;

    @InjectMocks
    private RedemptionRepository repo;

    @Mock
    private RestTemplate template;

    @Mock
    RewardRedemptionServiceBDInterface delegate;

    @Mock
    private UriComponentsBuilder builder;

    @Mock
    private HttpEntity<SubmitRedepmtionInputVO> requestEntity;

    @Mock
    OrderOutput orderOutput;

    @Captor
    private ArgumentCaptor<Order> orderCaptor;

    private BankAccount bankAccount;

    private RewardsAccount rewardsAccount;

    private CustomerIdentification id;

    private Customer customer;

    private PropertyAccessor propertyFinder;



    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        propertyFinder = RewardsTestConfiguration.earningsPropAccessor();
        id = MockCustomerBuilder.mockCustomerIdentification();
        customer = MockCustomerBuilder.mockBankCustomer();
        repo = new RedemptionRepository(template, propertyFinder,delegate);
        bankAccount = RewardsAccount.newBuilder()
                                    .setAccountNumber(AccountNumber.parse("123456"))
                                    .setBalance(BigInteger.TEN)
                                    .defineDepositAccount(AccountProduct.of("CHECKING", "002"))
                                    .build();
        rewardsAccount = new RewardsAccount(bankAccount);


    }

    @Test
    public void testRedeemRewardsDepositSameAccount()
                    throws RewardRedemptionServiceException_Exception, RewardsException {

        Redemption redemption = Redemption.newBuilder()
                                          .withFromRewardsAccount(rewardsAccount)
                                          .withToAccount(rewardsAccount)
                                          .withAmount(BigInteger.valueOf(100))
                                          .withRedemptionType("DEPST")
                                          .build();

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("HTTP_AUTH_TOKEN", "dsgjkhsdfkljghasdklfglkfjdng;a");
        headers.set("X-DFS-C-APP-INFO", getConsumerInfo(id));
        headers.set(HttpHeaders.ACCEPT_LANGUAGE, "en-US");


        Order order = new Order();
        order.setOrderId("21");
        order.setRewardsBalance("50");
        order.setAccountNumber("12344");


        AmountVO requestAmount = AmountVO.newInstance().
                        withAmount(new BigDecimal(100))
                        .withCurCode("USD")
                        .build();

        SubmitRedepmtionOutputVO output =
                        SubmitRedepmtionOutputVO.newInstance()
                                                .withOrderId("215")
                                                .withRequestAmount(requestAmount)
                                                .withRewardsBalanceAmount(
                                                                AmountVO.newInstance()
                                                                        .withAmount(new BigDecimal(
                                                                                        25))
                                                                        .withCurCode("USD")
                                                                        .build())
                                                .build();

        ResponseEntity<SubmitRedepmtionOutputVO> responseEntity =
                        new ResponseEntity<SubmitRedepmtionOutputVO>(output, HttpStatus.OK);
        
        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(SubmitRedepmtionOutputVO.class))).thenReturn(responseEntity);


        Redemption redeemOutput = repo.redeemRewards(redemption, customer);

        Assert.assertNotNull(redeemOutput);

       /* verify(delegate, times(1)).submitOrder((Matchers.any(Order.class)));

        // Assert the order input to the submit order mock in turn verifying buildSubmitOrderInput()
        assertEquals("123456", orderCaptor.getValue().getAccountNumber());
        assertEquals("MBB", orderCaptor.getValue().getActvySrcCde());
        assertEquals("MP", orderCaptor.getValue().getChannelCode());
        assertEquals("BCHK", orderCaptor.getValue().getFinancialAgreementType());
        assertEquals(1, orderCaptor.getValue().getOrderItems().size());
        assertEquals("123456", orderCaptor.getValue()
                                          .getOrderItems()
                                          .get(0)
                                          .getDestinationAccountNumber());*/
    }

    @Test
    public void testRedeemRewardsDepositDifferentAccount()
                    throws RewardRedemptionServiceException_Exception, RewardsException {
        BankAccount toAccount = BankAccount.newBuilder()
                                           .setAccountNumber(AccountNumber.parse("654321"))
                                           .setBalance(BigInteger.TEN)
                                           .defineDepositAccount(
                                                           AccountProduct.of("SAVINGS", "002"))
                                           .build();

        Redemption redemption = Redemption.newBuilder()
                                          .withFromRewardsAccount(rewardsAccount)
                                          .withToAccount(toAccount)
                                          .withAmount(BigInteger.valueOf(100))
                                          .withRedemptionType("deposit")
                                          .build();

        /*OrderOutput output = new OrderOutput();

        Order order = new Order();
        order.setRewardsBalance("50");

        output.setOrder(order);*/
        
        AmountVO requestAmount = AmountVO.newInstance().
                        withAmount(new BigDecimal(100))
                        .withCurCode("USD")
                        .build();

        SubmitRedepmtionOutputVO output =
                        SubmitRedepmtionOutputVO.newInstance()
                                                .withOrderId("215")
                                                .withRequestAmount(requestAmount)
                                                .withRewardsBalanceAmount(
                                                                AmountVO.newInstance()
                                                                        .withAmount(new BigDecimal(
                                                                                        25))
                                                                        .withCurCode("USD")
                                                                        .build())
                                                .build();

      //  when(delegate.submitOrder(orderCaptor.capture())).thenReturn(output);

        ResponseEntity<SubmitRedepmtionOutputVO> responseEntity =
                        new ResponseEntity<SubmitRedepmtionOutputVO>(output, HttpStatus.OK);
        
        when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(SubmitRedepmtionOutputVO.class))).thenReturn(responseEntity);

        Redemption redeemOutput = repo.redeemRewards(redemption, customer);

        Assert.assertNotNull(redeemOutput);

    //    verify(delegate, times(1)).submitOrder((Matchers.any(Order.class)));
/*
        // Assert the order input to the submit order mock in turn verifying buildSubmitOrderInput()
        assertEquals("123456", orderCaptor.getValue().getAccountNumber());
        assertEquals("MBB", orderCaptor.getValue().getActvySrcCde());
        assertEquals("MP", orderCaptor.getValue().getChannelCode());
        assertEquals("BCHK", orderCaptor.getValue().getFinancialAgreementType());
        assertEquals(1, orderCaptor.getValue().getOrderItems().size());
        assertEquals("654321", orderCaptor.getValue()
                                          .getOrderItems()
                                          .get(0)
                                          .getDestinationAccountNumber());*/
    }

    @Test
    public void testRedeemRewardsTransfer()
                    throws RewardRedemptionServiceException_Exception, RewardsException {
        CreditCardAccount ccAccount = CreditCardAccount.newBuilder()
                                                       .withAccountNumber((AccountNumber.parse(
                                                                       "6011123456")))
                                                       .withIncentiveCode("incentiveCode")
                                                       .withIncentiveType("incentiveType")
                                                       .build();


        Redemption redemption = Redemption.newBuilder()
                                          .withFromRewardsAccount(rewardsAccount)
                                          .withToCreditCardAccount(ccAccount)
                                          .withAmount(BigInteger.valueOf(100))
                                          .withRedemptionType("Transfer")
                                          .build();

        OrderOutput output = new OrderOutput();

        Order order = new Order();
        order.setRewardsBalance("50");

        output.setOrder(order);

        when(delegate.submitOrder(orderCaptor.capture())).thenReturn(output);

        Redemption redeemOutput = repo.redeemRewards(redemption, customer);

        assertEquals(BigInteger.valueOf(5000), redeemOutput.getRemainingBalance());

        verify(delegate, times(1)).submitOrder((Matchers.any(Order.class)));

        // Assert the order input to the submit order mock in turn verifying buildSubmitOrderInput()
        assertEquals("123456", orderCaptor.getValue().getAccountNumber());
        assertEquals("MBB", orderCaptor.getValue().getActvySrcCde());
        assertEquals("MP", orderCaptor.getValue().getChannelCode());
        assertEquals("BCHK", orderCaptor.getValue().getFinancialAgreementType());
        assertEquals(1, orderCaptor.getValue().getOrderItems().size());
        assertEquals("6011123456",
                        orderCaptor.getValue()
                                   .getOrderItems()
                                   .get(0)
                                   .getDestinationAccountNumber());
    }

    @Test
    public void testBuildOrderHistoryInput() {

        OrderHistoryInput result = repo.buildOrderHistoryInput(rewardsAccount, months);
        Assert.assertNotNull(result);
        Assert.assertEquals(result.getAccountNumber().toString(),
                        AccountNumber.parse("123456").getValue());
        Assert.assertEquals(result.getFinancialAgreementType(), "BCHK");
        Assert.assertEquals(result.getChannelCode(), "MP");
    }

    @Test
    public void test_getDefaultRedemptionTypeDesc_with_customer_deposits_IRA_Accounts() {
        
        BankAccount checkingAccount = BankAccount.newBuilder()
                                                 .setAccountNumber(
                                                                 AccountNumber.parse("7106006157"))
                                                 .setId("54321")
                                                 .setNickName("Checking Account")
                                                 .build();

        BankAccount iraAccount = BankAccount.newBuilder()
                                            .setAccountNumber(null) // IRA will not have account number
                                            .setId("TRAD_IRA")
                                            .setNickName("IRA Account")
                        .build();

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(checkingAccount);
        customerAccounts.add(iraAccount);

        PastOrderItem pastOrderItem = new PastOrderItem();
        pastOrderItem.setDestinationAccountNumber("7106006157");
        pastOrderItem.setModeCode("DEPST");
        pastOrderItem.setModeDesc("Deposit to Checking Account");

        Assert.assertEquals("Deposit into Checking Account (6157)",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem, customerAccounts));

        // Assert to see the description is empty if we pass null to the Order Item.
        Assert.assertEquals("", repo.getDefaultRedemptionTypeDesc(null, customerAccounts));

        // Assert to see the description is empty if we pass null to the Customer Accounts.
        Assert.assertEquals("", repo.getDefaultRedemptionTypeDesc(pastOrderItem, null));
    }

    @Test
    public void test_getDefaultRedemptionTypeDesc_Savings() {
        
        BankAccount savingsAccount = BankAccount.newBuilder()
                        .setAccountNumber(AccountNumber.parse("3547863251"))
                        .setId("SM124356")
                        .setNickName("Savings Account")
                        .build();
        
        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(savingsAccount);

        PastOrderItem pastOrderItem = new PastOrderItem();
        pastOrderItem.setDestinationAccountNumber("3547863251");
        pastOrderItem.setModeCode("DEPSV");
        pastOrderItem.setModeDesc("Deposit into Savings account");

        Assert.assertEquals("Deposit into Savings Account (3251)",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem, customerAccounts));
    }
    
    @Test
    public void test_getDefaultRedemptionTypeDesc_MoneyMarket() {
        
        BankAccount moneyMarketAccount = BankAccount.newBuilder()
                                                    .setAccountNumber(AccountNumber.parse(
                                                                    "5673423489"))
                                                    .setId("SM78631")
                                                    .setNickName("Money Market Account")
                        .build();

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(moneyMarketAccount);

        PastOrderItem pastOrderItem = new PastOrderItem();
        pastOrderItem.setDestinationAccountNumber("5673423489");
        pastOrderItem.setModeCode("DEPMM");
        pastOrderItem.setModeDesc("Deposit into Money Market account");

        Assert.assertEquals("Deposit into Money Market Account (3489)",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem, customerAccounts));
    }

    @Test
    public void test_getDefaultRedemptionTypeDesc_CreditCard() {

        PastOrderItem pastOrderItem = new PastOrderItem();
        pastOrderItem.setDestinationAccountNumber("6011008872693327");
        pastOrderItem.setModeCode("XTORW");
        pastOrderItem.setModeDesc("Checking Cashback Bonus Transfer");

        Assert.assertEquals("Transfer to Discover Credit Card (3327) Cashback Bonus",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem,
                                        new ArrayList<BankAccount>()));

        // Assert to see the description is empty if we pass null to the Order Item.
        Assert.assertEquals("",
                        repo.getDefaultRedemptionTypeDesc(null, new ArrayList<BankAccount>()));
    }
    
    @Test
    public void test_getDefaultRedemptionTypeDesc_CreditCard_Null() {

        PastOrderItem pastOrderItem = new PastOrderItem();
        pastOrderItem.setDestinationAccountNumber("6011008872693327");
        pastOrderItem.setModeCode("XTORW");
        pastOrderItem.setModeDesc(null);

        PastOrderItem pastOrderItem1 = new PastOrderItem();
        pastOrderItem1.setDestinationAccountNumber("6011008872693327");
        pastOrderItem1.setModeCode(null);
        pastOrderItem1.setModeDesc("Transfer to Discover Credit Card");

        Assert.assertEquals("Transfer to Discover Credit Card (3327) Cashback Bonus",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem,
                                        new ArrayList<BankAccount>()));

        // Assert to see the description is empty if we pass null to the Order Item.
        Assert.assertEquals("",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem1,
                                        new ArrayList<BankAccount>()));
    }
    
    @Test
    public void test_getRedempDescForNull_Customer_Account_Not_Owned() {
        
        BankAccount checkingAccount = BankAccount.newBuilder()
                                                 .setAccountNumber(AccountNumber.parse("7106006157"))
                                                 .setId("54321")
                                                 .setNickName("Checking Account")
                                                 .build();

        BankAccount savingsAccount1 = BankAccount.newBuilder()
                        .setAccountNumber(AccountNumber.parse("3547863251"))
                        .setId("SM124356")
                        .setNickName("Savings Account")
                        .build();
        
        BankAccount savingsAccount2 = BankAccount.newBuilder()
                        .setAccountNumber(AccountNumber.parse("7832145261"))
                        .setId("SM9806")
                        .setNickName("Savings Account New")
                        .build();

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(checkingAccount);
        customerAccounts.add(savingsAccount1);
        customerAccounts.add(savingsAccount2);

        PastOrderItem pastOrderItem_Checking = new PastOrderItem();
        pastOrderItem_Checking.setDestinationAccountNumber("456732111");
        pastOrderItem_Checking.setModeCode("DEPST");
        pastOrderItem_Checking.setModeDesc("Deposit to Checking Account");

        PastOrderItem pastOrderItem_Savings = new PastOrderItem();
        pastOrderItem_Savings.setDestinationAccountNumber("456732344");
        pastOrderItem_Savings.setModeCode("DEPSV");
        pastOrderItem_Savings.setModeDesc("Deposit to Savings Account");

        PastOrderItem pastOrderItem_MoneyMarket = new PastOrderItem();
        pastOrderItem_MoneyMarket.setDestinationAccountNumber("456732234");
        pastOrderItem_MoneyMarket.setModeCode("DEPMM");
        pastOrderItem_MoneyMarket.setModeDesc("Deposit to MoneyMarket Account");

        Assert.assertEquals("Deposit into Checking Cashback Bonus",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem_Checking,
                                        customerAccounts));

        Assert.assertEquals("Deposit into Savings Cashback Bonus",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem_Savings, customerAccounts));

        Assert.assertEquals("Deposit into Money Market Cashback Bonus",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem_MoneyMarket,
                                        customerAccounts));
    }
    
    @Test
    public void test_buildRedempTypeDescDeposits() {

        BankAccount checkingAccount = BankAccount.newBuilder()
                                                 .setAccountNumber(
                                                                 AccountNumber.parse("7106006157"))
                                                 .setId("54321")
                                                 .setNickName("Checking Account")
                                                 .build();

        BankAccount checkingAccount1 = BankAccount.newBuilder()
                                                  .setAccountNumber(
                                                                  AccountNumber.parse("7106002434"))
                                                  .setId("76899")
                                                  .setNickName("Checking Account one")
                                                  .build();

        BankAccount savingsAccount1 = BankAccount.newBuilder()
                                                 .setAccountNumber(
                                                                 AccountNumber.parse("3547863251"))
                                                 .setId("SM124356")
                                                 .setNickName("Savings Account")
                                                 .build();

        BankAccount savingsAccount2 = BankAccount.newBuilder()
                                                 .setAccountNumber(
                                                                 AccountNumber.parse("7832145261"))
                                                 .setId("SM9806")
                                                 .setNickName("Savings Account New")
                                                 .build();

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(checkingAccount);
        customerAccounts.add(checkingAccount1);
        customerAccounts.add(savingsAccount1);
        customerAccounts.add(savingsAccount2);

        PastOrderItem pastOrderItem_Checking = new PastOrderItem();
        pastOrderItem_Checking.setDestinationAccountNumber("7106002434");
        pastOrderItem_Checking.setModeCode("DEPST");
        pastOrderItem_Checking.setModeDesc("Deposit to Checking Account");

        PastOrderItem pastOrderItem_Savings = new PastOrderItem();
        pastOrderItem_Savings.setDestinationAccountNumber("3547863251");
        pastOrderItem_Savings.setModeCode("DEPSV");
        pastOrderItem_Savings.setModeDesc("Deposit to Savings Account");

        Assert.assertEquals("Deposit into Checking Account one (2434)",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem_Checking,
                                        customerAccounts));

        Assert.assertEquals("Deposit into Savings Account (3251)",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem_Savings, customerAccounts));
    }

    @Test
    public void test_buildRedempTypeDescDeposits_DefaultDesc() {

        BankAccount checkingAccount = BankAccount.newBuilder()
                                                 .setAccountNumber(
                                                                 AccountNumber.parse("7106006157"))
                                                 .setId("54321")
                                                 .setNickName("Checking Account")
                                                 .build();

        BankAccount savingsAccount1 = BankAccount.newBuilder()
                                                 .setAccountNumber(
                                                                 AccountNumber.parse("3547863251"))
                                                 .setId("SM124356")
                                                 .setNickName("Savings Account")
                                                 .build();

        BankAccount savingsAccount2 = BankAccount.newBuilder()
                                                 .setAccountNumber(
                                                                 AccountNumber.parse("7832145261"))
                                                 .setId("SM9806")
                                                 .setNickName("Savings Account New")
                                                 .build();

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(checkingAccount);
        customerAccounts.add(savingsAccount1);
        customerAccounts.add(savingsAccount2);

        PastOrderItem pastOrderItem_Savings = new PastOrderItem();
        pastOrderItem_Savings.setDestinationAccountNumber("3547863251");
        pastOrderItem_Savings.setModeCode("DEPSV");
        pastOrderItem_Savings.setModeDesc("Deposit to Savings Account");

        PastOrderItem savings_notowned = new PastOrderItem();
        savings_notowned.setDestinationAccountNumber("567893421");
        savings_notowned.setModeCode("DEPSV");
        savings_notowned.setModeDesc("Deposit to Savings Account");

        Assert.assertEquals("Deposit into Savings Cashback Bonus",
                        repo.getDefaultRedemptionTypeDesc(savings_notowned, customerAccounts));

        Assert.assertEquals("Deposit into Savings Account (3251)",
                        repo.getDefaultRedemptionTypeDesc(pastOrderItem_Savings, customerAccounts));
    }

    @Test
    public void test_BuildDefaultRedempDescForDeposits() {
        Assert.assertEquals("Deposit into Checking Cashback Bonus",
                        repo.buildDefaultRedempTypeDescDeposits("DEPST"));
        Assert.assertEquals("Deposit into Savings Cashback Bonus",
                        repo.buildDefaultRedempTypeDescDeposits("DEPSV"));
        Assert.assertEquals("Deposit into Money Market Cashback Bonus",
                        repo.buildDefaultRedempTypeDescDeposits("DEPMM"));
        // Assert to see the description is empty if we pass null to the mode code.
        Assert.assertEquals("", repo.buildDefaultRedempTypeDescDeposits(null));
    }

    @Test(expected = RewardsException.class)
    public void testLookupRedemptionHistoryForAccount()
                    throws RewardsException, RewardRedemptionServiceException_Exception {

        Mockito.when(delegate.getOrderHistory(Matchers.any(OrderHistoryInput.class)))
               .thenThrow(new RewardRedemptionServiceException_Exception("error",
                               new RewardRedemptionServiceException()));

        repo.lookupRedemptionHistoryForAccount(rewardsAccount, months,
                        new ArrayList<BankAccount>());
    }

    @Test(expected = RewardsException.class)
    public void testLookupRedemptionHistoryForAccount_null()
                    throws RewardsException, RewardRedemptionServiceException_Exception {

        Mockito.when(delegate.getOrderHistory(Matchers.any(OrderHistoryInput.class)))
               .thenReturn(null);

        repo.lookupRedemptionHistoryForAccount(rewardsAccount, months,
                        new ArrayList<BankAccount>());

    }

    protected String getConsumerInfo(CustomerIdentification customer) {
        StringBuilder sb = new StringBuilder();
        sb.append("CHANNEL_AND_APP_NAME").append("|");
        sb.append("CHANNEL_ID").append("|");
        sb.append("CHANNEL_NAME").append("|");
        sb.append(customer.getRequestIdentifier() != null
                        ? customer.getRequestIdentifier().getRequestId() : "")
          .append("|");
        sb.append("CHANNEL_AND_APP_NAME").append("|");
        sb.append("").append("|");
        sb.append("").append("|");

        return sb.toString();
    }


}
