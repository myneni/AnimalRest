package com.discover.bank.api.rewards.earnings;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Calendar;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.discover.bank.api.rewards.earnings.EarningsDates.EarningsDateGroup;
import com.discover.bank.api.rewards.earnings.EarningsFilter.GroupBy;

public class EarningsDatesTests {

    private Calendar year1Ago;
    private Calendar year3Ago;
    private Calendar year5Ago;
    private Calendar month3Ago;
    private Calendar month6Ago;
    private Calendar yesterday;
    private Calendar today;
    private Calendar tomorrow;


    @Before
    public void setupCalendars() {
        year1Ago = Calendar.getInstance();
        year1Ago.add(Calendar.YEAR, -1);

        year3Ago = Calendar.getInstance();
        year3Ago.add(Calendar.YEAR, -3);

        year5Ago = Calendar.getInstance();
        year5Ago.add(Calendar.YEAR, -5);

        month3Ago = Calendar.getInstance();
        month3Ago.add(Calendar.MONTH, -3);

        month6Ago = Calendar.getInstance();
        month6Ago.add(Calendar.MONTH, -6);

        yesterday = Calendar.getInstance();
        yesterday.add(Calendar.DATE, -1);

        today = Calendar.getInstance();

        tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DATE, 1);
    }

    @Test
    public void testEarningsStartDateOpen() {
        Calendar a = month6Ago;
        Calendar b = year1Ago;
        Calendar c = year3Ago;
        Calendar d = tomorrow;
        Calendar e = null;

        Calendar openAA = EarningsDates.getEarningsStartDate(month3Ago, a, a);
        Calendar openAB = EarningsDates.getEarningsStartDate(month3Ago, a, b);
        Calendar openAC = EarningsDates.getEarningsStartDate(month3Ago, a, c);
        Calendar openAD = EarningsDates.getEarningsStartDate(month3Ago, a, d);
        Calendar openAE = EarningsDates.getEarningsStartDate(month3Ago, a, e);

        Calendar openBA = EarningsDates.getEarningsStartDate(month3Ago, b, a);
        Calendar openBB = EarningsDates.getEarningsStartDate(month3Ago, b, b);
        Calendar openBC = EarningsDates.getEarningsStartDate(month3Ago, b, c);
        Calendar openBD = EarningsDates.getEarningsStartDate(month3Ago, b, d);
        Calendar openBE = EarningsDates.getEarningsStartDate(month3Ago, b, e);

        Calendar openCA = EarningsDates.getEarningsStartDate(month3Ago, c, a);
        Calendar openCB = EarningsDates.getEarningsStartDate(month3Ago, c, b);
        Calendar openCC = EarningsDates.getEarningsStartDate(month3Ago, c, c);
        Calendar openCD = EarningsDates.getEarningsStartDate(month3Ago, c, d);
        Calendar openCE = EarningsDates.getEarningsStartDate(month3Ago, c, e);

        Calendar openDA = EarningsDates.getEarningsStartDate(month3Ago, d, a);
        Calendar openDB = EarningsDates.getEarningsStartDate(month3Ago, d, b);
        Calendar openDC = EarningsDates.getEarningsStartDate(month3Ago, d, c);
        Calendar openDD = EarningsDates.getEarningsStartDate(month3Ago, d, d);
        Calendar openDE = EarningsDates.getEarningsStartDate(month3Ago, d, e);

        Calendar openEA = EarningsDates.getEarningsStartDate(month3Ago, e, a);
        Calendar openEB = EarningsDates.getEarningsStartDate(month3Ago, e, b);
        Calendar openEC = EarningsDates.getEarningsStartDate(month3Ago, e, c);
        Calendar openED = EarningsDates.getEarningsStartDate(month3Ago, e, d);
        Calendar openEE = EarningsDates.getEarningsStartDate(month3Ago, e, e);

        Assert.assertTrue(openAA.equals(month3Ago));
        Assert.assertTrue(openAB.equals(month3Ago));
        Assert.assertTrue(openAC.equals(month3Ago));
        Assert.assertTrue(openAD.equals(month3Ago));
        Assert.assertTrue(openAE.equals(month3Ago));

        Assert.assertTrue(openBA.equals(month3Ago));
        Assert.assertTrue(openBB.equals(month3Ago));
        Assert.assertTrue(openBC.equals(month3Ago));
        Assert.assertTrue(openBD.equals(month3Ago));
        Assert.assertTrue(openBE.equals(month3Ago));

        Assert.assertTrue(openCA.equals(month3Ago));
        Assert.assertTrue(openCB.equals(month3Ago));
        Assert.assertTrue(openCC.equals(month3Ago));
        Assert.assertTrue(openCD.equals(month3Ago));
        Assert.assertTrue(openCE.equals(month3Ago));

        Assert.assertTrue(openDA.equals(month3Ago));
        Assert.assertTrue(openDB.equals(month3Ago));
        Assert.assertTrue(openDC.equals(month3Ago));
        Assert.assertTrue(openDD.equals(month3Ago));
        Assert.assertTrue(openDE.equals(month3Ago));

        Assert.assertTrue(openEA.equals(month3Ago));
        Assert.assertTrue(openEB.equals(month3Ago));
        Assert.assertTrue(openEC.equals(month3Ago));
        Assert.assertTrue(openED.equals(month3Ago));
        Assert.assertTrue(openEE.equals(month3Ago));
    }

    @Test
    public void testEarningsStartDateFrom() {
        Calendar a = month6Ago;
        Calendar b = year1Ago;
        Calendar c = year3Ago;
        Calendar d = tomorrow;
        Calendar e = null;

        Calendar fromAA = EarningsDates.getEarningsStartDate(a, month3Ago, a);
        Calendar fromAB = EarningsDates.getEarningsStartDate(a, month3Ago, b);
        Calendar fromAC = EarningsDates.getEarningsStartDate(a, month3Ago, c);
        Calendar fromAD = EarningsDates.getEarningsStartDate(a, month3Ago, d);
        Calendar fromAE = EarningsDates.getEarningsStartDate(a, month3Ago, e);

        Calendar fromBA = EarningsDates.getEarningsStartDate(b, month3Ago, a);
        Calendar fromBB = EarningsDates.getEarningsStartDate(b, month3Ago, b);
        Calendar fromBC = EarningsDates.getEarningsStartDate(b, month3Ago, c);
        Calendar fromBD = EarningsDates.getEarningsStartDate(b, month3Ago, d);
        Calendar fromBE = EarningsDates.getEarningsStartDate(b, month3Ago, e);

        Calendar fromCA = EarningsDates.getEarningsStartDate(c, month3Ago, a);
        Calendar fromCB = EarningsDates.getEarningsStartDate(c, month3Ago, b);
        Calendar fromCC = EarningsDates.getEarningsStartDate(c, month3Ago, c);
        Calendar fromCD = EarningsDates.getEarningsStartDate(c, month3Ago, d);
        Calendar fromCE = EarningsDates.getEarningsStartDate(c, month3Ago, e);

        Calendar fromDA = EarningsDates.getEarningsStartDate(d, month3Ago, a);
        Calendar fromDB = EarningsDates.getEarningsStartDate(d, month3Ago, b);
        Calendar fromDC = EarningsDates.getEarningsStartDate(d, month3Ago, c);
        Calendar fromDD = EarningsDates.getEarningsStartDate(d, month3Ago, d);
        Calendar fromDE = EarningsDates.getEarningsStartDate(d, month3Ago, e);

        Calendar fromEA = EarningsDates.getEarningsStartDate(e, month3Ago, a);
        Calendar fromEB = EarningsDates.getEarningsStartDate(e, month3Ago, b);
        Calendar fromEC = EarningsDates.getEarningsStartDate(e, month3Ago, c);
        Calendar fromED = EarningsDates.getEarningsStartDate(e, month3Ago, d);
        Calendar fromEE = EarningsDates.getEarningsStartDate(e, month3Ago, e);

        Assert.assertTrue(fromAA.equals(month3Ago));
        Assert.assertTrue(fromAB.equals(month3Ago));
        Assert.assertTrue(fromAC.equals(month3Ago));
        Assert.assertTrue(fromAD.equals(month3Ago));
        Assert.assertTrue(fromAE.equals(month3Ago));

        Assert.assertTrue(fromBA.equals(month3Ago));
        Assert.assertTrue(fromBB.equals(month3Ago));
        Assert.assertTrue(fromBC.equals(month3Ago));
        Assert.assertTrue(fromBD.equals(month3Ago));
        Assert.assertTrue(fromBE.equals(month3Ago));

        Assert.assertTrue(fromCA.equals(month3Ago));
        Assert.assertTrue(fromCB.equals(month3Ago));
        Assert.assertTrue(fromCC.equals(month3Ago));
        Assert.assertTrue(fromCD.equals(month3Ago));
        Assert.assertTrue(fromCE.equals(month3Ago));

        Assert.assertTrue(fromDA.equals(month3Ago));
        Assert.assertTrue(fromDB.equals(month3Ago));
        Assert.assertTrue(fromDC.equals(month3Ago));
        Assert.assertTrue(fromDD.equals(month3Ago));
        Assert.assertTrue(fromDE.equals(month3Ago));

        Assert.assertTrue(fromEA.equals(month3Ago));
        Assert.assertTrue(fromEB.equals(month3Ago));
        Assert.assertTrue(fromEC.equals(month3Ago));
        Assert.assertTrue(fromED.equals(month3Ago));
        Assert.assertTrue(fromEE.equals(month3Ago));
    }

    @Test
    public void testEarningsStartDateStartDate() {
        Calendar a = month6Ago;
        Calendar b = year1Ago;
        Calendar c = year3Ago;
        Calendar d = tomorrow;
        Calendar e = null;

        Calendar startDateAA = EarningsDates.getEarningsStartDate(a, a, month3Ago);
        Calendar startDateAB = EarningsDates.getEarningsStartDate(a, b, month3Ago);
        Calendar startDateAC = EarningsDates.getEarningsStartDate(a, c, month3Ago);
        Calendar startDateAD = EarningsDates.getEarningsStartDate(a, d, month3Ago);
        Calendar startDateAE = EarningsDates.getEarningsStartDate(a, e, month3Ago);

        Calendar startDateBA = EarningsDates.getEarningsStartDate(b, a, month3Ago);
        Calendar startDateBB = EarningsDates.getEarningsStartDate(b, b, month3Ago);
        Calendar startDateBC = EarningsDates.getEarningsStartDate(b, c, month3Ago);
        Calendar startDateBD = EarningsDates.getEarningsStartDate(b, d, month3Ago);
        Calendar startDateBE = EarningsDates.getEarningsStartDate(b, e, month3Ago);

        Calendar startDateCA = EarningsDates.getEarningsStartDate(c, a, month3Ago);
        Calendar startDateCB = EarningsDates.getEarningsStartDate(c, b, month3Ago);
        Calendar startDateCC = EarningsDates.getEarningsStartDate(c, c, month3Ago);
        Calendar startDateCD = EarningsDates.getEarningsStartDate(c, d, month3Ago);
        Calendar startDateCE = EarningsDates.getEarningsStartDate(c, e, month3Ago);

        Calendar startDateDA = EarningsDates.getEarningsStartDate(d, a, month3Ago);
        Calendar startDateDB = EarningsDates.getEarningsStartDate(d, b, month3Ago);
        Calendar startDateDC = EarningsDates.getEarningsStartDate(d, c, month3Ago);
        Calendar startDateDD = EarningsDates.getEarningsStartDate(d, d, month3Ago);
        Calendar startDateDE = EarningsDates.getEarningsStartDate(d, e, month3Ago);

        Calendar startDateEA = EarningsDates.getEarningsStartDate(e, a, month3Ago);
        Calendar startDateEB = EarningsDates.getEarningsStartDate(e, b, month3Ago);
        Calendar startDateEC = EarningsDates.getEarningsStartDate(e, c, month3Ago);
        Calendar startDateED = EarningsDates.getEarningsStartDate(e, d, month3Ago);
        Calendar startDateEE = EarningsDates.getEarningsStartDate(e, e, month3Ago);



        Assert.assertTrue(startDateAA.equals(month3Ago));
        Assert.assertTrue(startDateAB.equals(month3Ago));
        Assert.assertTrue(startDateAC.equals(month3Ago));
        Assert.assertTrue(startDateAD.equals(month3Ago));
        Assert.assertTrue(startDateAE.equals(month3Ago));

        Assert.assertTrue(startDateBA.equals(month3Ago));
        Assert.assertTrue(startDateBB.equals(month3Ago));
        Assert.assertTrue(startDateBC.equals(month3Ago));
        Assert.assertTrue(startDateBD.equals(month3Ago));
        Assert.assertTrue(startDateBE.equals(month3Ago));

        Assert.assertTrue(startDateCA.equals(month3Ago));
        Assert.assertTrue(startDateCB.equals(month3Ago));
        Assert.assertTrue(startDateCC.equals(month3Ago));
        Assert.assertTrue(startDateCD.equals(month3Ago));
        Assert.assertTrue(startDateCE.equals(month3Ago));

        Assert.assertTrue(startDateDA.equals(month3Ago));
        Assert.assertTrue(startDateDB.equals(month3Ago));
        Assert.assertTrue(startDateDC.equals(month3Ago));
        Assert.assertTrue(startDateDD.equals(month3Ago));
        Assert.assertTrue(startDateDE.equals(month3Ago));

        Assert.assertTrue(startDateEA.equals(month3Ago));
        Assert.assertTrue(startDateEB.equals(month3Ago));
        Assert.assertTrue(startDateEC.equals(month3Ago));
        Assert.assertTrue(startDateED.equals(month3Ago));
        Assert.assertTrue(startDateEE.equals(month3Ago));
    }

    @Test
    public void testEarningsStartDate2Year() {
        Calendar a = year3Ago;
        Calendar b = year5Ago;
        Calendar c = tomorrow;
        Calendar d = null;

        Calendar tYearAAA = EarningsDates.getEarningsStartDate(a, a, a);
        Calendar tYearAAB = EarningsDates.getEarningsStartDate(a, a, b);
        Calendar tYearAAC = EarningsDates.getEarningsStartDate(a, a, c);
        Calendar tYearAAD = EarningsDates.getEarningsStartDate(a, a, d);
        Calendar tYearABA = EarningsDates.getEarningsStartDate(a, b, a);
        Calendar tYearABB = EarningsDates.getEarningsStartDate(a, b, b);
        Calendar tYearABC = EarningsDates.getEarningsStartDate(a, b, c);
        Calendar tYearABD = EarningsDates.getEarningsStartDate(a, b, d);
        Calendar tYearACA = EarningsDates.getEarningsStartDate(a, c, a);
        Calendar tYearACB = EarningsDates.getEarningsStartDate(a, c, b);
        Calendar tYearACC = EarningsDates.getEarningsStartDate(a, c, c);
        Calendar tYearACD = EarningsDates.getEarningsStartDate(a, c, d);
        Calendar tYearADA = EarningsDates.getEarningsStartDate(a, d, a);
        Calendar tYearADB = EarningsDates.getEarningsStartDate(a, d, b);
        Calendar tYearADC = EarningsDates.getEarningsStartDate(a, d, c);
        Calendar tYearADD = EarningsDates.getEarningsStartDate(a, d, d);

        Calendar tYearBAA = EarningsDates.getEarningsStartDate(b, a, a);
        Calendar tYearBAB = EarningsDates.getEarningsStartDate(b, a, b);
        Calendar tYearBAC = EarningsDates.getEarningsStartDate(b, a, c);
        Calendar tYearBAD = EarningsDates.getEarningsStartDate(b, a, d);
        Calendar tYearBBA = EarningsDates.getEarningsStartDate(b, b, a);
        Calendar tYearBBB = EarningsDates.getEarningsStartDate(b, b, b);
        Calendar tYearBBC = EarningsDates.getEarningsStartDate(b, b, c);
        Calendar tYearBBD = EarningsDates.getEarningsStartDate(b, c, d);
        Calendar tYearBCA = EarningsDates.getEarningsStartDate(b, c, a);
        Calendar tYearBCB = EarningsDates.getEarningsStartDate(b, c, b);
        Calendar tYearBCC = EarningsDates.getEarningsStartDate(b, c, c);
        Calendar tYearBCD = EarningsDates.getEarningsStartDate(b, c, d);
        Calendar tYearBDA = EarningsDates.getEarningsStartDate(b, d, c);
        Calendar tYearBDB = EarningsDates.getEarningsStartDate(b, d, c);
        Calendar tYearBDC = EarningsDates.getEarningsStartDate(b, d, c);
        Calendar tYearBDD = EarningsDates.getEarningsStartDate(b, d, d);

        Calendar tYearCAA = EarningsDates.getEarningsStartDate(c, a, a);
        Calendar tYearCAB = EarningsDates.getEarningsStartDate(c, a, b);
        Calendar tYearCAC = EarningsDates.getEarningsStartDate(c, a, c);
        Calendar tYearCAD = EarningsDates.getEarningsStartDate(c, a, d);
        Calendar tYearCBA = EarningsDates.getEarningsStartDate(c, b, a);
        Calendar tYearCBB = EarningsDates.getEarningsStartDate(c, b, b);
        Calendar tYearCBC = EarningsDates.getEarningsStartDate(c, b, c);
        Calendar tYearCBD = EarningsDates.getEarningsStartDate(c, a, d);
        Calendar tYearCCA = EarningsDates.getEarningsStartDate(c, c, a);
        Calendar tYearCCB = EarningsDates.getEarningsStartDate(c, c, b);
        Calendar tYearCCC = EarningsDates.getEarningsStartDate(c, c, c);
        Calendar tYearCCD = EarningsDates.getEarningsStartDate(c, a, d);
        Calendar tYearCDA = EarningsDates.getEarningsStartDate(c, d, a);
        Calendar tYearCDB = EarningsDates.getEarningsStartDate(c, d, a);
        Calendar tYearCDC = EarningsDates.getEarningsStartDate(c, d, a);
        Calendar tYearCDD = EarningsDates.getEarningsStartDate(c, d, d);

        Calendar tYearDAA = EarningsDates.getEarningsStartDate(d, a, a);
        Calendar tYearDAB = EarningsDates.getEarningsStartDate(d, a, b);
        Calendar tYearDAC = EarningsDates.getEarningsStartDate(d, a, c);
        Calendar tYearDAD = EarningsDates.getEarningsStartDate(d, a, d);
        Calendar tYearDBA = EarningsDates.getEarningsStartDate(d, b, a);
        Calendar tYearDBB = EarningsDates.getEarningsStartDate(d, b, b);
        Calendar tYearDBC = EarningsDates.getEarningsStartDate(d, b, c);
        Calendar tYearDBD = EarningsDates.getEarningsStartDate(d, a, d);
        Calendar tYearDCA = EarningsDates.getEarningsStartDate(d, c, a);
        Calendar tYearDCB = EarningsDates.getEarningsStartDate(d, c, b);
        Calendar tYearDCC = EarningsDates.getEarningsStartDate(d, c, c);
        Calendar tYearDCD = EarningsDates.getEarningsStartDate(d, a, d);
        Calendar tYearDDA = EarningsDates.getEarningsStartDate(d, d, a);
        Calendar tYearDDB = EarningsDates.getEarningsStartDate(d, d, a);
        Calendar tYearDDC = EarningsDates.getEarningsStartDate(d, d, a);
        Calendar tYearDDD = EarningsDates.getEarningsStartDate(d, d, d);

        // Hey!! Check it out, A NULL test!!

        Assert.assertFalse(tYearAAA == null || tYearAAA.equals(a) || tYearAAA.equals(b)
                        || tYearAAA.equals(c));
        Assert.assertFalse(tYearAAB == null || tYearAAB.equals(a) || tYearAAB.equals(b)
                        || tYearAAB.equals(c));
        Assert.assertFalse(tYearAAC == null || tYearAAC.equals(a) || tYearAAC.equals(b)
                        || tYearAAC.equals(c));
        Assert.assertFalse(tYearAAD == null || tYearAAD.equals(a) || tYearAAD.equals(b)
                        || tYearAAD.equals(c));
        Assert.assertFalse(tYearABA == null || tYearABA.equals(a) || tYearABA.equals(b)
                        || tYearABA.equals(c));
        Assert.assertFalse(tYearABB == null || tYearABB.equals(a) || tYearABB.equals(b)
                        || tYearABB.equals(c));
        Assert.assertFalse(tYearABC == null || tYearABC.equals(a) || tYearABC.equals(b)
                        || tYearABC.equals(c));
        Assert.assertFalse(tYearABD == null || tYearABD.equals(a) || tYearABD.equals(b)
                        || tYearABD.equals(c));
        Assert.assertFalse(tYearACA == null || tYearACA.equals(a) || tYearACA.equals(b)
                        || tYearACA.equals(c));
        Assert.assertFalse(tYearACB == null || tYearACB.equals(a) || tYearACB.equals(b)
                        || tYearACB.equals(c));
        Assert.assertFalse(tYearACC == null || tYearACC.equals(a) || tYearACC.equals(b)
                        || tYearACC.equals(c));
        Assert.assertFalse(tYearACD == null || tYearACD.equals(a) || tYearACD.equals(b)
                        || tYearACD.equals(c));
        Assert.assertFalse(tYearADA == null || tYearADA.equals(a) || tYearADA.equals(b)
                        || tYearADA.equals(c));
        Assert.assertFalse(tYearADB == null || tYearADB.equals(a) || tYearADB.equals(b)
                        || tYearADB.equals(c));
        Assert.assertFalse(tYearADC == null || tYearADC.equals(a) || tYearADC.equals(b)
                        || tYearADC.equals(c));
        Assert.assertFalse(tYearADD == null || tYearADD.equals(a) || tYearADD.equals(b)
                        || tYearADD.equals(c));

        Assert.assertFalse(tYearBAA == null || tYearAAA.equals(a) || tYearBAA.equals(b)
                        || tYearBAA.equals(c));
        Assert.assertFalse(tYearBAB == null || tYearBAB.equals(a) || tYearBAB.equals(b)
                        || tYearBAB.equals(c));
        Assert.assertFalse(tYearBAC == null || tYearBAC.equals(a) || tYearBAC.equals(b)
                        || tYearBAC.equals(c));
        Assert.assertFalse(tYearBAD == null || tYearBAD.equals(a) || tYearBAD.equals(b)
                        || tYearBAD.equals(c));
        Assert.assertFalse(tYearBBA == null || tYearBBA.equals(a) || tYearBBA.equals(b)
                        || tYearBBA.equals(c));
        Assert.assertFalse(tYearBBB == null || tYearBBB.equals(a) || tYearBBB.equals(b)
                        || tYearBBB.equals(c));
        Assert.assertFalse(tYearBBC == null || tYearBBC.equals(a) || tYearBBC.equals(b)
                        || tYearBBC.equals(c));
        Assert.assertFalse(tYearBBD == null || tYearBBD.equals(a) || tYearBBD.equals(b)
                        || tYearBBD.equals(c));
        Assert.assertFalse(tYearBCA == null || tYearBCA.equals(a) || tYearBCA.equals(b)
                        || tYearBCA.equals(c));
        Assert.assertFalse(tYearBCB == null || tYearBCB.equals(a) || tYearBCB.equals(b)
                        || tYearBCB.equals(c));
        Assert.assertFalse(tYearBCC == null || tYearBCC.equals(a) || tYearBCC.equals(b)
                        || tYearBCC.equals(c));
        Assert.assertFalse(tYearBCD == null || tYearBCD.equals(a) || tYearBCD.equals(b)
                        || tYearBCD.equals(c));
        Assert.assertFalse(tYearBDA == null || tYearBDA.equals(a) || tYearBDA.equals(b)
                        || tYearBDA.equals(c));
        Assert.assertFalse(tYearBDB == null || tYearBDB.equals(a) || tYearBDB.equals(b)
                        || tYearBDB.equals(c));
        Assert.assertFalse(tYearBDC == null || tYearBDC.equals(a) || tYearBDC.equals(b)
                        || tYearBDC.equals(c));
        Assert.assertFalse(tYearBDD == null || tYearBDD.equals(a) || tYearBDD.equals(b)
                        || tYearBDD.equals(c));

        Assert.assertFalse(tYearCAA == null || tYearCAA.equals(a) || tYearCAA.equals(b)
                        || tYearCAA.equals(c));
        Assert.assertFalse(tYearCAB == null || tYearCAB.equals(a) || tYearCAB.equals(b)
                        || tYearCAB.equals(c));
        Assert.assertFalse(tYearCAC == null || tYearCAC.equals(a) || tYearCAC.equals(b)
                        || tYearCAC.equals(c));
        Assert.assertFalse(tYearCAD == null || tYearCAD.equals(a) || tYearCAD.equals(b)
                        || tYearCAD.equals(c));
        Assert.assertFalse(tYearCBA == null || tYearCBA.equals(a) || tYearCBA.equals(b)
                        || tYearCBA.equals(c));
        Assert.assertFalse(tYearCBB == null || tYearCBB.equals(a) || tYearCBB.equals(b)
                        || tYearCBB.equals(c));
        Assert.assertFalse(tYearCBC == null || tYearCBC.equals(a) || tYearCBC.equals(b)
                        || tYearCBC.equals(c));
        Assert.assertFalse(tYearCBD == null || tYearCBD.equals(a) || tYearCBD.equals(b)
                        || tYearCBD.equals(c));
        Assert.assertFalse(tYearCCA == null || tYearCCA.equals(a) || tYearCCA.equals(b)
                        || tYearCCA.equals(c));
        Assert.assertFalse(tYearCCB == null || tYearCCB.equals(a) || tYearCCB.equals(b)
                        || tYearCCB.equals(c));
        Assert.assertFalse(tYearCCC == null || tYearCCC.equals(a) || tYearCCC.equals(b)
                        || tYearCCC.equals(c));
        Assert.assertFalse(tYearCCD == null || tYearCCD.equals(a) || tYearCCD.equals(b)
                        || tYearCCD.equals(c));
        Assert.assertFalse(tYearCDA == null || tYearCDA.equals(a) || tYearCDA.equals(b)
                        || tYearCDA.equals(c));
        Assert.assertFalse(tYearCDB == null || tYearCDB.equals(a) || tYearCDB.equals(b)
                        || tYearCDB.equals(c));
        Assert.assertFalse(tYearCDC == null || tYearCDC.equals(a) || tYearCDC.equals(b)
                        || tYearCDC.equals(c));
        Assert.assertFalse(tYearCDD == null || tYearCDD.equals(a) || tYearCDD.equals(b)
                        || tYearCDD.equals(c));

        Assert.assertFalse(tYearDAA == null || tYearDAA.equals(a) || tYearDAA.equals(b)
                        || tYearDAA.equals(c));
        Assert.assertFalse(tYearDAB == null || tYearDAB.equals(a) || tYearDAB.equals(b)
                        || tYearDAB.equals(c));
        Assert.assertFalse(tYearDAC == null || tYearDAC.equals(a) || tYearDAC.equals(b)
                        || tYearDAC.equals(c));
        Assert.assertFalse(tYearDAD == null || tYearDAD.equals(a) || tYearDAD.equals(b)
                        || tYearDAD.equals(c));
        Assert.assertFalse(tYearDBA == null || tYearDBA.equals(a) || tYearDBA.equals(b)
                        || tYearDBA.equals(c));
        Assert.assertFalse(tYearDBB == null || tYearDBB.equals(a) || tYearDBB.equals(b)
                        || tYearDBB.equals(c));
        Assert.assertFalse(tYearDBC == null || tYearDBC.equals(a) || tYearDBC.equals(b)
                        || tYearDBC.equals(c));
        Assert.assertFalse(tYearDBD == null || tYearDBD.equals(a) || tYearDBD.equals(b)
                        || tYearDBD.equals(c));
        Assert.assertFalse(tYearDCA == null || tYearDCA.equals(a) || tYearDCA.equals(b)
                        || tYearDCA.equals(c));
        Assert.assertFalse(tYearDCB == null || tYearDCB.equals(a) || tYearDCB.equals(b)
                        || tYearDCB.equals(c));
        Assert.assertFalse(tYearDCC == null || tYearDCC.equals(a) || tYearDCC.equals(b)
                        || tYearDCC.equals(c));
        Assert.assertFalse(tYearDCD == null || tYearDCD.equals(a) || tYearDCD.equals(b)
                        || tYearDCD.equals(c));
        Assert.assertFalse(tYearDDA == null || tYearDDA.equals(a) || tYearDDA.equals(b)
                        || tYearDDA.equals(c));
        Assert.assertFalse(tYearDDB == null || tYearDDB.equals(a) || tYearDDB.equals(b)
                        || tYearDDB.equals(c));
        Assert.assertFalse(tYearDDC == null || tYearDDC.equals(a) || tYearDDC.equals(b)
                        || tYearDDC.equals(c));
        Assert.assertFalse(tYearDDD == null || tYearDDD.equals(a) || tYearDDD.equals(b)
                        || tYearDDD.equals(c));
    }

    // TODO fix this test
    /*
     * @Test public void testEarningsEndDate() { //by using null, it will use dates.now() (or today)
     * Calendar in = EarningsDates.getEarningsEndDate(yesterday); Calendar def =
     * EarningsDates.getEarningsEndDate(tomorrow);
     * 
     * //when we sent the 2nd param it will use it. We can still use today for easy checking.
     * Calendar in2 = EarningsDates.getEarningsEndDate(yesterday); Calendar def2 =
     * EarningsDates.getEarningsEndDate(tomorrow);
     * 
     * 
     * Assert.assertTrue(in.equals(yesterday)); Assert.assertFalse(def.equals(tomorrow)); //can not
     * be after today.
     * 
     * Assert.assertTrue(in2.equals(yesterday)); Assert.assertFalse(def2.equals(tomorrow)); //can
     * not be after today.
     * 
     * }
     */

    @Test
    public void testEarningsDateGrouping() {
        // getDateGroups(Calendar start, Calendar end, GroupBy group){

        List<EarningsDateGroup> group1 = EarningsDates.getDateGroups(year5Ago, today, GroupBy.YEAR);
        List<EarningsDateGroup> group2 =
                        EarningsDates.getDateGroups(month6Ago, today, GroupBy.MONTH);
        List<EarningsDateGroup> group3 =
                        EarningsDates.getDateGroups(month6Ago, today, GroupBy.FULL);
        List<EarningsDateGroup> group4 = EarningsDates.getDateGroups(month6Ago, today, null);

        assertNotNull(group1);
        // if we hit mid year we will get 6
        assertTrue(group1.size() == 5 || group1.size() == 6);
        // is our start date correct?
        assertEquals(year5Ago.getTime(), group1.get(0).getStartDate());
        // is our end date correct?
        assertEquals(today.getTime(), group1.get(group1.size() - 1).getEndDate());

        assertNotNull(group2);
        // if we hit mid month we will get 7
        assertTrue(group2.size() == 6 || group2.size() == 7);
        // is our start date correct?
        assertEquals(month6Ago.getTime(), group2.get(0).getStartDate());
        // is our end date correct -- Note that if we're only including 6 groups it means we didn't
        // have enough another group (e.g. first day of the month).
        Calendar expected = (group2.size() == 6) ? yesterday : today;
        assertEquals(expected.getTime(), group2.get(group2.size() - 1).getEndDate());

        assertNotNull(group3);
        assertTrue(group3.size() == 1);
        // is our start date correct?
        assertEquals(month6Ago.getTime(), group3.get(0).getStartDate());
        // is our end date correct?
        assertEquals(today.getTime(), group3.get(group3.size() - 1).getEndDate());

        assertNotNull(group4);
        assertTrue(group4.size() == 1);
        // is our start date correct?
        assertEquals(month6Ago.getTime(), group4.get(0).getStartDate());
        // is our end date correct?
        assertEquals(today.getTime(), group4.get(group4.size() - 1).getEndDate());
    }
}