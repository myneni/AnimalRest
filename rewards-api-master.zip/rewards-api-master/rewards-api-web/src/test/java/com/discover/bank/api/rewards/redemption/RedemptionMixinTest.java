package com.discover.bank.api.rewards.redemption;

import java.io.IOException;
import java.math.BigInteger;

import org.junit.Test;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.MockAccountBuilder;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsTestConfiguration;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.common.base.Dates;
import com.discover.common.base.Dates.Format;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import junit.framework.Assert;

public class RedemptionMixinTest {

    PropertyAccessor props = RewardsTestConfiguration.propertyAccessor();

    ObjectMapper mapper = RewardsTestConfiguration.objectMapper();

    //@Test
    public void testRedemptionMixin_Output() throws JsonProcessingException {
        Redemption redemption =
                        Redemption.newBuilder().withAmount(new BigInteger("999"))
                                        .withConfirmationNumber("90").withRedemptionType("transfer")
                                        .withRedemptionTypeDesc(
                                                        "Transfer Cashback Bonus to a Discover Credit Card")
                        .on(Dates.parse("2014-04-07", Format.BIG_ENDIAN_HYPHEN))
                        .withStatus(Redemption.RedemptionStatus.fromCode("CMP"))
                        .withFromRewardsAccount(new RewardsAccount(
                                        MockAccountBuilder.newCheckingAccountBuilder().build()))
                        .withToCreditCardAccount(CreditCardAccount.newBuilder().withId("0")
                                        .withNickName("Credit card account ending 8002")
                                        .withAccountNumber(AccountNumber.parse("6008002")).build())
                        .build();

        String output = mapper.writeValueAsString(redemption);

        Assert.assertNotNull(output);
        Assert.assertEquals(props.get("Redemption.Output"), output);
    }

    @Test
    public void testRedemptionMixin_Input()
                    throws JsonParseException, JsonMappingException, IOException {
        Redemption input = mapper.readValue(props.get("Redemption.Input"), Redemption.class);

        Assert.assertNotNull(input);
        Assert.assertEquals(input.getFromRewardsAccount().getId(),
                        input.getFromRewardsAccount().getId());
        Assert.assertEquals(input.getToCreditCardAccount().getId(),
                        input.getToCreditCardAccount().getId());
        Assert.assertEquals(input.getAmount(), input.getAmount());
        Assert.assertEquals(input.getRedemptionType(), input.getRedemptionType());
    }
}
