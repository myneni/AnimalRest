/**
 * 
 */
package com.discover.bank.api.rewards.account;

import static org.mockito.Mockito.times;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.core.customers.MockCustomerBuilder;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsException;
import com.discover.bank.api.rewards.RewardsTestConfiguration;
import com.discover.bank.api.rewards.earnings.buckets.RewardsEarnBucketOutput;

/**
 * @author vgaddam
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class EligibleAccountsRepositoryTest {


    @InjectMocks
    private EligibleAccountsRepository eligibleAccountsRepository;

    @Mock
    private RestTemplate template;

    private CustomerIdentification id;

    private PropertyAccessor props;
    private List<EligibleAccount> eligibleAccounts;


    @Before
	public void setUp() throws Exception {
    	//The call below is to load says earnings properties, but it really is rewards properties.
		props = RewardsTestConfiguration.earningsPropAccessor();
		id = MockCustomerBuilder.mockCustomerIdentification();
		eligibleAccountsRepository = new EligibleAccountsRepository(template, props);
		eligibleAccounts = new ArrayList<EligibleAccount>();
		EligibleAccount sourceAccount1 = EligibleAccount.newInstance().withAccountNumber("0844")
				.withAlternateAccountNumber("SM67435").withEligibilityStatus("Y").build();
		EligibleAccount sourceAccount2 = EligibleAccount.newInstance().withAccountNumber("9876")
				.withAlternateAccountNumber("SM67497").withEligibilityStatus("N").build();
		eligibleAccounts.add(sourceAccount1);
		eligibleAccounts.add(sourceAccount2);
	}
    
    @Test
    public void test_getOneTimeEligibleAccounts() throws RewardsException {

		RewardsEligibilityResponse output1 = RewardsEligibilityResponse.newInstance().withCustomerId("123456789")
				.withSourceAccountDetailsList(eligibleAccounts).withTargetAccountDetailsList(eligibleAccounts).build();

		ResponseEntity<RewardsEligibilityResponse> response = new ResponseEntity<RewardsEligibilityResponse>(output1,
				HttpStatus.OK);

		Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
				Matchers.any(HttpEntity.class), Matchers.eq(RewardsEligibilityResponse.class))).thenReturn(response);

		Map<String, List<String>> accounts = eligibleAccountsRepository.getEligibleAccounts(id, "onetime");
		
		Mockito.verify(template, times(1)).exchange((Matchers.any(String.class)), Matchers.any(HttpMethod.class),
				Matchers.any(HttpEntity.class), Matchers.eq(RewardsEligibilityResponse.class));
		Assert.assertNotNull(accounts);
		List<String> responseAccounts = accounts.get("Source");
		Assert.assertTrue(responseAccounts.size() == 1);
		Assert.assertTrue(responseAccounts.contains(eligibleAccounts.get(0).getAlternateAccountNumber()));
		Assert.assertFalse(responseAccounts.contains(eligibleAccounts.get(1).getAlternateAccountNumber()));
	}
    
    @Test
    public void test_getAutoEligibleAccounts() throws RewardsException {
		
		RewardsEligibilityResponse output1 = RewardsEligibilityResponse.newInstance().withCustomerId("123456789")
				.withSourceAccountDetailsList(eligibleAccounts).withTargetAccountDetailsList(eligibleAccounts).build();

		ResponseEntity<RewardsEligibilityResponse> response = new ResponseEntity<RewardsEligibilityResponse>(output1,
				HttpStatus.OK);

		Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
				Matchers.any(HttpEntity.class), Matchers.eq(RewardsEligibilityResponse.class))).thenReturn(response);

		Map<String, List<String>> accounts = eligibleAccountsRepository.getEligibleAccounts(id, "auto");
		Mockito.verify(template, times(1)).exchange((Matchers.any(String.class)), Matchers.any(HttpMethod.class),
				Matchers.any(HttpEntity.class), Matchers.eq(RewardsEligibilityResponse.class));
		Assert.assertNotNull(accounts);
		List<String> responseAccounts = accounts.get("Target");
		Assert.assertTrue(responseAccounts.size() == 1);
		Assert.assertTrue(responseAccounts.contains(eligibleAccounts.get(0).getAlternateAccountNumber()));
		Assert.assertFalse(responseAccounts.contains(eligibleAccounts.get(1).getAlternateAccountNumber()));
		
	}

    
    @Test(expected = RewardsException.class)
    public void test_getEligibleAccounts_NoRecordsFound() throws RewardsException {
		String sResponse = "{\"errorCode\":\"E100\",\"errorDescription\":\"No Records Found in the Database for the given AccountNumber\"}";
		Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
				Matchers.any(HttpEntity.class), Matchers.eq(RewardsEarnBucketOutput.class)))
				.thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST, "400", sResponse.getBytes(),
						Charset.forName("UTF-8")));
		Map<String, List<String>> accounts = eligibleAccountsRepository.getEligibleAccounts(id, "auto");
		Assert.assertNull("Source", accounts.get("Source"));
	}


}
