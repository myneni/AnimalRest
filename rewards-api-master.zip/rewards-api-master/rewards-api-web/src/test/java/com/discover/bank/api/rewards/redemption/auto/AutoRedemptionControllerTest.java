package com.discover.bank.api.rewards.redemption.auto;

import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.restdocs.snippet.Snippet;
import org.springframework.test.web.servlet.MockMvc;

import com.discover.bank.api.config.ApiObjectMapper;
import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.AccountProduct;
import com.discover.bank.api.core.accounts.AccountStatus;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.accounts.MockAccountBuilder;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.hateoas.Hypermedia;
import com.discover.bank.api.mock.AbstractRestDocsControllerTest;
import com.discover.bank.api.mock.ApiMockMvcBuilder;
import com.discover.bank.api.rewards.RewardsBusinessObject;
import com.discover.bank.api.rewards.config.RewardsHypermediaConfiguration;
import com.discover.bank.api.rewards.redemption.Redemption;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(MockitoJUnitRunner.class)
public class AutoRedemptionControllerTest extends AbstractRestDocsControllerTest {

    @InjectMocks
    private AutoRedemptionController controller;

    @Mock
    private RewardsBusinessObject rewardsBO;

    @Spy
    private Hypermedia hyperize;

    private ObjectMapper mapper;

    @Before
    public void setUp() throws Exception {

        // This is to serialize the output as string values
        mapper = new ApiObjectMapper();

        new RewardsHypermediaConfiguration().configureObjectMapper(mapper);

        MappingJackson2HttpMessageConverter jsonMessageConverter =
                        new MappingJackson2HttpMessageConverter();

        jsonMessageConverter.setObjectMapper(mapper);

    }

    @Override
    protected ApiMockMvcBuilder getApiMvcBuilder() {
        return new ApiMockMvcBuilder(controller).configureObjectMapper(
                        new RewardsHypermediaConfiguration());
    }


    @Test
    public void testEnrollAutoRedemption() throws Exception {

        Mockito.when(rewardsBO.enrollAutoRedemption(Matchers.any(CustomerIdentification.class),
                        Matchers.any(String.class), Matchers.any(EnrollEditAutoRedemption.class)))
               .thenReturn(buildEnrollAutoRedemption());


        String autoRedemptionInput = mapper.writeValueAsString(
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM66664")
                                                                          .build())
                                                .build());


        MockMvc mockMvc = getMockMvc(postAutoRedemption_requestFields,
                        postAutoRedemption_responseFields());

        mockMvc.perform(post("/{accountId}/auto", "SM12232").contentType(MediaType.APPLICATION_JSON)
                                                            .header("Authorization",
                                                                            "BankBasic QWxhZGRpbjpPcGVuU2VzYW1l")
                                                            .content(autoRedemptionInput))
               .andDo(print())
               .andExpect(status().isOk())
               .andExpect(jsonPath("toAccount.id").value("SM66664"))
               .andExpect(jsonPath("toAccount.accountNumber.ending").value("1421"))
               .andExpect(jsonPath("toAccount.nickName").value("Mytest"))
               .andExpect(jsonPath("didOneTimeRedemption").value(true))
               .andExpect(jsonPath("oneTimeRedemption.redemptionType").value("deposit"))
               .andExpect(jsonPath("oneTimeRedemption.amount.value").value(100))
               .andExpect(jsonPath("bannerText").value(
                               "Success! You''ve redeemed your Debit Card <i>Cashback Bonus</i> and are now enrolled in Auto Redemption to Savings."));
    }

    private EnrollEditAutoRedemption buildEnrollAutoRedemption() {
        BankAccount toAccount =
                        BankAccount.newBuilder()
                                   .setAccountNumber(AccountNumber.parse("0121421"))
                                   .setId("SM66664")
                                   .setNickName("Mytest")
                                   .setStatus(AccountStatus.ACTIVE)
                                   .defineDepositAccount(AccountProduct.of("SBPRM", "002"))
                                   .build();

        Redemption oneTimeRedemption = Redemption.newBuilder()
                                                 .withAmount(new BigInteger("100"))
                                                 .withRedemptionType("deposit")
                                                 .withConfirmationNumber("1231212")
                                                 .build();

        return EnrollEditAutoRedemption.newBuilder()
                                       .withToAccount(toAccount)
                                       .withDidOneTimeRedemption(true)
                                       .withOneTimeRedemption(oneTimeRedemption)
                                       .withBannerText("Success! You''ve redeemed your Debit Card <i>Cashback Bonus</i> and are now enrolled in Auto Redemption to Savings.")
                                       .build();
    }

    @Test
    public void testEnrollAutoRedemption_noBalance() throws Exception {

        Mockito.when(rewardsBO.enrollAutoRedemption(Matchers.any(CustomerIdentification.class),
                        Matchers.any(String.class), Matchers.any(EnrollEditAutoRedemption.class)))
               .thenReturn(buildEnrollAutoRedemption_noBalance());


        String autoRedemptionInput = mapper.writeValueAsString(
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM66664")
                                                                          .build())
                                                .build());

        MockMvc mockMvc = getMockMvc(postAutoRedemption_requestFields,
                        postAutoRedemption_noBalance_responseFields());

        mockMvc.perform(post("/{accountId}/auto", "SM12232").contentType(MediaType.APPLICATION_JSON)
                                                            .header("Authorization",
                                                                            "BankBasic QWxhZGRpbjpPcGVuU2VzYW1l")
                                                            .content(autoRedemptionInput))
               .andDo(print())
               .andExpect(status().isOk())
               .andExpect(jsonPath("toAccount.id").value("SM66664"))
               .andExpect(jsonPath("toAccount.accountNumber.ending").value("1421"))
               .andExpect(jsonPath("toAccount.nickName").value("Mytest"))
               .andExpect(jsonPath("didOneTimeRedemption").value(false))
               .andExpect(jsonPath("bannerText").value(
                               "Success! You are now enrolled in Auto Redemption to Savings."));

    }

    private EnrollEditAutoRedemption buildEnrollAutoRedemption_noBalance() {
        BankAccount toAccount =
                        BankAccount.newBuilder()
                                   .setAccountNumber(AccountNumber.parse("0121421"))
                                   .setId("SM66664")
                                   .setNickName("Mytest")
                                   .setStatus(AccountStatus.ACTIVE)
                                   .defineDepositAccount(AccountProduct.of("SBPRM", "002"))
                                   .build();

        return EnrollEditAutoRedemption.newBuilder()
                                       .withToAccount(toAccount)
                                       .withDidOneTimeRedemption(false)
                                       .withBannerText("Success! You are now enrolled in Auto Redemption to Savings.")
                                       .build();
    }

    
    @Test
    public void testGetAutoRedemption() throws Exception {

        Mockito.when(rewardsBO.getAutoRedemption(Matchers.any(CustomerIdentification.class),
                        Matchers.anyString()))
               .thenReturn(getAutoRedemptionDetail());

        MockMvc mockMvc = getMockMvc(get_auto_redemption_responseFields());

        mockMvc.perform(get("/{accountId}/auto", "0"))
               .andExpect(status().isOk())
               .andDo(print())
               .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
               .andExpect(jsonPath("isEnrolled").value(false));

    }
    
    @Test
    public void testDeleteAutoRedemption() throws Exception {

        Mockito.when(rewardsBO.deleteAutoRedemption(Matchers.any(CustomerIdentification.class),
                        Matchers.anyString()))
               .thenReturn(deleteAutoRedemptionDetail());

        MockMvc mockMvc = getMockMvc(delete_auto_redemption_responseFields());

        mockMvc.perform(delete("/{accountId}/auto", "0"))
               .andExpect(status().isOk())
               .andDo(print())
               .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
               .andExpect(jsonPath("message").value(
                               "You have successfully removed your auto-redemption settings."));

    }

    private AutoRedemptionResponse deleteAutoRedemptionDetail() {
        return AutoRedemptionResponse.newBuilder()
                                     .withMessage("You have successfully removed your auto-redemption settings.")
                                     .build();
    }

    @Test
    public void testEditAutoRedemption() throws Exception {

        Mockito.when(rewardsBO.editAutoRedemption(Matchers.any(CustomerIdentification.class),
                        Matchers.anyString(), Matchers.any(EnrollEditAutoRedemption.class)))
               .thenReturn(editedAutoRedemptionDetail());

        String autoRedemptionInput = mapper.writeValueAsString(
                        EnrollEditAutoRedemption.newBuilder().withToAccount(
                                        BankAccount.newBuilder().setId("SM66664").build()));

        MockMvc mockMvc = getMockMvc(edit_auto_redemption_responseFields());

        mockMvc.perform(put("/{accountId}/auto", "0").contentType(MediaType.APPLICATION_JSON)
                                                     .content(autoRedemptionInput))
               .andExpect(status().isOk())
               .andDo(print())
               .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
               .andExpect(jsonPath("toAccount.id").value("SM66664"))
               .andExpect(jsonPath("toAccount.accountNumber.ending").value("1421"))
               .andExpect(jsonPath("toAccount.nickName").value("Mytest"));
    }

    @Test
    public void testGetAutoRedemptionAccounts() throws Exception {

        Mockito.when(rewardsBO.getAutoRedemptionAccountsStatus(
                        Matchers.any(CustomerIdentification.class), Matchers.anyList()))
               .thenReturn(buildAutoRedemptionAccounts());

        MockMvc mockMvc = getMockMvc(get_auto_redemption_accounts_responseFields());

        mockMvc.perform(get("/status").param("accounts", "SM1234"))
               .andExpect(status().isOk())
               .andDo(print())
               .andExpect(jsonPath("$.accounts[0].id").value("SM1234"))
               .andExpect(jsonPath("$.accounts[0].accountNumber.ending").value("6328"))
               .andExpect(jsonPath("$.accounts[0].accountNumber.formatted").value("(6328)"))
               .andExpect(jsonPath("$.accounts[0].nickName").value("Checking account"))
               .andExpect(jsonPath("$.accounts[0].toAccount.id").value("0"))
               .andExpect(jsonPath("$.accounts[0].toAccount.accountNumber.ending").value("1589"))
               .andExpect(jsonPath("$.accounts[0].toAccount.accountNumber.formatted").value(
                               "(1589)"))
               .andExpect(jsonPath("$.accounts[0].toAccount.nickName").value(
                               "Online Savings Account Ending 1589"))
               .andExpect(jsonPath("$.accounts[0].isEnrolled").value(true))
               .andExpect(jsonPath("$.accounts[0].rewardsBalance.value").value(1234))
               .andExpect(jsonPath("$.accounts[0].rewardsBalance.formatted").value("$12.34"))
               .andExpect(jsonPath("$.accounts[0].lastRedemptionDate").exists())
               .andExpect(jsonPath("$.accounts[0].lastRedemptionAmount.value").value(10))
               .andExpect(jsonPath("$.accounts[0].lastRedemptionAmount.formatted").value("$0.10"))
               .andExpect(jsonPath("$.accounts[0].hasRedeemed").value(true));
    }

    private List<AutoRedemptionAccount> buildAutoRedemptionAccounts() {

        List<AutoRedemptionAccount> autoRedemptionAccounts = new ArrayList<AutoRedemptionAccount>();
        AutoRedemptionAccount account1 =
                        AutoRedemptionAccount.getBuilder()
                                             .withIsEnrolled(true)
                                             .withId("SM1234")
                                             .withAccountNumber(AccountNumber.parse("712456328"))
                                             .withNickName("Checking account")
                                             .withRewardsBalance(BigInteger.valueOf(1234))
                                             .withToAccount(MockAccountBuilder.newSavingsAccountBuilder()
                                                                              .build())
                                             .withHasRedeemed(true)
                                             .withLastRedemptionDate(
                                                             LocalDate.parse("2018-5-28").toDate())
                                             .withLastRedemptionAmount(BigInteger.valueOf(10))
                                             .build();
        AutoRedemptionAccount account2 = AutoRedemptionAccount.getBuilder()
                                                              .withId("SM2345")
                                                              .withAccountNumber(
                                                                              AccountNumber.parse(
                                                                                              "712456329"))
                                                              .withNickName("Checking account1")
                                                              .withIsEnrolled(false)
                                                              .withRewardsBalance(
                                                                              BigInteger.valueOf(
                                                                                              1234))
                                                              .build();
        autoRedemptionAccounts.add(account1);
        autoRedemptionAccounts.add(account2);

        return autoRedemptionAccounts;
    }

    private EditAutoRedemptionResponse editedAutoRedemptionDetail() {
        BankAccount toAccount =
                        BankAccount.newBuilder()
                                   .setAccountNumber(AccountNumber.parse("0121421"))
                                   .setId("SM66664")
                                   .setNickName("Mytest")
                                   .setStatus(AccountStatus.ACTIVE)
                                   .defineDepositAccount(AccountProduct.of("SBPRM", "002"))
                                   .build();

        return EditAutoRedemptionResponse.newBuilder().withToAccount(toAccount).build();
    }

    private AutoRedemptionResponse getAutoRedemptionDetail() {
        return AutoRedemptionResponse.newBuilder().withIsEnrolled(false).build();
    }

    private Snippet get_auto_redemption_responseFields() {
        return responseFields(new FieldDescriptor[] {fieldWithPath("isEnrolled").description(
                        "Customer is enrolled for auto-redemption")});
    }

    private Snippet delete_auto_redemption_responseFields() {
        return responseFields(new FieldDescriptor[] {fieldWithPath("message").description(
                        "You have successfully removed your auto-redemption settings.")});
    }

    private Snippet edit_auto_redemption_responseFields() {
        return responseFields(new FieldDescriptor[] {
                        fieldWithPath("toAccount.id").description(
                                        "The account id to which rewards amount is to be transferred to"),
                        fieldWithPath("toAccount.accountNumber.ending").description(
                                        "The last four digits of the account number to which rewards amount is to be transferred to"),
                        fieldWithPath("toAccount.accountNumber.formatted").description(
                                        "The formatted account number to which rewards amount is to be transferred to"),
                        fieldWithPath("toAccount.nickName").description(
                                        "The account nickName to which rewards amount is to be transferred to")});
    }

    private Snippet get_auto_redemption_accounts_responseFields() {
        return responseFields(new FieldDescriptor[] {
                        fieldWithPath("accounts[0].id").description("The id of the source account"),
                        fieldWithPath("accounts[0].accountNumber").description(
                                        "The account number of the source account"),
                        fieldWithPath("accounts[0].nickName").description(
                                        "The nickname of the source account"),
                        fieldWithPath("accounts[0].isEnrolled").description(
                                        "The boolean flag to denote if account is enrolled for auto redempton"),
                        fieldWithPath("accounts[0].rewardsBalance.value").description(
                                        "The value fo the rewards balance of the source account"),
                        fieldWithPath("accounts[0].rewardsBalance.formatted").description(
                                        "The formatted value fo the rewards balance of the source account"),
                        fieldWithPath("accounts[0].toAccount.id").description(
                                        "The id of the target account"),
                        fieldWithPath("accounts[0].toAccount.accountNumber").description(
                                        "The account number of the target account"),
                        fieldWithPath("accounts[0].toAccount.nickName").description(
                                        "The nick name of the target account"),
                        fieldWithPath("accounts[0].hasRedeemed").description(
                                        "The boolean value to denote if redemption is done or not"),
                        fieldWithPath("accounts[0].lastRedemptionDate").description(
                                        "The date of the latest redemption done"),
                        fieldWithPath("accounts[0].lastRedemptionAmount").description(
                                        "The redeemed amount in the latest redemption")});
    }

    private Snippet postAutoRedemption_requestFields = requestFields(
                    fieldWithPath("toAccount.id").description(
                                    "The account id to which rewards amount is to be transferred to automatically"),
                    fieldWithPath("didOneTimeRedemption").ignored());

    private Snippet postAutoRedemption_responseFields() {
        return responseFields(new FieldDescriptor[] {
                        fieldWithPath("toAccount.id").description(
                                        "The account id to which rewards amount is to be transferred to"),
                        fieldWithPath("toAccount.accountNumber.ending").description(
                                        "The last four digits of the account number to which rewards amount is to be transferred to"),
                        fieldWithPath("toAccount.accountNumber.formatted").description(
                                        "The formatted account number to which rewards amount is to be transferred to"),
                        fieldWithPath("toAccount.nickName").description(
                                        "The account nickName to which rewards amount is to be transferred to"),
                        fieldWithPath("didOneTimeRedemption").description(
                                        "indicates if performed one time redemption "),
                        fieldWithPath("oneTimeRedemption.amount.value").description(
                                        "one time redemption amount value"),
                        fieldWithPath("oneTimeRedemption.amount.formatted").description(
                                        "The formatted one time redemption amount"),
                        fieldWithPath("oneTimeRedemption.redemptionType").description(
                                        "The redemption type of the one time redemption"),
                        fieldWithPath("oneTimeRedemption.confirmationNumber").description(
                                        "confirmation number of the one time redemption"),
                        fieldWithPath("bannerText").description(
                                        "The banner text to denote if one time redemption is done or not")});

    }

    private Snippet postAutoRedemption_noBalance_responseFields() {
        return responseFields(new FieldDescriptor[] {
                        fieldWithPath("toAccount.id").description(
                                        "The account id to which rewards amount is to be transferred to"),
                        fieldWithPath("toAccount.accountNumber.ending").description(
                                        "The last four digits of the account number to which rewards amount is to be transferred to"),
                        fieldWithPath("toAccount.accountNumber.formatted").description(
                                        "The formatted account number to which rewards amount is to be transferred to"),
                        fieldWithPath("toAccount.nickName").description(
                                        "The account nickName to which rewards amount is to be transferred to"),
                        fieldWithPath("didOneTimeRedemption").description(
                                        "indicates if performed one time redemption "),
                        fieldWithPath("bannerText").description(
                                        "The banner text to denote if one time redemption is done or not")});

    }
}
