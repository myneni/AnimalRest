package com.discover.bank.api.rewards.account;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.discover.bank.api.core.accounts.MockAccountBuilder;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsTestConfiguration;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RewardsAccountMixinTest {

    PropertyAccessor props = RewardsTestConfiguration.propertyAccessor();

    ObjectMapper mapper = RewardsTestConfiguration.objectMapper();

    //@Test
    public void testRewardsAccountMixin_Output() throws JsonProcessingException {
        String output = mapper.writeValueAsString(
                        new RewardsAccount(MockAccountBuilder.newCheckingAccountBuilder().build()));

        Assert.assertNotNull(output);
        Assert.assertEquals(props.get("RewardsAccount.Output"), output);
    }

    @Test
    public void testRewardsAccountMixin_Input()
                    throws JsonParseException, JsonMappingException, IOException {
        RewardsAccount input =
                        mapper.readValue(props.get("RewardsAccount.Input"), RewardsAccount.class);

        Assert.assertNotNull(input);
        Assert.assertNotNull(input.getId());

        Assert.assertEquals("0", input.getId());
    }

}
