package com.discover.bank.api.rewards.earnings;

import org.junit.Assert;
import org.junit.Test;

import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.RewardsTestConfiguration;
import com.discover.common.base.BigNumbers;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EarningsMixinTest {

    PropertyAccessor props = RewardsTestConfiguration.propertyAccessor();

    ObjectMapper mapper = RewardsTestConfiguration.objectMapper();

    @Test
    public void testEarningsMixin_Output() throws JsonProcessingException {
        Earnings earnings = new Earnings.Builder().from("2014-07-01").to("2015-03-31")
                        .add("Bill Pay", BigNumbers.toMoney(new Integer("999"))).build();

        String output = mapper.writeValueAsString(earnings);

        Assert.assertNotNull(output);
        Assert.assertEquals(props.get("Earnings.Output"), output);
    }

}
