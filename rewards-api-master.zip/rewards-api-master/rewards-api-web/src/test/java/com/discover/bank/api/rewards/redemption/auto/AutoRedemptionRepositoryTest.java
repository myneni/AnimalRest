package com.discover.bank.api.rewards.redemption.auto;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.joda.time.LocalDate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.accounts.MockAccountBuilder;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.core.customers.MockCustomerBuilder;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.redemption.UnrecoverableRedemptionException;

@RunWith(MockitoJUnitRunner.class)
public class AutoRedemptionRepositoryTest {

    @InjectMocks
    private AutoRedemptionRepository repository;

    @Mock
    private RestTemplate template;

    private CustomerIdentification id;

    @Mock
    private PropertyAccessor props;

    @Before
    public void setUp() throws Exception {

        id = MockCustomerBuilder.mockCustomerIdentification();
        repository = new AutoRedemptionRepository(template, props);
        Mockito.doReturn("https://test.com/").when(props).get(Matchers.any(String.class));

    }

    @Test
    public void testEnrollAutoRedemption_success() {

        EnrollAutoRedemptionOutput output =
                        EnrollAutoRedemptionOutput.newBuilder()
                                                  .withEnrollmentStatus("Success")
                                                  .build();

        ResponseEntity<EnrollAutoRedemptionOutput> response =
                        new ResponseEntity<EnrollAutoRedemptionOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EnrollAutoRedemptionOutput.class)))
               .thenReturn(response);


        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "enroll");

    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEnrollAutoRedemption_Failure() {

        EnrollAutoRedemptionOutput output =
                        EnrollAutoRedemptionOutput.newBuilder()
                                                  .withEnrollmentStatus("Failure")
                                                  .build();

        ResponseEntity<EnrollAutoRedemptionOutput> response =
                        new ResponseEntity<EnrollAutoRedemptionOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EnrollAutoRedemptionOutput.class)))
               .thenReturn(response);

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "enroll");
    }


    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEnrollAutoRedemption_HttpClientError_NOTFOUND() {

        String responseBody = "{\"statusCode\":\"E002\",\"errorDescription\":\"No Records Found\"}";

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EnrollAutoRedemptionOutput.class)))
               .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "404",
                               responseBody.getBytes(), null));

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "enroll");
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEnrollAutoRedemption_HttpClientError_BADREQUEST() {

        String responseBody = "{\"statusCode\":\"XXXXX\",\"errorDescription\":\"AAAAAAA\"}";

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EnrollAutoRedemptionOutput.class)))
               .thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST, "400",
                               responseBody.getBytes(), null));

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "enroll");
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEnrollAutoRedemption_HttpServerError() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EnrollAutoRedemptionOutput.class)))
               .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "500"));

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "enroll");
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEnrollAutoRedemption_NULLResponse() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EnrollAutoRedemptionOutput.class)))
               .thenReturn(null);

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "enroll");
    }

    @Test
    public void testEditAutoRedemption_Success() {

        EditAutoRedemptionOutput output =
                        EditAutoRedemptionOutput.newBuilder().withStatus("Success").build();

        ResponseEntity<EditAutoRedemptionOutput> response =
                        new ResponseEntity<EditAutoRedemptionOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EditAutoRedemptionOutput.class)))
               .thenReturn(response);

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "edit");

        Assert.assertEquals("Success", response.getBody().getStatus());

    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEditAutoRedemption_Failure() {

        EditAutoRedemptionOutput output =
                        EditAutoRedemptionOutput.newBuilder().withStatus("Failure").build();

        ResponseEntity<EditAutoRedemptionOutput> response =
                        new ResponseEntity<EditAutoRedemptionOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EditAutoRedemptionOutput.class)))
               .thenReturn(response);

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "edit");

    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEditAutoRedemption_Null() {

        ResponseEntity<EditAutoRedemptionOutput> response = null;

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EditAutoRedemptionOutput.class)))
               .thenReturn(response);

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "edit");

    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEditAutoRedemption_HttpClientError_NOTFOUND() {

        String responseBody = "{\"statusCode\":\"E002\",\"errorDescription\":\"No Records Found\"}";

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EditAutoRedemptionOutput.class)))
               .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "404",
                               responseBody.getBytes(), null));

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "edit");
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEditAutoRedemption_HttpClientError_BADREQUEST() {

        String responseBody = "{\"statusCode\":\"XXXXX\",\"errorDescription\":\"AAAAAAA\"}";

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EditAutoRedemptionOutput.class)))
               .thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST, "400",
                               responseBody.getBytes(), null));

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "edit");
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEditAutoRedemption_HttpServerError() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EditAutoRedemptionOutput.class)))
               .thenThrow(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "500"));

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "edit");
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEditAutoRedemption_Exception() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EditAutoRedemptionOutput.class)))
               .thenThrow(new RuntimeException());

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "edit");
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEditAutoRedemption_NULLResponse() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(EditAutoRedemptionOutput.class)))
               .thenReturn(null);

        repository.enrollOrEditAutoRedemption(id, "S4234232", "T234232", "edit");
    }

    @Test
    public void testGetAutoRedemptionAccounts_success() {

        AutoRedemptionAccount autoRedemptionAccount = AutoRedemptionAccount.getBuilder()
                                                                           .withId("SM12345")
                                                                           .withNickName("Cashback Debit Account Ending 1589")
                                                                           .withLastRedemptionAmount(
                                                                                           BigInteger.valueOf(
                                                                                                           10))
                                                                           .withLastRedemptionDate(
                                                                                           LocalDate.parse("2018-5-28")
                                                                                                    .toDate())
                                                                           .withHasRedeemed(true)
                                                                           .withIsEnrolled(true)
                                                                           .withAccountNumber(
                                                                                           AccountNumber.parse(
                                                                                                           "123456"))
                                                                           .build();

        EnrollmentDetailsOutput output = new EnrollmentDetailsOutput();
        EnrollmentDetail enrollmentDetail = new EnrollmentDetail();
        enrollmentDetail.setCustomerId("1234");
        enrollmentDetail.setEnrollmentStatus("Y");
        enrollmentDetail.setSourceAccountNumber("7894561");
        enrollmentDetail.setTargetAccountNumber("7412589");
        output.setEnrollmentDetails(Arrays.asList(enrollmentDetail));

        ResponseEntity<EnrollmentDetailsOutput> response =
                        new ResponseEntity<EnrollmentDetailsOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(EnrollmentDetailsOutput.class)))
               .thenReturn(response);

        AutoRedemptionRepository spyRepo = Mockito.spy(repository);

        Mockito.doReturn(Arrays.asList(autoRedemptionAccount))
               .when(spyRepo)
               .transformAutoRedemptionAccounts(Matchers.any(EnrollmentDetailsOutput.class),
                               Matchers.anyList());

        List<AutoRedemptionAccount> result = spyRepo.getAutoRedemptionAccountsStatus(id,
                        new EnrollmentDetailsInput(), null);

        Assert.assertNotNull(result);
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testGetAutoRedemptionAccounts_ClientError() {

        String responseBody = "{\"statusCode\":\"E002\",\"errorDescription\":\"No Records Found\"}";

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(EnrollmentDetailsOutput.class)))
               .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "404",
                               responseBody.getBytes(), null));

        repository.getAutoRedemptionAccountsStatus(id, new EnrollmentDetailsInput(), null);
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testGetAutoRedemptionAccounts_ServerError() {

        String responseBody = "{\"statusCode\":\"E002\",\"errorDescription\":\"No Records Found\"}";

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(EnrollmentDetailsOutput.class)))
               .thenThrow(new HttpServerErrorException(HttpStatus.NOT_FOUND, "404",
                               responseBody.getBytes(), null));

        repository.getAutoRedemptionAccountsStatus(id, new EnrollmentDetailsInput(), null);
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testGetAutoRedemptionAccounts_Exception() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(EnrollmentDetailsOutput.class)))
               .thenThrow(new RuntimeException());

        repository.getAutoRedemptionAccountsStatus(id, new EnrollmentDetailsInput(), null);
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testGetAutoRedemptionAccounts_ResponseNull() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(EnrollmentDetailsOutput.class)))
               .thenReturn(null);

        repository.getAutoRedemptionAccountsStatus(id, new EnrollmentDetailsInput(), null);
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testGetAutoRedemptionAccounts_ResponseBodyNull() {

        EnrollmentDetailsOutput output = null;

        ResponseEntity<EnrollmentDetailsOutput> response =
                        new ResponseEntity<EnrollmentDetailsOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class), Matchers.eq(EnrollmentDetailsOutput.class)))
               .thenReturn(response);

        repository.getAutoRedemptionAccountsStatus(id, new EnrollmentDetailsInput(), null);
    }

    @Test
    public void testTransformAutoRedemptionAccounts_ErrorNull() {

        EnrollmentDetailsOutput enrollmentDetailsOutput = new EnrollmentDetailsOutput();
        enrollmentDetailsOutput.setEnrollmentDetails(null);
        enrollmentDetailsOutput.setErrorCode("101");;
        enrollmentDetailsOutput.setErrorDescription("Error description");

        List<AutoRedemptionAccount> output =
                        repository.transformAutoRedemptionAccounts(enrollmentDetailsOutput, null);

        Assert.assertNotNull(output);
        Assert.assertTrue(output.get(0).getError());
        Assert.assertEquals("101 - Error description", output.get(0).getErrorDescription());
    }

    @Test
    public void testTransformAutoRedemptionAccounts_ErrorEmpty() {

        EnrollmentDetailsOutput enrollmentDetailsOutput = new EnrollmentDetailsOutput();
        enrollmentDetailsOutput.setEnrollmentDetails(new ArrayList<EnrollmentDetail>());
        enrollmentDetailsOutput.setErrorCode("101");;
        enrollmentDetailsOutput.setErrorDescription("Error description");

        List<AutoRedemptionAccount> output =
                        repository.transformAutoRedemptionAccounts(enrollmentDetailsOutput, null);

        Assert.assertNotNull(output);
        Assert.assertTrue(output.get(0).getError());
        Assert.assertEquals("101 - Error description", output.get(0).getErrorDescription());
    }

    @Test
    public void testTransformAutoRedemptionAccounts_NotEnrolled() {

        EnrollmentDetail enrollmentDetail = new EnrollmentDetail();
        enrollmentDetail.setSourceAccountNumber("789456123");
        enrollmentDetail.setEnrollmentStatus("N");

        EnrollmentDetailsOutput enrollmentDetailsOutput = new EnrollmentDetailsOutput();
        enrollmentDetailsOutput.setEnrollmentDetails(Arrays.asList(enrollmentDetail));

        List<AutoRedemptionAccount> output = repository.transformAutoRedemptionAccounts(
                        enrollmentDetailsOutput, Arrays.asList(BankAccount.newBuilder(
                                        MockAccountBuilder.newCheckingAccountBuilder().build())
                                                                          .setId("SM12345")
                                                                          .setAccountNumber(
                                                                                          AccountNumber.parse(
                                                                                                          "789456123"))
                                                                          .setAlternateAccountNumber(
                                                                                          "SM12345")
                                                                          .setNickName("nickname")
                                                                          .build()));

        Assert.assertNotNull(output);
        Assert.assertEquals("SM12345", output.get(0).getId());
        Assert.assertFalse(output.get(0).getIsEnrolled());
        Assert.assertEquals("789456123", output.get(0).getAccountNumber().getValue());
        Assert.assertEquals("nickname", output.get(0).getNickName());
    }

    @Test
    public void testTransformAutoRedemptionAccounts_Enrolled() {

        EnrollmentDetail enrollmentDetail = new EnrollmentDetail();
        enrollmentDetail.setSourceAccountNumber("789456123");
        enrollmentDetail.setTargetAccountNumber("777888999");
        enrollmentDetail.setEnrollmentStatus("Y");

        EnrollmentDetailsOutput enrollmentDetailsOutput = new EnrollmentDetailsOutput();
        enrollmentDetailsOutput.setEnrollmentDetails(Arrays.asList(enrollmentDetail));

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(BankAccount
                                        .newBuilder(MockAccountBuilder.newCheckingAccountBuilder()
                                                                      .build())
                                        .setId("SM12345")
                                        .setAccountNumber(AccountNumber.parse("789456123"))
                                        .setAlternateAccountNumber("SM12345")
                                        .setNickName("nickname")
                                        .build());
        customerAccounts.add(BankAccount
                                        .newBuilder(MockAccountBuilder.newCheckingAccountBuilder()
                                                                      .build())
                                        .setId("SM54321")
                                        .setAccountNumber(AccountNumber.parse("777888999"))
                                        .setAlternateAccountNumber("SM12345")
                                        .setNickName("nickname")
                                        .build());

        List<AutoRedemptionAccount> output = repository.transformAutoRedemptionAccounts(
                        enrollmentDetailsOutput, customerAccounts);

        Assert.assertNotNull(output);
        Assert.assertEquals("SM12345", output.get(0).getId());
        Assert.assertTrue(output.get(0).getIsEnrolled());
        Assert.assertEquals("789456123", output.get(0).getAccountNumber().getValue());
        Assert.assertEquals("nickname", output.get(0).getNickName());
        Assert.assertEquals("SM54321", output.get(0).getToAccount().getId());
    }

    @Test
    public void testTransformAutoRedemptionAccounts_AccountNotFound() {

        EnrollmentDetail enrollmentDetail = new EnrollmentDetail();
        enrollmentDetail.setSourceAccountNumber("78945612");
        enrollmentDetail.setEnrollmentStatus("Y");

        EnrollmentDetailsOutput enrollmentDetailsOutput = new EnrollmentDetailsOutput();
        enrollmentDetailsOutput.setEnrollmentDetails(Arrays.asList(enrollmentDetail));

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(BankAccount
                                        .newBuilder(MockAccountBuilder.newCheckingAccountBuilder()
                                                                      .build())
                                        .setId("SM12345")
                                        .setAccountNumber(AccountNumber.parse("789456123"))
                                        .setAlternateAccountNumber("SM12345")
                                        .setNickName("nickname")
                                        .build());

        List<AutoRedemptionAccount> output = repository.transformAutoRedemptionAccounts(
                        enrollmentDetailsOutput, customerAccounts);

        Assert.assertNotNull(output);
        Assert.assertEquals(0, output.size());
    }

    @Test
    public void testDeleteAutoRedemption_Success() {

        DeleteAutoRedemptionOutput output = new DeleteAutoRedemptionOutput();
        output.setStatus("success");

        ResponseEntity<DeleteAutoRedemptionOutput> response =
                        new ResponseEntity<DeleteAutoRedemptionOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(DeleteAutoRedemptionOutput.class)))
               .thenReturn(response);

        repository.deleteAutoRedemption(id,
                        AutoRedemptionAccount.getBuilder()
                                             .withBankAccount(
                                                             MockAccountBuilder.newCheckingAccountBuilder()
                                                                               .build())
                                             .build());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testDeleteAutoRedemption_Failed() {

        DeleteAutoRedemptionOutput output = new DeleteAutoRedemptionOutput();
        output.setStatus("failed");

        ResponseEntity<DeleteAutoRedemptionOutput> response =
                        new ResponseEntity<DeleteAutoRedemptionOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(DeleteAutoRedemptionOutput.class)))
               .thenReturn(response);

        repository.deleteAutoRedemption(id,
                        AutoRedemptionAccount.getBuilder()
                                             .withBankAccount(
                                                             MockAccountBuilder.newCheckingAccountBuilder()
                                                                               .build())
                                             .build());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testDeleteAutoRedemption_HttpClientError_NOTFOUND() {

        String responseBody = "{\"statusCode\":\"E002\",\"errorDescription\":\"No Records Found\"}";

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(DeleteAutoRedemptionOutput.class)))
               .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "404",
                               responseBody.getBytes(), null));

        repository.deleteAutoRedemption(id,
                        AutoRedemptionAccount.getBuilder()
                                             .withBankAccount(
                                                             MockAccountBuilder.newCheckingAccountBuilder()
                                                                               .build())
                                             .build());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testDeleteAutoRedemption_Exception() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(DeleteAutoRedemptionOutput.class)))
               .thenThrow(new RuntimeException());

        repository.deleteAutoRedemption(id,
                        AutoRedemptionAccount.getBuilder()
                                             .withBankAccount(
                                                             MockAccountBuilder.newCheckingAccountBuilder()
                                                                               .build())
                                             .build());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testDeleteAutoRedemption_HttpClientError_BADREQUEST() {

        String responseBody = "{\"statusCode\":\"XXXXX\",\"errorDescription\":\"AAAAAAA\"}";

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(DeleteAutoRedemptionOutput.class)))
               .thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST, "400",
                               responseBody.getBytes(), null));

        repository.deleteAutoRedemption(id,
                        AutoRedemptionAccount.getBuilder()
                                             .withBankAccount(
                                                             MockAccountBuilder.newCheckingAccountBuilder()
                                                                               .build())
                                             .build());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testDeleteAutoRedemption_HttpServerError() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(DeleteAutoRedemptionOutput.class)))
               .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "500"));

        repository.deleteAutoRedemption(id,
                        AutoRedemptionAccount.getBuilder()
                                             .withBankAccount(
                                                             MockAccountBuilder.newCheckingAccountBuilder()
                                                                               .build())
                                             .build());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testDeleteAutoRedemption_NULLResponse() {

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(DeleteAutoRedemptionOutput.class)))
               .thenReturn(null);

        repository.deleteAutoRedemption(id,
                        AutoRedemptionAccount.getBuilder()
                                             .withBankAccount(
                                                             MockAccountBuilder.newCheckingAccountBuilder()
                                                                               .build())
                                             .build());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testDeleteAutoRedemption_HttpClientError_ResponseBodyNull() {

        DeleteAutoRedemptionOutput output = null;

        ResponseEntity<DeleteAutoRedemptionOutput> response =
                        new ResponseEntity<DeleteAutoRedemptionOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(DeleteAutoRedemptionOutput.class)))
               .thenReturn(response);
        repository.deleteAutoRedemption(id,
                        AutoRedemptionAccount.getBuilder()
                                             .withBankAccount(
                                                             MockAccountBuilder.newCheckingAccountBuilder()
                                                                               .build())
                                             .build());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testDeleteAutoRedemption_HttpClientError_ResponseBodyStatusNull() {

        DeleteAutoRedemptionOutput output = new DeleteAutoRedemptionOutput();
        output.setStatus(null);

        ResponseEntity<DeleteAutoRedemptionOutput> response =
                        new ResponseEntity<DeleteAutoRedemptionOutput>(output, HttpStatus.OK);

        Mockito.when(template.exchange(Matchers.any(String.class), Matchers.any(HttpMethod.class),
                        Matchers.any(HttpEntity.class),
                        Matchers.eq(DeleteAutoRedemptionOutput.class)))
               .thenReturn(response);
        repository.deleteAutoRedemption(id,
                        AutoRedemptionAccount.getBuilder()
                                             .withBankAccount(
                                                             MockAccountBuilder.newCheckingAccountBuilder()
                                                                               .build())
                                             .build());
    }
}
