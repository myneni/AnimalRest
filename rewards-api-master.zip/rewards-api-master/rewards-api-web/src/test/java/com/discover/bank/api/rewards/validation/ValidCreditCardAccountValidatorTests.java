package com.discover.bank.api.rewards.validation;

import javax.validation.ConstraintValidatorContext;

import org.hibernate.validator.internal.engine.constraintvalidation.ConstraintValidatorContextImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.util.ReflectionUtils;

import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.creditcards.account.CreditCardAccount;

public class ValidCreditCardAccountValidatorTests {

    private ValidCreditCardAccountInputValidator validator;

    @Before
    public void setup() {
        this.validator = new ValidCreditCardAccountInputValidator();
        this.validator.initialize(ReflectionUtils
                        .findField(MockRewardsRedemption.class, "mockCreditCardAccount")
                        .getAnnotation(ValidCreditCardAccountInput.class));
    }

    public static class MockRewardsRedemption {
        @ValidCreditCardAccountInput
        CreditCardAccount mockCreditCardAccount;
    }

    // /**
    // * The credit card account cannot be null if we are doing a transfer redemption
    // */
    // @Test
    // public void testNullCreditCardAccount() {
    // Assert.assertFalse( this.validator.isValid( null, newContext() ) );
    // Assert.assertFalse( this.validator.isValid( CreditCardAccount.newBuilder().withAccountNumber(
    // AccountNumber.parse( null ) ).build(), newContext() ) );
    // }
    //
    // @Test
    // public void testHasIdOrAccountNumber() {
    // Assert.assertFalse( this.validator.isValid( CreditCardAccount.newBuilder().build(),
    // newContext() ) );
    // }
    //
    // /**
    // * Check that passing a credit card account with just an ID passes
    // */
    // @Test
    // public void testCreditCardAccountWithId() {
    // Assert.assertTrue( this.validator.isValid(
    // CreditCardAccount.newBuilder().withId("0").build(), newContext() ) );
    // }
    //
    // /**
    // * Need to do the "Mod 10" check to make sure it's a valid credit card number
    // */
    // @Test
    // public void testInvalidAccountNumber() {
    // //Create a credit cards that fails the "Mod 10" check
    // Assert.assertFalse( this.validator.isValid( CreditCardAccount.newBuilder().withAccountNumber(
    // AccountNumber.parse( "6011545423115642" ) ).build(), newContext() ) );
    //
    // //Create a credit card that is not the right length for discover (16 digits)
    // Assert.assertFalse( this.validator.isValid( CreditCardAccount.newBuilder().withAccountNumber(
    // AccountNumber.parse( "6011545423115" ) ).build(), newContext() ) );
    //
    // //Create a credit card with non-digits
    // Assert.assertFalse( this.validator.isValid( CreditCardAccount.newBuilder().withAccountNumber(
    // AccountNumber.parse( "6011e671a7651916" ) ).build(), newContext() ) );
    // }
    //
    // /**
    // * Test a valid (randomly generated) Visa number since the credit card used needs to be a
    // Discover Card.
    // * Note that it is unknown if this is actually someone's number, only that is could be used as
    // a Visa card number.
    // */
    // @Test
    // public void testValidNonDiscoverAccountNumber() {
    // //Create a CreditCard that passes "Mod 10" but is not a Discover Card
    // Assert.assertFalse( this.validator.isValid( CreditCardAccount.newBuilder().withAccountNumber(
    // AccountNumber.parse( "4539666444323646" ) ).build(), newContext() ) );
    // }

    /**
     * Test a valid (randomly generated) Discover Card number. Note that it is unknown if these are
     * actually someone's number, only that is could be used as a Discover Card number.
     */
    @Test
    public void testValidDiscoverAccountNumber() {
        // Create a credit card that passes "Mod 10" and is a Discover Card
        Assert.assertTrue(this.validator.isValid(CreditCardAccount.newBuilder()
                        .withAccountNumber(AccountNumber.parse("6011671765191699")).build(),
                        newContext()));
        Assert.assertTrue(this.validator.isValid(CreditCardAccount.newBuilder()
                        .withAccountNumber(AccountNumber.parse("6011201007194655")).build(),
                        newContext()));
        Assert.assertTrue(this.validator.isValid(CreditCardAccount.newBuilder()
                        .withAccountNumber(AccountNumber.parse("6011201008995951")).build(),
                        newContext()));
        Assert.assertTrue(this.validator.isValid(CreditCardAccount.newBuilder()
                        .withAccountNumber(AccountNumber.parse("6011201003605399")).build(),
                        newContext()));
    }

    private ConstraintValidatorContext newContext() {
        return new ConstraintValidatorContextImpl(null, PathImpl.createRootPath(), null);
    }
}