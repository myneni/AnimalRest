package com.discover.bank.api.rewards;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.validation.Validator;

import org.joda.time.LocalDate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.discover.bank.api.core.accounts.AccountNotFoundException;
import com.discover.bank.api.core.accounts.AccountNumber;
import com.discover.bank.api.core.accounts.AccountProduct;
import com.discover.bank.api.core.accounts.AccountStatus;
import com.discover.bank.api.core.accounts.BankAccount;
import com.discover.bank.api.core.accounts.BankAccountManager;
import com.discover.bank.api.core.accounts.MockAccountBuilder;
import com.discover.bank.api.core.customers.Customer;
import com.discover.bank.api.core.customers.CustomerIdentification;
import com.discover.bank.api.core.customers.CustomerManager;
import com.discover.bank.api.core.customers.CustomerNotFoundException;
import com.discover.bank.api.core.customers.MockCustomerBuilder;
import com.discover.bank.api.creditcards.CreditCardsException;
import com.discover.bank.api.creditcards.account.CreditCardAccount;
import com.discover.bank.api.creditcards.account.CreditCardAccountRepository;
import com.discover.bank.api.env.PropertyAccessor;
import com.discover.bank.api.rewards.account.EligibleAccounts;
import com.discover.bank.api.rewards.account.EligibleAccountsRepository;
import com.discover.bank.api.rewards.account.RewardsAccount;
import com.discover.bank.api.rewards.account.RewardsAccountEnricher;
import com.discover.bank.api.rewards.account.RewardsAccountNotFoundException;
import com.discover.bank.api.rewards.account.RewardsEligibleAccount;
import com.discover.bank.api.rewards.balance.RewardsBalance;
import com.discover.bank.api.rewards.earnings.Earnings;
import com.discover.bank.api.rewards.earnings.EarningsFilter;
import com.discover.bank.api.rewards.earnings.EarningsFilter.GroupBy;
import com.discover.bank.api.rewards.earnings.EarningsInvalidFilterException;
import com.discover.bank.api.rewards.earnings.EarningsV2;
import com.discover.bank.api.rewards.earnings.buckets.RewardsBucketRepository;
import com.discover.bank.api.rewards.email.EmailRepository;
import com.discover.bank.api.rewards.redemption.Redemption;
import com.discover.bank.api.rewards.redemption.RedemptionRepository;
import com.discover.bank.api.rewards.redemption.UnrecoverableRedemptionException;
import com.discover.bank.api.rewards.redemption.auto.AutoRedemptionAccount;
import com.discover.bank.api.rewards.redemption.auto.AutoRedemptionRepository;
import com.discover.bank.api.rewards.redemption.auto.AutoRedemptionResponse;
import com.discover.bank.api.rewards.redemption.auto.EditAutoRedemptionResponse;
import com.discover.bank.api.rewards.redemption.auto.EnrollEditAutoRedemption;
import com.discover.bank.api.rewards.redemption.auto.EnrollmentDetailsInput;

@RunWith(MockitoJUnitRunner.class)
public class RewardsBusinessObjectTest {

    @Mock
    private BankAccountManager accountManager;

    @Mock
    private RewardsBucketRepository rewardsBucketRepository;

    @Mock
    private CustomerIdentification customerId;

    @Mock
    private AutoRedemptionRepository autoRedemptionRepository;

    @Mock
    private EligibleAccountsRepository eligibleAccountsRepository;

    @Mock
    private RedemptionRepository rewardsRedemptionRepository;

    @Mock
    private Validator validator;

    private PropertyAccessor props;

    @Mock
    private List<RewardsAccountEnricher<RewardsAccount>> accountEnrichers;

    @Mock
    private CustomerManager customerManager;

    @Mock
    private EmailRepository emailRepository;

    private RewardsBusinessObject rewardsBO;

    @Mock
    private CreditCardAccountRepository creditCardRepository;

    @Before
    public void setup() {

        props = RewardsTestConfiguration.earningsPropAccessor();
        BankAccount bankAccount = BankAccount.newBuilder()
                                             .setAccountNumber(AccountNumber.parse("123456"))
                                             .setBalance(BigInteger.TEN)
                                             .setId("0")
                                             .setNickName("Test Account")
                                             .setOpenDate(new Date("07/07/2014"))
                                             .build();

        Mockito.when(accountManager.findCustomerAccountById(
                        Matchers.any(CustomerIdentification.class), Matchers.anyString()))
               .thenReturn(bankAccount);

        rewardsBO = new RewardsBusinessObject();
        rewardsBO.setBankAccountManager(accountManager);
        rewardsBO.setRewardsBucketsRepository(rewardsBucketRepository);
        rewardsBO.setAutoRedemptionRepository(autoRedemptionRepository);
        rewardsBO.setEligibleAccountsRepository(eligibleAccountsRepository);
        rewardsBO.setValidator(validator);
        rewardsBO.setPropertyAccessor(props);
        rewardsBO.setRewardsRedemptionRepository(rewardsRedemptionRepository);
        rewardsBO.setCustomerManager(customerManager);
        rewardsBO.setEmailRepository(emailRepository);
        rewardsBO.setCreditCardRepository(creditCardRepository);

        customerId = MockCustomerBuilder.mockCustomerIdentification();
    }

    @Test
    public void test_getHistory_Deposits_CreditCard()
                    throws RewardsException, RewardsAccountNotFoundException, CreditCardsException {
        BankAccount customerAccount = BankAccount.newBuilder()
                                                 .setAccountNumber(AccountNumber.parse("12345"))
                                                 .setId("54321")
                                                 .setNickName("nickname 1")
                                                 .build();

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(customerAccount);
        customerAccounts.add(BankAccount.newBuilder()
                                        .setAccountNumber(AccountNumber.parse("6157"))
                                        .setId("78910")
                                        .setNickName("nickname 2")
                                        .build());

        List<Redemption> history = new ArrayList<Redemption>();

        history.add(Redemption.newBuilder()
                              .withRedemptionType("deposit")
                              .withRedemptionTypeDesc("Deposit into nickname 2 (6157)")
                              .withToAccount(BankAccount.newBuilder()
                                                        .setAccountNumber(AccountNumber.parse(
                                                                        "6157"))
                                                        .setId("78910")
                                                        .build())
                              .build());
        
        history.add(Redemption.newBuilder()
                        .withRedemptionType("transfer")
                        .withRedemptionTypeDesc("Transfer to Discover Credit Card (3327)")
                        .withToCreditCardAccount(
                                        CreditCardAccount.newBuilder().withAccountNumber(
                                                        AccountNumber.parse("3327")).build())
                              .build());

        when(accountManager.findCustomerAccounts(any(CustomerIdentification.class))).thenReturn(
                        customerAccounts);

        when(customerManager.findCustomer(any(CustomerIdentification.class))).thenReturn(
                        MockCustomerBuilder.mockBankCustomer());

        when(rewardsRedemptionRepository.lookupRedemptionHistoryForAccount(
                        any(RewardsAccount.class), any(Integer.class),
                        Matchers.anyListOf(BankAccount.class))).thenReturn(history);

        CustomerIdentification customerIdentification = null;
        List<Redemption> redemptionHistory =
                        rewardsBO.getHistory("54321", customerIdentification, 12);

        Assert.assertFalse(redemptionHistory.isEmpty());
        Assert.assertEquals(history, redemptionHistory);
        Assert.assertEquals("nickname 2", redemptionHistory.get(0).getToAccount().getNickName());
        Assert.assertEquals("Deposit into nickname 2 (6157)", redemptionHistory.get(0).getRedemptionTypeDesc());
        Assert.assertEquals("Transfer to Discover Credit Card (3327)",
                        redemptionHistory.get(1).getRedemptionTypeDesc());

        verify(accountManager, times(1)).findCustomerAccounts(any(CustomerIdentification.class));
        verify(rewardsRedemptionRepository, times(1)).lookupRedemptionHistoryForAccount(
                        any(RewardsAccount.class), any(Integer.class), Matchers.anyListOf(BankAccount.class));
    }

    @Test(expected = RewardsAccountNotFoundException.class)
    public void test_getHistory_NoCustomerAccountFound()
                    throws RewardsException, RewardsAccountNotFoundException {
        BankAccount customerAccount = BankAccount.newBuilder()
                                                 .setAccountNumber(AccountNumber.parse("12345"))
                                                 .setId("54321")
                                                 .setNickName("nickname 1")
                                                 .build();

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(customerAccount);
        customerAccounts.add(BankAccount.newBuilder()
                                        .setAccountNumber(AccountNumber.parse("ABCDEF"))
                                        .setId("78910")
                                        .setNickName("nickname 2")
                                        .build());

        List<Redemption> history = new ArrayList<Redemption>();

        history.add(Redemption.newBuilder()
                              .withRedemptionType("deposit")
                              .withToAccount(BankAccount.newBuilder()
                                                        .setAccountNumber(AccountNumber.parse(
                                                                        "ABCDEF"))
                                                        .setId("78910")
                                                        .build())
                              .build());

        when(accountManager.findCustomerAccounts(any(CustomerIdentification.class))).thenReturn(
                        customerAccounts);

        when(rewardsRedemptionRepository.lookupRedemptionHistoryForAccount(
                        any(RewardsAccount.class), any(Integer.class),
                        Matchers.anyListOf(BankAccount.class))).thenReturn(history);

        CustomerIdentification customerIdentification = null;
        rewardsBO.getHistory("ZZZ", customerIdentification, 12);

        verify(accountManager, times(1)).findCustomerAccounts(any(CustomerIdentification.class));
        verify(rewardsRedemptionRepository, times(1)).lookupRedemptionHistoryForAccount(
                        any(RewardsAccount.class), any(Integer.class), customerAccounts);
    }

    @Test
    public void test_getEarningsV2() throws RewardsException, RewardsAccountNotFoundException,
                    EarningsInvalidFilterException {

        rewardsBO = new RewardsBusinessObject();
        rewardsBO.setBankAccountManager(accountManager);
        rewardsBO.setRewardsBucketsRepository(rewardsBucketRepository);

        final EarningsFilter filter = EarningsFilter.initialize().groupBy(GroupBy.MONTH).build();

        Earnings earnings = new Earnings.Builder().from(new Date("03/01/2017"))
                                                  .to(new Date("03/31/2018"))
                                                  .add("Promotions", BigInteger.valueOf(25))
                                                  .build();

        Mockito.when(rewardsBucketRepository.getRewardsBucketEarnings(
                        Matchers.any(CustomerIdentification.class),
                        Matchers.any(RewardsAccount.class), Matchers.any(Date.class),
                        Matchers.any(Date.class)))
               .thenReturn(earnings);

        CustomerIdentification customerIdentification = null;
        // month = "" to check the default 13 month scenario
        EarningsV2 earning = rewardsBO.getEarningsV2(filter, "0", 12, customerIdentification);

        Assert.assertNotNull(earning);
        Assert.assertEquals(earning.getEarningsPeriods().size(), 13);

    }

    @Test
    public void test_getEarningsV2_FULL() throws RewardsException, RewardsAccountNotFoundException,
                    EarningsInvalidFilterException {

        rewardsBO = new RewardsBusinessObject();
        rewardsBO.setBankAccountManager(accountManager);
        rewardsBO.setRewardsBucketsRepository(rewardsBucketRepository);

        final EarningsFilter filter = EarningsFilter.initialize().groupBy(GroupBy.FULL).build();

        Earnings earnings = new Earnings.Builder().from(new Date("03/01/2017"))
                                                  .to(new Date("03/31/2018"))
                                                  .add("Debit Card Purchases",
                                                                  BigInteger.valueOf(25))
                                                  .add("Promotions", BigInteger.valueOf(25))
                                                  .add("Adjustments - Positive",
                                                                  BigInteger.valueOf(25))
                                                  .add("Adjustments - Returns/Reversals",
                                                                  BigInteger.valueOf(25))
                                                  .build();

        Mockito.when(rewardsBucketRepository.getRewardsBucketEarnings(
                        Matchers.any(CustomerIdentification.class),
                        Matchers.any(RewardsAccount.class), Matchers.any(Date.class),
                        Matchers.any(Date.class)))
               .thenReturn(earnings);

        CustomerIdentification customerIdentification = null;
        EarningsV2 earning = rewardsBO.getEarningsV2(filter, "0", 12, customerIdentification);

        Assert.assertNotNull(earning);
        for (Earnings result : earning.getEarningsPeriods()) {
            assertEquals(4, result.getTypes().size());
        }

    }

    @Test(expected = Exception.class)
    public void test_getEarningsV2_exception() throws RewardsException,
                    RewardsAccountNotFoundException, EarningsInvalidFilterException {

        rewardsBO = new RewardsBusinessObject();
        rewardsBO.setRewardsBucketsRepository(rewardsBucketRepository);

        Mockito.when(accountManager.findCustomerAccountById(
                        Matchers.any(CustomerIdentification.class), Matchers.anyString()))
               .thenReturn(null);

        final EarningsFilter filter = EarningsFilter.initialize().groupBy(GroupBy.FULL).build();

        CustomerIdentification customerIdentification = null;
        rewardsBO.getEarningsV2(filter, "0", 12, customerIdentification);
    }

    @Test
    public void test_enrollAutoRedemption_withBalance()
                    throws AccountNotFoundException, CustomerNotFoundException, RewardsException {

        Mockito.doNothing().when(emailRepository).sendConfirmationEmail(
                        Matchers.any(Customer.class), Matchers.any(Redemption.class));

        EnrollEditAutoRedemption input =
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM66666")
                                                                          .build())
                                                .build();

        RewardsBalance rewardsBalance =
                        RewardsBalance.initialize()
                                      .withAvailableBalance(new BigInteger("500"))
                                      .build();

        BankAccount sourceAccount =
                        BankAccount.newBuilder()
                                   .setStatus(AccountStatus.ACTIVE)
                                   .setAccountNumber(AccountNumber.parse("8675309"))
                                   .setId("SM12345")
                                   .defineDepositAccount(AccountProduct.of("CAGEN", "002"))
                                   .build();

        RewardsAccount rewardsAccount = new RewardsAccount(sourceAccount);
        rewardsAccount.setRewardsBalance(rewardsBalance);

        EligibleAccounts eligibilityAccounts = populateEligibilityAccounts();

        // use spy in this test so we can mock getEligibleAccounts() response and
        // populateRewardAccountBalance() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(rewardsAccount)
               .when(spyBO)
               .populateRewardAccountBalance(Matchers.any(RewardsAccount.class));

        Mockito.doReturn(eligibilityAccounts).when(spyBO).getEligibleAccounts(customerId, "auto");

        Mockito.when(rewardsRedemptionRepository.redeemRewards(Matchers.any(Redemption.class),
                        Matchers.any(Customer.class)))
               .thenReturn(Redemption.newBuilder()
                                     .withFromRewardsAccount(rewardsAccount)
                                     .withRedemptionType("deposit")
                                     .withConfirmationNumber("1234123")
                                     .build());

        Mockito.doReturn(Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(false).build()))
               .when(spyBO)
               .getValidateAutoRedemptionAccounts(Matchers.any(CustomerIdentification.class),
                               Matchers.anyList(), Matchers.anyList());

        EnrollEditAutoRedemption enollResponse =
                        spyBO.enrollAutoRedemption(customerId, "SM12345", input);

        Assert.assertNotNull(enollResponse);
        Assert.assertTrue(enollResponse.didOneTimeRedemption());
        Assert.assertEquals("SM66666", enollResponse.getToAccount().getId());
        Assert.assertEquals("SM12345", enollResponse.getFromAccount().getId());
        Assert.assertEquals("ToAccount", enollResponse.getToAccount().getNickName());
        Assert.assertEquals("123121", enollResponse.getToAccount().getAccountNumber().getValue());
        Assert.assertNotNull(enollResponse.getOneTimeRedemption());
        Assert.assertEquals("deposit", enollResponse.getOneTimeRedemption().getRedemptionType());
        Assert.assertEquals("1234123",
                        enollResponse.getOneTimeRedemption().getConfirmationNumber());
        Assert.assertEquals(BigInteger.valueOf(500),
                        enollResponse.getOneTimeRedemption().getAmount());
        Assert.assertEquals(
                        "Success! You''ve redeemed your Debit Card <i>Cashback Bonus</i> and are now enrolled in Auto Redemption to Savings.",
                        enollResponse.getBannerText());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void test_enrollAutoRedemption_NullEligibileAccounts()
                    throws AccountNotFoundException, CustomerNotFoundException, RewardsException {

        EnrollEditAutoRedemption input =
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM66666")
                                                                          .build())
                                                .build();

        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(null).when(spyBO).getEligibleAccounts(customerId, "auto");

        spyBO.enrollAutoRedemption(customerId, "SM12345", input);
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void test_enrollAutoRedemption_alreadyEnrolled()
                    throws AccountNotFoundException, CustomerNotFoundException, RewardsException {

        EnrollEditAutoRedemption input =
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM66666")
                                                                          .build())
                                                .build();

        EligibleAccounts eligibilityAccounts = populateEligibilityAccounts();

        List<AutoRedemptionAccount> redemptionAccounts = Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(true).build());

        // use spy in this test so we can mock getEligibleAccounts() response and
        // populateRewardAccountBalance() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(eligibilityAccounts).when(spyBO).getEligibleAccounts(customerId, "auto");

        Mockito.doReturn(redemptionAccounts).when(spyBO).getAutoRedemptionAccountsStatus(customerId,
                        Arrays.asList("SM12345"));

        spyBO.enrollAutoRedemption(customerId, "SM12345", input);
    }

    @Test
    public void test_enrollAutoRedemption_noBalance()
                    throws AccountNotFoundException, CustomerNotFoundException, RewardsException {

        EnrollEditAutoRedemption input =
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM66666")
                                                                          .build())
                                                .build();
        // rewards balance is 0
        RewardsBalance rewardsBalance =
                        RewardsBalance.initialize()
                                      .withAvailableBalance(new BigInteger("0"))
                                      .build();

        BankAccount sourceAccount =
                        BankAccount.newBuilder()
                                   .setStatus(AccountStatus.ACTIVE)
                                   .setAccountNumber(AccountNumber.parse("8675309"))
                                   .setId("SM12345")
                                   .defineDepositAccount(AccountProduct.of("CAGEN", "002"))
                                   .build();

        RewardsAccount rewardsAccount = new RewardsAccount(sourceAccount);
        rewardsAccount.setRewardsBalance(rewardsBalance);

        EligibleAccounts eligibilityAccounts = populateEligibilityAccounts();

        // use spy in this test so we can mock getEligibleAccounts() response and
        // populateRewardAccountBalance() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(rewardsAccount)
               .when(spyBO)
               .populateRewardAccountBalance(Matchers.any(RewardsAccount.class));

        Mockito.doReturn(eligibilityAccounts).when(spyBO).getEligibleAccounts(customerId, "auto");

        Mockito.doReturn(Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(false).build()))
               .when(spyBO)
               .getValidateAutoRedemptionAccounts(Matchers.any(CustomerIdentification.class),
                               Matchers.anyList(), Matchers.anyList());

        EnrollEditAutoRedemption enollResponse =
                        spyBO.enrollAutoRedemption(customerId, "SM12345", input);

        Assert.assertNotNull(enollResponse);
        Assert.assertEquals("SM66666", enollResponse.getToAccount().getId());
        Assert.assertEquals("ToAccount", enollResponse.getToAccount().getNickName());
        Assert.assertEquals("123121", enollResponse.getToAccount().getAccountNumber().getValue());
        Assert.assertFalse(enollResponse.didOneTimeRedemption());
        Assert.assertNull(enollResponse.getOneTimeRedemption());
        Assert.assertEquals("Success! You are now enrolled in Auto Redemption to Savings.",
                        enollResponse.getBannerText());
    }

    @Test
    public void test_validateSourceAccountForEnroll_eligible() {

        EligibleAccounts eligibleAccounts = populateEligibilityAccounts();

        BankAccount account = rewardsBO.validateSourceAccountInput(eligibleAccounts, "SM12345");

        Assert.assertNotNull(account);
        Assert.assertEquals("SM12345", account.getId());
        Assert.assertEquals("8675309", account.getAccountNumber().getValue());

    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void test_validateSourceAccountForEnroll_invalid() {

        EligibleAccounts eligibleAccounts = populateEligibilityAccounts();

        rewardsBO.validateSourceAccountInput(eligibleAccounts, "asdsada");

    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void test_validateSourceAccountForEnroll_noEligibilityAccounts() {
        EligibleAccounts eligibleAccounts = EligibleAccounts.newInstance()
                                                            .withSourceEligibleAccounts(
                                                                            new ArrayList<RewardsEligibleAccount>())
                                                            .withTargetEligibleAccounts(
                                                                            new ArrayList<RewardsEligibleAccount>())
                                                            .withDisclaimer("XXXXXX")
                                                            .build();

        rewardsBO.validateSourceAccountInput(eligibleAccounts, "asdsada");
    }

    @Test
    public void test_validateEnrollAutoRedemptionInput_eligible() {

        EligibleAccounts eligibleAccounts = populateEligibilityAccounts();

        BankAccount input = BankAccount.newBuilder().setId("SM66666").build();

        BankAccount toAccount = rewardsBO.validateTargetAccountInput(eligibleAccounts, input);

        Assert.assertNotNull(toAccount);
        Assert.assertEquals("SM66666", toAccount.getId());
        Assert.assertEquals("123121", toAccount.getAccountNumber().getValue());
        Assert.assertEquals("ToAccount", toAccount.getNickName());

    }

    @Test
    public void testUpdateRedemptionDetails_enrolled_withRedemption()
                    throws RewardsException, RewardsAccountNotFoundException {

        List<Redemption> history = new ArrayList<Redemption>();

        history.add(Redemption.newBuilder()
                              .withRedemptionType("deposit")
                              .withAmount(BigInteger.valueOf(10))
                              .on(LocalDate.parse("2018-5-28").toDate())
                              .withToAccount(BankAccount.newBuilder()
                                                        .setAccountNumber(AccountNumber.parse(
                                                                        "ABCDEF"))
                                                        .setId("78910")
                                                        .build())
                              .build());

        // use spy in this test so we can mock getHistory() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(history).when(spyBO).getHistory(Matchers.any(String.class),
                        Matchers.any(CustomerIdentification.class), Matchers.any(Integer.class));

        List<AutoRedemptionAccount> inputAccounts = Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(true).build());

        List<AutoRedemptionAccount> output =
                        spyBO.updateRedemptionDetails(inputAccounts, customerId, null);

        Assert.assertNotNull(output);
        Assert.assertTrue(output.get(0).getIsEnrolled());
        Assert.assertTrue(output.get(0).getHasRedeemed());
        Assert.assertNotNull(output.get(0).getLastRedemptionDate());
        Assert.assertEquals(BigInteger.valueOf(10), output.get(0).getLastRedemptionAmount());
    }

    @Test
    public void testUpdateRedemptionDetails_enrolled_withRedemptionException()
                    throws RewardsException, RewardsAccountNotFoundException {

        List<Redemption> history = new ArrayList<Redemption>();

        history.add(Redemption.newBuilder()
                              .withRedemptionType("deposit")
                              .withAmount(BigInteger.valueOf(10))
                              .on(LocalDate.parse("2018-5-28").toDate())
                              .withToAccount(BankAccount.newBuilder()
                                                        .setAccountNumber(AccountNumber.parse(
                                                                        "ABCDEF"))
                                                        .setId("78910")
                                                        .build())
                              .build());

        // use spy in this test so we can mock getHistory() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doThrow(new RewardsException()).when(spyBO).getHistory(Matchers.any(String.class),
                        Matchers.any(CustomerIdentification.class), Matchers.any(Integer.class));

        List<AutoRedemptionAccount> inputAccounts = Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(true).build());

        List<AutoRedemptionAccount> output =
                        spyBO.updateRedemptionDetails(inputAccounts, customerId, null);

        Assert.assertNotNull(output);
        Assert.assertTrue(output.get(0).getIsEnrolled());
        Assert.assertFalse(output.get(0).getHasRedeemed());
    }

    @Test
    public void testUpdateRedemptionDetails_enrolled_withoutRedemption_empty()
                    throws RewardsException, RewardsAccountNotFoundException {

        // use spy in this test so we can mock getHistory() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(new ArrayList<Redemption>()).when(spyBO).getHistory(
                        Matchers.any(String.class), Matchers.any(CustomerIdentification.class),
                        Matchers.any(Integer.class));

        List<AutoRedemptionAccount> inputAccounts = Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(true).build());

        List<AutoRedemptionAccount> output =
                        spyBO.updateRedemptionDetails(inputAccounts, customerId, null);

        Assert.assertNotNull(output);
        Assert.assertTrue(output.get(0).getIsEnrolled());
        Assert.assertFalse(output.get(0).getHasRedeemed());
        Assert.assertNull(output.get(0).getLastRedemptionDate());
        Assert.assertNull(output.get(0).getLastRedemptionAmount());
    }

    @Test
    public void testUpdateRedemptionDetails_enrolled_withoutRedemption_null()
                    throws RewardsException, RewardsAccountNotFoundException {

        // use spy in this test so we can mock getHistory() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(null).when(spyBO).getHistory(Matchers.any(String.class),
                        Matchers.any(CustomerIdentification.class), Matchers.any(Integer.class));

        List<AutoRedemptionAccount> inputAccounts = Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(true).build());

        List<AutoRedemptionAccount> output =
                        spyBO.updateRedemptionDetails(inputAccounts, customerId, null);

        Assert.assertNotNull(output);
        Assert.assertTrue(output.get(0).getIsEnrolled());
        Assert.assertFalse(output.get(0).getHasRedeemed());
        Assert.assertNull(output.get(0).getLastRedemptionDate());
        Assert.assertNull(output.get(0).getLastRedemptionAmount());
    }

    @Test
    public void testUpdateRedemptionDetails_notEnrolled_withBalance()
                    throws RewardsAccountNotFoundException {

        // use spy in this test so we can mock getAccountById() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(MockAccountBuilder.newCheckingAccountBuilder().build())
               .when(spyBO)
               .getAccountById(Matchers.anyList(), Matchers.anyString());

        RewardsAccount rewardsAccount =
                        new RewardsAccount(MockAccountBuilder.newCheckingAccountBuilder().build());
        rewardsAccount.setRewardsBalance(
                        RewardsBalance.initialize()
                                      .withAvailableBalance(BigInteger.valueOf(10))
                                      .withCurrentBalance(BigInteger.valueOf(5))
                                      .build());

        Mockito.doReturn(rewardsAccount)
               .when(spyBO)
               .populateRewardAccountBalance(Matchers.any(RewardsAccount.class));

        List<AutoRedemptionAccount> inputAccounts = Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(false).build());

        List<AutoRedemptionAccount> output =
                        spyBO.updateRedemptionDetails(inputAccounts, customerId, null);

        Assert.assertNotNull(output);
        Assert.assertFalse(output.get(0).getIsEnrolled());
        Assert.assertNull(output.get(0).getHasRedeemed());
        Assert.assertNull(output.get(0).getLastRedemptionDate());
        Assert.assertNull(output.get(0).getLastRedemptionAmount());
        Assert.assertEquals(BigInteger.valueOf(10), output.get(0).getRewardsBalance());
    }

    @Test
    public void testUpdateRedemptionDetails_notEnrolled_withBalanceException()
                    throws RewardsAccountNotFoundException {

        // use spy in this test so we can mock getAccountById() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doThrow(new RewardsAccountNotFoundException())
               .when(spyBO)
               .getAccountById(Matchers.anyList(), Matchers.anyString());

        RewardsAccount rewardsAccount =
                        new RewardsAccount(MockAccountBuilder.newCheckingAccountBuilder().build());
        rewardsAccount.setRewardsBalance(
                        RewardsBalance.initialize()
                                      .withAvailableBalance(BigInteger.valueOf(10))
                                      .withCurrentBalance(BigInteger.valueOf(5))
                                      .build());

        Mockito.doReturn(rewardsAccount)
               .when(spyBO)
               .populateRewardAccountBalance(Matchers.any(RewardsAccount.class));

        List<AutoRedemptionAccount> inputAccounts = Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(false).build());

        List<AutoRedemptionAccount> output =
                        spyBO.updateRedemptionDetails(inputAccounts, customerId, null);

        Assert.assertNotNull(output);
        Assert.assertFalse(output.get(0).getIsEnrolled());
        Assert.assertNull(output.get(0).getHasRedeemed());
        Assert.assertNull(output.get(0).getLastRedemptionDate());
        Assert.assertNull(output.get(0).getLastRedemptionAmount());
        Assert.assertNull(output.get(0).getRewardsBalance());
    }

    @Test
    public void testUpdateRedemptionDetails_notEnrolled_nullBalance()
                    throws RewardsAccountNotFoundException {

        // use spy in this test so we can mock getAccountById() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(MockAccountBuilder.newCheckingAccountBuilder().build())
               .when(spyBO)
               .getAccountById(Matchers.anyList(), Matchers.anyString());

        RewardsAccount rewardsAccount =
                        new RewardsAccount(MockAccountBuilder.newCheckingAccountBuilder().build());
        rewardsAccount.setRewardsBalance(null);

        Mockito.doReturn(rewardsAccount)
               .when(spyBO)
               .populateRewardAccountBalance(Matchers.any(RewardsAccount.class));

        List<AutoRedemptionAccount> inputAccounts = Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(false).build());

        List<AutoRedemptionAccount> output =
                        spyBO.updateRedemptionDetails(inputAccounts, customerId, null);

        Assert.assertNotNull(output);
        Assert.assertFalse(output.get(0).getIsEnrolled());
        Assert.assertNull(output.get(0).getHasRedeemed());
        Assert.assertNull(output.get(0).getLastRedemptionDate());
        Assert.assertNull(output.get(0).getLastRedemptionAmount());
        Assert.assertNull(output.get(0).getRewardsBalance());
    }

    @Test
    public void testGetAutoRedemptionAccountsStatus_NoAccountId() {

        List<AutoRedemptionAccount> output = rewardsBO.getAutoRedemptionAccountsStatus(customerId,
                        new ArrayList<String>());

        Assert.assertEquals(0, output.size());
    }

    @Test
    public void testGetAutoRedemptionAccountsStatus_NullAccountId() {

        List<AutoRedemptionAccount> output =
                        rewardsBO.getAutoRedemptionAccountsStatus(customerId, null);

        Assert.assertEquals(0, output.size());
    }

    @Test
    public void testGetAutoRedemptionAccountsStatus_InvalidAccount() throws RewardsException {

        List<BankAccount> accounts = new ArrayList<BankAccount>();

        accounts.add(BankAccount.newBuilder(MockAccountBuilder.newCheckingAccountBuilder().build())
                                .setAlternateAccountNumber("SM12345")
                                .build());
        accounts.add(BankAccount.newBuilder(MockAccountBuilder.newSavingsAccountBuilder().build())
                                .setAlternateAccountNumber("SM23456")
                                .build());

        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(populateEligibilityAccounts()).when(spyBO).getEligibleAccounts(
                        Matchers.any(CustomerIdentification.class), Matchers.anyString());

        List<AutoRedemptionAccount> output =
                        spyBO.getAutoRedemptionAccountsStatus(customerId, Arrays.asList("SM7890"));

        Assert.assertNotNull(output);
        Assert.assertTrue(output.get(0).getError());
        Assert.assertEquals("Account doesn't exist or doesn't belong to the customer",
                        output.get(0).getErrorDescription());
    }

    @Test
    public void testGetAutoRedemptionAccountsStatus_OneChecking()
                    throws RewardsException, RewardsAccountNotFoundException {

        List<BankAccount> accounts = new ArrayList<BankAccount>();

        accounts.add(BankAccount.newBuilder(MockAccountBuilder.newCheckingAccountBuilder().build())
                                .setAlternateAccountNumber("SM12345")
                                .build());
        accounts.add(BankAccount.newBuilder(MockAccountBuilder.newSavingsAccountBuilder().build())
                                .setAlternateAccountNumber("SM23456")
                                .build());

        Mockito.when(accountManager.findCustomerAccounts(
                        Matchers.any(CustomerIdentification.class)))
               .thenReturn(accounts);

        AutoRedemptionAccount autoRedemptionAccount = AutoRedemptionAccount.getBuilder()
                                                                           .withId("SM12345")
                                                                           .withNickName("Cashback Debit Account Ending 1589")
                                                                           .withLastRedemptionAmount(
                                                                                           BigInteger.valueOf(
                                                                                                           10))
                                                                           .withLastRedemptionDate(
                                                                                           LocalDate.parse("2018-5-28")
                                                                                                    .toDate())
                                                                           .withHasRedeemed(true)
                                                                           .withIsEnrolled(true)
                                                                           .withAccountNumber(
                                                                                           AccountNumber.parse(
                                                                                                           "123456"))
                                                                           .build();

        Mockito.when(autoRedemptionRepository.getAutoRedemptionAccountsStatus(
                        Matchers.any(CustomerIdentification.class),
                        Matchers.any(EnrollmentDetailsInput.class), Matchers.anyList()))
               .thenReturn(Arrays.asList(autoRedemptionAccount));

        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(Arrays.asList(autoRedemptionAccount)).when(spyBO).updateRedemptionDetails(
                        Matchers.anyList(), Matchers.any(CustomerIdentification.class),
                        Matchers.anyList());

        Mockito.doReturn(BankAccount.newBuilder()
                                    .setId("SM12345")
                                    .setAccountNumber(AccountNumber.parse("123456"))
                                    .build())
               .when(spyBO)
               .findMatchingAccount(Matchers.anyList(), Matchers.anyString());


        List<AutoRedemptionAccount> output =
                        spyBO.getAutoRedemptionAccountsStatus(customerId, Arrays.asList("SM12345"));

        assertNotNull(output);
        assertEquals(1, output.size());
        assertTrue(output.get(0).getIsEnrolled());
        assertEquals("3456", output.get(0).getAccountNumber().getEnding());
        assertEquals("123456", output.get(0).getAccountNumber().getFormattedValue());
        assertEquals("SM12345", output.get(0).getId());
        assertEquals("Cashback Debit Account Ending 1589", output.get(0).getNickName());
        assertEquals(new BigInteger("10"), output.get(0).getLastRedemptionAmount());
    }    

    @Test
    public void testGetAutoRedemption() {

        CustomerIdentification customerIdentification = null;
        rewardsBO = new RewardsBusinessObject();
        AutoRedemptionResponse result = rewardsBO.getAutoRedemption(customerIdentification, "0");

        Assert.assertNotNull(result);
        Assert.assertEquals(false, result.getIsEnrolled());
    }
    
    @Test
    public void testEditAutoRedemption_Success() throws RewardsException {

        EnrollEditAutoRedemption input =
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM78631")
                                                                          .build())
                                                .build();

        EligibleAccounts eligibilityAccounts = populateEligibilityAccounts();

        // use spy in this test so we can mock getEligibleAccounts() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(Arrays.asList(AutoRedemptionAccount.getBuilder()
                                                            .withId("SM4444")
                                                            .withToAccount(MockAccountBuilder.newSavingsAccountBuilder()
                                                                                             .build())
                                                            .withIsEnrolled(true)
                                                            .build()))
               .when(spyBO)
               .getValidateAutoRedemptionAccounts(Matchers.any(CustomerIdentification.class),
                               Matchers.anyList(), Matchers.anyList());


        Mockito.doReturn(eligibilityAccounts).when(spyBO).getEligibleAccounts(customerId, "auto");

        EditAutoRedemptionResponse result = spyBO.editAutoRedemption(customerId, "SM12345", input);

        Mockito.verify(autoRedemptionRepository, times(1)).enrollOrEditAutoRedemption(
                        Matchers.any(CustomerIdentification.class), Matchers.anyString(),
                        Matchers.anyString(), Matchers.anyString());

        Assert.assertNotNull(result);
        Assert.assertEquals("SM78631", result.getToAccount().getId());
        Assert.assertEquals("SM12345", result.getFromAccount().getId());
    }

    @Test
    public void testEditAutoRedemption_SuccessSameToAccount() throws RewardsException {

        EnrollEditAutoRedemption input =
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM66666")
                                                                          .build())
                                                .build();

        EligibleAccounts eligibilityAccounts = populateEligibilityAccounts();

        // use spy in this test so we can mock getEligibleAccounts() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(Arrays.asList(
                        AutoRedemptionAccount.getBuilder()
                                             .withId("SM12345")
                                             .withToAccount(BankAccount.newBuilder(
                                                             MockAccountBuilder.newSavingsAccountBuilder()
                                                                               .build())
                                                                       .setId("SM66666")
                                                                       .build())
                                             .withIsEnrolled(true)
                                             .build()))
               .when(spyBO)
               .getValidateAutoRedemptionAccounts(Matchers.any(CustomerIdentification.class),
                               Matchers.anyList(), Matchers.anyList());

        Mockito.doReturn(eligibilityAccounts).when(spyBO).getEligibleAccounts(customerId, "auto");

        EditAutoRedemptionResponse result = spyBO.editAutoRedemption(customerId, "SM12345", input);

        Mockito.verify(autoRedemptionRepository, times(0)).enrollOrEditAutoRedemption(
                        Matchers.any(CustomerIdentification.class), Matchers.anyString(),
                        Matchers.anyString(), Matchers.anyString());

        Assert.assertNotNull(result);
        Assert.assertEquals("SM66666", result.getToAccount().getId());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEditAutoRedemption_NotEnrolled() throws RewardsException {

        List<BankAccount> accounts = new ArrayList<BankAccount>();

        accounts.add(BankAccount.newBuilder(MockAccountBuilder.newCheckingAccountBuilder().build())
                                .setAlternateAccountNumber("SM12345")
                                .build());
        accounts.add(BankAccount.newBuilder(MockAccountBuilder.newSavingsAccountBuilder().build())
                                .setAlternateAccountNumber("SM66666")
                                .build());
        accounts.add(BankAccount.newBuilder(MockAccountBuilder.newSavingsAccountBuilder().build())
                                .setAlternateAccountNumber("SM78631")
                                .build());

        AutoRedemptionAccount autoRedemptionAccount = AutoRedemptionAccount.getBuilder()
                                                                           .withId("SM12345")
                                                                           .withToAccount(BankAccount.newBuilder(
                                                                                           MockAccountBuilder.newSavingsAccountBuilder()
                                                                                                             .build())
                                                                                                     .setAlternateAccountNumber(
                                                                                                                     "SM66666")
                                                                                                     .build())
                                                                           .withIsEnrolled(false)
                                                                           .withAccountNumber(
                                                                                           AccountNumber.parse(
                                                                                                           "123456"))
                                                                           .build();

        EnrollEditAutoRedemption input =
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM78631")
                                                                          .build())
                                                .build();

        EligibleAccounts eligibilityAccounts = populateEligibilityAccounts();

        // use spy in this test so we can mock getEligibleAccounts() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(Arrays.asList(autoRedemptionAccount))
               .when(spyBO)
               .getAutoRedemptionAccountsStatus(customerId, Arrays.asList("SM12345"));

        Mockito.doReturn(eligibilityAccounts).when(spyBO).getEligibleAccounts(customerId, "auto");

        spyBO.editAutoRedemption(customerId, "SM12345", input);
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testEditAutoRedemption_NullEligibleAccounts() throws RewardsException {

        EnrollEditAutoRedemption input =
                        EnrollEditAutoRedemption.newBuilder()
                                                .withToAccount(BankAccount.newBuilder()
                                                                          .setId("SM78631")
                                                                          .build())
                                                .build();

        // use spy in this test so we can mock getEligibleAccounts() response
        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(null).when(spyBO).getEligibleAccounts(customerId, "auto");

        spyBO.editAutoRedemption(customerId, "SM12345", input);
    }

    @Test
    public void testDeleteAutoRedemptionSuccess_alreadyEnrolled() {

        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(BankAccount.newBuilder()
                                    .setId("SM12345")
                                    .setAccountNumber(AccountNumber.parse("123456"))
                                    .build())
               .when(spyBO)
               .findMatchingAccount(Matchers.anyList(), Matchers.anyString());

        Mockito.doReturn(Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(true).build()))
               .when(spyBO)
               .getValidateAutoRedemptionAccounts(Matchers.any(CustomerIdentification.class),
                               Matchers.anyList(), Matchers.anyList());

        Mockito.doNothing().when(autoRedemptionRepository).deleteAutoRedemption(
                        Matchers.any(CustomerIdentification.class),
                        Matchers.any(AutoRedemptionAccount.class));

        AutoRedemptionResponse result = spyBO.deleteAutoRedemption(customerId, "SM12345");

        Mockito.verify(autoRedemptionRepository).deleteAutoRedemption(
                        Matchers.any(CustomerIdentification.class),
                        Matchers.any(AutoRedemptionAccount.class));

        Assert.assertNotNull(result);
        Assert.assertEquals("Auto-Redeem to Savings is disabled.",
                        result.getMessage());
    }

    @Test
    public void testDeleteAutoRedemptionSuccess_Unenrolled() {

        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(Arrays.asList(
                        AutoRedemptionAccount.getBuilder().withIsEnrolled(false).build()))
               .when(spyBO)
               .getValidateAutoRedemptionAccounts(Matchers.any(CustomerIdentification.class),
                               Matchers.anyList(), Matchers.anyList());

        Mockito.doNothing().when(autoRedemptionRepository).deleteAutoRedemption(
                        Matchers.any(CustomerIdentification.class),
                        Matchers.any(AutoRedemptionAccount.class));

        Mockito.doReturn(BankAccount.newBuilder()
                                    .setId("SM12345")
                                    .setAccountNumber(AccountNumber.parse("123456"))
                                    .build())
               .when(spyBO)
               .findMatchingAccount(Matchers.anyList(), Matchers.anyString());

        AutoRedemptionResponse result = spyBO.deleteAutoRedemption(customerId, "SM12345");

        Assert.assertNotNull(result);
        Assert.assertEquals("Auto-Redeem to Savings is disabled.",
                        result.getMessage());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testDeleteAutoRedemptionFailed_alreadyEnrolled() throws RewardsException {

        RewardsBusinessObject spyBO = Mockito.spy(rewardsBO);

        Mockito.doReturn(populateEligibilityAccounts()).when(spyBO).getEligibleAccounts(
                        Matchers.any(CustomerIdentification.class), Matchers.anyString());

        spyBO.deleteAutoRedemption(customerId, "0");
    }

    private EligibleAccounts populateEligibilityAccounts() {
        BankAccount sourceAccount =
                        BankAccount.newBuilder()
                                   .setStatus(AccountStatus.ACTIVE)
                                   .setAccountNumber(AccountNumber.parse("8675309"))
                                   .setId("SM12345")
                                   .defineDepositAccount(AccountProduct.of("CAGEN", "002"))
                                   .build();

        BankAccount targetAccount1 =
                        BankAccount.newBuilder()
                                   .setStatus(AccountStatus.ACTIVE)
                                   .setAccountNumber(AccountNumber.parse("123121"))
                                   .setNickName("ToAccount")
                                   .setId("SM66666")
                                   .defineDepositAccount(AccountProduct.of("SBSTD", "001"))
                                   .build();

        BankAccount targetAccount2 =
                        BankAccount.newBuilder()
                                   .setStatus(AccountStatus.ACTIVE)
                                   .setAccountNumber(AccountNumber.parse("123342"))
                                   .setNickName("ToAccount2")
                                   .setId("SM78631")
                                   .defineDepositAccount(AccountProduct.of("SBSTD", "001"))
                                   .build();

        List<RewardsEligibleAccount> sourceRedemptionAccounts =
                        new ArrayList<RewardsEligibleAccount>();
        sourceRedemptionAccounts.add(new RewardsEligibleAccount(sourceAccount));

        List<RewardsEligibleAccount> targetRedemptionAccounts =
                        new ArrayList<RewardsEligibleAccount>();
        targetRedemptionAccounts.add(new RewardsEligibleAccount(targetAccount1));
        targetRedemptionAccounts.add(new RewardsEligibleAccount(targetAccount2));

        return EligibleAccounts.newInstance()
                               .withSourceEligibleAccounts(sourceRedemptionAccounts)
                               .withTargetEligibleAccounts(targetRedemptionAccounts)
                               .withDisclaimer("erwrwrqwrq")
                               .build();

    }

    @Test
    public void testGetValidateAutoRedemptionAccounts_Success() {

        Mockito.when(autoRedemptionRepository.getAutoRedemptionAccountsStatus(
                        Matchers.any(CustomerIdentification.class),
                        Matchers.any(EnrollmentDetailsInput.class), Matchers.anyList()))
               .thenReturn(Arrays.asList(AutoRedemptionAccount.getBuilder().build()));

        List<AutoRedemptionAccount> output = rewardsBO.getValidateAutoRedemptionAccounts(customerId,
                        Arrays.asList("71456231"), new ArrayList<BankAccount>());

        assertNotNull(output);
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testGetValidateAutoRedemptionAccounts_Null() {

        Mockito.when(autoRedemptionRepository.getAutoRedemptionAccountsStatus(
                        Matchers.any(CustomerIdentification.class),
                        Matchers.any(EnrollmentDetailsInput.class), Matchers.anyList()))
               .thenReturn(null);

        rewardsBO.getValidateAutoRedemptionAccounts(customerId, Arrays.asList("71456231"),
                        new ArrayList<BankAccount>());
    }

    @Test(expected = UnrecoverableRedemptionException.class)
    public void testGetValidateAutoRedemptionAccounts_Empty() {

        Mockito.when(autoRedemptionRepository.getAutoRedemptionAccountsStatus(
                        Matchers.any(CustomerIdentification.class),
                        Matchers.any(EnrollmentDetailsInput.class), Matchers.anyList()))
               .thenReturn(new ArrayList<AutoRedemptionAccount>());

        rewardsBO.getValidateAutoRedemptionAccounts(customerId, Arrays.asList("71456231"),
                        new ArrayList<BankAccount>());
    }

    @Test
    public void testFindMatchingAccount() {

        List<BankAccount> customerAccounts = new ArrayList<BankAccount>();
        customerAccounts.add(BankAccount
                                        .newBuilder(MockAccountBuilder.newCheckingAccountBuilder()
                                                                      .build())
                                        .setId("SM12345")
                                        .build());

        customerAccounts.add(BankAccount
                                        .newBuilder(MockAccountBuilder.newCheckingAccountBuilder()
                                                                      .build())
                                        .setId("SM23456")
                                        .build());

        BankAccount output = rewardsBO.findMatchingAccount(customerAccounts, "SM12345");

        assertNotNull(output);
        assertEquals("SM12345", output.getId());

        output = rewardsBO.findMatchingAccount(customerAccounts, "SM3456");

        assertNull(output);
    }

    @Test
    public void testConvertRewardsEligibleAccountToBankAccount() {

        List<BankAccount> output = rewardsBO.convertRewardsTargetEligibleAccountToBankAccount(
                        Arrays.asList(new RewardsEligibleAccount(
                                        MockAccountBuilder.newSavingsAccountBuilder().build())));

        assertNotNull(output);
        assertEquals("0", output.get(0).getId());
        assertEquals("1029321589", output.get(0).getAccountNumber().getValue());
    }
}
