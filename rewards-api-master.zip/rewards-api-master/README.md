# rewards-api

[![Build Status](https://jenkm1.discoverfinancial.com:8443/buildStatus/icon?job=digital-bank-org/rewards-api)](https://jenkm1.discoverfinancial.com:8443/job/digital-bank-org/job/rewards-api/)
[![Coverage](http://git-badges.cfd2.discoverfinancial.com/badges/sonar/coverage?id=com.discover.internet.bank%3Arewards)](https://sonarqube.discoverfinancial.com:8443/dashboard/index?id=com.discover.internet.bank%3Arewards)
[![Test Success](http://git-badges.cfd2.discoverfinancial.com/badges/sonar/testSuccess?id=com.discover.internet.bank%3Arewards)](https://sonarqube.discoverfinancial.com:8443/dashboard/index?id=com.discover.internet.bank%3Arewards)
[![Debt](http://git-badges.cfd2.discoverfinancial.com/badges/sonar/debt?id=com.discover.internet.bank%3Arewards)](https://sonarqube.discoverfinancial.com:8443/dashboard/index?id=com.discover.internet.bank%3Arewards)
[![LOC](http://git-badges.cfd2.discoverfinancial.com/badges/sonar/custom?id=com.discover.internet.bank%3Arewards&color=blue)](https://sonarqube.discoverfinancial.com:8443/dashboard/index?id=com.discover.internet.bank%3Arewards)
