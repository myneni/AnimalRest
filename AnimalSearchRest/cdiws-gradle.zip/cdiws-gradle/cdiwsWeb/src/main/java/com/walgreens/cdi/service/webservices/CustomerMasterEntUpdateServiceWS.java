/*
 * This is an auto-generated class for the service object. Please do not modify this class.
*/
package com.walgreens.cdi.service.webservices;

import javax.jws.WebResult;
import javax.jws.WebService;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.CDIExceptionFault;
import com.walgreens.cdi.exception.CDIException_Exception;
//As a part of WAS Migration Changes are in the new parameters addition for the @WebService tag, the new @SoapBinding tag, 
//and  replacing the @WebResult tag in the called methods with @WebMethod tags.
@WebService (targetNamespace="http://webservices.service.cdi.walgreens.com/", 
serviceName="CustomerMasterEntUpdateServiceWSService", 
portName="CustomerMasterEntUpdateServiceWSPort", 
wsdlLocation="WEB-INF/WSDL/CustomerMasterEntUpdateServiceWSService.wsdl")
@javax.jws.soap.SOAPBinding(style = javax.jws.soap.SOAPBinding.Style.DOCUMENT)
@javax.jws.HandlerChain(file="/WSHandlerChain.xml")
public class CustomerMasterEntUpdateServiceWS{
    private com.walgreens.cdi.service.impl.CustomerMasterEntUpdateService _service = null;

    @javax.jws.WebMethod(exclude=true)
    private com.walgreens.cdi.service.impl.CustomerMasterEntUpdateService getService() {
             _service = (com.walgreens.cdi.service.impl.CustomerMasterEntUpdateService)walgreens.utils.ioc.BeanFactoryUtil.getFactory().getBean("customerMasterEntUpdateService");
        return _service;
    }

    @WebResult(name = "updateCustomerMasterEntResponse", targetNamespace = "")	
    public @javax.jws.WebMethod com.walgreens.cdi.vo.CustomerMasterEntUpdateResponse updateCustomerMasterEnt(com.walgreens.cdi.vo.CustomerMasterEntUpdateRequest arg0) throws com.walgreens.cdi.exception.CDIException_Exception{
    	try{
    	return getService().updateCustomerMasterEnt( arg0);
    	}catch (CDIException e) {
    		CDIExceptionFault fault = new CDIExceptionFault();
			fault.setErrorCode(e.getErrorCode());
			fault.setDetailMessage(e.getDetailMessage());
			
			fault.setMsg(e.getMsg());
			throw new CDIException_Exception(e.getMessage(), fault);
    	}
    }
}
