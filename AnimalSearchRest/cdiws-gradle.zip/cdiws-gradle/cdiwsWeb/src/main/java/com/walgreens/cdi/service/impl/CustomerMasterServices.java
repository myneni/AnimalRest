/**
 * 
 */
package com.walgreens.cdi.service.impl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterGetRequest;
import com.walgreens.cdi.vo.CustomerMasterLookUpRequest;
import com.walgreens.cdi.vo.CustomerMasterMergeRequest;
import com.walgreens.cdi.vo.CustomerMasterUpdateRequest;
import com.walgreens.cdi.bo.ICustomerMasterGetBO;
import com.walgreens.cdi.bo.ICustomerMasterLookUpBO;
import com.walgreens.cdi.bo.ICustomerMasterMergeBO;
import com.walgreens.cdi.bo.ICustomerMasterUpdateBO;
import com.walgreens.cdi.exception.BaseException;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.vo.customer.ArrayOfCustomer;



/**
 * @author Picketta
 *
 */
public class CustomerMasterServices extends BaseService{
/*
	public ArrayOfCustomer lookupCustomerMaster(CustomerMasterLookUpRequest cdiSearchRequest){
		com.walgreens.cdi.service.impl.CustomerMasterLookUpService customerServices = new com.walgreens.cdi.service.impl.CustomerMasterLookUpService();
		return customerServices.lookUpCustomerMaster(cdiSearchRequest);
	}
	
	public ArrayOfCustomer getCustomerMaster(CustomerMasterGetRequest cdiRetrieveRequest){
		com.walgreens.cdi.service.impl.CustomerMasterGetService customerServices = new com.walgreens.cdi.service.impl.CustomerMasterGetService();
		return customerServices.getCustomerMaster(cdiRetrieveRequest);
	}
*/	
	
	private ICustomerMasterLookUpBO customerMasterLookUpBO;
	private ICustomerMasterGetBO customerMasterGetBO;
	private ICustomerMasterUpdateBO customerMasterUpdateBO;
	private ICustomerMasterMergeBO customerMasterMergeBO;
	
	public ArrayOfCustomer lookUpCustomerMaster(CustomerMasterLookUpRequest customerMasterLookUpRequest) throws CDIException,BaseException,Exception {
		
		try{
			//System.out.println("Start Calling CustomerMasterServices::lookUpCustomerMaster() method");
			return getcustomerMasterLookUpBO().lookUpCustomerMaster(customerMasterLookUpRequest);
		} catch (CDIException e) {
            //e.printStackTrace();
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return null;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
	}
	

	public ArrayOfCustomer getCustomerMaster(CustomerMasterGetRequest customerMasterGetRequest) throws CDIException{
		try{
			//System.out.println("Start calling CustomerMasterServices::getCustomerMaster() method");
			return getcustomerMasterGetBO().getCustomerMaster(customerMasterGetRequest);
		} catch (CDIException e) {
            //e.printStackTrace();
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return null;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
	}
	
public boolean updateCustomerMaster(CustomerMasterUpdateRequest customerMasterUpdateRequest) throws CDIException,BaseException,Exception {
		try{
			//System.out.println("Start Calling CustomerMasterServices::updateCustomerMaster() method");
			return  getcustomerMasterUpdateBO().updateCustomerMaster(customerMasterUpdateRequest);
		} catch (CDIException e) {
            //e.printStackTrace();
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return false;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
	}

	public boolean mergeCustomerMaster(CustomerMasterMergeRequest customerMasterMergeRequest) throws CDIException, Exception {
		try{
			//System.out.println("Start Calling CustomerMasterServices::mergeCustomerMaster() method");
			return 	getcustomerMasterMergeBO().mergeCustomerMaster(customerMasterMergeRequest);
		} catch (CDIException e) {
            //e.printStackTrace();
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return false;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
		
		
	}
	
	public ICustomerMasterMergeBO getcustomerMasterMergeBO() {
		return customerMasterMergeBO;
	}


	/**
	 * @param searchBO the searchBO to set
	 */
	public void setCustomerMasterMergeBO(ICustomerMasterMergeBO customerMasterMergeBO) {
		this.customerMasterMergeBO = customerMasterMergeBO;
	}
	

	/**
	 * @return the customerMasterUpdateBO
	 */
	public ICustomerMasterUpdateBO getcustomerMasterUpdateBO() {
		return customerMasterUpdateBO;
	}


	/**
	 * @param customerMasterUpdateBO set to the customerMasterUpdateBO 
	 */
	public void setCustomerMasterUpdateBO(ICustomerMasterUpdateBO customerMasterUpdateBO) {
		this.customerMasterUpdateBO = customerMasterUpdateBO;
	}

		/**
		 * @return the customerMasterGetBO
		 */
		public ICustomerMasterGetBO getcustomerMasterGetBO() {
			return customerMasterGetBO;
		}
		public void setCustomerMasterGetBO(ICustomerMasterGetBO customerMasterGetBO) {
				this.customerMasterGetBO = customerMasterGetBO;
		}

		/**
		 * @return the customerMasterLookUpBO
		 */
		public ICustomerMasterLookUpBO getcustomerMasterLookUpBO() {
			return customerMasterLookUpBO;
		}

		/**
		 * @param customerMasterLookUpBO set to the customerMasterLookUpBO 
		 */
		public void setCustomerMasterLookUpBO(ICustomerMasterLookUpBO customerMasterLookUpBO) {
			this.customerMasterLookUpBO = customerMasterLookUpBO;
		}
		

	
	
	
	
	public static void main(String[] args) {
		
		String[] springFile = { "classpath*:bounce.xml" };
		ApplicationContext context = new ClassPathXmlApplicationContext(
				springFile);
			
		CustomerMasterServices  myServices= (CustomerMasterServices) context
		.getBean("customerMasterServices");
		
		//System.out.println("22222222222222");
		// to test Authentication Service
		//authenticateService.getAuthenticate("wgreens", "wgreens");	
		//System.out.println("XXXX....AUTHENTICATED....XXXX");
		//to test search Service ....
		CustomerMasterUpdateRequest sendBuffer = populateSendBuffer(10);
		//System.out.println("Size = 1");
		try{
			
			//System.out.println("333333333333333333");
			myServices.updateCustomerMaster(sendBuffer);
			//System.out.println("record inserted");
		}
		catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		
		
		//CustomerMasterGetRequest sendBuffer = new CustomerMasterGetRequest();
		//sendBuffer.setCustSourceCode("IC");
		//sendBuffer.setCustSourceID("1");
		//sendBuffer.setCustEID("51923");
		//sendBuffer.setCustSourceCode("EC");
		//sendBuffer.setCustSourceID("406363303");
		
		/*CustomerMasterLookUpRequest sendBuffer = new CustomerMasterLookUpRequest();
		sendBuffer.setUsrSourceCode("IC");
		sendBuffer.setCustFirstName("vijay");
		sendBuffer.setCustLastName("reddy");
		sendBuffer.setMinMatchScore("1");*/
		
		
		
	/*	
		try{
			
			//ArrayOfCustomer tt= myServices.getCustomerMaster(sendBuffer);
			ArrayOfCustomer tt= myServices.lookUpCustomerMaster(sendBuffer);
			CustomerMasterResponse[] abcd = tt.getItem();
			System.out.println("Got the GETCustomer result ..."+abcd.toString()+ " : " + abcd.length);
		
			System.out.println("\n***************************CustomerGetService Result***********************\n");
			   for (int i=0; i<abcd.length; i++)
			   {
				   String aa= abcd[i].getCdiCustomer().toString();
				   System.out.println("\n##########################Customer : "  + i + " ########################\n " +aa);
			   }
			
		}
		catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}*/
	
	}
	
	public static CustomerMasterUpdateRequest populateSendBuffer(int level){
		CustomerMasterUpdateRequest sendBuffer = new CustomerMasterUpdateRequest();
		
		
		sendBuffer.setSrcCode("IC");
		sendBuffer.setSrcIdNum("987654321");
		
		// Set Name		
		sendBuffer.setNameFirst("Antoine");
		sendBuffer.setNameLast("Pickett");
		sendBuffer.setNameMiddle("D");
		sendBuffer.setNamePrefix("Mr");
		sendBuffer.setNameSuffix("Jr");
		
		// Set Gender
		sendBuffer.setGender("M");
		
		// Set Last Update Date
		//sendBuffer.setLastUpdateDate("2009\-06\-22 12:34:56");
		//sendBuffer.setLastUpdateDate("");
		sendBuffer.setLastUpdateDate("1990-06-22 07:10:10 AM");
		//sendBuffer.setLastUpdateDate("2009/06/22 12:34:56");
		//sendBuffer.setLastUpdateDate("2009\06\22 12:34:56");
		//sendBuffer.setLastUpdateDate("2009\\06\\22 12:34:56");
		//sendBuffer.setLastUpdateDate("06/22/2009");
		//sendBuffer.setLastUpdateDate("06-22-2009");
		
		
		// Set Pet Indicator
		sendBuffer.setPetInd("N");
		
		// Set Deceased Indicator
		sendBuffer.setDeceasedInd(null);
		
		// Set SEC Code
		sendBuffer.setSecCode("");
		
		// Set Email
		sendBuffer.setEmail("Test@email.com");
		
		// Set ECICMEMID
		sendBuffer.setEcicMemId("");
		
		// Set PCECMEMID
		sendBuffer.setPcecMemId("");
		
		// Set locked Indicator
		sendBuffer.setLockInd(null);
		
		// Set trust Id
		
		
		// Set birthdate
		sendBuffer.setBDate("1980-06-19");
		
		// Set Cust origin
		sendBuffer.setOrigin(null);
		sendBuffer.setOriginStoreInd(null);
		
		// Set Patient Insurance info
		
		// Set HOH ID & Relationship
		sendBuffer.setHohId("");
		sendBuffer.setHohRelateCode("");
		
		// Set Primary Address
		sendBuffer.setAddrStLine1("200 overlook point");
		sendBuffer.setAddrStLine2("4N");		
		sendBuffer.setAddrCity("lincolnshire");
		sendBuffer.setAddrState("illinois");
		sendBuffer.setAddrZip("60015");
		sendBuffer.setAddrCountry("US");
		sendBuffer.setAddrType("");
		sendBuffer.setAddrDpvFtNote("");
		sendBuffer.setAddrDpvInd("");
		sendBuffer.setAddrCassFtNote("");
		sendBuffer.setAddrLatitude("");
		sendBuffer.setAddrLongitude("");
		sendBuffer.setAddrStndrdPrDate("");
		sendBuffer.setAddrUrbCode("");
		sendBuffer.setAddrLacsFlag("");
		sendBuffer.setAddrLacsFtnote("");
		sendBuffer.setAddrLacsRtrnCode("");
		sendBuffer.setAddrNcoaStLine1("20 overlook point");
		sendBuffer.setAddrNcoaStLine2("40N");
		sendBuffer.setAddrNcoaCity("lincolnshire");
		sendBuffer.setAddrNcoaState("IL");
		sendBuffer.setAddrNcoaZip("60015");
		sendBuffer.setAddrNcoaType("");
		sendBuffer.setAddrNcoaActCode("");
		sendBuffer.setAddrNcoaAnkCode("");
		sendBuffer.setAddrNcoaMvDate("");
		sendBuffer.setAddrNcoaMvType("");
		sendBuffer.setAddrNcoaNewFlag("");
		sendBuffer.setAddrNcoaNixFtNote("");
		sendBuffer.setAddrNcoaPrDate("");
		sendBuffer.setAddrNcoaRtrnCode("");
		sendBuffer.setAddrNcoaUrbCode("");
		
		if(level > 1){
		
		// Set Secondary Address
		sendBuffer.setAddr2StLine1("300 Wilmot Rd");
		sendBuffer.setAddr2StLine2("4");
		sendBuffer.setAddr2City("Deerfield");
		sendBuffer.setAddr2State("IL");
		sendBuffer.setAddr2Zip("60015");
		sendBuffer.setAddr2Country("US");
		sendBuffer.setAddr2Type("");
		sendBuffer.setAddr2DpvFtNote("");
		sendBuffer.setAddr2DpvInd("");
		sendBuffer.setAddr2CassFtNote("");
		sendBuffer.setAddr2Latitude("");
		sendBuffer.setAddr2Longitude("");
		sendBuffer.setAddr2StndrdPrDate("");
		sendBuffer.setAddr2UrbCode("");
		sendBuffer.setAddr2LacsFlag("");
		sendBuffer.setAddr2LacsFtnote("");
		sendBuffer.setAddr2LacsRtrnCode("");
		
		// Set Work Address
		sendBuffer.setAddrWkStLine1("2 Overlook pt");
		sendBuffer.setAddrWkStLineWk("4n");
		sendBuffer.setAddrWkCity("lincolnshire");
		sendBuffer.setAddrWkState("Il");
		sendBuffer.setAddrWkZip("60015");
		sendBuffer.setAddrWkCountry("US");
		sendBuffer.setAddrWkType("");
		sendBuffer.setAddrWkDpvFtNote("");
		sendBuffer.setAddrWkDpvInd("");
		sendBuffer.setAddrWkCassFtNote("");
		sendBuffer.setAddrWkLatitude("");
		sendBuffer.setAddrWkLongitude("");
		sendBuffer.setAddrWkStndrdPrDate("");
		sendBuffer.setAddrWkUrbCode("");
		sendBuffer.setAddrWkLacsFlag("");
		sendBuffer.setAddrWkLacsFtnote("");
		sendBuffer.setAddrWkLacsRtrnCode("");
		
		}
		
		
		// Set Primary phone		
		sendBuffer.setPhoneArea("630");
		sendBuffer.setPhoneNumber("1234567");
		
		if (level > 1){
		// Set Secondary Phone
		sendBuffer.setPhone2Area("630");
		sendBuffer.setPhone2Number("1234567");
		
		// Set Wk Phone
		sendBuffer.setPhoneWkArea("630");
		sendBuffer.setPhoneWkNumber("1234567");
		}
		
		
		
		
		
		return sendBuffer;
	}
	
	

}
