package com.walgreens.cdi.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.walgreens.cdi.vo.CustomerMasterEnterpriseSearch;
import com.walgreens.cdi.vo.CustomerMasterLinkageVO;
/**
 * This Interface have all the methods declaration of EnterPrise Lookup Methods that will be implemented in DAO Class
 * 
 * @param eidSet
 * @return
 */
public interface ICustomerMasterEnterpriseLookUpDAO {
	public List<CustomerMasterEnterpriseSearch> getCdiCompViewAllSrc(Set eidSet);
	//Code changes start for PCC CR
	public List<CustomerMasterLinkageVO> getCdiLinkageAllSrc(Set eidSet,String applicationID);
	//Code changes ends for PCC CR
	public List<CustomerMasterEnterpriseSearch> getRefCompViewAllSrc(String srcCode, String srcId);
	public List<Map<String,Object>> getAllProgramsAndAttr(String srcCode, String srcId);
	public List<CustomerMasterEnterpriseSearch> getLoyaltyMemCompView(String srcCode, String srcId);
	public List<CustomerMasterEnterpriseSearch> getCompView(Set eidSet);
	public List<CustomerMasterLinkageVO> getLinkage(Set eidSet);
}
