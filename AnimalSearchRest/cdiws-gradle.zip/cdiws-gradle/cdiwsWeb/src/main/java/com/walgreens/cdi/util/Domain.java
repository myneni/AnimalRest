package com.walgreens.cdi.util;

/**
 * @author atul.prabhu
 */
public enum Domain {

	CUSTOMER_MASTER("11", CustomerMasterConstants.CUSTOMER_MASTER_PROPERTIES), ;

	private String code;

	private String fileName;

	Domain(String code, String fileName) {
		this.code = code;
		this.fileName = fileName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return code;
	}

	public String getFileName() {
		return fileName;
	}

}
