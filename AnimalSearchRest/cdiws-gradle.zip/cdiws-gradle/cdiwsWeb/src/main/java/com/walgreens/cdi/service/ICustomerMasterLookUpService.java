package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfCustomer;

/**
 * This service is an interface for exposing  lookUpCustomerMaster method at service
 * level.
 * 
 * @param CustomerMasterUpdateRequest
 * @return boolean
 * @throws CDIException
 * @author
 * 
 */
public interface ICustomerMasterLookUpService {
	
	public ArrayOfCustomer lookUpCustomerMaster(CustomerMasterLookUpRequest cdiSearchRequest) throws CDIException;
	
	
	

}
