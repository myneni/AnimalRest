package com.walgreens.cdi.dao;


public interface ICustomerMasterEntMemberIdGenerateDAO {

	public String getMemberIDNumber(String programCode);

}
