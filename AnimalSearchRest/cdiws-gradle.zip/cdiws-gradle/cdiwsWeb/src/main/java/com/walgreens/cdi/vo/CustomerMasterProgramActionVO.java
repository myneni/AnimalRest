package com.walgreens.cdi.vo;

public class CustomerMasterProgramActionVO {
	
	private String programCode;
	private String programId;	
	private String programAction;
	public String getProgramAction() {
		return programAction;
	}
	public void setProgramAction(String programAction) {
		this.programAction = programAction;
	}
	public String getProgramCode() {
		return programCode;
	}
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	public String getProgramId() {
		return programId;
	}
	public void setProgramId(String programId) {
		this.programId = programId;
	}

}
