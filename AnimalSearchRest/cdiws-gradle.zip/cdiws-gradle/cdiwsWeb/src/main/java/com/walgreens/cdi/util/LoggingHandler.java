package com.walgreens.cdi.util;

import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerException;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import javax.xml.xpath.XPathExpressionException;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import walgreens.services.LoggingFacility;
import walgreens.utils.logging.WalgreensLog4JImpl;

import com.walgreens.cdi.vo.TrackingInfoVO;

/**
 * This class is the custom SOAP handler class for retrieving the id details
 * from SOAP Header of the incoming SOAP Request
 * 
 * @author k.anurag
 * @version 1.0
 */
public class LoggingHandler implements
		javax.xml.ws.handler.soap.SOAPHandler<SOAPMessageContext> {

	private static final String MESSAGE_ID = "MessageId";

	private static final String CORRELATION_ID = "CorrelationID";

	private static final String APPLICATION_ID = "ApplicationId";

	private static final String TRACKING_INFO = "TrackingInfo";

	//CDI_289 change starts
	private static final String RETRY_ERROR_CODES = "110000,110001,110011,110012,114003,114004,114005,110002,110003,110004,110005";
	
	private static final String RESPONSE = "Response";
	
	private static final String RETRYABLE = "Retryable";
	
	//ErrorLog Optimization
	private static final String UPDATECUSTOMERENT="updateCustomerMasterEnt";
	//CDI_289 change ends
	

	/**
	 * This refers to trackingInfoProxyBean
	 */
	private TrackingInfoVO trackingInfoProxyBean;

	private CDILogger cdiLogger;

	/**
	 * @return the trackingInfoProxyBean
	 */
	public TrackingInfoVO getTrackingInfoProxyBean() {
		return trackingInfoProxyBean;
	}

	/**
	 * @param trackingInfoProxyBean
	 *            the trackingInfoProxyBean to set
	 */
	public void setTrackingInfoProxyBean(TrackingInfoVO correlationIDProxyBean) {
		this.trackingInfoProxyBean = correlationIDProxyBean;
	}

	@Override
	public void close(MessageContext messagecontext) {
		// Do nothing 
	}

	@Override
	public Set<QName> getHeaders(){
		Set<QName> tmp= null;
		return tmp;
	}

	public boolean handleFault(SOAPMessageContext messagecontext) {
		// Changes has been made to capture the error message response for each
		// service request.

		try {
			if (messagecontext != null) {
				SOAPMessage soapMessage = ((SOAPMessageContext) messagecontext)
						.getMessage();
				if (soapMessage.getSOAPBody().getFault() != null) {
					StringBuffer logMessage = new StringBuffer("");
					//CDI_289 change--starts
					String errorCode = soapMessage.getSOAPBody()
					.getElementsByTagName("errorCode").item(0)
					.getChildNodes().item(0).getNodeValue();
					
					String transactionName = null;
					if(getTrackingInfoProxyBean().getTransactionName().contains(UPDATECUSTOMERENT) && errorCode.equalsIgnoreCase("110001") )
					{
						transactionName = getTrackingInfoProxyBean().getTransactionName()+RESPONSE;
					}
					else
					{	
						if(RETRY_ERROR_CODES.contains(errorCode))
						{
							transactionName = getTrackingInfoProxyBean().getTransactionName()+RETRYABLE;
						}
						else
						{
							transactionName = getTrackingInfoProxyBean().getTransactionName()+RESPONSE;
						}
					}
					
					logMessage.append(transactionName);
					//CDI_289 change ends
					logMessage.append("|");
					logMessage.append(System.currentTimeMillis()
							- getTrackingInfoProxyBean().getStartTimeMillis());
					logMessage.append("|");
					logMessage.append("0");
					logMessage.append("|");
					logMessage.append("0");
					logMessage.append("|");
					logMessage.append(soapMessage.getSOAPBody()
							.getElementsByTagName("errorCode").item(0)
							.getChildNodes().item(0).getNodeValue());
					logMessage.append("|");
					logMessage.append(soapMessage.getSOAPBody()
							.getElementsByTagName("msg").item(0)
							.getChildNodes().item(0).getNodeValue());

					getCdiLogger().log(LoggingFacility.ERROR,
							logMessage.toString(),
							CustomerMasterConstants.TRACKTIMELOGGER);
					getCdiLogger().log(
							"Exception Occured |"
									+ soapMessage.getSOAPBody()
											.getElementsByTagName(
													"detailMessage").item(0)
											.getChildNodes().item(0)
											.getNodeValue());
				}
			}
		} catch (Exception exc) {
			exc.printStackTrace();
		}
		return true;
	}

	/**
	 * This method is a SOAP Handler method to handle the SOAP request message.
	 * It takes SOAPMessageContext as an input and invokes a method to process
	 * the SOAP Header.
	 * 
	 * @param messagecontext
	 *            refers to the messagecontext.
	 * @return boolean
	 */
	public boolean handleMessage(SOAPMessageContext messagecontext) {
		try {
			if (messagecontext != null) {
				SOAPMessage msg = ((SOAPMessageContext) messagecontext)
						.getMessage();

				boolean outbound = (Boolean) messagecontext
						.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
				// Process header only if inbound message
				if (!outbound) {
					SOAPEnvelope envelope = msg.getSOAPPart().getEnvelope();
					SOAPHeader header = envelope.getHeader();
					if (header == null) {
						new WalgreensLog4JImpl().log(LoggingFacility.DEBUG,
								"No Header Elements Found");

					} else {
						// call method to process header
						processSOAPHeader(msg);
					}

					getTrackingInfoProxyBean().setStartTimeMillis(
							System.currentTimeMillis());
				} else {
					StringBuffer logMessage = new StringBuffer("");
					if (msg != null && msg.getSOAPBody() != null
							&& msg.getSOAPBody().getFirstChild() != null) {
						logMessage.append(msg.getSOAPBody().getFirstChild()
								.getLocalName());
					}
					logMessage.append("|");
					logMessage.append(System.currentTimeMillis()
							- getTrackingInfoProxyBean().getStartTimeMillis());

					// Added for number of Entity and Members found
					logMessage.append("|");
					logMessage.append(msg.getSOAPBody().getElementsByTagName(
							"item").getLength());
					logMessage.append("|");
					logMessage.append(msg.getSOAPBody().getElementsByTagName(
							"linkageDetail").getLength());

					getCdiLogger().log(LoggingFacility.WARN,
							logMessage.toString(),
							CustomerMasterConstants.TRACKTIMELOGGER);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;
	}

	/**
	 * This method traverses through the SOAP Header element to retrieve
	 * message, correlation and application ID. It then sets these ids into
	 * CorrelationIdProxyBean.
	 * 
	 * @param soapMessage
	 *            refers to the soapMessage.
	 * @return void
	 */
	private void processSOAPHeader(SOAPMessage soapMessage)
			throws SOAPException, TransformerException,
			XPathExpressionException {
		getTrackingInfoProxyBean().setMessageID(null);
		getTrackingInfoProxyBean().setCorrelationID(null);
		getTrackingInfoProxyBean().setApplicationID(null);
        //CDI_289 change starts
		getTrackingInfoProxyBean().setTransactionName(null);
		//CDI_289 change ends
		
		SOAPHeader header = soapMessage.getSOAPHeader();
		NodeList trackingInfoNodeList = header
				.getElementsByTagName(TRACKING_INFO);

		
		//CDI_289 change-- starts	
				if(null != soapMessage.getSOAPBody())
				{
					Node child = null;
				if (soapMessage.getSOAPBody().getFirstChild().getNodeName() == "#text") {

					child = (Node) soapMessage.getSOAPBody().getFirstChild().getNextSibling();

					} else {

					child = (Node) soapMessage.getSOAPBody().getFirstChild();

					}

					getTrackingInfoProxyBean().setTransactionName(child.getLocalName());
				}
				//CDI_289 change-- ends

		if (trackingInfoNodeList != null
				&& trackingInfoNodeList.getLength() > 0) {
			Node trackingInfoNode = trackingInfoNodeList.item(0);

			// Retrieving the child nodes
			NodeList nodeList = trackingInfoNode.getChildNodes();

			if (nodeList != null && nodeList.getLength() > 0) {
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node childNode = nodeList.item(i);

					if (childNode.getNodeName() != null
							&& childNode.getNodeName().equals(APPLICATION_ID)) {

						if (childNode.getFirstChild() != null) {
							String applicationId = childNode.getFirstChild()
									.getNodeValue().trim();
							getTrackingInfoProxyBean().setApplicationID(
									applicationId);
						}

					} else if (childNode.getNodeName() != null
							&& childNode.getNodeName().equals(CORRELATION_ID)) {
						if (childNode.getFirstChild() != null) {
							String correlationID = childNode.getFirstChild()
									.getNodeValue().trim();
							getTrackingInfoProxyBean().setCorrelationID(
									correlationID);
						}

					} else if (childNode.getNodeName() != null
							&& childNode.getNodeName().equals(MESSAGE_ID)) {
						if (childNode.getFirstChild() != null) {
							String messageId = childNode.getFirstChild()
									.getNodeValue().trim();
							getTrackingInfoProxyBean().setMessageID(messageId);
						}
					}
				}
			}
		}
	}

	public CDILogger getCdiLogger() {
		return cdiLogger;
	}

	public void setCdiLogger(CDILogger cdiLogger) {
		this.cdiLogger = cdiLogger;
	}
}
