package com.walgreens.cdi.vo.customer.attr;

import com.walgreens.cdi.util.CustomerMasterConstants;

public class CustomerMasterPetInd extends CustomerMasterAttributeStatus{
	//	 (Pet Indicator attribute)		
	private String petIndicator;						//Date (0/1)	Composite customer PetIndicator.

	/**
	 * @return the petIndicator
	 */
	public String getPetIndicator() {
		return petIndicator;
	}

	/**
	 * @param petIndicator the petIndicator to set
	 */
	public void setPetIndicator(String custPetIndicator) {
		this.petIndicator = custPetIndicator;
	}
	
	public String toString() {
		String str="";
		str = "\nPetInd:\n____________________________________\n"+
		      " petIndicator =" + petIndicator + "\n" +
		      " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
			  " securityClassCode   =" + getSecurityClassCode() + "\n" +
			  " sourceCode   =" + getSourceCode() + "\n" ;
		
					
         return str;
	}
	
	public String toCompString() {
		String str="";
		 str = CustomerMasterConstants.DELIMITE_ATTR +
		      CustomerMasterConstants.COMP_ATTR_NAME_PETIND + CustomerMasterConstants.DELIMITE_FIELD +
		      petIndicator + CustomerMasterConstants.DELIMITE_FIELD +
		      getLastUpdateDate() + CustomerMasterConstants.DELIMITE_FIELD +
			  getSecurityClassCode() + CustomerMasterConstants.DELIMITE_FIELD +
			  getSourceCode() + CustomerMasterConstants.DELIMITE_FIELD ;
	
         return str;
	}
	
	
	  public boolean isNull(){
			
			if(isNull(petIndicator))
					return true;
			else
				return false;
		}
		
		 private boolean isNull(String str){
			    if(str==null)
					return  true;
				if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
					return true;
				else
					return false;
			}
			

	
}
