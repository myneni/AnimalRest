package com.walgreens.cdi.service.impl;

import walgreens.utils.logging.WalgreensLog4JImpl;

/**
 * This class is the base class for the service objects. All service objects
 * will extend this Base class. It contains log4j logging which can be directly
 * used by the inheriting classes
 * @author amal.arindam
 * @version 1.0
 */
public class BaseService {

    /**
     * Referring to the WalgreensLog4JImpl
     */
    private WalgreensLog4JImpl walgreensLogger;


    /**
     * @return the walgreensLogger
     */
    public WalgreensLog4JImpl getWalgreensLogger() {
        return walgreensLogger;
    }


    /**
     * @param walgreensLogger
     *            the walgreensLogger to set
     */
    public void setWalgreensLogger(WalgreensLog4JImpl walgreensLogger) {
        this.walgreensLogger = walgreensLogger;
    }

}
