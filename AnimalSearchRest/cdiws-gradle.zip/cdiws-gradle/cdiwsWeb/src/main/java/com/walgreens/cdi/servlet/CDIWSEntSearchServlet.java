package com.walgreens.cdi.servlet;
/**
 *
 */
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import walgreens.mail.*;

import com.walgreens.cdi.util.CustomerMasterConstants;

public class CDIWSEntSearchServlet extends HttpServlet implements java.beans.PropertyChangeListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//System.out.println("In CDIWSEntSearchServlet ..");
		String ALLOW_PROG_SEARCH = req.getParameter("ALLOW_PROG_SEARCH");
		String EXCLUDE_HUB_ONSEARCH = req.getParameter("EXCLUDE_HUB_ONSEARCH");
		String PVSEARCH_FLAG = req.getParameter("PVSEARCH_FLAG");
		String user = req.getParameter("user");
		// String msg=req.getRemoteHost();
		String msg = "  Requester IP: " + req.getRemoteAddr();
		msg = msg + "\n  Application Server: " + req.getLocalName();
		msg = msg + "\n  Application Port: " + req.getLocalPort();
		msg = msg + "\n  Application Context Path: " + req.getContextPath();

		if (user != null && ALLOW_PROG_SEARCH != null
				&& user.equalsIgnoreCase("cdiuser")) {

			if (ALLOW_PROG_SEARCH.equalsIgnoreCase("True")) {
				CustomerMasterConstants.ALLOW_PROG_SEARCH = true;
				msg += "\n  ALLOW_PROG_SEARCH flag set True";
				sendMail(msg,"CDIWS Allow Program Search Flag Updated ---DO NOT REPLY");
			} else if (ALLOW_PROG_SEARCH.equalsIgnoreCase("False")) {
				CustomerMasterConstants.ALLOW_PROG_SEARCH = false;
				msg += "\n  ALLOW_PROG_SEARCH flag set False";
				sendMail(msg, "CDIWS Allow Program Search Flag Updated ---DO NOT REPLY");
			}
		}
		if (user != null && PVSEARCH_FLAG != null
				&& user.equalsIgnoreCase("cdiuser")) {

			if (PVSEARCH_FLAG.equalsIgnoreCase("True")) {
				CustomerMasterConstants.ENT_PV_TABLE_SEARCH = true;
				msg += "\n  PV_TABLE_SEARCH flag set True";
				sendMail(msg,"CDIWS PV Search Flag Updated ---DO NOT REPLY");
			} else if (PVSEARCH_FLAG.equalsIgnoreCase("False")) {
				CustomerMasterConstants.ENT_PV_TABLE_SEARCH = false;
				msg += "\n  PV_TABLE_SEARCH flag set False";
				sendMail(msg, "CDIWS PV Search Flag Updated ---DO NOT REPLY");
			}
		}
		if (user != null && EXCLUDE_HUB_ONSEARCH != null
				&& user.equalsIgnoreCase("cdiuser")) {

			if (EXCLUDE_HUB_ONSEARCH.equalsIgnoreCase(CustomerMasterConstants.CDI_HUB)) {
				CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH = CustomerMasterConstants.CDI_HUB;
				msg += "\n  EXCLUDE_HUB_ONSEARCH Flag set to :"
						+ CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH;
				sendMail(msg, "CDIWS Exclude Hub On Search Flag Updated ---DO NOT REPLY");
			} else if (EXCLUDE_HUB_ONSEARCH.equalsIgnoreCase(CustomerMasterConstants.REF_HUB)) {
				CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH = CustomerMasterConstants.REF_HUB;
				msg += "\n  EXCLUDE_HUB_ONSEARCH Flag set to :"
						+ CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH;
				sendMail(msg, "CDIWS Exclude Hub On Search Flag Updated ---DO NOT REPLY");
			} else if (EXCLUDE_HUB_ONSEARCH.equalsIgnoreCase(CustomerMasterConstants.EXCLUDE_BOTH_HUB)) {
				CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH = null;
				msg += "\n  EXCLUDE_HUB_ONSEARCH Flag set to :"
						+ CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH;
				sendMail(msg, "CDIWS Exclude Hub On Search Flag Updated ---DO NOT REPLY");
			}

		} 
		
		res.setHeader("Cache-Control", "no-cache"); // HTTP 1.1
		res.setHeader("Pragma", "no-cache");
		res.setDateHeader("Expires", -1);
		res.getOutputStream().print(msg);
		res.flushBuffer();
	}
@Override
public void init() throws ServletException {
	// TODO Auto-generated method stub
	super.init();
    
		//System.out.println("CustomerMasterConstants.ALLOW_PROG_SEARCH: "+CustomerMasterConstants.ALLOW_PROG_SEARCH);
		//System.out.println("CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH: "+CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH);
	
}

    public void sendMail(String txtmsg, String subject) {

		SendMail sendMail = new SendMail();

		sendMail.addPropertyChangeListener(this);

		// Be sure to change this email address BEFORE
		// running the test!
		String mailTo[] = { CustomerMasterConstants.EMAIL_TO };

		sendMail.setMailFrom(CustomerMasterConstants.EMAIL_FROM);
		sendMail.setMailTo(mailTo);
		sendMail.setSubject(subject);
		
		// This next line puts a HIPAA mood stamp on the 
		// email.  It should only be used for secure email.
		sendMail.setHeaderLines("X-$MOODS: H");
		
		sendMail.setMessageText(txtmsg);
		sendMail.doSendMail();

		System.out.println("Success = " + sendMail.isMailSuccess());
		if (!sendMail.isMailSuccess()) {
			System.out.println("Error Message: " + sendMail.getSmtpMessage());
		}

	}
    
    
	/**
	 * This method gets called when a bound property is changed.
	 * @param evt A PropertyChangeEvent object describing the event source 
	 *   	and the property that has changed.
	 */
	public void propertyChange(java.beans.PropertyChangeEvent evt) {

		System.out.println(evt.getNewValue());
	}


}
