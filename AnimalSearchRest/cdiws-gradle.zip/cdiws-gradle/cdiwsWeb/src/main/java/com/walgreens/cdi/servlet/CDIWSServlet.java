package com.walgreens.cdi.servlet;
/**
 *
 */
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import walgreens.mail.*;

import com.walgreens.cdi.util.CustomerMasterConstants;

public class CDIWSServlet extends HttpServlet implements java.beans.PropertyChangeListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("In CDIWSServlet ..");
		String PVSEARCH_FLAG =req.getParameter("PVSEARCH_FLAG");
		String user = req.getParameter("user");
		//String msg=req.getRemoteHost();
		String msg = "  Requester IP: "+req.getRemoteAddr();
		msg = msg + "\n  Application Server: "+req.getLocalName();
		msg = msg + "\n  Application Port: "+req.getLocalPort();
		msg = msg + "\n  Application Context Path: "+req.getContextPath();
		
		if(user!=null && PVSEARCH_FLAG!=null && user.equalsIgnoreCase("cdiuser"))
		{
			
			if( PVSEARCH_FLAG.equalsIgnoreCase("True"))
			{
				CustomerMasterConstants.ENABLE_PV_SEARCH = true;
				msg+="\n  PV_SEARCH flag set True";
				sendMail(msg);
			}
			else if(PVSEARCH_FLAG.equalsIgnoreCase("FALSE"))
			{
				CustomerMasterConstants.ENABLE_PV_SEARCH = false;
				msg+="\n  PV_SEARCH flag set False";
				sendMail(msg);
			}else if(PVSEARCH_FLAG.equalsIgnoreCase("STATUS")){
				msg+="\n  PV_SEARCH  Flag is:"+CustomerMasterConstants.ENABLE_PV_SEARCH;
				//sendMail(msg);
			}
				
			
		}
		res.setHeader("Cache-Control","no-cache"); //HTTP 1.1
		res.setHeader("Pragma", "no-cache");
		res.setDateHeader("Expires", -1);				
		res.getOutputStream().print(msg);
		res.flushBuffer();
	}
@Override
public void init() throws ServletException {
	// TODO Auto-generated method stub
	super.init();
    
		System.out.println("CustomerMasterConstants.DISABLE_PV_SEARCH:"+CustomerMasterConstants.ENABLE_PV_SEARCH);
	
}

    public void sendMail(String txtmsg) {

		SendMail sendMail = new SendMail();

		sendMail.addPropertyChangeListener(this);

		// Be sure to change this email address BEFORE
		// running the test!
		String mailTo[] = { CustomerMasterConstants.EMAIL_TO };

		sendMail.setMailFrom(CustomerMasterConstants.EMAIL_FROM);
		sendMail.setMailTo(mailTo);
		sendMail.setSubject("CDIWS PVSearch Flag Updated ---DO NOT REPLY");
		
		// This next line puts a HIPAA mood stamp on the 
		// email.  It should only be used for secure email.
		sendMail.setHeaderLines("X-$MOODS: H");
		
		sendMail.setMessageText(txtmsg);
		sendMail.doSendMail();

		System.out.println("Success = " + sendMail.isMailSuccess());
		if (!sendMail.isMailSuccess()) {
			System.out.println("Error Message: " + sendMail.getSmtpMessage());
		}

	}
    
    /**
	 * Starts the application.
	 * @param args an array of command-line arguments
	 */
	public static void main(java.lang.String[] args) {

		CDIWSServlet obj = new CDIWSServlet();
		obj.sendMail("Test Mail");
	}
	/**
	 * This method gets called when a bound property is changed.
	 * @param evt A PropertyChangeEvent object describing the event source 
	 *   	and the property that has changed.
	 */
	public void propertyChange(java.beans.PropertyChangeEvent evt) {

		System.out.println(evt.getNewValue());
	}


}
