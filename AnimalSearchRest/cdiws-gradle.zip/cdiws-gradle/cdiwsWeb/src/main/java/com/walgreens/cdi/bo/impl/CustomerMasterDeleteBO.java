package com.walgreens.cdi.bo.impl;

import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterDeleteBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterDeleteRequest;
import com.walgreens.cdi.wsao.ICustomerMasterDeleteWSAO;

/**
 * This BO perform validation on input request and also handles exception.
 * It will return true on  successfull deletion of EC record , otherwise an exception will be
 * thrown with message and error code.
 *
 *
 * @author 245797
 *
 */
public class CustomerMasterDeleteBO extends BaseBO implements ICustomerMasterDeleteBO {

	private ICustomerMasterDeleteWSAO deleteWSAO;


	public boolean deleteCustomerMaster(CustomerMasterDeleteRequest customerMasterDeleteRequest) throws SystemException,BusinessRuleViolationException {
		try
		{
			ValidateCustomerMasterRequest.validateRequiredFields(customerMasterDeleteRequest);
			return  getcustomerMasterDeleteWSAO().deleteCustomerMaster(customerMasterDeleteRequest);
		}
		catch (JaxWsSoapFaultException e) {

			String exceptionCode = getExceptionCode(e);
			if(exceptionCode != null){
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(exceptionCode,e.getMessage());
			}else{
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e.getMessage());
			}
		}catch(BusinessRuleViolationException e){
			throw e;
		}
		catch(Exception e){
			throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, e.getMessage());
		}

	}


	/**
	 * @return the searchWSAO
	 */
	public ICustomerMasterDeleteWSAO getcustomerMasterDeleteWSAO() {
		return deleteWSAO;
	}


	/**
	 * @param searchWSAO the searchWSAO to set
	 */
	public void setCustomerMasterDeleteWSAO(ICustomerMasterDeleteWSAO deleteWSAO) {
		this.deleteWSAO = deleteWSAO;
	}


	/**
	 * Overriding getExceptionCode inherited from BaseBo to generate customised messages.
	 */
	public  String  getExceptionCode(Exception exception){
		   if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_EC_DELETE_RECORD_NOT_FOUND.trim())){
	           return CustomerMasterConstants.EC_DELETE_EXCEPTION_NO_RECORD_FOUND;
	       }else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_EC_DELETE_INVALID_SRCCD.trim())){
	           return CustomerMasterConstants.EC_DELETE_EXCEPTION_UNKNOWN_SRCCODE;
	       }
	       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_EC_DELETE_RECORD_ALREADY_DELETED.trim())){
	           return CustomerMasterConstants.EC_DELETE_EXCEPTION_RECORD_ALREADY_DELETED;
	       }
	       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_EC_DELETE_HUB_MAY_BE_DOWN.trim())){
	           return CustomerMasterConstants.EC_DELETE__EXCEPTION_HUB_MAY_BE_DOWN;
	       }
	       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_EC_DELETE_COULD_NOT_SEND_MSG.trim())){
	           return CustomerMasterConstants.EC_DELETE_EXCEPTION_COULD_NOT_SEND_MSG;
	       }

	       else{
	    	   return super.getExceptionCode(exception);
	       }
	   }






}
