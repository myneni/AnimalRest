package com.walgreens.cdi.util;

/**
 * 
 * @author TCS Created on Nov 05,2008
 */
public class CustomerMasterException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private short errorCode;

	private String errorDescription;

	public CustomerMasterException(short errorCode, String errorDescription) {
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
	}

	public CustomerMasterException(String errorDescription, Throwable e) {
		super(errorDescription, e);
	}

	public short getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(short errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

}
