package com.walgreens.cdi.servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import walgreens.mail.*;

import com.walgreens.cdi.util.CustomerMasterConstants;
public class CDIWSEnterpriseSearchServlet extends HttpServlet implements java.beans.PropertyChangeListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ALLOW_PROG_SEARCH = req.getParameter(CustomerMasterConstants.ALLOW_PROG_SEARCH_SERVLET);  
		String EXCLUDE_HUB_ONSEARCH = req.getParameter(CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH_SERVLET); 
		String PVSEARCH_FLAG = req.getParameter(CustomerMasterConstants.PVSEARCH_FLAG_SERVLET); 
		String user = req.getParameter(CustomerMasterConstants.USER); 
		// String msg=req.getRemoteHost();
		String msg = CustomerMasterConstants.REQUESTER_IP + req.getRemoteAddr(); 
		msg = msg + CustomerMasterConstants.APPLICATION_SERVER + req.getLocalName(); 
		msg = msg + CustomerMasterConstants.APPLICATION_PORT + req.getLocalPort(); 
		msg = msg + CustomerMasterConstants.APPLICATION_CONTEXT_PATH + req.getContextPath(); 

		if (user != null && ALLOW_PROG_SEARCH != null
				&& user.equalsIgnoreCase(CustomerMasterConstants.CDIUSER)) {

			if (ALLOW_PROG_SEARCH.equalsIgnoreCase(CustomerMasterConstants.VALUE_TRUE)) 
			{
				CustomerMasterConstants.ALLOW_PROG_SEARCH = true;
				msg += CustomerMasterConstants.ALLOW_PROG_SRCH_TRUE; 
				sendMail(msg,CustomerMasterConstants.MAIL_PROG_SRCH_FLAG_UPDATED);
			} else if (ALLOW_PROG_SEARCH.equalsIgnoreCase(CustomerMasterConstants.VALUE_FALSE))
			{
				CustomerMasterConstants.ALLOW_PROG_SEARCH = false;
				msg += CustomerMasterConstants.ALLOW_PROG_SRCH_FALSE;
				sendMail(msg, CustomerMasterConstants.MAIL_PROG_SRCH_FLAG_UPDATED);
			}
		}
		if (user != null && PVSEARCH_FLAG != null
				&& user.equalsIgnoreCase(CustomerMasterConstants.CDIUSER)) {

			if (PVSEARCH_FLAG.equalsIgnoreCase(CustomerMasterConstants.VALUE_TRUE)) {
				CustomerMasterConstants.ENT_PV_TABLE_SEARCH = true;
				msg += CustomerMasterConstants.PV_TABLE_FLAG_TRUE;
				sendMail(msg,CustomerMasterConstants.MAIL_PV_FLAG_UPDATED);
			} else if (PVSEARCH_FLAG.equalsIgnoreCase(CustomerMasterConstants.VALUE_FALSE)) {
				CustomerMasterConstants.ENT_PV_TABLE_SEARCH = false;
				msg += CustomerMasterConstants.PV_TABLE_FLAG_FALSE;
				sendMail(msg, CustomerMasterConstants.MAIL_PV_FLAG_UPDATED);
			}
		}
		if (user != null && EXCLUDE_HUB_ONSEARCH != null
				&& user.equalsIgnoreCase(CustomerMasterConstants.CDIUSER)) {

			if (EXCLUDE_HUB_ONSEARCH.equalsIgnoreCase(CustomerMasterConstants.CDI_HUB)) {
				CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH = CustomerMasterConstants.CDI_HUB;
				msg += CustomerMasterConstants.EXCLUDE_HUB_ON_SEARCH_FLAG
						+ CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH;
				sendMail(msg, CustomerMasterConstants.MAIL_EXCLUDE_HUB_FLAG_UPDATED);
			} else if (EXCLUDE_HUB_ONSEARCH.equalsIgnoreCase(CustomerMasterConstants.REF_HUB)) {
				CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH = CustomerMasterConstants.REF_HUB;
				msg += CustomerMasterConstants.EXCLUDE_HUB_ON_SEARCH_FLAG
						+ CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH;
		     	sendMail(msg, CustomerMasterConstants.MAIL_EXCLUDE_HUB_FLAG_UPDATED);
			} else if (EXCLUDE_HUB_ONSEARCH.equalsIgnoreCase(CustomerMasterConstants.EXCLUDE_BOTH_HUB)) {
				CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH = null;
				msg += CustomerMasterConstants.EXCLUDE_HUB_ON_SEARCH_FLAG
						+ CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH;
				sendMail(msg, CustomerMasterConstants.MAIL_EXCLUDE_HUB_FLAG_UPDATED);
			}

		} 
		
		res.setHeader(CustomerMasterConstants.CACHE_CONTROL, CustomerMasterConstants.NO_CACHE); // HTTP 1.1
		res.setHeader(CustomerMasterConstants.PRAGMA, CustomerMasterConstants.NO_CACHE);
		res.setDateHeader(CustomerMasterConstants.EXPIRES, -1);
		res.getOutputStream().print(msg);
		res.flushBuffer();
	}
@Override
public void init() throws ServletException {
	// TODO Auto-generated method stub
	super.init();
    
	
}

    public void sendMail(String txtmsg, String subject) {

		SendMail sendMail = new SendMail();

		sendMail.addPropertyChangeListener(this);

		// Be sure to change this email address BEFORE
		// running the test!
		String mailTo[] = { CustomerMasterConstants.EMAIL_TO };

		sendMail.setMailFrom(CustomerMasterConstants.EMAIL_FROM);
		sendMail.setMailTo(mailTo);
		sendMail.setSubject(subject);
		
		// This next line puts a HIPAA mood stamp on the 
		// email.  It should only be used for secure email.
		sendMail.setHeaderLines("X-$MOODS: H");
		
		sendMail.setMessageText(txtmsg);
		sendMail.doSendMail();

		System.out.println("Success = " + sendMail.isMailSuccess());
		if (!sendMail.isMailSuccess()) {
			System.out.println("Error Message: " + sendMail.getSmtpMessage());
		}

	}
    
    
	/**
	 * This method gets called when a bound property is changed.
	 * @param evt A PropertyChangeEvent object describing the event source 
	 *   	and the property that has changed.
	 */
	public void propertyChange(java.beans.PropertyChangeEvent evt) {

		System.out.println(evt.getNewValue());
	}


}
