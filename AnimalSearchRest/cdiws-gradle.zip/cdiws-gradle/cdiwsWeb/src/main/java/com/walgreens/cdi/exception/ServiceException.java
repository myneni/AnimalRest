package com.walgreens.cdi.exception;

/**
 * Class for handling Exceptions other than Business Rule violation exception
 * @author siddhartha.basu
 *
 */

public class ServiceException extends BaseException{
    
    
    /**
     * 
     * @param errorCode
     * @param detailedMessage
     */
    
  
    public ServiceException( String errorCode, String detailedMessage)
    {
        super(errorCode, detailedMessage);
      
        
    }
    /**
     * 
     * @param errorCode
     * @param detailedMessage
     * @param userMessage
     */
    
    public ServiceException( String errorCode, String detailedMessage, String userMessage)
    {
        super(errorCode, detailedMessage , userMessage);
        this.errorCode=errorCode;
        
    }
    

}
