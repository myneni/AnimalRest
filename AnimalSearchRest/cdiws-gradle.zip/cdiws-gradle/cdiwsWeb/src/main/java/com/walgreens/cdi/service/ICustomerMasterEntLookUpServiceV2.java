/**
 * 
 */
package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfEnterpriseCustomer;

/**
 * This service is an interface for exposing  lookUpCustomerMasterEnterprise method at service
 * level.
 * 
 * @param CustomerMasterEnterpriseLookUpRequest
 * @return boolean
 * @throws CDIException
 * @author
 * 
 */
public interface ICustomerMasterEntLookUpServiceV2 {
	public ArrayOfEnterpriseCustomer lookUpCustomerMasterEnterprise(CustomerMasterEnterpriseLookUpRequest enterpriseSearchRequest) throws CDIException ;
}
