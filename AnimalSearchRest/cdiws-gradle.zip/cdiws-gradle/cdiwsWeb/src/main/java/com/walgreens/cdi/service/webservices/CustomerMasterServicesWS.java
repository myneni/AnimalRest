/*
 * This is an auto-generated class for the service object. Please do not modify this class.
*/
package com.walgreens.cdi.service.webservices;

import javax.jws.WebResult;
import javax.jws.WebService;

import com.walgreens.cdi.exception.BaseException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.CDIExceptionFault;
import com.walgreens.cdi.exception.CDIException_Exception;
//As a part of WAS Migration Changes are in the new parameters addition for the @WebService tag, the new @SoapBinding tag, 
//and  replacing the @WebResult tag in the called methods with @WebMethod tags.
@WebService (targetNamespace="http://webservices.service.cdi.walgreens.com/", 
serviceName="CustomerMasterServicesWSService", 
portName="CustomerMasterServicesWSPort", 
wsdlLocation="WEB-INF/WSDL/CustomerMasterServicesWSService.wsdl")
@javax.jws.soap.SOAPBinding(style = javax.jws.soap.SOAPBinding.Style.DOCUMENT)

@javax.jws.HandlerChain(file="/WSHandlerChain.xml")

public class CustomerMasterServicesWS{
    private com.walgreens.cdi.service.impl.CustomerMasterServices _service = null;

    @javax.jws.WebMethod(exclude=true)
    private com.walgreens.cdi.service.impl.CustomerMasterServices getService() {
             _service = (com.walgreens.cdi.service.impl.CustomerMasterServices)walgreens.utils.ioc.BeanFactoryUtil.getFactory().getBean("customerMasterServices");
        return _service;
    }

    @WebResult(name = "lookUpCustomerMasterResponse", targetNamespace = "")
    
    public @javax.jws.WebMethod com.walgreens.cdi.vo.customer.ArrayOfCustomer lookUpCustomerMaster (com.walgreens.cdi.vo.CustomerMasterLookUpRequest arg0) throws com.walgreens.cdi.exception.CDIException_Exception,BaseException,Exception{
       try{
    	return getService().lookUpCustomerMaster(arg0);
    }
       catch (CDIException e) {
   		CDIExceptionFault fault = new CDIExceptionFault();
			fault.setErrorCode(e.getErrorCode());
			fault.setDetailMessage(e.getDetailMessage());
			
			fault.setMsg(e.getMsg());
			throw new CDIException_Exception(e.getMessage(), fault);
   	}
    }

    @WebResult(name = "getCustomerMasterResponse", targetNamespace = "")
       public @javax.jws.WebMethod com.walgreens.cdi.vo.customer.ArrayOfCustomer getCustomerMaster (com.walgreens.cdi.vo.CustomerMasterGetRequest arg0) throws com.walgreens.cdi.exception.CDIException_Exception{
       
    	   try{
    	   return getService().getCustomerMaster( arg0);
    }
    	   catch (CDIException e) {
       		CDIExceptionFault fault = new CDIExceptionFault();
   			fault.setErrorCode(e.getErrorCode());
   			fault.setDetailMessage(e.getDetailMessage());
   			
   			fault.setMsg(e.getMsg());
   			throw new CDIException_Exception(e.getMessage(), fault);
       	}   
       }
    
    @WebResult(name = "updateCustomerMasterResponse", targetNamespace = "")
           public @javax.jws.WebMethod boolean updateCustomerMaster (com.walgreens.cdi.vo.CustomerMasterUpdateRequest arg0) throws com.walgreens.cdi.exception.CDIException_Exception,BaseException,Exception{
        
    	try{
        	   return getService().updateCustomerMaster( arg0);
    }
        catch (CDIException e) {
    		CDIExceptionFault fault = new CDIExceptionFault();
			fault.setErrorCode(e.getErrorCode());
			fault.setDetailMessage(e.getDetailMessage());
			fault.setMsg(e.getMsg());
			throw new CDIException_Exception(e.getMessage(), fault);
    	}
        }

    
    @WebResult(name = "mergeCustomerMasterResponse", targetNamespace = "")
           public @javax.jws.WebMethod boolean mergeCustomerMaster(com.walgreens.cdi.vo.CustomerMasterMergeRequest arg0) throws com.walgreens.cdi.exception.CDIException_Exception,Exception{
        try{
        	   return getService().mergeCustomerMaster( arg0);
    }
        catch (CDIException e) {
    		CDIExceptionFault fault = new CDIExceptionFault();
			fault.setErrorCode(e.getErrorCode());
			fault.setDetailMessage(e.getDetailMessage());
			
			fault.setMsg(e.getMsg());
			throw new CDIException_Exception(e.getMessage(), fault);
    	}
}
}
