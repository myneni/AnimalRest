package com.walgreens.cdi.dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseSearch;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddress;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttrNCOA;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterBirthDate;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEmail;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEntSearchPhone;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEnterpriseSearchAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterGender;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterName;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPhoneAttr;

public class EnterpriseRefMemRowsMapper implements ParameterizedRowMapper<CustomerMasterEnterpriseSearch> {
	
	String globalSQL = null;
	long lastTime = 0L;
	public EnterpriseRefMemRowsMapper(){
		
	}
	
	public EnterpriseRefMemRowsMapper(String sql, long st){
		
		globalSQL = sql;
		lastTime = st;
	}
	/**
	 * This method is used to map the rows in database
	 * 
	 * @param rs
	 *            ,rowNum
	 * @return
	 */
	public CustomerMasterEnterpriseSearch mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerMasterEnterpriseSearch customer = new CustomerMasterEnterpriseSearch();
		try
		{
		
		CustomerMasterEnterpriseSearchAttr custAll = new CustomerMasterEnterpriseSearchAttr();
		
		//Set Name
		CustomerMasterName name = new CustomerMasterName();		
		name.setFirstName(rs.getString(CustomerMasterConstants.FLD_FIRSTNAME)!=null?rs.getString(CustomerMasterConstants.FLD_FIRSTNAME):"");
		name.setMiddleName(rs.getString(CustomerMasterConstants.FLD_MIDDLENAME)!=null?rs.getString(CustomerMasterConstants.FLD_MIDDLENAME):"");
		name.setLastName(rs.getString(CustomerMasterConstants.FLD_LASTNAME)!=null?rs.getString(CustomerMasterConstants.FLD_LASTNAME):"");			
		name.setSuffixName(rs.getString(CustomerMasterConstants.FLD_SUFFIXNAME)!=null?rs.getString(CustomerMasterConstants.FLD_SUFFIXNAME):"");	
		
		if (!name.isNull()){
			custAll.setName(name);
		}
						
		//set Gender				
		CustomerMasterGender gender = new CustomerMasterGender();
		gender.setGenderCode(rs.getString(CustomerMasterConstants.FLD_GENDER)!=null?rs.getString(CustomerMasterConstants.FLD_GENDER):"");
		if(!gender.isNull()){
			customer.setGender(gender);
		}
		
		
			
		//EMAIL1
		CustomerMasterEmail customerEmail = new CustomerMasterEmail();		
		customerEmail.setEmailAddress(rs.getString(CustomerMasterConstants.FLD_EMAIL1)!=null?rs.getString(CustomerMasterConstants.FLD_EMAIL1):"");
		if(!customerEmail.isNull()){
			custAll.setEmail(customerEmail);
		}
		
		//EMAIL2
		CustomerMasterEmail customerEmail2 = new CustomerMasterEmail();
		customerEmail.setEmailAddress(rs.getString(CustomerMasterConstants.FLD_EMAIL2)!=null?rs.getString(CustomerMasterConstants.FLD_EMAIL2):"");
		
		if(!customerEmail2.isNull()){
			custAll.setEmail(customerEmail2);
		}
		
		
	   //BIRTHDT
		CustomerMasterBirthDate customerBirthDate = new CustomerMasterBirthDate();
		customerBirthDate.setBirthdate(rs.getString(CustomerMasterConstants.FLD_BIRTHDATE)!=null?rs.getString(CustomerMasterConstants.FLD_BIRTHDATE):"");		
		if(!customerBirthDate.isNull()){
			custAll.setBirthDate(customerBirthDate);
		}
		
		//Address
		CustomerMasterAddress address = new CustomerMasterAddress();
		//PRADDR
		CustomerMasterAddressAttrNCOA permAddress = new CustomerMasterAddressAttrNCOA(CustomerMasterConstants.CM_ADDRESS_TYPE_P);		  
	    permAddress.setCity(rs.getString(CustomerMasterConstants.FLD_PCUSTCITY)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTCITY):"");
	    permAddress.setState(rs.getString(CustomerMasterConstants.FLD_PCUSTSTATE)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTSTATE):"");
	    permAddress.setStreetLine1(rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE1)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE1):"");
	    permAddress.setStreetLine2(rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE2)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE2):"");
	    permAddress.setZipCode(rs.getString(CustomerMasterConstants.FLD_PCUSTZIPCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTZIPCODE):"");
	    if(!permAddress.isNull()){
	    	address.setPermAddress(permAddress);
	    	custAll.setAddress(address);
	    }  
			
		
		CustomerMasterEntSearchPhone phone = new CustomerMasterEntSearchPhone();
		
		//PRPHONE
		CustomerMasterPhoneAttr homePhone = new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_H);
		homePhone.setAreaCode(rs.getString(CustomerMasterConstants.FLD_HPHAREA)!=null?rs.getString(CustomerMasterConstants.FLD_HPHAREA):"");
		homePhone.setPhoneNumber(rs.getString(CustomerMasterConstants.FLD_HPHNUMBER)!=null?rs.getString(CustomerMasterConstants.FLD_HPHNUMBER):"");
		if(!homePhone.isNull()){
			phone.setHomePhone(homePhone);
		}
		
		custAll.setPhone(phone);		
		customer.setSrcCode(rs.getString(CustomerMasterConstants.FLD_SRCCODE));
		customer.setMemberId(rs.getString(CustomerMasterConstants.FLD_PRSNSEQNO));				
		customer.setCustAll(custAll);		
		customer.setGender(gender);			
				
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return customer;		
		
	}


}
