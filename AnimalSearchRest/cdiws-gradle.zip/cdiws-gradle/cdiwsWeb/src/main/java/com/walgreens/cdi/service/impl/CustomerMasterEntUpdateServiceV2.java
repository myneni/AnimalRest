package com.walgreens.cdi.service.impl;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterEnterpriseUpdateBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterEntUpdateServiceV2;
import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateResponse;

public class CustomerMasterEntUpdateServiceV2 extends BaseService implements
		ICustomerMasterEntUpdateServiceV2 {

	private ICustomerMasterEnterpriseUpdateBO customerMasterEnterpriseUpdateBO;
	/**
	 * This service is exposing  updateCustomerMasterEnterprise method at service level.
	 * @param enterpriseUpdateRequest
	 * @return
	 * @throws CDIException
	 */
	public CustomerMasterEnterpriseUpdateResponse updateCustomerMasterEnterprise(
			CustomerMasterEnterpriseUpdateRequest enterpriseUpdateRequest)
			throws CDIException {

		CustomerMasterEnterpriseUpdateResponse responseObj = new CustomerMasterEnterpriseUpdateResponse();
		try {
			responseObj = getCustomerMasterEnterpriseUpdateBO()
					.updateCustomerMasterEnterprise(enterpriseUpdateRequest);

		} catch (CDIException e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					e.getDetailMessage());
			if (e instanceof BusinessRuleViolationException) {
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);

			} else {
				e = ExceptionHandler.processServiceException(
						Domain.CUSTOMER_MASTER, e);
				throw e;
			}
		}
		return responseObj;
	}

	/**
	 * @return the customerMasterEnterpriseUpdateBO
	 */
	public ICustomerMasterEnterpriseUpdateBO getCustomerMasterEnterpriseUpdateBO() {
		return customerMasterEnterpriseUpdateBO;
	}

	/**
	 * @param customerMasterEnterpriseUpdateBO
	 *            the customerMasterEnterpriseUpdateBO to set
	 */
	public void setCustomerMasterEnterpriseUpdateBO(
			ICustomerMasterEnterpriseUpdateBO customerMasterEnterpriseUpdateBO) {
		this.customerMasterEnterpriseUpdateBO = customerMasterEnterpriseUpdateBO;
	}
}
