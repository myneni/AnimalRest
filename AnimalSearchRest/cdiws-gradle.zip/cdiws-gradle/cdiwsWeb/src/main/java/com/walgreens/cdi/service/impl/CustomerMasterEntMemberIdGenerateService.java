package com.walgreens.cdi.service.impl;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterEntMemberIdGenerateBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterEntMemberIdGenerateService;
import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateRequest;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateResponse;

public class CustomerMasterEntMemberIdGenerateService extends BaseService implements
		ICustomerMasterEntMemberIdGenerateService {

	ICustomerMasterEntMemberIdGenerateBO customerMasterEntMemberIdGenerateBO;

	public CustomerMasterEntMemberIdGenerateResponse generateCustomerEntMemberId(
			CustomerMasterEntMemberIdGenerateRequest customerMasterEntMemberIdGenerateRequest)
			throws CDIException

	{
		try{
			return getCustomerMasterEntMemberIdGenerateBO().callMemberIDGenerator(
					customerMasterEntMemberIdGenerateRequest);
			}
		catch (CDIException e) {
        	getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
		if(e instanceof BusinessRuleViolationException){
			ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
			return null;
		}else{
            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
            throw e;
		}}
		
	}

	public ICustomerMasterEntMemberIdGenerateBO getCustomerMasterEntMemberIdGenerateBO() {
		return customerMasterEntMemberIdGenerateBO;
	}

	public void setCustomerMasterEntMemberIdGenerateBO(
			ICustomerMasterEntMemberIdGenerateBO customerMasterEntMemberIdGenerateBO) {
		this.customerMasterEntMemberIdGenerateBO = customerMasterEntMemberIdGenerateBO;
	}

}
