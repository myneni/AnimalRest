package com.walgreens.cdi.vo.customer.attr;

import com.walgreens.cdi.util.CustomerMasterConstants;

public class CustomerMasterEmail extends CustomerMasterAttributeStatus{
	//	 (Email attribute from all sources)		
	private String emailUsageType;			//String (0/1)	AllSource EmailUsageType.
	private String emailAddress;					//String (0/1)	AllSource Email.
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the emailUsageType
	 */
	public String getEmailUsageType() {
		return emailUsageType;
	}
	/**
	 * @param emailUsageType the emailUsageType to set
	 */
	public void setEmailUsageType(String emailUsageType) {
		this.emailUsageType = emailUsageType;
	}
	
	public String toString() {
		String str="";
		str = "\nEmail:\n____________________________________\n"+
		      " emailUsageType    =" + emailUsageType + "\n"+
			  " emailAddress   =" + emailAddress + "\n" +
			  " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
			  " securityClassCode   =" + getSecurityClassCode() + "\n" +
			  " sourceCode   =" + getSourceCode() + "\n" ;
		
					
         return str;
	}
	public String toCompString() {
		String str="";
		 str = CustomerMasterConstants.DELIMITE_ATTR +
		       CustomerMasterConstants.COMP_ATTR_NAME_Email +CustomerMasterConstants.DELIMITE_FIELD +
		       emailUsageType +CustomerMasterConstants.DELIMITE_FIELD +
			   emailAddress +CustomerMasterConstants.DELIMITE_FIELD +
			   getLastUpdateDate() +CustomerMasterConstants.DELIMITE_FIELD +
			   getSecurityClassCode() +CustomerMasterConstants.DELIMITE_FIELD +
			   getSourceCode()+CustomerMasterConstants.DELIMITE_FIELD ;
		
					
         return str;
	}
	
public boolean isNull(){
		
		if(isNull(emailUsageType)&& isNull(emailAddress))
				return true;
		else
			return false;
	}
	
	 private boolean isNull(String str){
			if(str==null)
				return  true;
			if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
				return true;
			else
				return false;
		}
	
	
}
