/**
 *
 */
package com.walgreens.cdi.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.vo.CustomerMasterAttributesVO;
import com.walgreens.cdi.vo.CustomerMasterDeleteRequest;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpRequest;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateRequest;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseAttributesVO;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseProgramActionVO;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseProgramVO;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterGetRequest;
import com.walgreens.cdi.vo.CustomerMasterIcunmergeRequest;
import com.walgreens.cdi.vo.CustomerMasterLookUpRequest;
import com.walgreens.cdi.vo.CustomerMasterMergeRequest;
import com.walgreens.cdi.vo.CustomerMasterProgramActionVO;
import com.walgreens.cdi.vo.CustomerMasterProgramVO;
import com.walgreens.cdi.vo.CustomerMasterUnDeleteRequest;
import com.walgreens.cdi.vo.CustomerMasterUpdateRequest;

/**
 * @author picketta
 * 
 */
public class ValidateCustomerMasterRequest {
	public static CustomerMasterUtility cdiUtil = new CustomerMasterUtility();

	// ****************************************** Required Field validation
	/**
	 * This method validates the required fields for the Get Request
	 * 
	 * @param customerMasterGetRequest
	 * @throws BusinessRuleViolationException
	 */

	// GET
	public static void validateRequiredFields(
			CustomerMasterGetRequest customerMasterGetRequest)
			throws BusinessRuleViolationException {
		if ((!cdiUtil.isEmpty(customerMasterGetRequest.getCustSourceCode()) && cdiUtil
				.isEmpty(customerMasterGetRequest.getCustSourceID()))
				|| (cdiUtil.isEmpty(customerMasterGetRequest
						.getCustSourceCode()) && !cdiUtil
						.isEmpty(customerMasterGetRequest.getCustSourceID()))) {
			if (cdiUtil.isEmpty(customerMasterGetRequest.getCustSourceCode())) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.GET_EC_MANDATORY_FIELDS_SRC_CODE);
			}
			if (cdiUtil.isEmpty(customerMasterGetRequest.getCustSourceID())) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.GET_EC_MANDATORY_FIELDS_SRC_ID);
			}
		}

		if ((cdiUtil.isEmpty(customerMasterGetRequest.getCustSourceCode()) || cdiUtil
				.isEmpty(customerMasterGetRequest.getCustSourceID()))
				&& cdiUtil.isEmpty(customerMasterGetRequest.getCustEID())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.GET_EC_MANDATORY_FIELDS);
		}

	}

	// LOOK UP
	public static void validateRequiredFields(
			CustomerMasterLookUpRequest customerMasterLookUpRequest) {
		// NA
	}

	// ADD / UPDATE
	/**
	 * This method having logic for for mandatory field validation for Insert/Update Request
	 * 
	 * @param customerMasterUpdateRequest
	 * @return boolean
	 * @throws BusinessRuleViolationException
	 */
	public static void validateRequiredFields(
			CustomerMasterUpdateRequest customerMasterUpdateRequest)
			throws BusinessRuleViolationException {
		if (cdiUtil.isEmpty(customerMasterUpdateRequest.getSrcCode())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_MANDATORY_FIELD_SRC_CODE);
		}
		if (cdiUtil.isEmpty(customerMasterUpdateRequest.getSrcIdNum())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_MANDATORY_FIELD_SRC_ID);
		}
		if (cdiUtil.isEmpty(customerMasterUpdateRequest.getLastUpdateDate())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_MANDATORY_FIELD_LST_UPD_DATE);
		}

	}

	// MERGE
	public static void validateRequiredFields(
			CustomerMasterMergeRequest customerMasterMergeRequest)
			throws BusinessRuleViolationException {
		if (cdiUtil.isEmpty(customerMasterMergeRequest.getSrcCodeSrv())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.MERGE_EC_MANDATORY_FIELD_SRC_CODE_SRV);
		}
		if (cdiUtil.isEmpty(customerMasterMergeRequest.getMemIdnumSrv())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.MERGE_EC_MANDATORY_FIELD_SRC_ID_SRV);
		}
		if (cdiUtil.isEmpty(customerMasterMergeRequest.getSrcCodeObs())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.MERGE_EC_MANDATORY_FIELD_SRC_CODE_OBS);
		}
		if (cdiUtil.isEmpty(customerMasterMergeRequest.getMemIdnumObs())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.MERGE_EC_MANDATORY_FIELD_SRC_ID_OBS);
		}
	}

	// ICUNMERGE
	public static void validateRequiredFields(
			CustomerMasterIcunmergeRequest customerMasterIcunmergeRequest)
			throws BusinessRuleViolationException {
		if (cdiUtil.isEmpty(customerMasterIcunmergeRequest.getMemIdnumNew())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.ICUNMERGE_EC_MANDATORY_FIELD_SRC_ID_NEW);
		}
		if (cdiUtil.isEmpty(customerMasterIcunmergeRequest.getMemIdnumSrv())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.ICUNMERGE_EC_MANDATORY_FIELD_SRC_ID_SRV);
		}
		if (cdiUtil.isEmpty(customerMasterIcunmergeRequest.getLastUpdateDate())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.ICUNMERGE_EC_MANDATORY_FIELD_LST_UPD_DATE);
		}
	}

	// ****************************************** Invalid Character validation

	// GET
	public static void validateInvalidFieldValues(
			CustomerMasterGetRequest customerMasterGetRequest)
			throws BusinessRuleViolationException {
		if (!cdiUtil.isEmpty(customerMasterGetRequest.getCustSourceCode())
				&& !cdiUtil.isEmpty(customerMasterGetRequest.getCustSourceID())) {
			if (cdiUtil.containsNonAlphaCharacter(customerMasterGetRequest
					.getCustSourceCode())) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.GET_EC_INVALID_CHAR_FIELDS_SRC_CODE);
			}
			/*
			 * if(cdiUtil.containsNonNumeric(customerMasterGetRequest.getCustSourceID())){
			 * throw new
			 * BusinessRuleViolationException(CustomerMasterConstants.GET_EC_INVALID_CHAR_FIELDS_SRC_ID); }
			 */
		} else if (!cdiUtil.isEmpty(customerMasterGetRequest.getCustEID())) {
			if (cdiUtil.containsNonNumeric(customerMasterGetRequest
					.getCustEID())) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.GET_EC_INVALID_CHAR_FIELDS_EID);
			}
		}
	}

	// LOOK UP
	public static void validateInvalidFieldValues(
			CustomerMasterLookUpRequest customerMasterLookUpRequest)
			throws BusinessRuleViolationException {
		// NA
	}

	// MERGE
	public static void validateInvalidFieldValues(
			CustomerMasterMergeRequest customerMasterMergeRequest)
			throws BusinessRuleViolationException {
		if (cdiUtil.containsNonAlphaCharacter(customerMasterMergeRequest
				.getSrcCodeSrv())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.MERGE_EC_INVALID_CHAR_SRC_CODE_SRV);
		}
		if (cdiUtil.containsNonAlphaCharacter(customerMasterMergeRequest
				.getSrcCodeObs())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.MERGE_EC_INVALID_CHAR_SRC_CODE_OBS);
		}
	}

	// ICUNMERGE
	public static void validateInvalidFieldValues(
			CustomerMasterIcunmergeRequest customerMasterIcunmergeRequest)
			throws BusinessRuleViolationException {
		
		if (!cdiUtil.isEmpty(customerMasterIcunmergeRequest.getLockInd())) {
			if (!CustomerMasterConstants.ACCEPTABLE_VALUES_LOCK_IND
					.contains(customerMasterIcunmergeRequest.getLockInd() + ",")) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ICUNMERGE_EC_INVALID_LOCK_IND);
			}
		}

		if (!cdiUtil.isEmpty(customerMasterIcunmergeRequest.getPetInd())) {
			if (!CustomerMasterConstants.ACCEPTABLE_VALUES_PET_IND
					.contains(customerMasterIcunmergeRequest.getPetInd() + ",")) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ICUNMERGE_EC_INVALID_PET_IND);
			}
		}


		SimpleDateFormat sdfLstUpdDate = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		try {
			sdfLstUpdDate.parse(customerMasterIcunmergeRequest
					.getLastUpdateDate());
		} catch (Exception e) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.ICUNMERGE_EC_INVALID_DATE_FORMAT_LST_UPD_DATE);
		}
	}

	// ADD / UPDATE
	/**
	 * This method contains logic for checking  InvalidFieldValues for 
	 * (customerMasterUpdateRequest) 
	 * 
	 * @param customerMasterUpdateRequest
	 * @return boolean
	 * @throws BusinessRuleViolationException
	 */
	public static void validateInvalidFieldValues(
			CustomerMasterUpdateRequest customerMasterUpdateRequest)
			throws BusinessRuleViolationException {
		validateMaxLength(customerMasterUpdateRequest);
		// LR Specific
		if (customerMasterUpdateRequest instanceof CustomerMasterEntUpdateRequest) {
			CustomerMasterEntUpdateRequest customerMasterEntUpdateRequest = (CustomerMasterEntUpdateRequest) customerMasterUpdateRequest;
			if (cdiUtil
					.notAcceptableValue(
							customerMasterUpdateRequest.getSrcCode(),
							CustomerMasterConstants.ACCEPTABLE_ENTUPDATE_VALUES_SOURCE_CODE)) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.UPDATE_ENT_INVALID_SRC_CODE);
			}
		}// Existing Add update check- Apart from LR
		else {
			
//			Code Change start For ECOMM Validation
			if(!CustomerMasterUtility.isEmpty(customerMasterUpdateRequest.getCvControl()))
			{
				if(CustomerMasterConstants.CVCONTROL_SRC.contains(customerMasterUpdateRequest.getSrcCode()))
				{
					if(CustomerMasterUtility.notAcceptableValue(customerMasterUpdateRequest.getCvControl(), CustomerMasterConstants.ACCEPTABLE_VALUE_CV_CONTROL)){
						throw new BusinessRuleViolationException(CustomerMasterConstants.INVALID_CV_CONTROL_VAL);
					}
					else if(customerMasterUpdateRequest.getCvControl()
							.equalsIgnoreCase(CustomerMasterConstants.STRING_NULL)
							|| customerMasterUpdateRequest.getCvControl()
							.equalsIgnoreCase(CustomerMasterConstants.STRING_BLANK))
					{
						customerMasterUpdateRequest.setCvControl(CustomerMasterConstants.BLANK_VAL);
					}
				}
			}
			//	Code Change end For ECOMM Validation
			
			if (cdiUtil.notAcceptableValue(customerMasterUpdateRequest
					.getSrcCode(),
					CustomerMasterConstants.ACCEPTABLE_VALUES_SOURCE_CODE)) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.UPDATE_EC_INVALID_SRC_CODE);
			}
				
			// Phone Alignment changs start: Check to validate accepatble value
			// of phone priority value
			if ((!CustomerMasterUtility.isEmpty(customerMasterUpdateRequest
					.getPhonePriority()) && CustomerMasterUtility.notAcceptableValue(
					customerMasterUpdateRequest.getPhonePriority(),
					CustomerMasterConstants.ACCEPTABLE_VALUES_PHONE_PRIORITY))
					|| (!CustomerMasterUtility
							.isEmpty(customerMasterUpdateRequest
									.getPhone2Priority()) && CustomerMasterUtility
							.notAcceptableValue(
									customerMasterUpdateRequest
											.getPhone2Priority(),
									CustomerMasterConstants.ACCEPTABLE_VALUES_PHONE_PRIORITY))
					|| (!CustomerMasterUtility
							.isEmpty(customerMasterUpdateRequest
									.getPhoneWkPriority()) && CustomerMasterUtility
							.notAcceptableValue(
									customerMasterUpdateRequest
											.getPhoneWkPriority(),
									CustomerMasterConstants.ACCEPTABLE_VALUES_PHONE_PRIORITY))) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.UPDATE_EC_INVALID_PHONE_PRIOR_CODE);
			}
			// Phone Alignment changes end
		}
		if (cdiUtil.containsNonAlphaCharacter(customerMasterUpdateRequest
				.getSrcCode())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_CHAR_SRC_CODE);
		}

		// Commented for SRCID change
		/*
		 * if(cdiUtil.containsNonNumeric(customerMasterUpdateRequest.getSrcIdNum())){
		 * throw new
		 * BusinessRuleViolationException(CustomerMasterConstants.UPDATE_EC_INVALID_CHAR_SRC_ID); }
		 */

		
		// Loyalty : Changes have been made not to check Lock indicator for
		// Loyalty source and set to default as 'N'.
		// Wrong Lock Indicator Assignment Issue for Non Loyalty Members - Amit
		// 05/09/2013 - Moved AND clause to seperate outer if block
		if ((!CustomerMasterConstants.DEFAULT_LOCK_IND_NO_CHECK
				.contains(customerMasterUpdateRequest.getSrcCode() + ","))) {
			if (!cdiUtil.isEmpty(customerMasterUpdateRequest.getLockInd())) {
				// Added for EC Lock Ind change - Nida starts here
				if(customerMasterUpdateRequest.getSrcCode().equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC))
				{
					customerMasterUpdateRequest.setLockInd(CustomerMasterConstants.VALUE_N);
				} // Added for EC Lock Ind change - Nida ends here
				else if (CustomerMasterConstants.DEFAULT_LOCK_IND_N_SOURCES
						.contains(customerMasterUpdateRequest.getSrcCode()
								+ ",")) {
					if (!customerMasterUpdateRequest.getLockInd()
							.equalsIgnoreCase(CustomerMasterConstants.VALUE_N)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.UPDATE_EC_INVALID_LOCK_IND);
					}
				} else if (CustomerMasterConstants.DEFAULT_LOCK_IND_Y_SOURCES
						.contains(customerMasterUpdateRequest.getSrcCode()
								+ ",")) {
					if (!customerMasterUpdateRequest.getLockInd()
							.equalsIgnoreCase(CustomerMasterConstants.VALUE_Y)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.UPDATE_EC_INVALID_LOCK_IND);
					}
				}

				if (!customerMasterUpdateRequest.getLockInd().equalsIgnoreCase(
						CustomerMasterConstants.VALUE_Y)
						&& !customerMasterUpdateRequest.getLockInd()
								.equalsIgnoreCase(
										CustomerMasterConstants.VALUE_N)
						&& !customerMasterUpdateRequest.getLockInd()
								.equalsIgnoreCase(
										CustomerMasterConstants.VALUE_H)
						&& !customerMasterUpdateRequest.getLockInd()
								.equalsIgnoreCase(
										CustomerMasterConstants.VALUE_R)) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.UPDATE_EC_INVALID_LOCK_IND);
				}
			}
		} else {
			customerMasterUpdateRequest.setLockInd("N");
		}

		// Loyalty : Changes have been made not to check PET indicator for
		// Loyalty source and set to default as 'N'.
		// Wrong Pet Indicator Assignment Issue for Non Loyalty Members - Amit
		// 05/09/2013 - Moved AND clause to seperate outer if block
		if ((!CustomerMasterConstants.DEFAULT_PET_IND_NO_CHECK
				.contains(customerMasterUpdateRequest.getSrcCode() + ","))) {
			if (!cdiUtil.isEmpty(customerMasterUpdateRequest.getPetInd())) {
				if (CustomerMasterConstants.DEFAULT_PET_IND_N_SOURCES
						.contains(customerMasterUpdateRequest.getSrcCode()
								+ ",")) {
					if (!customerMasterUpdateRequest.getPetInd()
							.equalsIgnoreCase(CustomerMasterConstants.VALUE_N)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.UPDATE_EC_INVALID_PET_IND);
					}
				} else if (CustomerMasterConstants.DEFAULT_PET_IND_Y_SOURCES
						.contains(customerMasterUpdateRequest.getSrcCode()
								+ ",")) {
					if (!customerMasterUpdateRequest.getPetInd()
							.equalsIgnoreCase(CustomerMasterConstants.VALUE_Y)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.UPDATE_EC_INVALID_PET_IND);
					}
				}

				if (!customerMasterUpdateRequest.getPetInd().equalsIgnoreCase(
						CustomerMasterConstants.VALUE_Y)
						&& !customerMasterUpdateRequest.getPetInd()
								.equalsIgnoreCase(
										CustomerMasterConstants.VALUE_N)) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.UPDATE_EC_INVALID_PET_IND);
				}
			}
		} else {
			customerMasterUpdateRequest.setPetInd("N");

		}

		// Loyalty : Changes have been made not to check Security Code for
		// Loyalty source and set to default as 'P'.
		if (!cdiUtil.isEmpty(customerMasterUpdateRequest.getSecCode())
				&& (!CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_NO_CHECK
						.contains(customerMasterUpdateRequest.getSrcCode()
								+ ","))) {
			if (CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_H_SOURCES
					.contains(customerMasterUpdateRequest.getSrcCode() + ",")) {
				if (!customerMasterUpdateRequest.getSecCode().equalsIgnoreCase(
						CustomerMasterConstants.SEC_CLASS_CODE_H)) {

					customerMasterUpdateRequest.setSecCode("H");
					// throw new
					// BusinessRuleViolationException(CustomerMasterConstants.UPDATE_EC_INVALID_SEC_CLASS_CODE);
				}
			} else if (CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_P_SOURCES
					.contains(customerMasterUpdateRequest.getSrcCode() + ",")) {
				if (!customerMasterUpdateRequest.getSecCode().equalsIgnoreCase(
						CustomerMasterConstants.SEC_CLASS_CODE_P)) {

					customerMasterUpdateRequest.setSecCode("P");
					// throw new
					// BusinessRuleViolationException(CustomerMasterConstants.UPDATE_EC_INVALID_SEC_CLASS_CODE);
				}
			}

			if (!customerMasterUpdateRequest.getSecCode().equalsIgnoreCase(
					CustomerMasterConstants.SEC_CLASS_CODE_P)
					&& !customerMasterUpdateRequest.getSecCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SEC_CLASS_CODE_H)) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.UPDATE_EC_INVALID_SEC_CLASS_CODE);
			}
		} else {
			// Reject message , if Sec code is coming blank for EC.
			// Commenting out below check 08/22/13 due to prod issue
			/*
			 * if(CustomerMasterConstants.SRC_CODE_EC.equalsIgnoreCase(customerMasterUpdateRequest.getSrcCode())){
			 * throw new
			 * BusinessRuleViolationException(CustomerMasterConstants.UPDATE_EC_MANDATE_SEC_CLASS_CODE); }
			 */
			if (CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_H_SOURCES
					.contains(customerMasterUpdateRequest.getSrcCode() + ",")) {
				customerMasterUpdateRequest.setSecCode("H");
			} else if (CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_P_SOURCES
					.contains(customerMasterUpdateRequest.getSrcCode() + ","))/*
																				 * ||
																				 * (CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_NO_CHECK.contains(customerMasterUpdateRequest.getSrcCode())))
																				 */
			{
				customerMasterUpdateRequest.setSecCode("P");
			}
		}

		// SimpleDateFormat sdfBDate = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdfLstUpdDate = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		try {
			sdfLstUpdDate
					.parse(customerMasterUpdateRequest.getLastUpdateDate());
		} catch (Exception e) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_DATE_FORMAT_LST_UPD_DATE);
		}
	}

	public static void validateMaxLength(
			CustomerMasterUpdateRequest customerMasterUpdateRequest)
			throws BusinessRuleViolationException {
		if (!cdiUtil.isEmpty(customerMasterUpdateRequest.getSrcCode())
				&& cdiUtil.exceedsMaxLength(customerMasterUpdateRequest
						.getSrcCode().trim(),
						CustomerMasterConstants.MAX_LENGTH_SOURCE_CODE)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_SRC_CODE);
		}

		if (!cdiUtil.isEmpty(customerMasterUpdateRequest.getSrcIdNum())
				&& cdiUtil.exceedsMaxLength(customerMasterUpdateRequest
						.getSrcIdNum().trim(),
						CustomerMasterConstants.MAX_LENGTH_SOURCE_ID)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_SRC_ID);
		}

		if (!cdiUtil.isEmpty(customerMasterUpdateRequest.getLastUpdateDate())
				&& cdiUtil.exceedsMaxLength(customerMasterUpdateRequest
						.getLastUpdateDate().trim(),
						CustomerMasterConstants.MAX_LENGTH_LAST_UPDATE_DATE)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_DATE_FORMAT_LST_UPD_DATE);
		}

		if (!cdiUtil.isEmpty(customerMasterUpdateRequest.getPetInd())
				&& cdiUtil.exceedsMaxLength(customerMasterUpdateRequest
						.getPetInd().trim(),
						CustomerMasterConstants.MAX_LENGTH_PET_IND)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_PET_IND);
		}

		if (!cdiUtil.isEmpty(customerMasterUpdateRequest.getLockInd())
				&& cdiUtil.exceedsMaxLength(customerMasterUpdateRequest
						.getLockInd().trim(),
						CustomerMasterConstants.MAX_LENGTH_LOCK_IND)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_LOCK_IND);
		}

		if (!cdiUtil.isEmpty(customerMasterUpdateRequest.getSecCode())
				&& cdiUtil.exceedsMaxLength(customerMasterUpdateRequest
						.getSecCode().trim(),
						CustomerMasterConstants.MAX_LENGTH_SEC_CLASS_CODE)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_SEC_CLASS_CODE);
		}
	}

	/**
	 * This method will throw an exception with customized message and error
	 * code , if either of the mandatory field (Source Code or Source ID) found
	 * missing in the request of EC delete service.
	 * 
	 * @param customerMasterDeleteRequest
	 * @throws BusinessRuleViolationException
	 */
	public static void validateRequiredFields(
			CustomerMasterDeleteRequest customerMasterDeleteRequest)
			throws BusinessRuleViolationException {
		if (cdiUtil.isEmpty(customerMasterDeleteRequest.getSourceCode())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.EC_DELETE_MANDATORY_FIELDS_SRC_CODE);
		} else if (cdiUtil.isEmpty(customerMasterDeleteRequest.getSourceId())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.EC_DELETE_MANDATORY_FIELDS_SRC_ID);
		}

	}

	/*
	 * Following method will validate Program code in LR Add\Update request, if
	 * Program Array is present. 1) Program Code should not be blank 2) Program
	 * Code should be from the list of valid codes 3) Prog Id should not be
	 * blank other than VCD. 4) Prog Array and Prog Action Array count should be
	 * the same. 5) Prog Code should match between both the arrays. 6) Prog ID
	 * should match between both the arrays. 7) Prog Action should not be blank
	 * and should have designated values. 8) Prog Status should not be blank and
	 * should have designated values.
	 */
	public static void validateProgramDetails(
			CustomerMasterEntUpdateRequest customerMasterEntUpdateRequest)
			throws BusinessRuleViolationException {
		if (null != customerMasterEntUpdateRequest) {
			ArrayList<CustomerMasterProgramVO> custProgIdArray = customerMasterEntUpdateRequest
					.getCustProgIdArray();
			ArrayList<CustomerMasterProgramActionVO> custProgActionArray = customerMasterEntUpdateRequest
					.getCustProgActionArray();
			ArrayList<CustomerMasterAttributesVO> custMasterAttribute = customerMasterEntUpdateRequest
					.getCustArrayOfAttributes();
			// if block changed for ProgIdarray and progactionarray size
			// mismatch
			// Silky Added
			boolean isEMPLProgramAvailable = false;
			
			if (!custProgIdArray.isEmpty() || !custProgActionArray.isEmpty()) {

				int length = custProgIdArray.size();
				int len = custProgActionArray.size();
				// Both Program Array and Program Action Array count should be
				// same.
				if (len != length) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.ARRAY_COUNT_MISMATCH);
				}
				String programCode = "";
				String programID = "";
				String programStatus = "";
				String progStartDate = "";
				String progExpDate = "";

				String programCodeActionArray = "";
				String progIdActionArray = "";
				String progActionArray = "";
				String progLastUpdate = "";
				// Code Change start For Duplicate ProgramCode+ProgramId in
				// Request
				Set<String> progSet = new HashSet<String>();
				for (int progCounter = 0; progCounter < length; progCounter++) {
					CustomerMasterProgramVO customerMasterProgramVO = custProgIdArray
							.get(progCounter);
					String progCodeID = customerMasterProgramVO
							.getProgramCode().toUpperCase()
							+ customerMasterProgramVO.getProgramId();
					if (!progSet.add(progCodeID)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.DUPLICATE_PROGCODE_PROGID);

					}

				}
				int emplCount = 0;
				// Code Change End For Duplicate ProgramCode+ProgramId in
				// Request
				for (int index = 0; index < length; index++) {
					CustomerMasterProgramVO customerMasterProgramVO = custProgIdArray
							.get(index);
					programCode = customerMasterProgramVO.getProgramCode();
					programID = customerMasterProgramVO.getProgramId();
					programStatus = customerMasterProgramVO.getProgramStatus();
					progStartDate = customerMasterProgramVO.getProgStartDt();
					progExpDate = customerMasterProgramVO.getProgExpDt();
					progLastUpdate = customerMasterProgramVO.getProgLstUpDt();

					CustomerMasterProgramActionVO customerMasterProgramActionVO = custProgActionArray
							.get(index);
					programCodeActionArray = customerMasterProgramActionVO
							.getProgramCode();
					progIdActionArray = customerMasterProgramActionVO
							.getProgramId();
					progActionArray = customerMasterProgramActionVO
							.getProgramAction();

					if (!customerMasterProgramVO.isNull()) {
						if (cdiUtil.isEmpty(programCode)
								|| cdiUtil.isEmpty(programCodeActionArray)) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.PROGRAM_CODE_MISSING);
						} else {
							if (!programCode
									.equalsIgnoreCase(programCodeActionArray)) {
								throw new BusinessRuleViolationException(
										CustomerMasterConstants.PROGRAM_CODE_NOT_MATCHING_WITHIN_ARRAY);
							}

							if (cdiUtil
									.notAcceptableValue(
											programCode,
											CustomerMasterConstants.ACCEPTABLE_ENTUPDATE_PROGRAM_CODE_VALUES)
									|| (cdiUtil
											.notAcceptableValue(
													programCodeActionArray,
													CustomerMasterConstants.ACCEPTABLE_ENTUPDATE_PROGRAM_CODE_VALUES))) {
								throw new BusinessRuleViolationException(
										CustomerMasterConstants.NOT_A_VALID_PROGRAM_CODE_ADD_UPDATE);
							}
						}
						if (!progIdActionArray.equalsIgnoreCase(programID)) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.PROGRAM_ID_NOT_MATCHING_WITHIN_ARRAY);
						}
						if (cdiUtil.isEmpty(programID)
								&& (!programCode
										.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_VCD) && !cdiUtil
										.isEmpty(programCode))
								|| cdiUtil.isEmpty(progIdActionArray)
								&& (!programCode
										.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_VCD) && !cdiUtil
										.isEmpty(programCodeActionArray))) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.PROGRAM_IDENTIFIER_MISSING);
						}
						if (!cdiUtil.isEmpty(progIdActionArray)
								&& cdiUtil
										.notAcceptableValue(
												progActionArray,
												CustomerMasterConstants.ACCEPTABLE_PROGRAM_ACTION_VALUES)) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.INVALID_PROGRAM_ACTION_VALUE);
						}
						if (cdiUtil.isEmpty(progActionArray)) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.PROGRAM_ACTION_MISSING);
						}

						if (programCode
								.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_EMPL)) {
							emplCount++;
							isEMPLProgramAvailable = true;
						}
						// Commenting to accept blank values for program dates
						// and status.
					}
				}
				if (emplCount > 1) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.MULTIPLE_EMPL_BENEFIT);
				}

			}
			// Silky Added - Commented by ankit
			
			if (!custMasterAttribute.isEmpty()) {
				int countArray = custMasterAttribute.size();
				// @Ankit - Added in order to handle loyalty attributes benefits
				// in Incoming Requests
				int countLoyatlyCard = 0;
				int countSecretCode = 0;

				for (int count = 0; count < countArray; count++) {
					CustomerMasterAttributesVO custMasterAttributesVO = (CustomerMasterAttributesVO) custMasterAttribute
							.get(count);
					if (null != custMasterAttributesVO) {
						if (null != custMasterAttributesVO.getCdiKey()) {
							if (cdiUtil.notAcceptableValue(
									custMasterAttributesVO.getCdiKey(),
									CustomerMasterConstants.ACCEPTABLE_CDI_KEY)) {
								throw new BusinessRuleViolationException(
										CustomerMasterConstants.NOT_A_VALID_CDIKEY);
							} else {
								if (custMasterAttributesVO
										.getCdiKey()
										.equalsIgnoreCase(
												CustomerMasterConstants.STR_VERFICATION_CODE)
										&& custMasterAttributesVO.getCdiValue() != null
										&& !custMasterAttributesVO
												.getCdiValue()
												.equalsIgnoreCase("")) {
									countSecretCode++;

								} else if (custMasterAttributesVO
										.getCdiKey()
										.equalsIgnoreCase(
												CustomerMasterConstants.STR_EECARDNO)
										&& custMasterAttributesVO.getCdiValue() != null
										&& !custMasterAttributesVO
												.getCdiValue()
												.equalsIgnoreCase("")) {
									countLoyatlyCard++;
								}
							}
						} else if (null != custMasterAttributesVO.getCdiValue()) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.CDIKEY_MISSING);
						}
					}
				}
				// @Ankit - Added in order to check multiple loyalty attributes
				// in the request
				if (countSecretCode > 1 || countLoyatlyCard > 1) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.MULTIPLE_LR_EMPL_ATTR);
				}
				// @Ankit - Added in order to check presence of both the
				// attributes in the request
				else if ((countSecretCode == 1 && countLoyatlyCard != 1)
						|| (countLoyatlyCard == 1 && countSecretCode != 1)) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.LR_EMPL_ATTR_INCOMPLETE);
				}
				// @Ankit 6-feb-2013
				else if (!((isEMPLProgramAvailable && countSecretCode == 1 && countLoyatlyCard == 1) || (countSecretCode != 1
						&& countLoyatlyCard != 1 && !isEMPLProgramAvailable))) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.LR_EMPL_BENEFIT_INCOMPLETE);
				}

			}
		}
	}

	/**
	 * This method validates that the minimum age required for LR member is
	 * greater than 13.
	 * 
	 * @param dateOfBirth
	 * @throws BusinessRuleViolationException
	 */
	public static void validateMinimumAgeRequired(String dateOfBirth)
			throws BusinessRuleViolationException {
		if (null != dateOfBirth) {
			/*
			 * Validation has added to handle soft delete of Birth Date for
			 * Enterprise Add/Update Service.
			 */
			if (!cdiUtil.hasSoftDeleteKey(dateOfBirth)) {
				Calendar today = Calendar.getInstance();
				Calendar birthDate = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat(
						CustomerMasterConstants.BDATE_FORMAT);
				int age = 0;
				try {
					Date dob = sdf.parse(dateOfBirth);
					birthDate.setTime(dob);

					if (birthDate.after(today)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.BDATE_AGE_FORMAT_ERROR);
					}
					age = today.get(Calendar.YEAR)
							- birthDate.get(Calendar.YEAR);

					// If birth date is greater than todays date (after 2 days
					// adjustment of leap year) then decrement age one year
					if ((birthDate.get(Calendar.DAY_OF_YEAR)
							- today.get(Calendar.DAY_OF_YEAR) > 3)
							|| (birthDate.get(Calendar.MONTH) > today
									.get(Calendar.MONTH))) {
						age--;

					}
					// If birth date and todays date are of same month and birth
					// day of month is greater than todays day of month then
					// decrement age
					else if ((birthDate.get(Calendar.MONTH) == today
							.get(Calendar.MONTH))
							&& (birthDate.get(Calendar.DAY_OF_MONTH) > today
									.get(Calendar.DAY_OF_MONTH))) {
						age--;
					}
				} catch (Exception ex) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.BDATE_AGE_FORMAT_ERROR);
				}

				if (age < CustomerMasterConstants.MINIMUM_AGE_REQUIRED) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.MINIMUM_AGE_VALIDATION);
				}

			}
		}
	}

	public static void validateRequiredFields(
			CustomerMasterEntLookUpRequest customerMasterEntLookUpRequest)
			throws BusinessRuleViolationException {
		if ((!cdiUtil.isEmpty(customerMasterEntLookUpRequest.getProgramCode()) && cdiUtil
				.isEmpty(customerMasterEntLookUpRequest.getProgramIdentifier()))
				|| (cdiUtil.isEmpty(customerMasterEntLookUpRequest
						.getProgramCode()) && (!cdiUtil
						.isEmpty(customerMasterEntLookUpRequest
								.getProgramIdentifier())))) {
			if (cdiUtil
					.isEmpty(customerMasterEntLookUpRequest.getProgramCode())) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.MISSING_PROGRAM_CODE);
			} else if (cdiUtil.isEmpty(customerMasterEntLookUpRequest
					.getProgramIdentifier())) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.MISSING_PROGRAM_ID);
			}
		}
		
		if (cdiUtil.isEmpty(customerMasterEntLookUpRequest
				.getSearchCalibrateCd())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.ENT_SEARCH_EMPTY_CALIBRATION_CODE);
		}

		if (cdiUtil.isEmpty(customerMasterEntLookUpRequest.getMemSearchSrc())
				&& cdiUtil.isEmpty(customerMasterEntLookUpRequest
						.getEntSearchSrc())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.ENT_SEARCH_ENT_MEM_SEARCHSRC_ABS);
		}

	}

	public static void validateInvalidFieldValues(
			CustomerMasterEntLookUpRequest customerMasterEntLookUpRequest)
			throws BusinessRuleViolationException {

		if ((!cdiUtil.isEmpty(customerMasterEntLookUpRequest.getProgramCode()))
				&& cdiUtil
						.notAcceptableValue(
								customerMasterEntLookUpRequest.getProgramCode(),
								CustomerMasterConstants.ACCEPTABLE_ENTSEARCH_PROGRAM_CODE_VALUES)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.NOT_A_VALID_PROGRAM_CODE);
		}

		if (!cdiUtil.isEmpty(customerMasterEntLookUpRequest.getMemSearchSrc())) {
			String[] tempArray = customerMasterEntLookUpRequest
					.getMemSearchSrc().split(
							CustomerMasterConstants.SPLIT_PIPE_DELIMITER);
			for (int i = 0; i < tempArray.length; i++) {
				if (cdiUtil.notAcceptableValue(tempArray[i],
						CustomerMasterConstants.ACCEPTABLE_SRCCODE_VALUE))
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.ENT_SEARCH_INVAL_SRCCODE);
			}
		}

		if (!cdiUtil.isEmpty(customerMasterEntLookUpRequest.getEntSearchSrc())) {
			String[] tempArray2 = customerMasterEntLookUpRequest
					.getEntSearchSrc().split(
							CustomerMasterConstants.SPLIT_PIPE_DELIMITER);
			for (int i = 0; i < tempArray2.length; i++) {
				if (cdiUtil.notAcceptableValue(tempArray2[i],
						CustomerMasterConstants.ACCEPTABLE_SRCCODE_VALUE))
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.ENT_SEARCH_INVAL_SRCCODE);
			}
		}

		if (!CustomerMasterConstants.CALIBRATION_CODE
				.contains(customerMasterEntLookUpRequest.getSearchCalibrateCd()
						.toUpperCase())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.ENT_SEARCH_INVAL_CALIBRATION_CODE);
		}

		if (!cdiUtil.isEmpty(customerMasterEntLookUpRequest
				.getMemSearchMinMatchScore())) {
			try {
				float num = Float.parseFloat(customerMasterEntLookUpRequest
						.getMemSearchMinMatchScore());
				num = num * 10;
			} catch (Exception e) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.MEM_SEARCH_INVAL_MIN_SCORE);
			}
		}

		
		if (!cdiUtil.isEmpty(customerMasterEntLookUpRequest
				.getEntSearchMinMatchScore())) {
			try {
				float num = Float.parseFloat(customerMasterEntLookUpRequest
						.getEntSearchMinMatchScore());
				num = num * 10;
			} catch (Exception e) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ENT_SEARCH_INVAL_MIN_SCORE);
			}
		}

		if (!cdiUtil.isEmpty(customerMasterEntLookUpRequest.getMemSearchStat())) {
			String[] tempArray3 = customerMasterEntLookUpRequest
					.getMemSearchStat().split(
							CustomerMasterConstants.SPLIT_PIPE_DELIMITER);
			for (int i = 0; i < tempArray3.length; i++) {
				if (cdiUtil.notAcceptableValue(tempArray3[i],
						CustomerMasterConstants.ACCEPTABLE_MEM_STATUS_VALUE))
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.ENT_SEARCH_INVAL_MEMSTATUS);
			}
		}

	}

	public static void validateRequestProgramCode(
			CustomerMasterEntMemberIdGenerateRequest memberIDRequest)
			throws BusinessRuleViolationException {

		if (memberIDRequest.getProgCodeArray().size() == 0) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.ID_SERVICE_PROGRAM_CODE_ISMISSING);
		}

		for (int i = 0; i < memberIDRequest.getProgCodeArray().size(); i++) {
			if (CustomerMasterUtility.isEmpty(memberIDRequest
					.getProgCodeArray().get(i).getProgCode())) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ID_SERVICE_PROGRAM_CODE_ISMISSING);
			}
			if (!((memberIDRequest.getProgCodeArray().get(i).getProgCode()
					.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_LYCD))
					|| (memberIDRequest.getProgCodeArray().get(i).getProgCode()
							.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_VCD)) ||

			(memberIDRequest.getProgCodeArray().get(i).getProgCode()
					.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_MEMID)))) {

				throw new BusinessRuleViolationException(
						CustomerMasterConstants.INVALID_ID_PROGRAM_CODE);
			}
		}
	}
	/**
	 * This method checks if any of the mandatory field missing from the input
	 * request. If it is missing then this method will throw an exception with
	 * custom error code and error message. This method of
	 * ValidateCustomerMasterRequest is invoked by CustomerMasterUnDeleteBO
	 * 
	 * @aram customerMasterUnDeleteRequest throwsBusinessRuleViolationException
	 */
	public static void validateRequiredFields(
			CustomerMasterUnDeleteRequest customerMasterUnDeleteRequest)
			throws BusinessRuleViolationException {

		if (CustomerMasterUtility.isEmpty(customerMasterUnDeleteRequest.getSourceCode())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.EC_DELETE_MANDATORY_FIELDS_SRC_CODE);
		} else if (CustomerMasterUtility.isEmpty(customerMasterUnDeleteRequest.getSourceId())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.EC_DELETE_MANDATORY_FIELDS_SRC_ID);
		}

	}
	
	/**
	 * This method checks if any of the mandatory field missing from the input
	 * request. If it is missing then this method will throw an exception with
	 * custom error code and error message. This method of
	 * ValidateCustomerMasterRequest is invoked by CustomerMasterEnterpriseUpdateBO
	 * 
	 * @param customerMasterEnterpriseUpdateRequest throwsBusinessRuleViolationException
	 */
	public static void validateRequiredFields(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws BusinessRuleViolationException {
		if (CustomerMasterUtility.isEmpty(customerMasterEnterpriseUpdateRequest
				.getSrcCode())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_MANDATORY_FIELD_SRC_CODE);
		}
		if (CustomerMasterUtility.isEmpty(customerMasterEnterpriseUpdateRequest
				.getSrcIdNum())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_MANDATORY_FIELD_SRC_ID);
		}
		if (CustomerMasterUtility.isEmpty(customerMasterEnterpriseUpdateRequest
				.getLastUpdateDate())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_MANDATORY_FIELD_LST_UPD_DATE);
		}

	}
	
	//Code Change start for EnterPrise Search
	/**
	 * This method validates the required fields for the CustomerMasterEnterpriseLookUpRequest 
	 * 
	 * @param CustomerMasterEnterpriseLookUpRequest
	 * @throws BusinessRuleViolationException
	 */

	public static void validateRequiredFields(
			CustomerMasterEnterpriseLookUpRequest customerMasterEnterpriseLookUpRequest,boolean validateSearchLevel2)
			throws BusinessRuleViolationException {
		if ((!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseLookUpRequest.getProgramCode()) && CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseLookUpRequest
						.getProgramIdentifier()))
				|| (CustomerMasterUtility
						.isEmpty(customerMasterEnterpriseLookUpRequest
								.getProgramCode()) && (!CustomerMasterUtility
						.isEmpty(customerMasterEnterpriseLookUpRequest
								.getProgramIdentifier())))) {
			if (CustomerMasterUtility
					.isEmpty(customerMasterEnterpriseLookUpRequest
							.getProgramCode())) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.MISSING_PROGRAM_CODE);
			} else if (CustomerMasterUtility
					.isEmpty(customerMasterEnterpriseLookUpRequest
							.getProgramIdentifier())) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.MISSING_PROGRAM_ID);
			}
		}
		
		// logic addition start to throw exception if minscore and max rows fields are empty
		 if(CustomerMasterUtility.isEmpty(customerMasterEnterpriseLookUpRequest.getMinMatchScore())){
			 throw new BusinessRuleViolationException(CustomerMasterConstants.MISSING_MIN_MATCH_SCORE);
			 
		 }
		
		if(CustomerMasterUtility.isEmpty(customerMasterEnterpriseLookUpRequest.getMaxResponse())){
			throw new BusinessRuleViolationException(CustomerMasterConstants.MISSING_MAX_ROWS_COUNT);
		}
		// logic addition end to throw exception if minscore and max rows fields are empty
		
		
		
		
		// PC realtime change starts
		//validate search level1
		validateEnterpriseSearchLevel(
				customerMasterEnterpriseLookUpRequest.getSearchType1(),
				customerMasterEnterpriseLookUpRequest.getSearchSource1(),
				customerMasterEnterpriseLookUpRequest.getCvType1());
		//validate search level2
		if (validateSearchLevel2)
		{	
		validateEnterpriseSearchLevel(
				customerMasterEnterpriseLookUpRequest.getSearchType2(),
				customerMasterEnterpriseLookUpRequest.getSearchSource2(),
				customerMasterEnterpriseLookUpRequest.getCvType2());
		}
		// PC realtime change ends
	}
	//Application ID added as a part of PCC_CR change
	public static void validateInvalidFieldValues(
			CustomerMasterEnterpriseLookUpRequest customerMasterEnterpriseLookUpRequest,boolean validateSearchLevel2,
			String applicationId)
			throws BusinessRuleViolationException {
		
		if ((!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseLookUpRequest.getProgramCode()))
				&& CustomerMasterUtility
						.notAcceptableValue(
								customerMasterEnterpriseLookUpRequest
										.getProgramCode(),
								CustomerMasterConstants.ACCEPTABLE_ENTSEARCH_PROGRAM_CODE_VALUES)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.NOT_A_VALID_PROGRAM_CODE);
		}

		if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseLookUpRequest
						.getMinMatchScore())) {
			try {
				float num = Float
						.parseFloat(customerMasterEnterpriseLookUpRequest
								.getMinMatchScore());
				num = num * 10;
				if(num<0)
				{	
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.INVALID_MIN_MATCH_SCORE);
				}
			} catch (Exception e) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.INVALID_MIN_MATCH_SCORE);
			}
		}
		if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseLookUpRequest
						.getMaxResponse())) {
			try {
				long maxResP=Long.parseLong(customerMasterEnterpriseLookUpRequest
						.getMaxResponse());
				if(maxResP<0)
				{	
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.INVALID_MAX_RESPONSE);
				}
			} catch (Exception e) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.INVALID_MAX_RESPONSE);
			}
		}

		if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseLookUpRequest
						.getMemSearchStat())) {
			String[] tempArray3 = customerMasterEnterpriseLookUpRequest
					.getMemSearchStat().split(
							CustomerMasterConstants.SPLIT_PIPE_DELIMITER);
			for (int i = 0; i < tempArray3.length; i++) {
				if (CustomerMasterUtility.notAcceptableValue(tempArray3[i],
						CustomerMasterConstants.ACCEPTABLE_MEM_STATUS_VALUE))
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.ENT_SEARCH_INVAL_MEMSTATUS);
			}
		}
		//Application ID added as a part of PCC_CR change
		validateEnterprise(customerMasterEnterpriseLookUpRequest.getSearchType1(), customerMasterEnterpriseLookUpRequest.getSearchSource1(),customerMasterEnterpriseLookUpRequest.getCvType1(),applicationId);
		if(validateSearchLevel2)
		validateEnterprise(customerMasterEnterpriseLookUpRequest.getSearchType2(), customerMasterEnterpriseLookUpRequest.getSearchSource2(),customerMasterEnterpriseLookUpRequest.getCvType2(),applicationId);
	}

	/**
	 * This method checks for any invalid source code If any invalid source code
	 * is found then this method will throw an exception with custom error code
	 * and error message. This method of ValidateCustomerMasterRequest is
	 * invoked by CustomerMasterEnterpriseUpdateBO
	 * 
	 * @param customerMasterEnterpriseUpdateRequest
	 * @throws BusinessRuleViolationException
	 */
	// Code Change For PC Realtime Update
	public static void validateInvalidFieldValues(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws BusinessRuleViolationException {

		validateMaxLength(customerMasterEnterpriseUpdateRequest);
		// LR Specific
		if (CustomerMasterUtility
				.notAcceptableValue(
						customerMasterEnterpriseUpdateRequest.getSrcCode(),
						CustomerMasterConstants.ACCEPTABLE_ENTERPRISE_UPDATE_VALUES_SOURCE_CODE)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_ENT_INVALID_SRC_CODE);
		} else {

			// Code Change start For ECOMM Validation
			if (!CustomerMasterUtility
					.isEmpty(customerMasterEnterpriseUpdateRequest
							.getCvControl())) {
				if (CustomerMasterConstants.CVCONTROL_SRC
						.contains(customerMasterEnterpriseUpdateRequest
								.getSrcCode())) {
					if (CustomerMasterUtility
							.notAcceptableValue(
									customerMasterEnterpriseUpdateRequest
											.getCvControl(),
									CustomerMasterConstants.ACCEPTABLE_VALUE_CV_CONTROL)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.INVALID_CV_CONTROL_VAL);
					} else if (customerMasterEnterpriseUpdateRequest
							.getCvControl().equalsIgnoreCase(
									CustomerMasterConstants.STRING_NULL)
							|| customerMasterEnterpriseUpdateRequest
									.getCvControl()
									.equalsIgnoreCase(
											CustomerMasterConstants.STRING_BLANK)) {
						customerMasterEnterpriseUpdateRequest
								.setCvControl(CustomerMasterConstants.BLANK_VAL);
					}
				}
			}
			// Code Change end For ECOMM Validation
			// Phone Alignment changs start: Check to validate acceptable value
			// of phone priority value
			if ((!CustomerMasterUtility
					.isEmpty(customerMasterEnterpriseUpdateRequest
							.getPhonePriority()) && CustomerMasterUtility
					.notAcceptableValue(
							customerMasterEnterpriseUpdateRequest
									.getPhonePriority(),
							CustomerMasterConstants.ACCEPTABLE_VALUES_PHONE_PRIORITY))
					|| (!CustomerMasterUtility
							.isEmpty(customerMasterEnterpriseUpdateRequest
									.getPhone2Priority()) && CustomerMasterUtility
							.notAcceptableValue(
									customerMasterEnterpriseUpdateRequest
											.getPhone2Priority(),
									CustomerMasterConstants.ACCEPTABLE_VALUES_PHONE_PRIORITY))
					|| (!CustomerMasterUtility
							.isEmpty(customerMasterEnterpriseUpdateRequest
									.getPhoneWkPriority()) && CustomerMasterUtility
							.notAcceptableValue(
									customerMasterEnterpriseUpdateRequest
											.getPhoneWkPriority(),
									CustomerMasterConstants.ACCEPTABLE_VALUES_PHONE_PRIORITY))) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.UPDATE_EC_INVALID_PHONE_PRIOR_CODE);
			}
			// Phone Alignment changes end
		}
		if (CustomerMasterUtility
				.containsNonAlphaCharacter(customerMasterEnterpriseUpdateRequest
						.getSrcCode())) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_CHAR_SRC_CODE);
		}

		if ((!CustomerMasterConstants.DEFAULT_LOCK_IND_NO_CHECK
				.contains(customerMasterEnterpriseUpdateRequest.getSrcCode()
						+ CustomerMasterConstants.COMA_DELIMITER))) {
			if (!CustomerMasterUtility
					.isEmpty(customerMasterEnterpriseUpdateRequest.getLockInd())) {
				// Added for EC Lock Ind change - Nida starts here
				if (customerMasterEnterpriseUpdateRequest.getSrcCode()
						.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
					customerMasterEnterpriseUpdateRequest
							.setLockInd(CustomerMasterConstants.VALUE_N);
				}
				// Added for EC Lock Ind change - Nida ends here else
				if (CustomerMasterConstants.DEFAULT_LOCK_IND_N_SOURCES_ENTERPRISE
						.contains(customerMasterEnterpriseUpdateRequest
								.getSrcCode()
								+ CustomerMasterConstants.COMA_DELIMITER)) {
					if (!customerMasterEnterpriseUpdateRequest.getLockInd()
							.equalsIgnoreCase(CustomerMasterConstants.VALUE_N)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.UPDATE_EC_INVALID_LOCK_IND);
					}
				} else if (CustomerMasterConstants.DEFAULT_LOCK_IND_Y_SOURCES
						.contains(customerMasterEnterpriseUpdateRequest
								.getSrcCode()
								+ CustomerMasterConstants.COMA_DELIMITER)) {
					if (!customerMasterEnterpriseUpdateRequest.getLockInd()
							.equalsIgnoreCase(CustomerMasterConstants.VALUE_Y)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.UPDATE_EC_INVALID_LOCK_IND);
					}
				}

				if (!(CustomerMasterConstants.NOCHECK_LOCK_PET_SEC_IND_SOURCES.contains(customerMasterEnterpriseUpdateRequest.getSrcCode()))&& !customerMasterEnterpriseUpdateRequest.getLockInd()
						.equalsIgnoreCase(CustomerMasterConstants.VALUE_Y)
						&& !customerMasterEnterpriseUpdateRequest.getLockInd()
								.equalsIgnoreCase(
										CustomerMasterConstants.VALUE_N)
						&& !customerMasterEnterpriseUpdateRequest.getLockInd()
								.equalsIgnoreCase(
										CustomerMasterConstants.VALUE_H)
						&& !customerMasterEnterpriseUpdateRequest.getLockInd()
								.equalsIgnoreCase(
										CustomerMasterConstants.VALUE_R)) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.UPDATE_EC_INVALID_LOCK_IND);
				}
			}
		} else {
			customerMasterEnterpriseUpdateRequest.setLockInd(CustomerMasterConstants.VALUE_N);
		}

		// Loyalty : Changes have been made not to check PET indicator for
		// Loyalty source and set to default as 'N'.
		// Wrong Pet Indicator Assignment Issue for Non Loyalty Members - Amit
		// 05/09/2013 - Moved AND clause to seperate outer if block

		if ((!CustomerMasterConstants.DEFAULT_PET_IND_NO_CHECK
				.contains(customerMasterEnterpriseUpdateRequest.getSrcCode()
						+ CustomerMasterConstants.COMA_DELIMITER))) {
			if (!CustomerMasterUtility
					.isEmpty(customerMasterEnterpriseUpdateRequest.getPetInd())) {
				if (CustomerMasterConstants.DEFAULT_PET_IND_N_SOURCES_ENTERPRISE
						.contains(customerMasterEnterpriseUpdateRequest
								.getSrcCode()
								+ CustomerMasterConstants.COMA_DELIMITER)) {
					if (!customerMasterEnterpriseUpdateRequest.getPetInd()
							.equalsIgnoreCase(CustomerMasterConstants.VALUE_N)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.UPDATE_EC_INVALID_PET_IND);
					}
				} else if (CustomerMasterConstants.DEFAULT_PET_IND_Y_SOURCES
						.contains(customerMasterEnterpriseUpdateRequest
								.getSrcCode()
								+ CustomerMasterConstants.COMA_DELIMITER)) {
					if (!customerMasterEnterpriseUpdateRequest.getPetInd()
							.equalsIgnoreCase(CustomerMasterConstants.VALUE_Y)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.UPDATE_EC_INVALID_PET_IND);
					}
				}

				if (!(CustomerMasterConstants.NOCHECK_LOCK_PET_SEC_IND_SOURCES.contains
						(customerMasterEnterpriseUpdateRequest.getSrcCode()))
						&&!customerMasterEnterpriseUpdateRequest.getPetInd()
						.equalsIgnoreCase(CustomerMasterConstants.VALUE_Y)
						&& !customerMasterEnterpriseUpdateRequest.getPetInd()
								.equalsIgnoreCase(
										CustomerMasterConstants.VALUE_N)) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.UPDATE_EC_INVALID_PET_IND);
				}
			}
		} else {
			customerMasterEnterpriseUpdateRequest
					.setPetInd(CustomerMasterConstants.VAL_NO);

		}

		// Loyalty : Changes have been made not to check Security Code for
		// Loyalty source and set to default as 'P'.

		if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseUpdateRequest.getSecCode())
				&& (!CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_NO_CHECK
						.contains(customerMasterEnterpriseUpdateRequest
								.getSrcCode()
								+ CustomerMasterConstants.COMA_DELIMITER))) {
			if (CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_H_SOURCES
					.contains(customerMasterEnterpriseUpdateRequest
							.getSrcCode()
							+ CustomerMasterConstants.COMA_DELIMITER)) {
				if (!customerMasterEnterpriseUpdateRequest.getSecCode()
						.equalsIgnoreCase(
								CustomerMasterConstants.SEC_CLASS_CODE_H)) {

					customerMasterEnterpriseUpdateRequest.setSecCode(CustomerMasterConstants.SEC_CLASS_CODE_H);
				}
			} else if (CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_P_SOURCES_ENTERPRISE
					.contains(customerMasterEnterpriseUpdateRequest
							.getSrcCode()
							+ CustomerMasterConstants.COMA_DELIMITER)) {
				if (!customerMasterEnterpriseUpdateRequest.getSecCode()
						.equalsIgnoreCase(
								CustomerMasterConstants.SEC_CLASS_CODE_P)) {

					customerMasterEnterpriseUpdateRequest
							.setSecCode(CustomerMasterConstants.SEC_CLASS_CODE_P);
				}
			}

			if (!(CustomerMasterConstants.NOCHECK_LOCK_PET_SEC_IND_SOURCES.contains
					(customerMasterEnterpriseUpdateRequest.getSrcCode()))
					&& !customerMasterEnterpriseUpdateRequest.getSecCode()
					.equalsIgnoreCase(CustomerMasterConstants.SEC_CLASS_CODE_P)
					&& !customerMasterEnterpriseUpdateRequest.getSecCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SEC_CLASS_CODE_H)) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.UPDATE_EC_INVALID_SEC_CLASS_CODE);
			}
		} else {
			if (CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_H_SOURCES
					.contains(customerMasterEnterpriseUpdateRequest
							.getSrcCode()
							+ CustomerMasterConstants.COMA_DELIMITER)) {
				customerMasterEnterpriseUpdateRequest
						.setSecCode(CustomerMasterConstants.SECURITY_CLASS_CODE_H);
			} else if (CustomerMasterConstants.DEFAULT_SEC_CLASS_CODE_P_SOURCES
					.contains(customerMasterEnterpriseUpdateRequest
							.getSrcCode()
							+ CustomerMasterConstants.COMA_DELIMITER)) {
				customerMasterEnterpriseUpdateRequest
						.setSecCode(CustomerMasterConstants.SECURITY_CLASS_CODE_P);
			}
		}

		SimpleDateFormat sdfLstUpdDate = new SimpleDateFormat(
				CustomerMasterConstants.DEFAULT_DATE_FORMAT);
		try {
			sdfLstUpdDate.parse(customerMasterEnterpriseUpdateRequest
					.getLastUpdateDate());
		} catch (Exception e) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_DATE_FORMAT_LST_UPD_DATE);
		}
	}

	/**
	 * This method checks for maximum length of the fields entered. If any field
	 * exceeds its max length then this method will throw an exception with
	 * custom error code and error message. This method of
	 * ValidateCustomerMasterRequest is invoked by
	 * CustomerMasterEnterpriseUpdateBO
	 * 
	 * @param customerMasterEnterpriseUpdateRequest
	 * @throws BusinessRuleViolationException
	 */
	public static void validateMaxLength(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws BusinessRuleViolationException {
		if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseUpdateRequest.getSrcCode())
				&& CustomerMasterUtility.exceedsMaxLength(
						customerMasterEnterpriseUpdateRequest.getSrcCode()
								.trim(),
						CustomerMasterConstants.MAX_LENGTH_SOURCE_CODE)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_SRC_CODE);
		}

		/*if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseUpdateRequest.getSrcIdNum())
				&& CustomerMasterUtility.exceedsMaxLength(
						customerMasterEnterpriseUpdateRequest.getSrcIdNum()
								.trim(),
						CustomerMasterConstants.MAX_LENGTH_SOURCE_ID)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_SRC_ID);
		}*/

		if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseUpdateRequest
						.getLastUpdateDate())
				&& CustomerMasterUtility.exceedsMaxLength(
						customerMasterEnterpriseUpdateRequest
								.getLastUpdateDate().trim(),
						CustomerMasterConstants.MAX_LENGTH_LAST_UPDATE_DATE)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_DATE_FORMAT_LST_UPD_DATE);
		}

		if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseUpdateRequest.getPetInd())
				&& CustomerMasterUtility.exceedsMaxLength(
						customerMasterEnterpriseUpdateRequest.getPetInd()
								.trim(),
						CustomerMasterConstants.MAX_LENGTH_PET_IND)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_PET_IND);
		}

		if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseUpdateRequest.getLockInd())
				&& CustomerMasterUtility.exceedsMaxLength(
						customerMasterEnterpriseUpdateRequest.getLockInd()
								.trim(),
						CustomerMasterConstants.MAX_LENGTH_LOCK_IND)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_LOCK_IND);
		}

		if (!CustomerMasterUtility
				.isEmpty(customerMasterEnterpriseUpdateRequest.getSecCode())
				&& CustomerMasterUtility.exceedsMaxLength(
						customerMasterEnterpriseUpdateRequest.getSecCode()
								.trim(),
						CustomerMasterConstants.MAX_LENGTH_SEC_CLASS_CODE)) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.UPDATE_EC_INVALID_SEC_CLASS_CODE);
		}
	}

	/**
	 * This method checks for program details in case of source code LR If
	 * invalid program details are entered then this method will throw an
	 * exception with custom error code and error message. This method of
	 * ValidateCustomerMasterRequest is invoked by
	 * CustomerMasterEnterpriseUpdateBO
	 * 
	 * @param customerMasterEnterpriseUpdateRequest
	 * @throws BusinessRuleViolationException
	 */
	public static void validateProgramDetails(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws BusinessRuleViolationException {
		if (null != customerMasterEnterpriseUpdateRequest) {
			ArrayList<CustomerMasterEnterpriseProgramVO> custProgIdArray = customerMasterEnterpriseUpdateRequest
					.getCustProgIdArray();
			ArrayList<CustomerMasterEnterpriseProgramActionVO> custProgActionArray = customerMasterEnterpriseUpdateRequest
					.getCustProgActionArray();
			ArrayList<CustomerMasterEnterpriseAttributesVO> custMasterAttribute = customerMasterEnterpriseUpdateRequest
					.getCustArrayOfAttributes();
			// if block changed for ProgIdarray and progactionarray size
			// mismatch
			// Silky Added
			boolean isEMPLProgramAvailable = false;

			if (!custProgIdArray.isEmpty() || !custProgActionArray.isEmpty()) {

				int length = custProgIdArray.size();
				int len = custProgActionArray.size();
				// Both Program Array and Program Action Array count should be
				// same.
				if (len != length) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.ARRAY_COUNT_MISMATCH);
				}
				String programCode = CustomerMasterConstants.BLANK_VAL;
				String programID = CustomerMasterConstants.BLANK_VAL;
				String programStatus = CustomerMasterConstants.BLANK_VAL;
				String progStartDate = CustomerMasterConstants.BLANK_VAL;
				String progExpDate = CustomerMasterConstants.BLANK_VAL;

				String programCodeActionArray = CustomerMasterConstants.BLANK_VAL;
				String progIdActionArray = CustomerMasterConstants.BLANK_VAL;
				String progActionArray = CustomerMasterConstants.BLANK_VAL;
				String progLastUpdate = CustomerMasterConstants.BLANK_VAL;
				// Code Change start For Duplicate ProgramCode+ProgramId in
				// Request
				Set<String> progSet = new HashSet<String>();
				for (int progCounter = 0; progCounter < length; progCounter++) {
					CustomerMasterEnterpriseProgramVO customerMasterProgramVO = custProgIdArray
							.get(progCounter);
					String progCodeID = customerMasterProgramVO
							.getProgramCode().toUpperCase()
							+ customerMasterProgramVO.getProgramId();
					if (!progSet.add(progCodeID)) {
						throw new BusinessRuleViolationException(
								CustomerMasterConstants.DUPLICATE_PROGCODE_PROGID);
					}
				}
				int emplCount = 0;
				// Code Change End For Duplicate ProgramCode+ProgramId in
				// Request
				for (int index = 0; index < length; index++) {
					CustomerMasterEnterpriseProgramVO customerMasterProgramVO = custProgIdArray
							.get(index);
					programCode = customerMasterProgramVO.getProgramCode();
					programID = customerMasterProgramVO.getProgramId();
					programStatus = customerMasterProgramVO.getProgramStatus();
					progStartDate = customerMasterProgramVO.getProgStartDt();
					progExpDate = customerMasterProgramVO.getProgExpDt();
					progLastUpdate = customerMasterProgramVO.getProgLstUpDt();

					CustomerMasterEnterpriseProgramActionVO customerMasterProgramActionVO = custProgActionArray
							.get(index);
					programCodeActionArray = customerMasterProgramActionVO
							.getProgramCode();
					progIdActionArray = customerMasterProgramActionVO
							.getProgramId();
					progActionArray = customerMasterProgramActionVO
							.getProgramAction();

					if (!customerMasterProgramVO.isNull()) {
						if (CustomerMasterUtility.isEmpty(programCode)
								|| CustomerMasterUtility
										.isEmpty(programCodeActionArray)) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.PROGRAM_CODE_MISSING);
						} else {
							if (!programCode
									.equalsIgnoreCase(programCodeActionArray)) {
								throw new BusinessRuleViolationException(
										CustomerMasterConstants.PROGRAM_CODE_NOT_MATCHING_WITHIN_ARRAY);
							}

							if (CustomerMasterUtility
									.notAcceptableValue(
											programCode,
											CustomerMasterConstants.ACCEPTABLE_ENTUPDATE_PROGRAM_CODE_VALUES)
									|| (CustomerMasterUtility
											.notAcceptableValue(
													programCodeActionArray,
													CustomerMasterConstants.ACCEPTABLE_ENTUPDATE_PROGRAM_CODE_VALUES))) {
								throw new BusinessRuleViolationException(
										CustomerMasterConstants.NOT_A_VALID_PROGRAM_CODE_ADD_UPDATE);
							}
						}
						if (!progIdActionArray.equalsIgnoreCase(programID)) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.PROGRAM_ID_NOT_MATCHING_WITHIN_ARRAY);
						}
						if (CustomerMasterUtility.isEmpty(programID)
								&& (!programCode
										.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_VCD) && !CustomerMasterUtility
										.isEmpty(programCode))
								|| CustomerMasterUtility
										.isEmpty(progIdActionArray)
								&& (!programCode
										.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_VCD) && !CustomerMasterUtility
										.isEmpty(programCodeActionArray))) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.PROGRAM_IDENTIFIER_MISSING);
						}
						if (!CustomerMasterUtility.isEmpty(progIdActionArray)
								&& CustomerMasterUtility
										.notAcceptableValue(
												progActionArray,
												CustomerMasterConstants.ACCEPTABLE_PROGRAM_ACTION_VALUES)) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.INVALID_PROGRAM_ACTION_VALUE);
						}
						if (CustomerMasterUtility.isEmpty(progActionArray)) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.PROGRAM_ACTION_MISSING);
						}

						if (programCode
								.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_EMPL)) {
							emplCount++;
							isEMPLProgramAvailable = true;
						}
						// Commenting to accept blank values for program dates
						// and status.
					}
				}
				if (emplCount > 1) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.MULTIPLE_EMPL_BENEFIT);
				}

			}
			// Silky Added - Commented by ankit

			if (!custMasterAttribute.isEmpty()) {
				int countArray = custMasterAttribute.size();
				// @Ankit - Added in order to handle loyalty attributes benefits
				// in Incoming Requests
				int countLoyatlyCard = 0;
				int countSecretCode = 0;

				for (int count = 0; count < countArray; count++) {
					CustomerMasterEnterpriseAttributesVO custMasterAttributesVO = (CustomerMasterEnterpriseAttributesVO) custMasterAttribute
							.get(count);
					if (null != custMasterAttributesVO) {
						if (null != custMasterAttributesVO.getCdiKey()) {
							if (CustomerMasterUtility.notAcceptableValue(
									custMasterAttributesVO.getCdiKey(),
									CustomerMasterConstants.ACCEPTABLE_CDI_KEY)) {
								throw new BusinessRuleViolationException(
										CustomerMasterConstants.NOT_A_VALID_CDIKEY);
							} else {
								if (custMasterAttributesVO
										.getCdiKey()
										.equalsIgnoreCase(
												CustomerMasterConstants.STR_VERFICATION_CODE)
										&& custMasterAttributesVO.getCdiValue() != null
										&& !custMasterAttributesVO
												.getCdiValue()
												.equalsIgnoreCase("")) {
									countSecretCode++;

								} else if (custMasterAttributesVO
										.getCdiKey()
										.equalsIgnoreCase(
												CustomerMasterConstants.STR_EECARDNO)
										&& custMasterAttributesVO.getCdiValue() != null
										&& !custMasterAttributesVO
												.getCdiValue()
												.equalsIgnoreCase("")) {
									countLoyatlyCard++;
								}
							}
						} else if (null != custMasterAttributesVO.getCdiValue()) {
							throw new BusinessRuleViolationException(
									CustomerMasterConstants.CDIKEY_MISSING);
						}
					}
				}
				// @Ankit - Added in order to check multiple loyalty attributes
				// in the request
				if (countSecretCode > 1 || countLoyatlyCard > 1) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.MULTIPLE_LR_EMPL_ATTR);
				}
				// @Ankit - Added in order to check presence of both the
				// attributes in the request
				else if ((countSecretCode == 1 && countLoyatlyCard != 1)
						|| (countLoyatlyCard == 1 && countSecretCode != 1)) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.LR_EMPL_ATTR_INCOMPLETE);
				}
				// @Ankit 6-feb-2013
				else if (!((isEMPLProgramAvailable && countSecretCode == 1 && countLoyatlyCard == 1) || (countSecretCode != 1
						&& countLoyatlyCard != 1 && !isEMPLProgramAvailable))) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.LR_EMPL_BENEFIT_INCOMPLETE);
				}

			}
		}
	}
	// PC Realtime change starts
	/**
	 * This Method validate searchSources.
	 * @param inputSrc
	 * @param validSrc
	 * @throws BusinessRuleViolationException
	 */
	public static void validateSearchSource(String inputSrc, String validSrc)
			throws BusinessRuleViolationException {
		String[] tempArray = inputSrc
				.split(CustomerMasterConstants.SPLIT_COMA_DELIMITER);
		if (tempArray.length == 0) {
			throw new BusinessRuleViolationException(
					CustomerMasterConstants.INVALID_SEARCH_SRC);
		}
		for (int i = 0; i < tempArray.length; i++) {
			if (CustomerMasterUtility.isEmpty(tempArray[i])|| CustomerMasterUtility
					.notAcceptableValue(tempArray[i], validSrc))
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.INVALID_SEARCH_SRC);
		}
	}


	/**
	 * This method validates search level 2 criteria
	 * @param customerMasterEnterpriseLookUpRequest
	 * @throws BusinessRuleViolationException
	 */
	public static void validateEnterpriseSearchLevel(String searchType,
			String searchSource, String cvType)
			throws BusinessRuleViolationException {

		if (CustomerMasterUtility.isEmpty(searchType)
				|| CustomerMasterUtility.isEmpty(searchSource)
				|| CustomerMasterUtility.isEmpty(cvType)) {

			throw new BusinessRuleViolationException(
					CustomerMasterConstants.SEARCH_TYPE_SEARCH_SRC_AND_CV_TYPE_SHOULD_NOT_BE_BLANK);
		} 
		
		
	}

	/**
	 * This mehtod validates search source based on search type
	 * @param searchType
	 * @param searchSource
	 * @throws BusinessRuleViolationException
	 */
	public static void validateEnterprise(String searchType, String searchSource,String cvType,String applicationId)
			throws BusinessRuleViolationException {
		validateSearchType(searchType);
		validateCVType(searchType, cvType,applicationId);
		
		if (CustomerMasterConstants.SEARCH_TYPE_CUSTOMER
				.equalsIgnoreCase(searchType)) {
			validateSearchSource(searchSource,
					CustomerMasterConstants.ACCEPTABLE_CUSTOMER_SRC);
			
		}

	else if (CustomerMasterConstants.SEARCH_TYPE_CONSUMER
				.equalsIgnoreCase(searchType)) {
			validateSearchSource(searchSource,
					CustomerMasterConstants.ACCEPTABLE_CONSUMER_SRC);
			
		}

	else if (CustomerMasterConstants.SEARCH_TYPE_BOTH
				.equalsIgnoreCase(searchType)) {
			String[] srcArray = null;

			if (searchSource.contains(CustomerMasterConstants.PIPE_DELIMITER)) {
				srcArray = searchSource
						.split(CustomerMasterConstants.SPLIT_PIPE_DELIMITER);

				if (srcArray.length != 2 || CustomerMasterUtility.isEmpty(srcArray[0])|| CustomerMasterUtility.isEmpty(srcArray[1])) 
				{
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.INVALID_SEARCH_SRC);
				}
			}

			else {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.INVALID_SEARCH_SRC);
			}
			validateSearchSource(srcArray[0],CustomerMasterConstants.ACCEPTABLE_CUSTOMER_SRC);// Customer Source Validation
			validateSearchSource(srcArray[1],CustomerMasterConstants.ACCEPTABLE_CONSUMER_SRC);//Consumer source Validation
		}
	}		
	/**
	 * This Method validate searchTypes.
	 * @param searchType
	 * @throws BusinessRuleViolationException
	 */
	public static void validateSearchType(String searchType)
			throws BusinessRuleViolationException {
            
            
			if(!(CustomerMasterConstants.SEARCH_TYPE_CUSTOMER.equalsIgnoreCase(searchType)||CustomerMasterConstants.SEARCH_TYPE_CONSUMER.equalsIgnoreCase(searchType)||CustomerMasterConstants.SEARCH_TYPE_BOTH.equalsIgnoreCase(searchType)))
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ACCEPTABLE_SEARCH_TYPE_ERROR);
		}
	
/**
 * This Method validate cvTypes based on Search type.
 * @param cvType
 * @param searchType
 * @throws BusinessRuleViolationException
 */
	public static void validateCVType(String searchType, String cvType,String applicationId)
			throws BusinessRuleViolationException {
		//code changes for PCC CR starts
		//Fixed ST issue for PC CR of jira CDIES 566
		if(applicationId!=null && CustomerMasterConstants.NON_AUTHORIZE_APPLICATION_ID_HIPAA.contains(applicationId) &&
				cvType.contains(CustomerMasterConstants.CVTYPE_HIPPA))
		{
			throw new BusinessRuleViolationException(CustomerMasterConstants.INVALID_SEARCH_CRITERIA);
		}
		//code changes for PCC CR ends
		if (CustomerMasterConstants.SEARCH_TYPE_CUSTOMER
				.equalsIgnoreCase(searchType)) {
			if (!(CustomerMasterConstants.CVTYPE_HIPPA.equalsIgnoreCase(cvType)
					|| CustomerMasterConstants.CVTYPE_MARKETING
							.equalsIgnoreCase(cvType) || CustomerMasterConstants.CVTYPE_LOYALTY
						.equalsIgnoreCase(cvType))) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ACCEPTABLE_CV_TYPE_ERROR);
			}
		} else if (CustomerMasterConstants.SEARCH_TYPE_CONSUMER
				.equalsIgnoreCase(searchType)) {
			if (!(CustomerMasterConstants.ACCEPTABLE_CV_TYPE_CONSUMER
					.equalsIgnoreCase(cvType))) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ACCEPTABLE_CV_TYPE_ERROR);
			}
		}

		else if (CustomerMasterConstants.SEARCH_TYPE_BOTH
				.equalsIgnoreCase(searchType)) {

			String[] cvArray = null;

			if (cvType.contains(CustomerMasterConstants.PIPE_DELIMITER)) {
				cvArray = cvType
						.split(CustomerMasterConstants.SPLIT_PIPE_DELIMITER);

				if (cvArray.length != 2
						|| CustomerMasterUtility.isEmpty(cvArray[0])
						|| CustomerMasterUtility.isEmpty(cvArray[1])) {
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.ACCEPTABLE_CV_TYPE_ERROR);
				}
			}

			else {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ACCEPTABLE_CV_TYPE_ERROR);
			}

			if (!(CustomerMasterConstants.CVTYPE_HIPPA
					.equalsIgnoreCase(cvArray[0])
					|| CustomerMasterConstants.CVTYPE_MARKETING
							.equalsIgnoreCase(cvArray[0]) || CustomerMasterConstants.CVTYPE_LOYALTY
						.equalsIgnoreCase(cvArray[0]))) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ACCEPTABLE_CV_TYPE_ERROR);
			}

			if (!(CustomerMasterConstants.ACCEPTABLE_CV_TYPE_CONSUMER
					.equalsIgnoreCase(cvArray[1]))) {
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.ACCEPTABLE_CV_TYPE_ERROR);
			}
		}
	}

			//PC Realtime change ends
}