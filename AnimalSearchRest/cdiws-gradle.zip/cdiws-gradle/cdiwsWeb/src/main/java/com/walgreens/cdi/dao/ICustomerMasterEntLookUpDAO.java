package com.walgreens.cdi.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.walgreens.cdi.vo.CustomerMasterLinkageVO;
import com.walgreens.cdi.vo.customer.CustomerMasterEntSearch;


public interface ICustomerMasterEntLookUpDAO {
	
public List<CustomerMasterEntSearch> getCdiCompViewAllSrc(Set eidSet);
public List<CustomerMasterLinkageVO> getCdiLinkageAllSrc(Set eidSet);
public List<CustomerMasterEntSearch> getRefCompViewAllSrc(String srcCode, String srcId);
public List<Map<String,Object>> getAllProgramsAndAttr(String srcCode, String srcId);
public List<CustomerMasterEntSearch> getLoyaltyMemCompView(String srcCode, String srcId);
}
