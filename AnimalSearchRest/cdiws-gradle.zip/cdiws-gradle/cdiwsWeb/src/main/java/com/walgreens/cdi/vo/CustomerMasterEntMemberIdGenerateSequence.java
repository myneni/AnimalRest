package com.walgreens.cdi.vo;

public class CustomerMasterEntMemberIdGenerateSequence {

	private String currentSequence;

	public String getCurrentSequence() {
		return currentSequence;
	}

	public void setCurrentSequence(String currentSequence) {
		this.currentSequence = currentSequence;
	}
}
