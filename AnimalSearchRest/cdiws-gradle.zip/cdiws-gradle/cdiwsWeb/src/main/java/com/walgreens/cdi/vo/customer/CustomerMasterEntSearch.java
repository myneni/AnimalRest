/**
 * 
 */
package com.walgreens.cdi.vo.customer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.walgreens.cdi.vo.CustomerMasterEntAttributesVO;
import com.walgreens.cdi.vo.CustomerMasterEntSearchProgramVO;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEntSearchAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterDeceasedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterGender;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterHubLinkageRec;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLockedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPetInd;

/**
 * @author Picketta, lzhang
 *
 */
public class CustomerMasterEntSearch {

	private String EID; 			
	private Date compositeDateTime = Calendar.getInstance().getTime();
	private String matchScore;
	private String memberStatus;
	private String srcCode;
	private String memberId;
	private CustomerMasterEntSearchAttr custAll =  new CustomerMasterEntSearchAttr(false);
	private CustomerMasterEntSearchAttr custLim = new CustomerMasterEntSearchAttr(false);
	private CustomerMasterGender gender;
	private CustomerMasterPetInd petInd;
	private CustomerMasterDeceasedInd deceasedInd;
	private CustomerMasterLockedInd lockedInd;	
	private CustomerMasterHubLinkageRec hubLinkageRec;	 
	private ArrayList<CustomerMasterEntSearchProgramVO> programArray = new ArrayList<CustomerMasterEntSearchProgramVO>();
	private ArrayList<CustomerMasterEntAttributesVO> attributeArray = new ArrayList<CustomerMasterEntAttributesVO>();
	
	

	public Date getCompositeDateTime() {
		return compositeDateTime;
	}

	public void setCompositeDateTime(Date compositeDateTime) {
		this.compositeDateTime = compositeDateTime;
	}


	public CustomerMasterEntSearchAttr getCustAll() {
		return custAll;
	}

	public void setCustAll(CustomerMasterEntSearchAttr custAll) {
		this.custAll = custAll;
	}

	public CustomerMasterEntSearchAttr getCustLim() {
		return custLim;
	}

	public void setCustLim(CustomerMasterEntSearchAttr custLim) {
		this.custLim = custLim;
	}

	public CustomerMasterDeceasedInd getDeceasedInd() {
		return deceasedInd;
	}

	public void setDeceasedInd(CustomerMasterDeceasedInd deceasedInd) {
		this.deceasedInd = deceasedInd;
	}

	public String getEID() {
		return EID;
	}

	public void setEID(String eid) {
		EID = eid;
	}

	public CustomerMasterGender getGender() {
		return gender;
	}

	public void setGender(CustomerMasterGender gender) {
		this.gender = gender;
	}

	public CustomerMasterLockedInd getLockedInd() {
		return lockedInd;
	}

	public void setLockedInd(CustomerMasterLockedInd lockedInd) {
		this.lockedInd = lockedInd;
	}

	public String getMatchScore() {
		return matchScore;
	}

	public void setMatchScore(String matchScore) {
		this.matchScore = matchScore;
	}

	public CustomerMasterPetInd getPetInd() {
		return petInd;
	}

	public void setPetInd(CustomerMasterPetInd petInd) {
		this.petInd = petInd;
	}	

	public String getMemberStatus() {
		return memberStatus;
	}

	public void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}

	public ArrayList<CustomerMasterEntAttributesVO> getAttributeArray() {
		return attributeArray;
	}

	public void setAttributeArray(
			ArrayList<CustomerMasterEntAttributesVO> attributeArray) {
		this.attributeArray = attributeArray;
	}

	public ArrayList<CustomerMasterEntSearchProgramVO> getProgramArray() {
		return programArray;
	}

	public void setProgramArray(
			ArrayList<CustomerMasterEntSearchProgramVO> programArray) {
		this.programArray = programArray;
	}
	
	public void addProgramArray(
			ArrayList<CustomerMasterEntSearchProgramVO> programArray) {
		if (this.programArray==null)
		{
			this.programArray= new ArrayList<CustomerMasterEntSearchProgramVO>();
		}
		this.programArray.addAll(programArray);
	}

	public CustomerMasterHubLinkageRec getHubLinkageRec() {
		return hubLinkageRec;
	}

	public void setHubLinkageRec(CustomerMasterHubLinkageRec hubLinkageRec) {
		this.hubLinkageRec = hubLinkageRec;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getSrcCode() {
		return srcCode;
	}

	public void setSrcCode(String srcCode) {
		this.srcCode = srcCode;
	}

}
