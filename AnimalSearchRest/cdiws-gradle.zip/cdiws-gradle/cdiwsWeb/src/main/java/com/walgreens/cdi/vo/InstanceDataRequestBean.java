package com.walgreens.cdi.vo;

/**
 * Bean class with the attribute containing the name of subject area which is
 * been requested from the admin.jsp page.
 * @author p.kumar.mudaliar
 */
public class InstanceDataRequestBean {
    private String subjectArea;

    private String logLevel;


    public String getSubjectArea() {
        return subjectArea;
    }


    public void setSubjectArea(String buttonName) {
        this.subjectArea = buttonName;
    }


    /**
     * @return the logLevel
     */
    public String getLogLevel() {
        return logLevel;
    }


    /**
     * @param logLevel
     *            the logLevel to set
     */
    public void setLogLevel(String logLevel) {
        this.logLevel = logLevel;
    }
}
