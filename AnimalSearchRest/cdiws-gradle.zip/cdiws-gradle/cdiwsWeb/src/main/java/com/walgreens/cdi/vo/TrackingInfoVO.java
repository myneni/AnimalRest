package com.walgreens.cdi.vo;

/**
 * The class contains variables which wil be used to Track the Transaction
 * @author k.anurag
 */
public class TrackingInfoVO {

    /**
     * It references messageID
     */
    private String messageID;

    /**
     * It references correlationID
     */
    private String correlationID;

    /**
     * It references applicationID
     */
    private String applicationID;

    /**
     * It references start time of the Transaction
     */
    private long startTimeMillis;

  //CDI_289 change added
    private String transactionName;

    /**
     * Getter for correlationID
     * @return
     */
    public String getCorrelationID() {
        return correlationID;
    }


    /**
     * Setter for correlationID
     * @param correlationID
     */
    public void setCorrelationID(String correlationID) {
        this.correlationID = correlationID;
    }


    public String getApplicationID() {
        return applicationID;
    }


    public void setApplicationID(String applicationID) {
        this.applicationID = applicationID;
    }


    public String getMessageID() {
        return messageID;
    }


    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }


    public long getStartTimeMillis() {
        return startTimeMillis;
    }


    public void setStartTimeMillis(long startTimeMillis) {
        this.startTimeMillis = startTimeMillis;
    }


	public String getTransactionName() {
		return transactionName;
	}


	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
    
    
}
