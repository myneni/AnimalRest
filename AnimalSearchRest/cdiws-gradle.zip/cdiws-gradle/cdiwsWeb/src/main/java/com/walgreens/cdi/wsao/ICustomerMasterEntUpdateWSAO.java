package com.walgreens.cdi.wsao;

import com.initiate.bean.ArrayOfMember;
import com.initiate.bean.MemberGetRequest;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateRequest;

public interface ICustomerMasterEntUpdateWSAO {
	
	public boolean updateEntCustomerMaster(CustomerMasterEntUpdateRequest customerMasterEntUpdateRequest) throws BusinessRuleViolationException,Exception;
	public ArrayOfMember getMemberEntAddUpdateResponse(MemberGetRequest memberGetRequest);
}
