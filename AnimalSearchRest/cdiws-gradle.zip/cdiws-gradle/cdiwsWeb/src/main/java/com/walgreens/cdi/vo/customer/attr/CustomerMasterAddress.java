package com.walgreens.cdi.vo.customer.attr;

import com.walgreens.cdi.util.CustomerMasterConstants;

public class CustomerMasterAddress extends CustomerMasterAttributeStatus {

	CustomerMasterAddressAttrNCOA permAddress ; 
	CustomerMasterAddressAttr home2Address;
	CustomerMasterAddressAttr workAddress; 
	
	
	/**
	 * @return the home2Address
	 */
	public CustomerMasterAddressAttr getHome2Address() {
		return home2Address;
	}
	/**
	 * @param home2Address the home2Address to set
	 */
	public void setHome2Address(CustomerMasterAddressAttr home2Address) {
		this.home2Address = home2Address;
	}
	/**
	 * @return the permAddress
	 */
	public CustomerMasterAddressAttrNCOA getPermAddress() {
		return permAddress;
	}
	/**
	 * @param permAddress the permAddress to set
	 */
	public void setPermAddress(CustomerMasterAddressAttrNCOA permAddress) {
		this.permAddress = permAddress;
	}
	/**
	 * @return the workAddress
	 */
	public CustomerMasterAddressAttr getWorkAddress() {
		return workAddress;
	}
	/**
	 * @param workAddress the workAddress to set
	 */
	public void setWorkAddress(CustomerMasterAddressAttr workAddress) {
		this.workAddress = workAddress;
	}
	/**
	 * 
	 */
	public CustomerMasterAddress() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String toString() {
		String str = "";
		String strTemp = "";
		if (permAddress != null)
		{
			strTemp = "\nPermAddress\n_________________________________\n" +
			permAddress.toString() ;
			str = str + strTemp;
		}
		if (home2Address != null)
		{
			strTemp = "\nHome2Address\n_________________________________\n" +
			home2Address.toString() ;
			str = str + strTemp;
		}
		if (workAddress != null)
		{
			strTemp = "\nWorkAddress\n_________________________________\n" +
			workAddress.toString() ;
			str = str + strTemp;
		}
	
		return str;
	}
	
	public String toCompString() {
		String str = "";
		String strTemp = CustomerMasterConstants.DELIMITE_ATTR
			   + CustomerMasterConstants.COMP_ATTR_NAME_PRADDR;
		if (permAddress != null)
		{
			strTemp = permAddress.toCompString() ;
			str = str + strTemp;
		}
		if (home2Address != null)
		{
			strTemp = home2Address.toCompString() ;
			str = str + strTemp;
		}
		if (workAddress != null)
		{
			strTemp = workAddress.toCompString() ;
			str = str + strTemp;
		}
	
		return str;
	}
			
}
