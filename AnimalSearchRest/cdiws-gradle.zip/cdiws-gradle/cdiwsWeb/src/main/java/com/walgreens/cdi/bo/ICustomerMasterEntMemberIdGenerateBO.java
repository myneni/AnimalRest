package com.walgreens.cdi.bo;



import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateRequest;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateResponse;

public interface ICustomerMasterEntMemberIdGenerateBO {

	public CustomerMasterEntMemberIdGenerateResponse callMemberIDGenerator(CustomerMasterEntMemberIdGenerateRequest memberIDRequest) throws SystemException, BusinessRuleViolationException;
	
	
	
}
