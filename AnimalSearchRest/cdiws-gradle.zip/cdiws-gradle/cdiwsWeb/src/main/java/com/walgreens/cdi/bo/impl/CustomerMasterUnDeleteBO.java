package com.walgreens.cdi.bo.impl;

import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterUnDeleteBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterUnDeleteRequest;
import com.walgreens.cdi.wsao.ICustomerMasterUnDeleteWSAO;

/**
 * This BO perform validation on input request and also handles exception. It
 * will return true on successfull Undeletion of EC record , otherwise an
 * exception will be thrown with message and error code.
 * 
 * @author
 */

public class CustomerMasterUnDeleteBO extends BaseBO implements
		ICustomerMasterUnDeleteBO {

	private ICustomerMasterUnDeleteWSAO customerMasterUnDeleteWSAO;

	/**
	 * This method calls the validation method validateRequiredFields
	 * (customerMasterUnDeleteRequest) for mandatory field validation
	 * 
	 * @param customerMasterUnDeleteRequest
	 * @return boolean
	 * @throws SystemException
	 */
	public boolean unDeleteCustomerMaster(
			final CustomerMasterUnDeleteRequest customerMasterUnDeleteRequest)
			throws SystemException, BusinessRuleViolationException {
		try {
			ValidateCustomerMasterRequest
					.validateRequiredFields(customerMasterUnDeleteRequest);
			return getCustomerMasterUnDeleteWSAO().unDeleteCustomerMaster(
					customerMasterUnDeleteRequest);
		} catch (JaxWsSoapFaultException e) {

			final String exceptionCode = getExceptionCode(e);
			if (exceptionCode != null) {
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(exceptionCode, e.getMessage());
			} else {
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(
						CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e
								.getMessage());
			}
		} catch (BusinessRuleViolationException e) {
			throw e;
		} catch (Exception e) {
			throw new SystemException(
					CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, e
							.getMessage());
		}
	}

	/**
	 * Overriding getExceptionCode inherited from BaseBo to generate customised
	 * messages.
	 */
	public String getExceptionCode(final Exception exception) {
		String excpCode="";
		if (exception.getMessage().contains(
				CustomerMasterConstants.EXCEPTION_EC_DELETE_RECORD_NOT_FOUND
						.trim())) {
			excpCode= CustomerMasterConstants.EC_DELETE_EXCEPTION_NO_RECORD_FOUND;
		} else if (exception.getMessage().contains(
				CustomerMasterConstants.EXCEPTION_EC_UNDELETE_INVALID_SRCCD
						.trim())) {
			excpCode= CustomerMasterConstants.EC_DELETE_EXCEPTION_UNKNOWN_SRCCODE;
		} else if (exception
				.getMessage()
				.contains(
						CustomerMasterConstants.EXCEPTION_EC_UNDELETE_RECORD_ALREADY_ACTIVE
								.trim())) {
			excpCode= CustomerMasterConstants.EC_UNDELETE_EXCEPTION_RECORD_ALREADY_ACTIVE;
		} else if (exception.getMessage().contains(
				CustomerMasterConstants.EXCEPTION_EC_DELETE_HUB_MAY_BE_DOWN
						.trim())) {
			excpCode= CustomerMasterConstants.EC_DELETE__EXCEPTION_HUB_MAY_BE_DOWN;
		} else if (exception.getMessage().contains(
				CustomerMasterConstants.EXCEPTION_EC_DELETE_COULD_NOT_SEND_MSG
						.trim())) {
			excpCode= CustomerMasterConstants.EC_DELETE_EXCEPTION_COULD_NOT_SEND_MSG;
		} else {
			excpCode= super.getExceptionCode(exception);
		}
		return excpCode;
	}

	/**
	 * @return the searchWSAO
	 */
	public ICustomerMasterUnDeleteWSAO getCustomerMasterUnDeleteWSAO() {
		return customerMasterUnDeleteWSAO;
	}

	/**
	 * @param searchWSAO
	 *            the searchWSAO to set
	 */
	public void setCustomerMasterUnDeleteWSAO(
			final ICustomerMasterUnDeleteWSAO customerMasterUnDeleteWSAO) {
		this.customerMasterUnDeleteWSAO = customerMasterUnDeleteWSAO;
	}
}
