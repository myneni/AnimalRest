package com.walgreens.cdi.vo;

public class CustomerMasterAttributesVO {

private String cdiKey;
private String cdiValue;


public String getCdiKey() {
	return cdiKey;
}
public void setCdiKey(String cdiKey) {
	this.cdiKey = cdiKey;
}
public String getCdiValue() {
	return cdiValue;
}
public void setCdiValue(String cdiValue) {
	this.cdiValue = cdiValue;
}



}