package com.walgreens.cdi.service.impl;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterUpdateBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterUpdateService;
import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterUpdateRequest;
/**
 * This service class will handle any exception thrown from BO layer , or else
 * return the Insert/Update status of New/Enrolled member.
 * 
 * @author
 * 
 */
public class CustomerMasterUpdateService extends BaseService  implements ICustomerMasterUpdateService{
	
	private ICustomerMasterUpdateBO customerMasterUpdateBO;
	/**
	 * This method calls the object customerMasterUpdateBO class for returning
	 * the status of the Insert/Update member.
	 * 
	 * @param customerMasterUpdateRequest
	 * @return boolean
	 * @throws CDIException
	 */

	public boolean updateCustomerMaster(CustomerMasterUpdateRequest customerMasterUpdateRequest) throws CDIException {
		try{
			return getcustomerMasterUpdateBO().updateCustomerMaster(customerMasterUpdateRequest);
		} catch (CDIException e) {
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return false;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
		
	}


	/**
	 * @return the updateBO
	 */
	public ICustomerMasterUpdateBO getcustomerMasterUpdateBO() {
		return customerMasterUpdateBO;
	}


	/**
	 * @param customerMasterUpdateBO the seBO to set
	 */
	public void setCustomerMasterUpdateBO(ICustomerMasterUpdateBO customerMasterUpdateBO) {
		this.customerMasterUpdateBO = customerMasterUpdateBO;
	}
	
}
