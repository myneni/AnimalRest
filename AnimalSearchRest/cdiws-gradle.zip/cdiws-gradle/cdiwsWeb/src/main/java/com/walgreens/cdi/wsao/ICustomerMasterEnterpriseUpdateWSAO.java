package com.walgreens.cdi.wsao;

import com.initiate.bean.ArrayOfMember;
import com.initiate.bean.MemberGetRequest;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateRequest;
/**
 * This Interface have all the methods declaration of EnterPrise Update Methods that will be implemented in WSAO Class
 * @author 
 *
 */
public interface ICustomerMasterEnterpriseUpdateWSAO {

	public boolean updateCustomerMasterEnterprise(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws BusinessRuleViolationException, Exception;

	public ArrayOfMember getMemberEnterpriseAddUpdateResponse(
			MemberGetRequest memberGetRequest);
}
