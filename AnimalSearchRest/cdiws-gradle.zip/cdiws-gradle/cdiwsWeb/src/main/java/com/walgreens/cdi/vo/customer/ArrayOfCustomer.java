package com.walgreens.cdi.vo.customer;
import java.util.ArrayList;
import java.util.List;
import com.walgreens.cdi.vo.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfCustomer complex type.
  * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfCustomer", propOrder = {
    "item"
})
public class ArrayOfCustomer {

    protected List<CustomerMasterResponse> item;

    /**
     * 
     * 
     * @return
     *     array of
     *     {@link Customer }
     *     
     */
    public CustomerMasterResponse[] getItem() {
        if (this.item == null) {
            return new CustomerMasterResponse[ 0 ] ;
        }
        return ((CustomerMasterResponse[]) this.item.toArray(new CustomerMasterResponse[this.item.size()] ));
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link Customer }
     *     
     */
    public CustomerMasterResponse getItem(int idx) {
        if (this.item == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.item.get(idx);
    }

    public int getItemLength() {
        if (this.item == null) {
            return  0;
        }
        return this.item.size();
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link CustomerMasterResponse }
     *     
     */
    public void setItem(CustomerMasterResponse[] values) {
        this._getItem().clear();
        int len = values.length;
        for (int i = 0; (i<len); i ++) {
            this.item.add(values[i]);
        }
    }

    protected List<CustomerMasterResponse> _getItem() {
        if (item == null) {
            item = new ArrayList<CustomerMasterResponse>();
        }
        return item;
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerMasterResponse }
     *     
     */
    public CustomerMasterResponse setItem(int idx, CustomerMasterResponse value) {
        return this.item.set(idx, value);
    }

}
