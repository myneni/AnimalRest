package com.walgreens.cdi.dao.impl;


import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import walgreens.services.LoggingFacility;
import walgreens.utils.logging.WalgreensLog4JImpl;

import com.walgreens.cdi.dao.ICustomerMasterEntUpdateDAO;

public class CustomerMasterEntUpdateDAO implements ICustomerMasterEntUpdateDAO {
	
private JdbcTemplate jdbcTemplate;
private String TAG = "CustomerMasterEntUpdateDAO";
	
	public void setDataSource(DataSource datasource){
		jdbcTemplate = new JdbcTemplate(datasource);
		jdbcTemplate.setFetchSize(50);		
	}
	
	
	/**
     * Referring to the WalgreensLog4JImpl
     */
    private WalgreensLog4JImpl walgreensLogger;

    /**
     * @return the walgreensLogger
     */
    public WalgreensLog4JImpl getWalgreensLogger() {
        return walgreensLogger;
    }


    /**
     * @param walgreensLogger
     *            the walgreensLogger to set
     */
    public void setWalgreensLogger(WalgreensLog4JImpl walgreensLogger) {
        this.walgreensLogger = walgreensLogger;
    }
	
		//Following method will generate Loyalty Sequnce Number (3rd Part of VCD #)- LR Addd update
		public String getLoyaltySequencNumber()
		{
			Long vcdSequence=null;
			try{
				getWalgreensLogger().log(LoggingFacility.INFO,"DAO:Inside getLoyaltySequencNumber method");
				String qry="SELECT LOYALTY_VCD_ID_NO_SEQ.NEXTVAL FROM DUAL";
				vcdSequence=this.jdbcTemplate.queryForLong(qry);
		}catch (DataAccessException we) {
				String msg = "Error while getting value from LOYALTY_VCD_ID_NO_SEQ:";
					
				msg = msg + we.getMessage();
				getWalgreensLogger().log(LoggingFacility.ERROR,msg);
				throw we;
			
		}
		return String.valueOf(vcdSequence);
		}
    }

