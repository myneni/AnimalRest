package com.walgreens.cdi.vo;

import java.util.ArrayList;

public class CustomerMasterEntUpdateResponse {
	
	private String memIdNum;
	private String memStat;
	
	
	private ArrayList<CustomerMasterProgramVO> custProgIdArray = new ArrayList<CustomerMasterProgramVO>();
	private ArrayList<CustomerMasterAttributesVO> custArrayOfAttributes = new ArrayList<CustomerMasterAttributesVO>();
	/*private ArrayList<CustomerMasterProgramActionVO> custProgActionArray=new ArrayList<CustomerMasterProgramActionVO>();
	
	public ArrayList<CustomerMasterProgramActionVO> getCustProgActionArray() {
		return custProgActionArray;
	}
	public void setCustProgActionArray(
			ArrayList<CustomerMasterProgramActionVO> custProgActionArray) {
		this.custProgActionArray = custProgActionArray;
	}*/
	public ArrayList<CustomerMasterProgramVO> getCustProgIdArray() {
		return custProgIdArray;
	}
	public void setCustProgIdArray(
			ArrayList<CustomerMasterProgramVO> custProgIdArray) {
		this.custProgIdArray = custProgIdArray;
	}
	
	public ArrayList<CustomerMasterAttributesVO> getCustArrayOfAttributes() {
		return custArrayOfAttributes;
	}
	public void setCustArrayOfAttributes(
			ArrayList<CustomerMasterAttributesVO> custArrayOfAttributes) {
		this.custArrayOfAttributes = custArrayOfAttributes;
	}
	public String getMemIdNum() {
		return memIdNum;
	}
	public void setMemIdNum(String memIdNum) {
		this.memIdNum = memIdNum;
	}
	public String getMemStat() {
		return memStat;
	}
	public void setMemStat(String memStat) {
		this.memStat = memStat;
	}
	
	
	
}
