package com.walgreens.cdi.bo.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import walgreens.rap.webservices.security.server.ConsumerContext;
import walgreens.services.LoggingFacility;

import com.initiate.bean.ArrayOfMember;
import com.initiate.bean.Member;
import com.initiate.bean.MemberGetRequest;
import com.walgreens.cdi.bo.ICustomerMasterEntUpdateBO;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.CustomerMasterUtility;
import com.walgreens.cdi.util.SecurityResource;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterAttributesVO;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateResponse;
import com.walgreens.cdi.vo.CustomerMasterProgramVO;
import com.walgreens.cdi.wsao.ICustomerMasterEntUpdateWSAO;

public class CustomerMasterEntUpdateBO extends BaseBO implements ICustomerMasterEntUpdateBO {

	private ICustomerMasterEntUpdateWSAO customerMasterEntUpdateWSAO;

	//New method added for LR Specific Add\Update Service
	public CustomerMasterEntUpdateResponse updateCustomerMasterEnt(CustomerMasterEntUpdateRequest customerMasterEntUpdateRequest) 
	throws SystemException, BusinessRuleViolationException {
		
		CustomerMasterEntUpdateResponse responseObj = new CustomerMasterEntUpdateResponse();		
		
		try{
			validateRequestObject(customerMasterEntUpdateRequest);			
			if(getCustomerMasterEntUpdateWSAO().updateEntCustomerMaster(customerMasterEntUpdateRequest))
			{
				responseObj=populateEntUpdateResponseObject(customerMasterEntUpdateRequest);		

			}
			
		}catch (JaxWsSoapFaultException e) {
			String exceptionCode = getExceptionCode(e);
			getWalgreensLogger().log(LoggingFacility.DEBUG, "THE CURRENT ERROR CODE :: " + exceptionCode);
			getWalgreensLogger().log(LoggingFacility.DEBUG, "THE CURRENT SRC CODE :: " + customerMasterEntUpdateRequest.getSrcCode());
			if(exceptionCode != null){
				if(exceptionCode.equals(CustomerMasterConstants.DO_NOT_THROW_EXCEPTION)){
					exceptionCode = CustomerMasterConstants.EXCEPTION_UPDATE_DO_NOT_THROW;
					try{
					responseObj=populateEntUpdateResponseObject(customerMasterEntUpdateRequest);
					}
					catch(Exception exxe)
					{
						getWalgreensLogger().log(LoggingFacility.ERROR,"Inside catch within catch (inside entupdate bo) exception -> :"+e.getMessage());
						throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, e.getMessage());
						
					}
					//throw new SystemException(CustomerMasterConstants.EXCEPTION_UPDATE_DO_NOT_THROW,e.getMessage());
				}else if(exceptionCode.equals(CustomerMasterConstants.EC_EXCEPTION_PET_IND_REQUIRED)
						&& CustomerMasterConstants.RETRY_PET_SOURCES.contains(customerMasterEntUpdateRequest.getSrcCode()+",")){
					exceptionCode = CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET;
					throw new SystemException(CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET,e.getMessage());
				}else if(exceptionCode.equals(CustomerMasterConstants.EC_EXCEPTION_LOCK_IND_REQUIRED)
						&& CustomerMasterConstants.RETRY_LOCK_SOURCES.contains(customerMasterEntUpdateRequest.getSrcCode()+",")){
					exceptionCode = CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET;
					throw new SystemException(CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET,e.getMessage());
				}
				//Added by ankit for loyalty employee benefits
				else if(exceptionCode.equals(CustomerMasterConstants.LR_DETACH_PREVIOUS_PROGRAM)
						){
					exceptionCode = CustomerMasterConstants.LR_DETACH_PREVIOUS_PROGRAM;
					throw new BusinessRuleViolationException(CustomerMasterConstants.LR_DETACH_PREVIOUS_PROGRAM);
				}
				else if(exceptionCode.equals(CustomerMasterConstants.LR_DETACHING_NONEXISTING_PROGRAM)
				){
					exceptionCode = CustomerMasterConstants.LR_DETACHING_NONEXISTING_PROGRAM;
					throw new BusinessRuleViolationException(CustomerMasterConstants.LR_DETACHING_NONEXISTING_PROGRAM);
				}
				//ENDS
				else{
					getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
					throw new SystemException(exceptionCode,e.getMessage());
				}
			}else{
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e.getMessage());
			}
		}catch(BusinessRuleViolationException e){
			throw e;
		}catch(Exception e){
			throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, e.getMessage());
		}
		
		return responseObj;
	}


	/**
	 * @return the searchWSAO
	 */
	public ICustomerMasterEntUpdateWSAO getCustomerMasterEntUpdateWSAO() {
		return customerMasterEntUpdateWSAO;
	}


	/**
	 * @param searchWSAO the searchWSAO to set
	 */
	public void setCustomerMasterEntUpdateWSAO(ICustomerMasterEntUpdateWSAO customerMasterEntUpdateWSAO) {
		this.customerMasterEntUpdateWSAO = customerMasterEntUpdateWSAO;
	}


	public void validateRequestObject(CustomerMasterEntUpdateRequest customerMasterEntUpdateRequest) throws BusinessRuleViolationException {
		
		
		ValidateCustomerMasterRequest.validateRequiredFields(customerMasterEntUpdateRequest);
		ValidateCustomerMasterRequest.validateInvalidFieldValues(customerMasterEntUpdateRequest);
		//LR Specific Validations
		if(null!=customerMasterEntUpdateRequest.getBDate() && !"".equalsIgnoreCase(customerMasterEntUpdateRequest.getBDate())){
		ValidateCustomerMasterRequest.validateMinimumAgeRequired(customerMasterEntUpdateRequest.getBDate());}
		ValidateCustomerMasterRequest.validateProgramDetails(customerMasterEntUpdateRequest);
			
		}

	//Following method will be used to populate EntUpdateReposne Object by MemGet
	public CustomerMasterEntUpdateResponse populateEntUpdateResponseObject(CustomerMasterEntUpdateRequest customerMasterEntUpdateRequest)
	throws Exception
	{
		CustomerMasterEntUpdateResponse respObj = new CustomerMasterEntUpdateResponse();
		MemberGetRequest memberGetRequest=new MemberGetRequest();
		
		memberGetRequest.setSrcCode(customerMasterEntUpdateRequest.getSrcCode().toUpperCase());
		memberGetRequest.setMemIdnum(customerMasterEntUpdateRequest.getSrcIdNum());				
		memberGetRequest.setSrcCodeFilter(CustomerMasterConstants.SRC_CODE_FILTER);				
		memberGetRequest.setEntType(CustomerMasterConstants.ENT_TYPE_ID);
		memberGetRequest.setMemType(CustomerMasterConstants.PATIENT_MEMBER_TYPE);
		memberGetRequest.setMemRecno(CustomerMasterConstants.ZERO);
		memberGetRequest.setEntRecno(CustomerMasterConstants.ZERO);				
		memberGetRequest.setGetType(CustomerMasterConstants.AS_MEMBER);				
		memberGetRequest.setRecStatFilter(CustomerMasterConstants.Active);
		memberGetRequest.setMemStatFilter(CustomerMasterConstants.Active);
		memberGetRequest.setSegCodeFilter(CustomerMasterConstants.SEG_CODE_ENT_ADD_UPDATE);
		

		String consumerAppId = ConsumerContext.getCurrentConsumerApplicationId();
		String initiateID="";
		String initiatePWD="";				

		SecurityResource securityResource =SecurityResource.getInstance();
		initiateID=securityResource.getInitiateID(consumerAppId);
		initiatePWD=securityResource.getInitiatePassword(initiateID);
		
		// Log Enhancement change start : Set correlationId|MessageID| as
		// argument
		memberGetRequest.setArgs(CustomerMasterUtility.generateLogString(
				getLoggingHandlerObj().getTrackingInfoProxyBean(),
				CustomerMasterConstants.BLANK_STRING,
				CustomerMasterConstants.BLANK_STRING));
		// Log Enhancement change end
		memberGetRequest.setUserName(initiateID);
		memberGetRequest.setUserPassword(initiatePWD);
		try{
		
		ArrayOfMember arrMemberRes = getCustomerMasterEntUpdateWSAO().getMemberEntAddUpdateResponse(memberGetRequest);				
		//System.out.println("RESPONSE: ->"+arrMemberRes.getItem(0));
		List<Member> memberList=arrMemberRes.getItem();
		Member[] memberRes = memberList.toArray(new Member[memberList.size()]);
		
		
		String attrCode="";
		
		CustomerMasterProgramVO progVO = null;
		CustomerMasterAttributesVO attributeVO=null;
		
		int count =0;
		
		ArrayList<CustomerMasterProgramVO> custProgIdArray =new ArrayList<CustomerMasterProgramVO>(); 
		ArrayList<CustomerMasterAttributesVO> custMasterAttrArray =new ArrayList<CustomerMasterAttributesVO>();
	//	boolean isPendingStatusPresent=false;
		
		for(int index=0;index<memberRes[0].getMemIds().getItem().size();index++)
		{
			attrCode=memberRes[0].getMemIds().getItem().get(index).getAttrCode();	
			
			if(	CustomerMasterConstants.ATTR_CODE_PROGRAM.contains(attrCode))
				
			{
									
				String status=memberRes[0].getMemIds().getItem().get(index).getValues().getItem().get(count++);
				progVO = new CustomerMasterProgramVO();	
				progVO.setProgramStatus(status);
				String progId = memberRes[0].getMemIds().getItem().get(index).getValues().getItem().get(count++);
				String progStartDt = memberRes[0].getMemIds().getItem().get(index).getValues().getItem().get(count++);
				String progExpDate = memberRes[0].getMemIds().getItem().get(index).getValues().getItem().get(count++);
				String progCode = memberRes[0].getMemIds().getItem().get(index).getValues().getItem().get(count++);
				String progLstUpDt =memberRes[0].getMemIds().getItem().get(index).getValues().getItem().get(count++);
				//System.out.println("status:"+status+"|progId :"+ progId + "|progStartDt:"+progStartDt + "|progExpDate:"+progExpDate+"|progCode:"+progCode+"|progLstUpDt:"+progLstUpDt);
				progVO.setProgramId(progId);
				progVO.setProgStartDt(progStartDt);
				progVO.setProgExpDt(progExpDate);
				progVO.setProgramCode(progCode);
				progVO.setProgLstUpDt(progLstUpDt);			
				
				custProgIdArray.add(progVO);	
					
			}
			
			if((attrCode.equals(CustomerMasterConstants.ATTR_CODE_CUSTGENATTR_CODE)))
			{
				attributeVO=new CustomerMasterAttributesVO();					
		        attributeVO.setCdiKey(memberRes[0].getMemIds().getItem().get(index).getValues().getItem().get(0));
				attributeVO.setCdiValue(memberRes[0].getMemIds().getItem().get(index).getValues().getItem().get(1));						
				custMasterAttrArray.add(attributeVO);					
				
			}			
			
			count=0;
			
		}
		
        if(custMasterAttrArray.isEmpty())
        {
        	attributeVO=new CustomerMasterAttributesVO();
        	attributeVO.setCdiKey("");
        	attributeVO.setCdiValue("");
        	custMasterAttrArray.add(attributeVO);
        }
        if(custProgIdArray.isEmpty())
        {
        	progVO = new CustomerMasterProgramVO();	
			progVO.setProgramStatus("");
			progVO.setProgramId("");
			progVO.setProgStartDt("");
			progVO.setProgExpDt("");
			progVO.setProgramCode("");
			progVO.setProgLstUpDt("");
			custProgIdArray.add(progVO);
        }
			respObj.setMemStat(memberRes[0].getMemHead().getMemStat());
			respObj.setMemIdNum(memberRes[0].getMemIds().getItem().get(0)
					.getMemIdnum());
			respObj.setCustArrayOfAttributes(custMasterAttrArray);
			respObj.setCustProgIdArray(custProgIdArray);
	
	}
	catch(Exception ex)
	{
		getWalgreensLogger().log(LoggingFacility.ERROR, "Inside populateEntUpdateResponseObject (inside entupdate bo) exception -> :"+ex.getMessage());
		throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, ex.getMessage());
	}
	return respObj;
	}
}