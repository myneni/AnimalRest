/**
 * 
 */
package com.walgreens.cdi.vo.customer.attr;

import java.util.ArrayList;

/**
 * @author Picketta
 *
 */
public class CustomerMasterHouseholdLinkageRec {
	//	 (Linkage of CustEID to Cust Source Records)		
	private ArrayList householdLinkageArrayList;		//Array (1/n)	Linkage array, with occurrences for every active linkage
	/**
	 * For householdLinkageArrayList
	 * 0 = sourceID
	 * 1 = sourceCode
	 * 2 = status ("Active" or "Inactive")
	 */
	private String householdeid	;								//String (1/1)	Enterprise ID for the requested customer. 
	
	
	/**
	 * 
	 */
	public CustomerMasterHouseholdLinkageRec() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@SuppressWarnings("unchecked")
	public void addHubLinkageRecord(String sourceID, String sourceCode, String status){
		this.householdLinkageArrayList.add(new String[]{sourceID, sourceCode, status});
	}

	/**
	 * @return the householdeid
	 */
	public String getHouseholdeid() {
		return householdeid;
	}

	/**
	 * @param householdeid the householdeid to set
	 */
	public void setHouseholdeid(String custEID) {
		this.householdeid = custEID;
	}

	/**
	 * @return the householdLinkageArrayList
	 */
	public ArrayList getHouseholdLinkageArrayList() {
		return householdLinkageArrayList;
	}

	/**
	 * @param householdLinkageArrayList the householdLinkageArrayList to set
	 */
	public void setHouseholdLinkageArrayList(ArrayList hubLinkageArrayList) {
		this.householdLinkageArrayList = hubLinkageArrayList;
	}
	
	
}
