package com.walgreens.cdi.bo.impl;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import walgreens.services.LoggingFacility;

import madison.mpi.MemRowList;

import com.walgreens.cdi.util.CDILogger;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpResponse;
import com.walgreens.cdi.wsao.ICustomerMasterEnterpriseLookUpWSAO;
import com.walgreens.cdi.wsao.impl.CustomerMasterEnterpriseLookUpWSAO;

public class ConsumerSearchThread extends Thread {

	CustomerMasterEnterpriseLookUpResponse[] searchResponse = null;

	CustomerMasterEnterpriseLookUpBO lookUpBO;

	ICustomerMasterEnterpriseLookUpWSAO lookUpWSAO;

	CustomerMasterEnterpriseLookUpRequest customerMasterEnterpriseLookupRequest;

	
	CDILogger cdiLogger = null;
    String searchSource;
	int maxMemberCnt;
    
	ConsumerSearchThread(
			CustomerMasterEnterpriseLookUpRequest customerMasterReq, String searchSource,
			CustomerMasterEnterpriseLookUpBO lookUpBO,
			ICustomerMasterEnterpriseLookUpWSAO lookUpWSAO,CDILogger _cdilogger, int maxMemberCnt) {
		this.customerMasterEnterpriseLookupRequest = customerMasterReq;

		this.lookUpBO = lookUpBO;
		this.lookUpWSAO = lookUpWSAO;
		this.cdiLogger = _cdilogger;
	    this.searchSource = searchSource;
	    this.maxMemberCnt=maxMemberCnt;
	}

	public void run() {
		
MemRowList MemberList = null;
		
		long starttime= 0;
		long endtime = 0;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss:S");
		
	try{
		starttime = Calendar.getInstance().getTimeInMillis();
		Date startTime = new Date();
		cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|CDIWS to RefHub|"+(formatter.format(startTime))+"|"); 
		//Code Changes Start CDI-368
		 //((CustomerMasterEnterpriseLookUpWSAO)lookUpWSAO).getLoggingHandlerObj().setTrackingInfoProxyBean(cdiLogger.getTrackingInfoProxyBean());
		 //Code Changes END CDI-368
		MemberList = lookUpWSAO.getDatafromRefHub(customerMasterEnterpriseLookupRequest,searchSource,
				CustomerMasterConstants.SEG_CODE_MEMHEAD,false);
		endtime = Calendar.getInstance().getTimeInMillis();
		cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|RefHub to CDIWS|"+(endtime-starttime)+"|");
	
		if (CustomerMasterConstants.ENT_PV_TABLE_SEARCH) {
			searchResponse = lookUpWSAO.getDetailsFromRefPVtable(MemberList,maxMemberCnt);
		}
		else{
			//System.out.println("PV search disabled.Seraching in hub");
		}
		if (searchResponse == null) {
			//System.out.println("No records in PV table.Seraching in REF hub");
			starttime = Calendar.getInstance().getTimeInMillis();
			Date startTime2 = new Date();
			cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|CDIWS to RefHub|"+(formatter.format(startTime2))+"|");
			searchResponse = lookUpWSAO.lookUpConsumerMasterDynamic(
					customerMasterEnterpriseLookupRequest,searchSource,false,maxMemberCnt);
			endtime = Calendar.getInstance().getTimeInMillis();
			cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|RefHub to CDIWS|"+(endtime-starttime)+"|");

		}

	}
	
	catch (Exception e) {
		endtime = Calendar.getInstance().getTimeInMillis();
		cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|RefHub to CDIWS|RUN TIME EXCEPTION|"+(endtime-starttime)+"|");
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	
	
	
	
	
	
	}
}
