package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateResponse;

public interface ICustomerMasterEntUpdateBO {
	
	public void validateRequestObject(CustomerMasterEntUpdateRequest customerMasterEntUpdateRequest) throws BusinessRuleViolationException;

	public CustomerMasterEntUpdateResponse updateCustomerMasterEnt(CustomerMasterEntUpdateRequest customerMasterEntUpdateRequest) throws SystemException, BusinessRuleViolationException;
	
	
}
