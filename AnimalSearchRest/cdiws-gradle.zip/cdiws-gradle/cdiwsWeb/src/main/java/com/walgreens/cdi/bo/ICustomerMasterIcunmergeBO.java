package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterIcunmergeRequest;

public interface ICustomerMasterIcunmergeBO {
	
	public boolean icunmergeCustomerMaster(CustomerMasterIcunmergeRequest CcustomerMasterIcunmergeRequest) throws SystemException, BusinessRuleViolationException;

	public void validateRequestObject(CustomerMasterIcunmergeRequest customerMasterIcunmergeRequest) throws BusinessRuleViolationException;

}
