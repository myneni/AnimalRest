package com.walgreens.cdi.bo.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import walgreens.services.LoggingFacility;

import com.initiate.bean.ArrayOfMember;
import com.walgreens.cdi.util.CDILogger;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpRequest;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpResponse;
import com.walgreens.cdi.vo.TrackingInfoVO;
import com.walgreens.cdi.wsao.ICustomerMasterEntLookUpWSAO;
import com.walgreens.cdi.wsao.impl.CustomerMasterEntLookUpWSAO;


public class CustomerMasterCDISearchThread extends Thread {	

	CustomerMasterEntLookUpResponse[] searchResponse = null;

	CustomerMasterEntLookUpBO lookUpBO;

	ICustomerMasterEntLookUpWSAO lookUpWSAO;

	CustomerMasterEntLookUpRequest customerMasterEntLookupRequest;

	String srcCodeFilter;
	String getType;
	String userID;
	String passWd;
	
	
	CDILogger cdiLogger = null;
	TrackingInfoVO localTrackingInfoVo=null;

	CustomerMasterCDISearchThread(
			CustomerMasterEntLookUpRequest customerMasterReq,
			String srcCodeFilter, CustomerMasterEntLookUpBO lookUpBO,
			ICustomerMasterEntLookUpWSAO lookUpWSAO, String getType,
			String userId, String passwd,CDILogger _cdilogger, TrackingInfoVO localTrackingInfoVo) {
		this.customerMasterEntLookupRequest = customerMasterReq;
		this.srcCodeFilter = srcCodeFilter;
		this.lookUpBO = lookUpBO;
		this.lookUpWSAO = lookUpWSAO;
		this.getType = getType;
		this.userID = userId;
		this.passWd = passwd;
		this.cdiLogger = _cdilogger;
		this.localTrackingInfoVo=localTrackingInfoVo;
		
	}

	public void run() {

		ArrayOfMember arrMemberRes = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss:S");

		long starttime= 0;
		long endtime = 0;
		
		try {
			 starttime = Calendar.getInstance().getTimeInMillis();
			 Date startTime = new Date();
			 cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpService|CDIWS to InitiateWS|"+(formatter.format(startTime))+"|");
			 //Code Changes Start CDI-368
			/* ((CustomerMasterEntLookUpWSAO)lookUpWSAO).getLoggingHandlerObj().setTrackingInfoProxyBean(cdiLogger.getTrackingInfoProxyBean());*/
			// ((CustomerMasterEntLookUpWSAO)lookUpWSAO).getLoggingHandlerObj().setTrackingInfoProxyBean(localTrackingInfoVo);
			 //Code Changes END CDI-368
			 arrMemberRes = lookUpWSAO.getCdiMemHead(customerMasterEntLookupRequest,
					srcCodeFilter,getType, userID,passWd,false,localTrackingInfoVo);
			 endtime = Calendar.getInstance().getTimeInMillis();
			 cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpService|InitiateWS to CDIWS|"+(endtime-starttime)+"|");
			
		if(CustomerMasterConstants.ENT_PV_TABLE_SEARCH){
		searchResponse = lookUpBO.getCVLinkageFromPVtable(arrMemberRes,						
						customerMasterEntLookupRequest.getEntReturnLinkages());
		}
		else{
			//System.out.println("PV search disabled.Seraching in hub");
		}
		if (searchResponse == null) {
			//System.out.println("No records in PV table.Seraching in CDI hub");
			Date startTime2 = new Date();
			starttime = Calendar.getInstance().getTimeInMillis();
			cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpService|CDIWS to InitiateWS|"+(formatter.format(startTime2))+"|");
			searchResponse = lookUpWSAO.lookUpEntCustomerMasterCdi(
					customerMasterEntLookupRequest, srcCodeFilter, getType,userID,passWd,false,localTrackingInfoVo);
			endtime = Calendar.getInstance().getTimeInMillis();
			cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpService|InitiateWS to CDIWS|"+(endtime-starttime)+"|");

		}
		} catch (Exception e) {
			 endtime = Calendar.getInstance().getTimeInMillis();
			 cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpService|InitiateWS to CDIWS|RUN TIME EXCEPTION|"+(endtime-starttime)+"|");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
