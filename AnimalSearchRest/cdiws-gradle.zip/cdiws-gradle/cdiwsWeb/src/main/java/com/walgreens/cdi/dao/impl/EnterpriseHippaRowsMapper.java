package com.walgreens.cdi.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseSearch;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddress;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttrNCOA;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterBirthDate;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterDeceasedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEmail;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEntSearchPhone;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEnterpriseSearchAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterGender;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLockedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterName;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterOrigin;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPetInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPhoneAttr;

public class EnterpriseHippaRowsMapper implements ParameterizedRowMapper<CustomerMasterEnterpriseSearch>{
	
	String globalSQL = null;
	long lastTime = 0L;
	public EnterpriseHippaRowsMapper(){
	}
	
	public EnterpriseHippaRowsMapper(String sql, long st){
		globalSQL = sql;
		lastTime = st;
	}
	/**
	 * This method is used to map the rows in database
	 * 
	 * @param rs
	 *            ,rowNum
	 * @return
	 */
	public CustomerMasterEnterpriseSearch mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerMasterEnterpriseSearch customer = new CustomerMasterEnterpriseSearch();
		try
		{
			 
			CustomerMasterEnterpriseSearchAttr custAll = new CustomerMasterEnterpriseSearchAttr();
		
//		Set Name
		CustomerMasterName name = new CustomerMasterName();
		name.setFirstName(rs.getString(CustomerMasterConstants.FLD_FIRSTNAME)!=null?rs.getString(CustomerMasterConstants.FLD_FIRSTNAME):"");
		name.setMiddleName(rs.getString(CustomerMasterConstants.FLD_MIDDLENAME)!=null?rs.getString(CustomerMasterConstants.FLD_MIDDLENAME):"");
		name.setLastName(rs.getString(CustomerMasterConstants.FLD_LASTNAME)!=null?rs.getString(CustomerMasterConstants.FLD_LASTNAME):"");
		name.setPrefixName(rs.getString(CustomerMasterConstants.PREFIX_NAME)!=null?rs.getString(CustomerMasterConstants.PREFIX_NAME):"");	
		name.setSuffixName(rs.getString(CustomerMasterConstants.FLD_SUFFIXNAME)!=null?rs.getString(CustomerMasterConstants.FLD_SUFFIXNAME):"");	
		name.setLastUpdateDate(rs.getString(CustomerMasterConstants.NAME_UPDATE)!=null?rs.getString(CustomerMasterConstants.NAME_UPDATE):"");
		name.setSourceCode(rs.getString(CustomerMasterConstants.NAME_SRC_CODE)!=null?rs.getString(CustomerMasterConstants.NAME_SRC_CODE):"");
		name.setSecurityClassCode(rs.getString(CustomerMasterConstants.NAME_SEC_CODE)!=null?rs.getString(CustomerMasterConstants.NAME_SEC_CODE):"");
		
		if (!name.isNull()){
			custAll.setName(name);
		}
		//set Gender				
		CustomerMasterGender gender = new CustomerMasterGender();
		gender.setSecurityClassCode(rs.getString(CustomerMasterConstants.GENDER_SEC_CODE)!=null?rs.getString(CustomerMasterConstants.GENDER_SEC_CODE):"");
		gender.setGenderCode(rs.getString(CustomerMasterConstants.GENDER)!=null?rs.getString(CustomerMasterConstants.GENDER):"");
		gender.setLastUpdateDate(rs.getString(CustomerMasterConstants.GENDER_UPDATE)!=null?rs.getString(CustomerMasterConstants.GENDER_UPDATE):"");
		gender.setSourceCode(rs.getString(CustomerMasterConstants.GENDER_SRC_CODE)!=null?rs.getString(CustomerMasterConstants.GENDER_SRC_CODE):"");
		
		if(!gender.isNull()){
			customer.setGender(gender);
		}
		//PETIND
		CustomerMasterPetInd petInd = new CustomerMasterPetInd();
		petInd.setPetIndicator(rs.getString(CustomerMasterConstants.PETIND)!=null?rs.getString(CustomerMasterConstants.PETIND):"");
		petInd.setLastUpdateDate(rs.getString(CustomerMasterConstants.PET_UPDATE)!=null?rs.getString(CustomerMasterConstants.PET_UPDATE):"");
		petInd.setSecurityClassCode(rs.getString(CustomerMasterConstants.PET_SEC_CODE)!=null?rs.getString(CustomerMasterConstants.PET_SEC_CODE):"");
		petInd.setSourceCode(rs.getString(CustomerMasterConstants.PET_SRC_CODE)!=null?rs.getString(CustomerMasterConstants.PET_SRC_CODE):"");
		if(!petInd.isNull()){
			customer.setPetInd(petInd);
		}
		//DeceasedIND
		CustomerMasterDeceasedInd deceasedInd = new CustomerMasterDeceasedInd();
		deceasedInd.setDeceasedIndicator(rs.getString(CustomerMasterConstants.DEATH_IND)!=null?rs.getString(CustomerMasterConstants.DEATH_IND):"");
		deceasedInd.setLastUpdateDate(rs.getString(CustomerMasterConstants.DEATH_UPDATE)!=null?rs.getString(CustomerMasterConstants.DEATH_UPDATE):"");
		deceasedInd.setSecurityClassCode(rs.getString(CustomerMasterConstants.DEATH_SEC_CODE)!=null?rs.getString(CustomerMasterConstants.DEATH_SEC_CODE):"");
		deceasedInd.setSourceCode(rs.getString(CustomerMasterConstants.DEATH_SRC_CODE)!=null?rs.getString(CustomerMasterConstants.DEATH_SRC_CODE):"");
		if(!deceasedInd.isNull()){
			customer.setDeceasedInd(deceasedInd);
		}
		//EMAIL
		CustomerMasterEmail customerEmail = new CustomerMasterEmail();
		customerEmail.setEmailAddress(rs.getString(CustomerMasterConstants.EMAIL)!=null?rs.getString(CustomerMasterConstants.EMAIL):"");
		//customerEmail.setEmailUsageType(rs.getString("EmailTYPE"));
		customerEmail.setLastUpdateDate(rs.getString(CustomerMasterConstants.EMAIL_UPDATE)!=null?rs.getString(CustomerMasterConstants.EMAIL_UPDATE):"");
		customerEmail.setSecurityClassCode(rs.getString(CustomerMasterConstants.EMAIL_SEC_CODE)!=null?rs.getString(CustomerMasterConstants.EMAIL_SEC_CODE):"");
		customerEmail.setSourceCode(rs.getString(CustomerMasterConstants.EMAIL_SRC_CODE)!=null?rs.getString(CustomerMasterConstants.EMAIL_SRC_CODE):"");
		if(!customerEmail.isNull()){
			custAll.setEmail(customerEmail);
		}
		//LOCKIND
		CustomerMasterLockedInd lockedInd = new CustomerMasterLockedInd();
		lockedInd.setLockedIndicator(rs.getString(CustomerMasterConstants.LOCK_IND)!=null?rs.getString(CustomerMasterConstants.LOCK_IND):"");
		lockedInd.setLastUpdateDate(rs.getString(CustomerMasterConstants.LOCK_UPDATE)!=null?rs.getString(CustomerMasterConstants.LOCK_UPDATE):"");
		lockedInd.setSecurityClassCode(rs.getString(CustomerMasterConstants.LOCK_SEC_CODE)!=null?rs.getString(CustomerMasterConstants.LOCK_SEC_CODE):"");
		lockedInd.setSourceCode(rs.getString(CustomerMasterConstants.LOCK_SRC_CODE)!=null?rs.getString(CustomerMasterConstants.LOCK_SRC_CODE):"");
		if(!lockedInd.isNull()){
			customer.setLockedInd(lockedInd);
		}	
	   //BIRTHDT
		CustomerMasterBirthDate customerBirthDate = new CustomerMasterBirthDate();
		customerBirthDate.setBirthdate(rs.getString(CustomerMasterConstants.BIRTH_DATE)!=null?rs.getString(CustomerMasterConstants.BIRTH_DATE):"");
		customerBirthDate.setLastUpdateDate(rs.getString(CustomerMasterConstants.BIRTH_UPDATE)!=null?rs.getString(CustomerMasterConstants.BIRTH_UPDATE):"");
		customerBirthDate.setSecurityClassCode(rs.getString(CustomerMasterConstants.BIRTH_SEC_CODE)!=null?rs.getString(CustomerMasterConstants.BIRTH_SEC_CODE):"");
		customerBirthDate.setSourceCode(rs.getString(CustomerMasterConstants.BIRTH_SRC_CODE)!=null?rs.getString(CustomerMasterConstants.BIRTH_SRC_CODE):"");
		if(!customerBirthDate.isNull()){
			custAll.setBirthDate(customerBirthDate);
		}
		//CUSTORGN
		
		CustomerMasterOrigin origin = new CustomerMasterOrigin();
		origin.setOriginCode(rs.getString(CustomerMasterConstants.STOREORIG)!=null?rs.getString(CustomerMasterConstants.STOREORIG):"");
		origin.setStoreIndicator(rs.getString(CustomerMasterConstants.STOREIND)!=null?rs.getString(CustomerMasterConstants.STOREIND):"");
		origin.setLastUpdateDate(rs.getString(CustomerMasterConstants.STOREUPDATE)!=null?rs.getString(CustomerMasterConstants.STOREUPDATE):"");
		origin.setSecurityClassCode(rs.getString(CustomerMasterConstants.STORESECCODE)!=null?rs.getString(CustomerMasterConstants.STORESECCODE):"");
		origin.setSourceCode(rs.getString(CustomerMasterConstants.STORESRCCODE)!=null?rs.getString(CustomerMasterConstants.STORESRCCODE):"");
		if(!origin.isNull()){
			customer.setOrigin(origin);
		}
	//Address
		CustomerMasterAddress address = new CustomerMasterAddress();
		//PRADDR
		CustomerMasterAddressAttrNCOA permAddress = new CustomerMasterAddressAttrNCOA(CustomerMasterConstants.CM_ADDRESS_TYPE_P);
		permAddress.setAddressUsageType(rs.getString(CustomerMasterConstants.ADDR_TYPE)!=null?rs.getString(CustomerMasterConstants.ADDR_TYPE):"");
		permAddress.setCASSFootnote(rs.getString(CustomerMasterConstants.PFTNOTE)!=null?rs.getString(CustomerMasterConstants.PFTNOTE):"");
		permAddress.setCity(rs.getString(CustomerMasterConstants.PCUSTCITY)!=null?rs.getString(CustomerMasterConstants.PCUSTCITY):"");
		permAddress.setCountry(rs.getString(CustomerMasterConstants.PCUSTCOUNTRY)!=null?rs.getString(CustomerMasterConstants.PCUSTCOUNTRY):"");
		permAddress.setDPVFootnote(rs.getString(CustomerMasterConstants.PDPVFTNOTE)!=null?rs.getString(CustomerMasterConstants.PDPVFTNOTE):"");
		permAddress.setDPVIndicator(rs.getString(CustomerMasterConstants.PDPVIND)!=null?rs.getString(CustomerMasterConstants.PDPVIND):"");
		permAddress.setLACSAddressFlag(rs.getString(CustomerMasterConstants.PLACSADDRFLAG)!=null?rs.getString(CustomerMasterConstants.PLACSADDRFLAG):"");
		permAddress.setLACSFootnote(rs.getString(CustomerMasterConstants.PLACSFTNOTE)!=null?rs.getString(CustomerMasterConstants.PLACSFTNOTE):"");
		permAddress.setLACSReturnCode(rs.getString(CustomerMasterConstants.PLACSRTRNCODE)!=null?rs.getString(CustomerMasterConstants.PLACSRTRNCODE):"");
		permAddress.setLastUpdateDate(rs.getString(CustomerMasterConstants.PADDRUPDATE)!=null?rs.getString(CustomerMasterConstants.PADDRUPDATE):"");
		permAddress.setLatitude(rs.getString(CustomerMasterConstants.PLATITUDE)!=null?rs.getString(CustomerMasterConstants.PLATITUDE):"");
		permAddress.setLongitude(rs.getString(CustomerMasterConstants.PLONGITUDE)!=null?rs.getString(CustomerMasterConstants.PLONGITUDE):"");
		permAddress.setNCOAActionCode(rs.getString(CustomerMasterConstants.PNCOA_ACT_CODE)!=null?rs.getString(CustomerMasterConstants.PNCOA_ACT_CODE):"");
	    permAddress.setNCOAANKCode(rs.getString(CustomerMasterConstants.PNCOA_ANK_CODE)!=null?rs.getString(CustomerMasterConstants.PNCOA_ANK_CODE):"");
	    permAddress.setNCOAMoveDate(rs.getString(CustomerMasterConstants.PNCOA_MV_DATE)!=null?rs.getString(CustomerMasterConstants.PNCOA_MV_DATE):"");
	    permAddress.setNCOAMoveType(rs.getString(CustomerMasterConstants.PNCOA_MV_TYPE)!=null?rs.getString(CustomerMasterConstants.PNCOA_MV_TYPE):"");	    
	    permAddress.setNCOANewAddressFlag(rs.getString(CustomerMasterConstants.PNCOA_NEW_ADDR_FLG)!=null?rs.getString(CustomerMasterConstants.PNCOA_NEW_ADDR_FLG):"");
	    permAddress.setNCOANIXIEFootnote(rs.getString(CustomerMasterConstants.PNCOA_NIX_FTNOTE)!=null?rs.getString(CustomerMasterConstants.PNCOA_NIX_FTNOTE):"");
	    permAddress.setNCOAProcessDate(rs.getString(CustomerMasterConstants.PNCOA_PR_DATE)!=null?rs.getString(CustomerMasterConstants.PNCOA_PR_DATE):"");
	    permAddress.setNCOAReturnCode(rs.getString(CustomerMasterConstants.PNCOA_RTRN_CODE)!=null?rs.getString(CustomerMasterConstants.PNCOA_RTRN_CODE):"");
	    permAddress.setSecurityClassCode(rs.getString(CustomerMasterConstants.PADDR_SEC_CODE)!=null?rs.getString(CustomerMasterConstants.PADDR_SEC_CODE):"");
	    permAddress.setSourceCode(rs.getString(CustomerMasterConstants.PADDR_SRC_CODE)!=null?rs.getString(CustomerMasterConstants.PADDR_SRC_CODE):"");
	    permAddress.setStandardizationProcessDate(rs.getString(CustomerMasterConstants.PPRDATE)!=null?rs.getString(CustomerMasterConstants.PPRDATE):"");
	    permAddress.setState(rs.getString(CustomerMasterConstants.PCUSTSTATE)!=null?rs.getString(CustomerMasterConstants.PCUSTSTATE):"");
	    permAddress.setStreetLine1(rs.getString(CustomerMasterConstants.PCUSTSTLINE1)!=null?rs.getString(CustomerMasterConstants.PCUSTSTLINE1):"");
	    permAddress.setStreetLine2(rs.getString(CustomerMasterConstants.PCUSTSTLINE2)!=null?rs.getString(CustomerMasterConstants.PCUSTSTLINE2):"");
	    permAddress.setUrbanizationCode(rs.getString(CustomerMasterConstants.PURBCODE)!=null?rs.getString(CustomerMasterConstants.PURBCODE):"");
	    permAddress.setUSPSAddressType(rs.getString(CustomerMasterConstants.PADDRTYPE)!=null?rs.getString(CustomerMasterConstants.PADDRTYPE):"");
	    permAddress.setZipCode(rs.getString(CustomerMasterConstants.PCUSTZIPCODE)!=null?rs.getString(CustomerMasterConstants.PCUSTZIPCODE):"");
	    if(!permAddress.isNull()){
	    	address.setPermAddress(permAddress);
	    }
	    //PRADDR2
	    CustomerMasterAddressAttr home2Address = new CustomerMasterAddressAttr(CustomerMasterConstants.CM_ADDRESS_TYPE_2);
	    home2Address.setAddressUsageType(rs.getString(CustomerMasterConstants.ADDRTYPE2)!=null?rs.getString(CustomerMasterConstants.ADDRTYPE2):"");
	    home2Address.setCASSFootnote(rs.getString(CustomerMasterConstants.HFTNOTE)!=null?rs.getString(CustomerMasterConstants.HFTNOTE):"");
	    home2Address.setCity(rs.getString(CustomerMasterConstants.HCUST_CITY)!=null?rs.getString(CustomerMasterConstants.HCUST_CITY):"");
	    home2Address.setCountry(rs.getString(CustomerMasterConstants.HCUST_COUNTRY)!=null?rs.getString(CustomerMasterConstants.HCUST_COUNTRY):"");
		home2Address.setDPVFootnote(rs.getString(CustomerMasterConstants.HDPV_FTNOTE)!=null?rs.getString(CustomerMasterConstants.HDPV_FTNOTE):"");
		home2Address.setDPVIndicator(rs.getString(CustomerMasterConstants.HDPV_IND)!=null?rs.getString(CustomerMasterConstants.HDPV_IND):"");
		home2Address.setLACSAddressFlag( rs.getString(CustomerMasterConstants.HLACS_ADDR_FLAG)!=null?rs.getString(CustomerMasterConstants.HLACS_ADDR_FLAG):"");
		home2Address.setLACSFootnote(rs.getString(CustomerMasterConstants.HLACS_FTNOTE)!=null?rs.getString(CustomerMasterConstants.HLACS_FTNOTE):"");
		home2Address.setLACSReturnCode(rs.getString(CustomerMasterConstants.HLACS_RTRN_CODE)!=null?rs.getString(CustomerMasterConstants.HLACS_RTRN_CODE):"");		
	    home2Address.setLastUpdateDate(rs.getString(CustomerMasterConstants.HADDRUPDATE)!=null?rs.getString(CustomerMasterConstants.HADDRUPDATE):"");
		home2Address.setLongitude(rs.getString(CustomerMasterConstants.HLONGITUDE)!=null?rs.getString(CustomerMasterConstants.HLONGITUDE):"");
		home2Address.setLatitude(rs.getString(CustomerMasterConstants.HLATITUDE)!=null?rs.getString(CustomerMasterConstants.HLATITUDE):"");
		home2Address.setSecurityClassCode(rs.getString(CustomerMasterConstants.HADDRSECCODE)!=null?rs.getString(CustomerMasterConstants.HADDRSECCODE):"");
		home2Address.setSourceCode(rs.getString(CustomerMasterConstants.HADDRSRCCODE)!=null?rs.getString(CustomerMasterConstants.HADDRSRCCODE):"");
		home2Address.setStandardizationProcessDate(rs.getString(CustomerMasterConstants.HPRDATE)!=null?rs.getString(CustomerMasterConstants.HPRDATE):"");
	    home2Address.setStreetLine1(rs.getString(CustomerMasterConstants.HCUST_STLINE1)!=null?rs.getString(CustomerMasterConstants.HCUST_STLINE1):"");
		home2Address.setStreetLine2(rs.getString(CustomerMasterConstants.HCUST_STLINE2)!=null?rs.getString(CustomerMasterConstants.HCUST_STLINE2):"");		
		home2Address.setState(rs.getString(CustomerMasterConstants.HCUST_STATE)!=null?rs.getString(CustomerMasterConstants.HCUST_STATE):"");
		home2Address.setUrbanizationCode(rs.getString(CustomerMasterConstants.HURBCODE)!=null?rs.getString(CustomerMasterConstants.HURBCODE):"");
		home2Address.setUSPSAddressType(rs.getString(CustomerMasterConstants.HADDRTYPE)!=null?rs.getString(CustomerMasterConstants.HADDRTYPE):"");
		home2Address.setZipCode(rs.getString(CustomerMasterConstants.HCUST_ZIP_CODE)!=null?rs.getString(CustomerMasterConstants.HCUST_ZIP_CODE):"");
		if(!home2Address.isNull()){
			address.setHome2Address(home2Address);
		}
		//WORKADDR
		CustomerMasterAddressAttr workAddress = new CustomerMasterAddressAttr(CustomerMasterConstants.CM_ADDRESS_TYPE_W);
		workAddress.setAddressUsageType(rs.getString(CustomerMasterConstants.ADDRTYPE3)!=null?rs.getString(CustomerMasterConstants.ADDRTYPE3):"");
		workAddress.setCASSFootnote(rs.getString(CustomerMasterConstants.WFTNOTE)!=null?rs.getString(CustomerMasterConstants.WFTNOTE):"");
		workAddress.setCity(rs.getString(CustomerMasterConstants.WCUSTCITY)!=null?rs.getString(CustomerMasterConstants.WCUSTCITY):"");
		workAddress.setCountry(rs.getString(CustomerMasterConstants.WCUSTCOUNTRY)!=null?rs.getString(CustomerMasterConstants.WCUSTCOUNTRY):"");
		workAddress.setDPVFootnote(rs.getString(CustomerMasterConstants.WDPVFTNOTE)!=null?rs.getString(CustomerMasterConstants.WDPVFTNOTE):"");
		workAddress.setDPVIndicator(rs.getString(CustomerMasterConstants.WDPVIND)!=null?rs.getString(CustomerMasterConstants.WDPVIND):"");
		workAddress.setLACSAddressFlag(rs.getString(CustomerMasterConstants.WLACSADDRFLAG)!=null?rs.getString(CustomerMasterConstants.WLACSADDRFLAG):"");
		workAddress.setLACSFootnote(rs.getString(CustomerMasterConstants.WLACSFTNOTE)!=null?rs.getString(CustomerMasterConstants.WLACSFTNOTE):"");
		workAddress.setLACSReturnCode(rs.getString(CustomerMasterConstants.WLACSRTRNCODE)!=null?rs.getString(CustomerMasterConstants.WLACSRTRNCODE):"");
		workAddress.setLastUpdateDate(rs.getString(CustomerMasterConstants.WADDRUPDATE)!=null?rs.getString(CustomerMasterConstants.WADDRUPDATE):"");
		workAddress.setLatitude(rs.getString(CustomerMasterConstants.WLATITUDE)!=null?rs.getString(CustomerMasterConstants.WLATITUDE):"");
		workAddress.setLongitude(rs.getString(CustomerMasterConstants.WLONGITUDE)!=null?rs.getString(CustomerMasterConstants.WLONGITUDE):"");
		workAddress.setSecurityClassCode(rs.getString(CustomerMasterConstants.WADDRSECCODE)!=null?rs.getString(CustomerMasterConstants.WADDRSECCODE):"");
		workAddress.setSourceCode(rs.getString(CustomerMasterConstants.WADDRSRCCODE)!=null?rs.getString(CustomerMasterConstants.WADDRSRCCODE):"");
		workAddress.setStandardizationProcessDate(rs.getString(CustomerMasterConstants.WPRDATE)!=null?rs.getString(CustomerMasterConstants.WPRDATE):"");
		workAddress.setState(rs.getString(CustomerMasterConstants.WCUSTSTATE)!=null?rs.getString(CustomerMasterConstants.WCUSTSTATE):"");
		workAddress.setStreetLine1(rs.getString(CustomerMasterConstants.WCUSTSTLINE1)!=null?rs.getString(CustomerMasterConstants.WCUSTSTLINE1):"");
		workAddress.setStreetLine2(rs.getString(CustomerMasterConstants.WCUSTSTLINE2)!=null?rs.getString(CustomerMasterConstants.WCUSTSTLINE2):"");
		workAddress.setUrbanizationCode(rs.getString(CustomerMasterConstants.WURBCODE)!=null?rs.getString(CustomerMasterConstants.WURBCODE):"");
		workAddress.setUSPSAddressType(rs.getString(CustomerMasterConstants.WADDRTYPE)!=null?rs.getString(CustomerMasterConstants.WADDRTYPE):"");
		workAddress.setZipCode(rs.getString(CustomerMasterConstants.WCUSTZIPCODE)!=null?rs.getString(CustomerMasterConstants.WCUSTZIPCODE):"");
		if(!workAddress.isNull()){
			address.setWorkAddress(workAddress);
		}
		custAll.setAddress(address);
		
		CustomerMasterEntSearchPhone phone = new CustomerMasterEntSearchPhone();
	
		//cellPHONE
			CustomerMasterPhoneAttr cellPhone = new CustomerMasterPhoneAttr(
					CustomerMasterConstants.CM_PHONE_TYPE_C);
			cellPhone.setUsageType(populateValue(rs
					.getString(CustomerMasterConstants.CPHTYPE)));
			cellPhone.setAreaCode(populateValue(rs
					.getString(CustomerMasterConstants.CPHAREA)));
			cellPhone.setPhoneNumber(populateValue(rs
					.getString(CustomerMasterConstants.CPHNUMBER)));
			cellPhone.setLastUpdateDate(populateValue(rs
					.getString(CustomerMasterConstants.CPHUPDATE)));
			cellPhone.setSourceCode(populateValue(rs
					.getString(CustomerMasterConstants.CPHSRCCODE)));
			cellPhone.setSecurityClassCode(populateValue(rs
					.getString(CustomerMasterConstants.CPHSECCODE)));
			cellPhone
					.setPhonePriority(rs
							.getString(CustomerMasterConstants.CPHPRIORITY) != null ? rs
							.getString(CustomerMasterConstants.CPHPRIORITY)
							: CustomerMasterConstants.PRIOR_PRIMARY);
			if (!cellPhone.isNull()) {
				phone.setCellPhone(cellPhone);
			}
			
				// PRPHONE
			CustomerMasterPhoneAttr homePhone = new CustomerMasterPhoneAttr(
					CustomerMasterConstants.CM_PHONE_TYPE_H);
			homePhone.setUsageType(populateValue(rs
					.getString(CustomerMasterConstants.HPHTYPE)));
			homePhone.setAreaCode(populateValue(rs
					.getString(CustomerMasterConstants.HPHAREA)));
			homePhone.setPhoneNumber(populateValue(rs
					.getString(CustomerMasterConstants.HPHNUMBER)));
			homePhone.setLastUpdateDate(populateValue(rs
					.getString(CustomerMasterConstants.HPHUPDATE)));
			homePhone.setSourceCode(populateValue(rs
					.getString(CustomerMasterConstants.HPHSRCCODE)));
			homePhone.setSecurityClassCode(populateValue(rs
					.getString(CustomerMasterConstants.HPHSECCODE)));
			homePhone
					.setPhonePriority(rs
							.getString(CustomerMasterConstants.HPHPRIORITY) != null ? rs
							.getString(CustomerMasterConstants.HPHPRIORITY)
							: (cellPhone.isNull() ? CustomerMasterConstants.PRIOR_PRIMARY
									: CustomerMasterConstants.PRIOR_ALT1));
			if (!homePhone.isNull()) {
				phone.setHomePhone(homePhone);
			}
			
		// WKPHONE
			CustomerMasterPhoneAttr workPhone = new CustomerMasterPhoneAttr(
					CustomerMasterConstants.CM_PHONE_TYPE_W);
			workPhone.setUsageType(populateValue(rs
					.getString(CustomerMasterConstants.WPHTYPE)));
			workPhone.setAreaCode(populateValue(rs
					.getString(CustomerMasterConstants.WPHAREA)));
			workPhone.setPhoneNumber(populateValue(rs
					.getString(CustomerMasterConstants.WPHNUMBER)));
			workPhone.setLastUpdateDate(populateValue(rs
					.getString(CustomerMasterConstants.WPHUPDATE)));
			workPhone.setSourceCode(populateValue(rs
					.getString(CustomerMasterConstants.WPHSRCCODE)));
			workPhone.setSecurityClassCode(populateValue(rs
					.getString(CustomerMasterConstants.WPHSECCODE)));
			// Phone Alignment Change
			String wphPrior = rs.getString(CustomerMasterConstants.WPHPRIORITY);
			if (wphPrior != null)
				workPhone.setPhonePriority(wphPrior);
			else if (!cellPhone.isNull() && !homePhone.isNull()) {
				workPhone.setPhonePriority(CustomerMasterConstants.PRIOR_ALT2);
			} else if (cellPhone.isNull() && homePhone.isNull()) {
				workPhone
						.setPhonePriority(CustomerMasterConstants.PRIOR_PRIMARY);
			} else {
				workPhone.setPhonePriority(CustomerMasterConstants.PRIOR_ALT1);
			}
			
			if (!workPhone.isNull()) {
				phone.setWorkPhone(workPhone);
			}
		custAll.setPhone(phone);
		customer.setCustAll(custAll);
		customer.setEID(rs.getString(CustomerMasterConstants.FLD_ENTITYID));
		customer.setGender(gender);
		customer.setLockedInd(lockedInd);
		customer.setSecCode(CustomerMasterConstants.SEC_CODE_H); //No Info Available-- Put "H" as per Larry
		
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return customer;		
		
	}
	private static String populateValue(String colValue) {
		if (colValue != null)
			return colValue;
		else
			return CustomerMasterConstants.BLANK_STRING;
	}

}
