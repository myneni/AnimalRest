package com.walgreens.cdi.util;

import java.io.IOException;
import java.util.Properties;

/**
 * @author kunal.janyani
 */
public final class ResourceBundleUtils {

	private static ResourceBundleUtils resourceBundleUtils;

	/**
	 * The properties loaded from ApllicationReaources.propeties.
	 */
	private static Properties messageProps = null;

	/**
	 * Gets the only single instance of <code>ResourceBundleUtils</code>.
	 * 
	 * @return single instance of <code>ResourceBundleUtils</code>
	 */
	public static ResourceBundleUtils getInstance() {
		if (resourceBundleUtils == null) {
			synchronized (ResourceBundleUtils.class) {
				resourceBundleUtils = new ResourceBundleUtils();
			}
		}
		return resourceBundleUtils;
	}

	/**
	 * Initialize the singleton object.
	 */
	private ResourceBundleUtils() {
		init();
	}

	/**
	 * Initializing method for properties.
	 */
	private void init() {
		messageProps = new Properties();
		try {
			for (Domain domain : Domain.values()) {
				messageProps.load(CustomerMasterConstants.class
						.getClassLoader().getResourceAsStream(
								domain.getFileName()));
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Retrives and returns the corresponding message for the passed in code
	 * from the loaded properties file.
	 * 
	 * @param code
	 *            Code for which the corresponding message to be retrived
	 * @return Corresponding message for the passed in code
	 */
	public String getMessage(final int code) {
		if (messageProps != null) {
			return messageProps.getProperty(String.valueOf(code));
		}
		return null;
	}

	/**
	 * Retrives and returns the corresponding message for the passed in code
	 * from the loaded properties file.
	 * 
	 * @param code
	 *            Code for which the corresponding message to be retrived
	 * @return Corresponding message for the passed in code
	 */
	public String getMessage(final String code) {
		if (messageProps != null) {
			return messageProps.getProperty(code);
		}
		return null;
	}

	/**
	 * Retrives and returns the corresponding message for the passed in code
	 * from the loaded properties file.
	 * 
	 * @param code
	 *            Code for which the corresponding message to be retrived
	 * @return Corresponding message for the passed in code
	 */
	public int getMessageCount(String code) {
		if (messageProps != null) {
			return Integer.parseInt(messageProps.getProperty(code));
		}
		return 0;
	}
}