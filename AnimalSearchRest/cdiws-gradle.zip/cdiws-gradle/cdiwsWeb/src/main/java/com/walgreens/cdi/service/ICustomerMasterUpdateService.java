package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterUpdateRequest;
/**
 * This service is an interface for exposing  updateCustomerMaster method at service
 * level.
 * 
 * @param CustomerMasterUpdateRequest
 * @return boolean
 * @throws CDIException
 * @author
 * 
 */

public interface ICustomerMasterUpdateService {
	
	public boolean updateCustomerMaster(CustomerMasterUpdateRequest customerMasterUpdateRequest) throws CDIException;
		

}
