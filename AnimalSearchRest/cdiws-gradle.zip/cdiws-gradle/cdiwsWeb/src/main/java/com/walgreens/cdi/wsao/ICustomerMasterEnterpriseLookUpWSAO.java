package com.walgreens.cdi.wsao;

import madison.mpi.MemRowList;

import com.initiate.bean.ArrayOfMember;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpResponse;
import com.walgreens.cdi.vo.TrackingInfoVO;
/**
 * This Interface have all the methods declaration of EnterPrise Lookup Methods that will be implemented in WSAO Class
 * @author 
 *
 */
public interface ICustomerMasterEnterpriseLookUpWSAO {
	
	public CustomerMasterEnterpriseLookUpResponse[] searchCustHub(CustomerMasterEnterpriseLookUpRequest customerMasterLookUpRequest,String initiateID, String initiatePWD,String SearchSrc,String segCodeFiletr);

	public ArrayOfMember getMemHeadfromCustomer  (
			CustomerMasterEnterpriseLookUpRequest customerMasterEnterpriseLookUpRequest,String searchSource,
			String initiateID, String initiatePWD,String cvType,boolean printCorelationlogger, TrackingInfoVO localTrackingInfoVo)throws Exception;
	public CustomerMasterEnterpriseLookUpResponse[] getDetailsFromCustomerPVtable(ArrayOfMember arrMemberRes,String cvType,String returnLinkages,int maxResponse,String applicationID);
	public CustomerMasterEnterpriseLookUpResponse[] lookUpCustomerMasterDynamic(
			CustomerMasterEnterpriseLookUpRequest enterpriseLookUpRequest,String searchSrc,
			String initiateID, String initiatePWD,String cvType,int maxMemberCnt,boolean printCorelationlogger, TrackingInfoVO localTrackingInfo)throws Exception;
	public MemRowList getDatafromRefHub (
			CustomerMasterEnterpriseLookUpRequest enterpriseLookUpRequest,String searchSource,
			String segCodeFilter, boolean printCorelationlogger)throws Exception ;
	CustomerMasterEnterpriseLookUpResponse[] getDetailsFromRefPVtable(
			MemRowList MemberList, int maxMemberCnt);
	CustomerMasterEnterpriseLookUpResponse[] lookUpConsumerMasterDynamic(
			CustomerMasterEnterpriseLookUpRequest enterpriseLookUpRequest,String searchSource,
			boolean printCorelationlogger,int maxMemberCnt) throws Exception;
}
