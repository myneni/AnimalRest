/**
 * 
 */
package com.walgreens.cdi.vo.customer.attr;

import com.walgreens.cdi.util.CustomerMasterConstants;

/**
 * @author Picketta
 *
 */
public class CustomerMasterName extends CustomerMasterAttributeStatus {
	//	 (Name attribute from all sources)		
	private String firstName;				//String (0/1)	AllSource FirstName.
	private String middleName;				//String (0/1)	AllSource MiddleName.
	private String lastName;					//String (0/1)	AllSource LastName.
	private String prefixName;				//String (0/1)	AllSource PrefixName,
	private String suffixName;				//String (0/1)	AllSource SuffixName.
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}
	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	/**
	 * @return the prefixName
	 */
	public String getPrefixName() {
		return prefixName;
	}
	/**
	 * @param prefixName the prefixName to set
	 */
	public void setPrefixName(String prefixName) {
		this.prefixName = prefixName;
	}
	/**
	 * @return the suffixName
	 */
	public String getSuffixName() {
		return suffixName;
	}
	/**
	 * @param suffixName the suffixName to set
	 */
	public void setSuffixName(String suffixName) {
		this.suffixName = suffixName;
	}
	
	
	public boolean isNull(){
		
		if(isNull(firstName)&& isNull(lastName)&&isNull(middleName)&&  isNull(prefixName)&& isNull(suffixName))
				return true;
		else
			return false;
	}
	
    private boolean isNull(String str){
    	if(str==null)
			return  true;
		if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
			return true;
		else
			return false;
	}
	
	public String toString() {
		String str="";
		str = "\nNAME:\n____________________________________\n"+
		      " firstName    =" + getFirstName() + "\n"+
			  " middleName   =" + getMiddleName()+ "\n"+
			  " lastName     =" + getLastName( ) + "\n"+
			  " prefixName   =" + getPrefixName()+ "\n"+
			  " suffixName   =" + getSuffixName()+ "\n" +
			  " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
			  " securityClassCode   =" + getSecurityClassCode() + "\n" +
			  " sourceCode   =" + getSourceCode() + "\n" ;
		
         return str;
	}
	
	public String toCompString() {
		String str="";
		 str = CustomerMasterConstants.DELIMITE_ATTR +
		      CustomerMasterConstants.COMP_ATTR_NAME_Name + CustomerMasterConstants.DELIMITE_FIELD +
		      getFirstName() + CustomerMasterConstants.DELIMITE_FIELD +
			  getMiddleName()+ CustomerMasterConstants.DELIMITE_FIELD +
			  getLastName( ) + CustomerMasterConstants.DELIMITE_FIELD +
			  getPrefixName()+ CustomerMasterConstants.DELIMITE_FIELD +
			  getSuffixName()+ CustomerMasterConstants.DELIMITE_FIELD +
			  getLastUpdateDate() + CustomerMasterConstants.DELIMITE_FIELD +
			  getSecurityClassCode()+ CustomerMasterConstants.DELIMITE_FIELD +
			  getSourceCode() + CustomerMasterConstants.DELIMITE_FIELD ;
		
         return str;
	}
}
