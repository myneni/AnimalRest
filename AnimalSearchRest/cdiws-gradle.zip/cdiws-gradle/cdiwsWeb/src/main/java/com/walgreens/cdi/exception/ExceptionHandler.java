package com.walgreens.cdi.exception;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.UnmarshalException;
import java.sql.SQLException;

import javax.xml.namespace.QName;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.Detail;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;



import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.util.ResourceBundleUtils;

/**
 * @author atul.prabhu
 */
public class ExceptionHandler {

    private static ResourceBundleUtils resourceBundleUtils;
    
    private static final String CANNOT_GET_JDBC_CONN_DETAIL_MESSAGE = "Could not get JDBC connection. The Database server may be down.";
    
    static {
        resourceBundleUtils = ResourceBundleUtils.getInstance();
    }


    public static void processException(Domain domain, Exception e)
            throws CDIException {

        if (e instanceof BusinessRuleViolationException) {
            processBRVException((BusinessRuleViolationException)e, domain);
        } else if (e instanceof SystemException) {
            processSystemException(e, domain);
        } else {
            processUnKnownException(e, domain);
        }
    }


    private static void processUnKnownException(Exception e, Domain domain)
            throws SystemException {
        processHandledException(domain, e);
        e.printStackTrace();
        throw new SystemException(domain.toString() + "0000" , resourceBundleUtils.getMessage("0000"), e.getMessage());
    }


    private static void processSystemException(Exception e, Domain domain)
            throws SystemException {
        SystemException systemException = (SystemException) e;
        Exception actualException = systemException.getException();
        processUnKnownException(actualException, domain);

    }


    private static void processHandledException(Domain domain,
            Exception actualException) throws SystemException {
        if (actualException instanceof SQLException) {
            throw new SystemException(domain.toString() + "0001", resourceBundleUtils.getMessage("0001"), actualException.getMessage());
        } else if (actualException instanceof IOException) {
            throw new SystemException(domain.toString() + "0002", resourceBundleUtils.getMessage("0002"), actualException.getMessage());
        } else if (actualException instanceof InvocationTargetException) {
            throw new SystemException(domain.toString() + "0020", resourceBundleUtils.getMessage("0020"),actualException.getMessage());
        } else if (actualException instanceof UnmarshalException) {
            throw new SystemException(domain.toString() + "0021" ,resourceBundleUtils.getMessage("0021"),actualException.getLocalizedMessage());
        }
    }


    private static void throwSOAPException(String faultCode, String message) throws SOAPException  {
        SOAPFactory soapFactory = SOAPFactory.newInstance();
        Detail detail = soapFactory.createDetail();
        detail.addDetailEntry(soapFactory.createName("Method", message, null));
        throw new SOAPFaultException(new QName("SOAP-ENV:Server"), faultCode,null,detail);
    }


    private static void processBRVException(BusinessRuleViolationException e, Domain domain) throws BusinessRuleViolationException {
        if(e.getMessage().length() == 4) {
            e.setMsg(resourceBundleUtils.getMessage(e.getMessage()));
            e.setDetailMessage(resourceBundleUtils.getMessage(e.getMessage()));
            throw e;
            //throwSOAPException(domain.toString() + e.getMessage() + " " + resourceBundleUtils.getMessage(e.getMessage()),resourceBundleUtils.getMessage(e.getMessage()));    
        } else {
            e.setMsg(resourceBundleUtils.getMessage(e.getMessage()));
            e.setDetailMessage(resourceBundleUtils.getMessage(e.getMessage()));
            throw e;
        }
    }
    

    public static CDIException processServiceException(Domain domain,
            CDIException actualException) {
          
        return new SystemException(domain.toString() + actualException.getErrorCode(), actualException.getDetailMessage(),resourceBundleUtils.getMessage(domain.toString() + actualException.getErrorCode()));
        
            
        }
    
    
   
 
}
