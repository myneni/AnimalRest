package com.walgreens.cdi.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterEntAttributesVO;
import com.walgreens.cdi.vo.CustomerMasterEntSearchProgramVO;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseSearch;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddress;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttrNCOA;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterBirthDate;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterDeceasedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEmail;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEntSearchPhone;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEnterpriseSearchAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterGender;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLockedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterName;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPetInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPhoneAttr;

public class EnterpriseLoyaltyMemRowsMapper implements ParameterizedRowMapper<CustomerMasterEnterpriseSearch>{

	
	String globalSQL = null;
	long lastTime = 0L;
	public EnterpriseLoyaltyMemRowsMapper(){
		
	}
	
	public EnterpriseLoyaltyMemRowsMapper(String sql, long st){
		
		globalSQL = sql;
		lastTime = st;
	}
	/**
	 * This method is used to map the rows in database
	 * 
	 * @param rs
	 *            ,rowNum
	 * @return
	 */
	public CustomerMasterEnterpriseSearch mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerMasterEnterpriseSearch customer = new CustomerMasterEnterpriseSearch();
		try
		{
		
		CustomerMasterEnterpriseSearchAttr custAll = new CustomerMasterEnterpriseSearchAttr();
		
//		Set Name
		CustomerMasterName name = new CustomerMasterName();
		name.setFirstName(rs.getString(CustomerMasterConstants.FLD_FIRSTNAME)!=null?rs.getString(CustomerMasterConstants.FLD_FIRSTNAME):"");
		name.setMiddleName(rs.getString(CustomerMasterConstants.FLD_MIDDLENAME)!=null?rs.getString(CustomerMasterConstants.FLD_MIDDLENAME):"");
		name.setLastName(rs.getString(CustomerMasterConstants.FLD_LASTNAME)!=null?rs.getString(CustomerMasterConstants.FLD_LASTNAME):"");
		name.setPrefixName(rs.getString(CustomerMasterConstants.FLD_PREFIXNAME)!=null?rs.getString(CustomerMasterConstants.FLD_PREFIXNAME):"");	
		name.setSuffixName(rs.getString(CustomerMasterConstants.FLD_SUFFIXNAME)!=null?rs.getString(CustomerMasterConstants.FLD_SUFFIXNAME):"");	
		name.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_NAMEUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_NAMEUPDATE):"");
		name.setSourceCode(rs.getString(CustomerMasterConstants.FLD_NAMSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_NAMSRCCODE):"");
		name.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_NAMSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_NAMSECCODE):"");
		
		if (!name.isNull()){
			custAll.setName(name);
		}
						
		//set Gender				
		CustomerMasterGender gender = new CustomerMasterGender();
		gender.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_GENDERSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_GENDERSECCODE):"");
		gender.setGenderCode(rs.getString(CustomerMasterConstants.FLD_GENDER)!=null?rs.getString(CustomerMasterConstants.FLD_GENDER):"");
		gender.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_GENDERUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_GENDERUPDATE):"");
		gender.setSourceCode(rs.getString(CustomerMasterConstants.FLD_GENDERSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_GENDERSRCCODE):"");
		
		if(!gender.isNull()){
			customer.setGender(gender);
		}
		
		//PETIND
		CustomerMasterPetInd petInd = new CustomerMasterPetInd();
		petInd.setPetIndicator(rs.getString(CustomerMasterConstants.FLD_PETIND)!=null?rs.getString(CustomerMasterConstants.FLD_PETIND):"");
		petInd.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_PETUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PETUPDATE):"");
		petInd.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_PETSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PETSECCODE):"");
		petInd.setSourceCode(rs.getString(CustomerMasterConstants.FLD_PETSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PETSRCCODE):"");
		if(!petInd.isNull()){
			customer.setPetInd(petInd);
		}
		
		//DeceasedIND
		CustomerMasterDeceasedInd deceasedInd = new CustomerMasterDeceasedInd();
		deceasedInd.setDeceasedIndicator(rs.getString(CustomerMasterConstants.FLD_DEATHIND)!=null?rs.getString(CustomerMasterConstants.FLD_DEATHIND):"");
		deceasedInd.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_DEATHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_DEATHUPDATE):"");
		deceasedInd.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_DEATHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_DEATHSECCODE):"");
		deceasedInd.setSourceCode(rs.getString(CustomerMasterConstants.FLD_DEATHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_DEATHSRCCODE):"");
		if(!deceasedInd.isNull()){
			customer.setDeceasedInd(deceasedInd);
		}
			
		//EMAIL
		CustomerMasterEmail customerEmail = new CustomerMasterEmail();
		customerEmail.setEmailAddress(rs.getString(CustomerMasterConstants.FLD_EMAIL)!=null?rs.getString(CustomerMasterConstants.FLD_EMAIL):"");
		customerEmail.setEmailUsageType(rs.getString(CustomerMasterConstants.FLD_EMAILTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_EMAILTYPE):"");
		customerEmail.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_EMAILUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_EMAILUPDATE):"");
		customerEmail.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_EMAILSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_EMAILSECCODE):"");
		customerEmail.setSourceCode(rs.getString(CustomerMasterConstants.FLD_EMAILSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_EMAILSRCCODE):"");
		if(!customerEmail.isNull()){
			custAll.setEmail(customerEmail);
		}
		
		//LOCKIND
		CustomerMasterLockedInd lockedInd = new CustomerMasterLockedInd();
		lockedInd.setLockedIndicator(rs.getString(CustomerMasterConstants.FLD_LOCKIND)!=null?rs.getString(CustomerMasterConstants.FLD_LOCKIND):"");
		lockedInd.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_LOCKUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_LOCKUPDATE):"");
		lockedInd.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_LOCKSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_LOCKSECCODE):"");
		lockedInd.setSourceCode(rs.getString(CustomerMasterConstants.FLD_LOCKSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_LOCKSRCCODE):"");
		if(!lockedInd.isNull()){
			customer.setLockedInd(lockedInd);
		}		
		
	   //BIRTHDT
		CustomerMasterBirthDate customerBirthDate = new CustomerMasterBirthDate();
		customerBirthDate.setBirthdate(rs.getString(CustomerMasterConstants.FLD_BIRTHDATE)!=null?rs.getString(CustomerMasterConstants.FLD_BIRTHDATE):"");
		customerBirthDate.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_BIRTHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_BIRTHUPDATE):"");
		customerBirthDate.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_BIRTHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_BIRTHSECCODE):"");
		customerBirthDate.setSourceCode(rs.getString(CustomerMasterConstants.FLD_BIRTHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_BIRTHSRCCODE):"");
		if(!customerBirthDate.isNull()){
			custAll.setBirthDate(customerBirthDate);
		}
		
		//Address
		CustomerMasterAddress address = new CustomerMasterAddress();
		//PRADDR
		CustomerMasterAddressAttrNCOA permAddress = new CustomerMasterAddressAttrNCOA(CustomerMasterConstants.CM_ADDRESS_TYPE_P);
		permAddress.setAddressUsageType(rs.getString(CustomerMasterConstants.FLD_ADDRTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_ADDRTYPE):"");
		permAddress.setCASSFootnote(rs.getString(CustomerMasterConstants.FLD_PFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_PFTNOTE):"");
		permAddress.setCity(rs.getString(CustomerMasterConstants.FLD_PCUSTCITY)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTCITY):"");
		permAddress.setCountry(rs.getString(CustomerMasterConstants.FLD_PCUSTCOUNTRY)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTCOUNTRY):"");
		permAddress.setDPVFootnote(rs.getString(CustomerMasterConstants.FLD_PDPVFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_PDPVFTNOTE):"");
		permAddress.setDPVIndicator(rs.getString(CustomerMasterConstants.FLD_PDPVIND)!=null?rs.getString(CustomerMasterConstants.FLD_PDPVIND):"");
		permAddress.setLACSAddressFlag(rs.getString(CustomerMasterConstants.FLD_PLACSADDRFLAG)!=null?rs.getString(CustomerMasterConstants.FLD_PLACSADDRFLAG):"");
		permAddress.setLACSFootnote(rs.getString(CustomerMasterConstants.FLD_PLACSFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_PLACSFTNOTE):"");
		permAddress.setLACSReturnCode(rs.getString(CustomerMasterConstants.FLD_PLACSRTRNCODE)!=null?rs.getString("PLACSRTRNCODE"):"");
		permAddress.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_PADDRUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PADDRUPDATE):"");
		permAddress.setLatitude(rs.getString(CustomerMasterConstants.FLD_PLATITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_PLATITUDE):"");
		permAddress.setLongitude(rs.getString(CustomerMasterConstants.FLD_PLONGITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_PLONGITUDE):"");
		permAddress.setNCOAActionCode(rs.getString(CustomerMasterConstants.FLD_PNCOAACTCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAACTCODE):"");
	    permAddress.setNCOAANKCode(rs.getString(CustomerMasterConstants.FLD_PNCOAANKCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAANKCODE):"");
	    permAddress.setNCOAMoveDate(rs.getString(CustomerMasterConstants.FLD_PNCOAMVDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAMVDATE):"");
	    permAddress.setNCOAMoveType(rs.getString(CustomerMasterConstants.FLD_PNCOAMVTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAMVTYPE):"");	    
	    permAddress.setNCOANewAddressFlag(rs.getString(CustomerMasterConstants.FLD_PNCOANEWADDRFLG)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOANEWADDRFLG):"");
	    permAddress.setNCOANIXIEFootnote(rs.getString(CustomerMasterConstants.FLD_PNCOANIXFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOANIXFTNOTE):"");
	    permAddress.setNCOAProcessDate(rs.getString(CustomerMasterConstants.FLD_PNCOAPRDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAPRDATE):"");
	    permAddress.setNCOAReturnCode(rs.getString(CustomerMasterConstants.FLD_PNCOARTRNCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOARTRNCODE):"");
	    permAddress.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_PADDRSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PADDRSECCODE):"");
	    permAddress.setSourceCode(rs.getString(CustomerMasterConstants.FLD_PADDRSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PADDRSRCCODE):"");
	    permAddress.setStandardizationProcessDate(rs.getString(CustomerMasterConstants.FLD_PPRDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PPRDATE):"");
	    permAddress.setState(rs.getString(CustomerMasterConstants.FLD_PCUSTSTATE)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTSTATE):"");
	    permAddress.setStreetLine1(rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE1)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE1):"");
	    permAddress.setStreetLine2(rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE2)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE2):"");
	    permAddress.setUrbanizationCode(rs.getString(CustomerMasterConstants.FLD_PURBCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PURBCODE):"");
	    permAddress.setUSPSAddressType(rs.getString(CustomerMasterConstants.FLD_PADDRTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_PADDRTYPE):"");
	    permAddress.setZipCode(rs.getString(CustomerMasterConstants.FLD_PCUSTZIPCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTZIPCODE):"");
	    if(!permAddress.isNullEnterpriseLookup()){
	    	address.setPermAddress(permAddress);
	    }
	    
	    //home2Address
	    CustomerMasterAddressAttr home2Address = new CustomerMasterAddressAttr(CustomerMasterConstants.CM_ADDRESS_TYPE_2);
	    home2Address.setAddressUsageType(rs.getString(CustomerMasterConstants.FLD_ADDRTYPE2)!=null?rs.getString(CustomerMasterConstants.FLD_ADDRTYPE2):"");
	    home2Address.setCASSFootnote(rs.getString(CustomerMasterConstants.FLD_HFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_HFTNOTE):"");
	    home2Address.setCity(rs.getString(CustomerMasterConstants.FLD_HCUSTCITY)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTCITY):"");
	    home2Address.setCountry(rs.getString(CustomerMasterConstants.FLD_HCUSTCOUNTRY)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTCOUNTRY):"");
		home2Address.setDPVFootnote(rs.getString(CustomerMasterConstants.FLD_HDPVFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_HDPVFTNOTE):"");
		home2Address.setDPVIndicator(rs.getString(CustomerMasterConstants.FLD_HDPVIND)!=null?rs.getString(CustomerMasterConstants.FLD_HDPVIND):"");
		home2Address.setLACSAddressFlag( rs.getString(CustomerMasterConstants.FLD_HLACSADDRFLAG)!=null?rs.getString(CustomerMasterConstants.FLD_HLACSADDRFLAG):"");
		home2Address.setLACSFootnote(rs.getString(CustomerMasterConstants.FLD_HLACSFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_HLACSFTNOTE):"");
		home2Address.setLACSReturnCode(rs.getString(CustomerMasterConstants.FLD_HLACSRTRNCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HLACSRTRNCODE):"");		
	    home2Address.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_HADDRUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_HADDRUPDATE):"");
		home2Address.setLongitude(rs.getString(CustomerMasterConstants.FLD_HLONGITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_HLONGITUDE):"");
		home2Address.setLatitude(rs.getString(CustomerMasterConstants.FLD_HLATITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_HLATITUDE):"");
		home2Address.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_HADDRSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HADDRSECCODE):"");
		home2Address.setSourceCode(rs.getString(CustomerMasterConstants.FLD_HADDRSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HADDRSRCCODE):"");
		home2Address.setStandardizationProcessDate(rs.getString(CustomerMasterConstants.FLD_HPRDATE)!=null?rs.getString(CustomerMasterConstants.FLD_HPRDATE):"");		
	    home2Address.setStreetLine1(rs.getString(CustomerMasterConstants.FLD_HCUSTSTLINE1)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTSTLINE1):"");
		home2Address.setStreetLine2(rs.getString(CustomerMasterConstants.FLD_HCUSTSTLINE2)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTSTLINE2):"");		
		home2Address.setState(rs.getString(CustomerMasterConstants.FLD_HCUSTSTATE)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTSTATE):"");
		home2Address.setUrbanizationCode(rs.getString(CustomerMasterConstants.FLD_HURBCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HURBCODE):"");
		home2Address.setUSPSAddressType(rs.getString(CustomerMasterConstants.FLD_HADDRTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_HADDRTYPE):"");
		home2Address.setZipCode(rs.getString(CustomerMasterConstants.FLD_HCUSTZIPCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTZIPCODE):"");
		if(!home2Address.isNullEnterpriseLookup()){
			address.setHome2Address(home2Address);
		}
		
		//WORKADDR
		CustomerMasterAddressAttr workAddress = new CustomerMasterAddressAttr(CustomerMasterConstants.CM_ADDRESS_TYPE_W);
		workAddress.setAddressUsageType(rs.getString(CustomerMasterConstants.FLD_ADDRTYPE3)!=null?rs.getString(CustomerMasterConstants.FLD_ADDRTYPE3):"");
		workAddress.setCASSFootnote(rs.getString(CustomerMasterConstants.FLD_WFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_WFTNOTE):"");
		workAddress.setCity(rs.getString(CustomerMasterConstants.FLD_WCUSTCITY)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTCITY):"");
		workAddress.setCountry(rs.getString(CustomerMasterConstants.FLD_WCUSTCOUNTRY)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTCOUNTRY):"");
		workAddress.setDPVFootnote(rs.getString(CustomerMasterConstants.FLD_WDPVFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_WDPVFTNOTE):"");
		workAddress.setDPVIndicator(rs.getString(CustomerMasterConstants.FLD_WDPVIND)!=null?rs.getString(CustomerMasterConstants.FLD_WDPVIND):"");
		workAddress.setLACSAddressFlag(rs.getString(CustomerMasterConstants.FLD_WLACSADDRFLAG)!=null?rs.getString(CustomerMasterConstants.FLD_WLACSADDRFLAG):"");
		workAddress.setLACSFootnote(rs.getString(CustomerMasterConstants.FLD_WLACSFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_WLACSFTNOTE):"");
		workAddress.setLACSReturnCode(rs.getString(CustomerMasterConstants.FLD_WLACSRTRNCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WLACSRTRNCODE):"");
		workAddress.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_WADDRUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_WADDRUPDATE):"");
		workAddress.setLatitude(rs.getString(CustomerMasterConstants.FLD_WLATITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_WLATITUDE):"");
		workAddress.setLongitude(rs.getString(CustomerMasterConstants.FLD_WLONGITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_WLONGITUDE):"");
		workAddress.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_WADDRSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WADDRSECCODE):"");
		workAddress.setSourceCode(rs.getString(CustomerMasterConstants.FLD_WADDRSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WADDRSRCCODE):"");
		workAddress.setStandardizationProcessDate(rs.getString(CustomerMasterConstants.FLD_WPRDATE)!=null?rs.getString(CustomerMasterConstants.FLD_WPRDATE):"");
		workAddress.setState(rs.getString(CustomerMasterConstants.FLD_WCUSTSTATE)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTSTATE):"");
		workAddress.setStreetLine1(rs.getString(CustomerMasterConstants.FLD_WCUSTSTLINE1)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTSTLINE1):"");
		workAddress.setStreetLine2(rs.getString(CustomerMasterConstants.FLD_WCUSTSTLINE2)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTSTLINE2):"");
		workAddress.setUrbanizationCode(rs.getString(CustomerMasterConstants.FLD_WURBCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WURBCODE):"");
		workAddress.setUSPSAddressType(rs.getString(CustomerMasterConstants.FLD_WADDRTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_WADDRTYPE):"");
		workAddress.setZipCode(rs.getString(CustomerMasterConstants.FLD_WCUSTZIPCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTZIPCODE):"");
		if(!workAddress.isNullEnterpriseLookup()){
			address.setWorkAddress(workAddress);
		}
		
		custAll.setAddress(address);
			
		
		CustomerMasterEntSearchPhone phone = new CustomerMasterEntSearchPhone();
		
		//PRPHONE
		CustomerMasterPhoneAttr homePhone = new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_H);
		homePhone.setUsageType(rs.getString(CustomerMasterConstants.FLD_HPHTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_HPHTYPE):"");
		homePhone.setAreaCode(rs.getString(CustomerMasterConstants.FLD_HPHAREA)!=null?rs.getString(CustomerMasterConstants.FLD_HPHAREA):"");
		homePhone.setPhoneNumber(rs.getString(CustomerMasterConstants.FLD_HPHNUMBER)!=null?rs.getString(CustomerMasterConstants.FLD_HPHNUMBER):"");
		homePhone.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_HPHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_HPHUPDATE):"");
		homePhone.setSourceCode(rs.getString(CustomerMasterConstants.FLD_HPHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HPHSRCCODE):"");
		homePhone.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_HPHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HPHSECCODE):"");
		if(!homePhone.isNull()){
			phone.setHomePhone(homePhone);
		}
		
		//cellPHONE
		CustomerMasterPhoneAttr cellPhone = new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_C);
		cellPhone.setUsageType(rs.getString(CustomerMasterConstants.FLD_CPHTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_CPHTYPE):"");
		cellPhone.setAreaCode(rs.getString(CustomerMasterConstants.FLD_CPHAREA)!=null?rs.getString(CustomerMasterConstants.FLD_CPHAREA):"");
		cellPhone.setPhoneNumber(rs.getString(CustomerMasterConstants.FLD_CPHNUMBER)!=null?rs.getString(CustomerMasterConstants.FLD_CPHNUMBER):"");
		cellPhone.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_CPHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_CPHUPDATE):"");
		cellPhone.setSourceCode(rs.getString(CustomerMasterConstants.FLD_CPHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_CPHSRCCODE):"");
		cellPhone.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_CPHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_CPHSECCODE):"");
		if(!cellPhone.isNull()){
			phone.setCellPhone(cellPhone);
		}
		
		//WKPHONE
		CustomerMasterPhoneAttr workPhone= new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_W);
		workPhone.setUsageType(rs.getString(CustomerMasterConstants.FLD_WPHTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_WPHTYPE):"");
		workPhone.setAreaCode(rs.getString(CustomerMasterConstants.FLD_WPHAREA)!=null?rs.getString(CustomerMasterConstants.FLD_WPHAREA):"");
		workPhone.setPhoneNumber(rs.getString(CustomerMasterConstants.FLD_WPHNUMBER)!=null?rs.getString(CustomerMasterConstants.FLD_WPHNUMBER):"");
		workPhone.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_WPHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_WPHUPDATE):"");
		workPhone.setSourceCode(rs.getString(CustomerMasterConstants.FLD_WPHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WPHSRCCODE):"");
		workPhone.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_WPHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WPHSECCODE):"");
		if(!workPhone.isNull()){
			phone.setWorkPhone(workPhone);
		}
		
				
			custAll.setPhone(phone);
			ArrayList<CustomerMasterEntSearchProgramVO> progList = new ArrayList<CustomerMasterEntSearchProgramVO>();
			ArrayList<CustomerMasterEntAttributesVO> attrList = new ArrayList<CustomerMasterEntAttributesVO>();

			if (rs.getString(CustomerMasterConstants.EESEC_CODE) != null) {
				CustomerMasterEntAttributesVO secCodeVo = new CustomerMasterEntAttributesVO();
				secCodeVo
						.setCdiKey(CustomerMasterConstants.STR_VERFICATION_CODE);
				secCodeVo.setCdiValue(rs
						.getString(CustomerMasterConstants.EESEC_CODE));
				attrList.add(secCodeVo);

			}
			if (rs.getString(CustomerMasterConstants.ENROLL_FORMID) != null) {
				CustomerMasterEntAttributesVO enrollVo = new CustomerMasterEntAttributesVO();
				enrollVo.setCdiKey(CustomerMasterConstants.STR_FOREIGN_ID);
				enrollVo.setCdiValue(rs
						.getString(CustomerMasterConstants.ENROLL_FORMID));
				attrList.add(enrollVo);

			}

			if (rs.getString(CustomerMasterConstants.EECARDNO) != null) {
				CustomerMasterEntAttributesVO eeCardNoVo = new CustomerMasterEntAttributesVO();
				eeCardNoVo.setCdiKey(CustomerMasterConstants.STR_EECARDNO);
				eeCardNoVo.setCdiValue(rs
						.getString(CustomerMasterConstants.EECARDNO));
				attrList.add(eeCardNoVo);

			}

			customer.setAttributeArray(attrList);
			customer.setProgramArray(progList);

			customer.setCustAll(custAll);
			customer.setGender(gender);
			customer.setLockedInd(lockedInd);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return customer;		
		
	}




}
