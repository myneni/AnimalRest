package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterGetRequest;
import com.walgreens.cdi.vo.customer.ArrayOfCustomer;

public interface ICustomerMasterGetService {
	
	public ArrayOfCustomer getCustomerMaster(CustomerMasterGetRequest cdiRetrieveRequest) throws CDIException;
		
	

}
