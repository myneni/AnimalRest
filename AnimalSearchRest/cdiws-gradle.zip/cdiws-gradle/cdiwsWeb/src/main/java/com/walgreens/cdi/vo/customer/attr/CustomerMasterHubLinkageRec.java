/**
 * 
 */
package com.walgreens.cdi.vo.customer.attr;

import java.util.ArrayList;

import com.walgreens.cdi.util.CustomerMasterConstants;

/**
 * @author Picketta
 *
 */
public class CustomerMasterHubLinkageRec {
	
	private CustomerMasterLinkageDetail [] linkageDetail;	
	
	private String eid	;	
	
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public CustomerMasterLinkageDetail[] getLinkageDetail() {
		return linkageDetail;
	}
	public void setLinkageDetail(CustomerMasterLinkageDetail[] linkageDetail) {
		this.linkageDetail = linkageDetail;
	}
	
	public String toString() {
		String str="";
		str = "\nHubLinkageRec:\n____________________________________\n"+
		      " Eid    =" + eid + "\n";
		if( linkageDetail != null ) 
			for(int i = 0; i < linkageDetail.length; i++){
				str= str+ i+ ":" + linkageDetail[i].toString();
			}
		else 
			str= str+ "no linkage \n";	
		
         return str;
	}
	
	public String toCompString() {
		String str = "";
		String strTemp = CustomerMasterConstants.DELIMITE_ATTR
			   + CustomerMasterConstants.DELIMITE_FIELD +
	             eid  + CustomerMasterConstants.DELIMITE_FIELD ;
			if( linkageDetail != null ) 
				for(int i = 0; i < linkageDetail.length; i++){
					str= CustomerMasterConstants.DELIMITE_LINK_REP+  linkageDetail[i].toCompString();
				}
			 return str;
	}
			
	
	
}
