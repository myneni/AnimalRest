package com.walgreens.cdi.vo.customer.attr;

public class CustomerMasterAddressAttrBase extends CustomerMasterAttributeStatus {

	/**
	 * 
	 */
	public CustomerMasterAddressAttrBase() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerMasterAddressAttrBase(String addressUsageType) {
		super();
		this.addressUsageType = addressUsageType;
		// TODO Auto-generated constructor stub
	}
	
	private String addressUsageType;
	private String streetLine1;					//String (0/1)	AllSource Home2 StreetLine1.
	private String streetLine2;					//String (0/1)	AllSource Home2 StreetLine2.
	private String city;						//String (0/1)	AllSource Home2 City.
	private String state;						//String (0/1)	AllSource Home2 State.
	private String zipCode;						//String (0/1)	AllSource Home2 ZipCode,
	/**
	 * @return the addressUsageType
	 */
	public String getAddressUsageType() {
		return addressUsageType;
	}
	/**
	 * @param addressUsageType the addressUsageType to set
	 */
	public void setAddressUsageType(String addressUsageType) {
		this.addressUsageType = addressUsageType;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the streetLine1
	 */
	public String getStreetLine1() {
		return streetLine1;
	}
	/**
	 * @param streetLine1 the streetLine1 to set
	 */
	public void setStreetLine1(String streetLine1) {
		this.streetLine1 = streetLine1;
	}
	/**
	 * @return the streetLine2
	 */
	public String getStreetLine2() {
		return streetLine2;
	}
	/**
	 * @param streetLine2 the streetLine2 to set
	 */
	public void setStreetLine2(String streetLine2) {
		this.streetLine2 = streetLine2;
	}
	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}
	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	
	
	
}
