package com.walgreens.cdi.vo;

/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author 
 * 
 */
public class CustomerMasterIcunmergeRequest {

	    private java.lang.String memIdnumSrv;
	    private java.lang.String memIdnumNew;

	    private java.lang.String petInd;
	    private java.lang.String lockInd;
	    private java.lang.String secCode;
	    private java.lang.String lastUpdateDate;
	        

	    public java.lang.String getMemIdnumNew() {
			return memIdnumNew;
		}

		public void setMemIdnumNew(java.lang.String memIdnumNew) {
			this.memIdnumNew = memIdnumNew;
		}

		public java.lang.String getMemIdnumSrv() {
	        return memIdnumSrv;
	    }

	    public void setMemIdnumSrv(java.lang.String memIdnumSrv) {
	        this.memIdnumSrv = memIdnumSrv;
	    }

		public java.lang.String getLastUpdateDate() {
			return lastUpdateDate;
		}

		public void setLastUpdateDate(java.lang.String lastUpdateDate) {
			this.lastUpdateDate = lastUpdateDate;
		}

		public java.lang.String getLockInd() {
			return lockInd;
		}

		public void setLockInd(java.lang.String lockInd) {
			this.lockInd = lockInd;
		}

		public java.lang.String getPetInd() {
			return petInd;
		}

		public void setPetInd(java.lang.String petInd) {
			this.petInd = petInd;
		}

		public java.lang.String getSecCode() {
			return secCode;
		}

		public void setSecCode(java.lang.String secCode) {
			this.secCode = secCode;
		}

	    
}
