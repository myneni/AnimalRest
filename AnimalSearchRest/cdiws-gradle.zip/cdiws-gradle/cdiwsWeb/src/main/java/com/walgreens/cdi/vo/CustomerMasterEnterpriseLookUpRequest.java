package com.walgreens.cdi.vo;
/**
 * This class would contain all the attributes required to enterPrise Search
 * and get the response back
 * 
 * @author 
 * 
 */
public class CustomerMasterEnterpriseLookUpRequest {
	 
		private String custFirstName;
		private String custLastName;
		private String custMiddleName;
		private String custSuffix;	
		private String custBirthDttm;	
		private String custEMail;	
		private String custStreetLine1;
		private String custStreetLine2;
		private String custCity;
		private String custState;
		private String custZip;	
		private String custPhoneArea;
		private String custPhoneNumber;	
		private String programCode;
		private String programIdentifier;
		private String memSearchStat;
		private String maxResponse;
		private String minMatchScore;
		private String returnLinkages;
		private String cvType1;
		private String cvType2;
		private String searchSource1;
		private String searchSource2;
		private String searchType1 ;
		private String searchType2;

		public String getMaxResponse() {
			return maxResponse;
		}
		public void setMaxResponse(String maxResponse) {
			this.maxResponse = maxResponse;
		}
		public String getMinMatchScore() {
			return minMatchScore;
		}
		public void setMinMatchScore(String minMatchScore) {
			this.minMatchScore = minMatchScore;
		}
		public String getReturnLinkages() {
			return returnLinkages;
		}
		public void setReturnLinkages(String returnLinkages) {
			this.returnLinkages = returnLinkages;
		}
		public String getCvType1() {
			return cvType1;
		}
		public void setCvType1(String cvType1) {
			this.cvType1 = cvType1;
		}
		public String getCvType2() {
			return cvType2;
		}
		public void setCvType2(String cvType2) {
			this.cvType2 = cvType2;
		}
		public String getSearchSource1() {
			return searchSource1;
		}
		public void setSearchSource1(String searchSource1) {
			this.searchSource1 = searchSource1;
		}
		public String getSearchSource2() {
			return searchSource2;
		}
		public void setSearchSource2(String searchSource2) {
			this.searchSource2 = searchSource2;
		}
		public String getSearchType1() {
			return searchType1;
		}
		public void setSearchType1(String searchType1) {
			this.searchType1 = searchType1;
		}
		public String getSearchType2() {
			return searchType2;
		}
		public void setSearchType2(String searchType2) {
			this.searchType2 = searchType2;
		}
		
		
		public String getCustBirthDttm() {
			return custBirthDttm;
		}
		public void setCustBirthDttm(String custBirthDttm) {
			this.custBirthDttm = custBirthDttm;
		}
		public String getCustCity() {
			return custCity;
		}
		public void setCustCity(String custCity) {
			this.custCity = custCity;
		}	

		public String getCustFirstName() {
			return custFirstName;
		}
		public void setCustFirstName(String custFirstName) {
			this.custFirstName = custFirstName;
		}
		public String getCustLastName() {
			return custLastName;
		}
		public void setCustLastName(String custLastName) {
			this.custLastName = custLastName;
		}
		public String getCustMiddleName() {
			return custMiddleName;
		}
		public void setCustMiddleName(String custMiddleName) {
			this.custMiddleName = custMiddleName;
		}
		public String getCustPhoneArea() {
			return custPhoneArea;
		}
		public void setCustPhoneArea(String custPhoneArea) {
			this.custPhoneArea = custPhoneArea;
		}
		public String getCustPhoneNumber() {
			return custPhoneNumber;
		}
		public void setCustPhoneNumber(String custPhoneNumber) {
			this.custPhoneNumber = custPhoneNumber;
		}
		public String getCustState() {
			return custState;
		}
		public void setCustState(String custState) {
			this.custState = custState;
		}
		public String getCustStreetLine1() {
			return custStreetLine1;
		}
		public void setCustStreetLine1(String custStreetLine1) {
			this.custStreetLine1 = custStreetLine1;
		}
		public String getCustStreetLine2() {
			return custStreetLine2;
		}
		public void setCustStreetLine2(String custStreetLine2) {
			this.custStreetLine2 = custStreetLine2;
		}
		public String getCustSuffix() {
			return custSuffix;
		}
		public void setCustSuffix(String custSuffix) {
			this.custSuffix = custSuffix;
		}
		public String getCustZip() {
			return custZip;
		}
		public void setCustZip(String custZip) {
			this.custZip = custZip;
		}
		public String getMemSearchStat() {
			return memSearchStat;
		}
		public void setMemSearchStat(String memSearchStat) {
			this.memSearchStat = memSearchStat;
		}
		public String getProgramCode() {
			return programCode;
		}
		public void setProgramCode(String programCode) {
			this.programCode = programCode;
		}
		public String getProgramIdentifier() {
			return programIdentifier;
		}
		public void setProgramIdentifier(String programIdentifier) {
			this.programIdentifier = programIdentifier;
		}
		public String getCustEMail() {
			return custEMail;
		}
		public void setCustEMail(String custEMail) {
			this.custEMail = custEMail;
		}
		
		
		
		


}
