package com.walgreens.cdi.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseSearch;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddress;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttrNCOA;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterBirthDate;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterDeceasedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEmail;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEntSearchPhone;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEnterpriseSearchAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterGender;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLockedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterName;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPetInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPhoneAttr;

public class CustomerMasterEnterpriseLookUpRowsMapper implements ParameterizedRowMapper<CustomerMasterEnterpriseSearch>  {
	String globalSQL = null;
	long lastTime = 0L;
	public CustomerMasterEnterpriseLookUpRowsMapper(){
		
	}
	public CustomerMasterEnterpriseLookUpRowsMapper(String sql, long st){
		
		globalSQL = sql;
		lastTime = st;
	}
	/**
	 * This method is used to map the rows in database
	 * @param rs,rowNum
	 * @return
	 */
	public CustomerMasterEnterpriseSearch mapRow(ResultSet rs, int rowNum) throws SQLException {


		CustomerMasterEnterpriseSearch customer = new CustomerMasterEnterpriseSearch();
		try
		{
		
			CustomerMasterEnterpriseSearchAttr custAll = new CustomerMasterEnterpriseSearchAttr();
		
		//Set Name
		CustomerMasterName name = new CustomerMasterName();
		name.setFirstName(rs.getString(CustomerMasterConstants.FLD_FIRSTNAME)!=null?rs.getString(CustomerMasterConstants.FLD_FIRSTNAME):CustomerMasterConstants.BLANK_VAL);
		name.setMiddleName(rs.getString(CustomerMasterConstants.FLD_MIDDLENAME)!=null?rs.getString(CustomerMasterConstants.FLD_MIDDLENAME):CustomerMasterConstants.BLANK_VAL);
		name.setLastName(rs.getString(CustomerMasterConstants.FLD_LASTNAME)!=null?rs.getString(CustomerMasterConstants.FLD_LASTNAME):CustomerMasterConstants.BLANK_VAL);
		name.setPrefixName(rs.getString(CustomerMasterConstants.FLD_PREFIXNAME)!=null?rs.getString(CustomerMasterConstants.FLD_PREFIXNAME):CustomerMasterConstants.BLANK_VAL);	
		name.setSuffixName(rs.getString(CustomerMasterConstants.FLD_SUFFIXNAME)!=null?rs.getString(CustomerMasterConstants.FLD_SUFFIXNAME):CustomerMasterConstants.BLANK_VAL);	
		name.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_NAMEUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_NAMEUPDATE):CustomerMasterConstants.BLANK_VAL);
		name.setSourceCode(rs.getString(CustomerMasterConstants.FLD_NAMSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_NAMSRCCODE):CustomerMasterConstants.BLANK_VAL);
		name.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_NAMSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_NAMSECCODE):CustomerMasterConstants.BLANK_VAL);
		
		if (!name.isNull()){
			custAll.setName(name);
		}
						
		//set Gender				
		CustomerMasterGender gender = new CustomerMasterGender();
		gender.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_GENDERSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_GENDERSECCODE):CustomerMasterConstants.BLANK_VAL);
		gender.setGenderCode(rs.getString(CustomerMasterConstants.FLD_GENDER)!=null?rs.getString(CustomerMasterConstants.FLD_GENDER):CustomerMasterConstants.BLANK_VAL);
		gender.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_GENDERUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_GENDERUPDATE):CustomerMasterConstants.BLANK_VAL);
		gender.setSourceCode(rs.getString(CustomerMasterConstants.FLD_GENDERSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_GENDERSRCCODE):CustomerMasterConstants.BLANK_VAL);
		
		if(!gender.isNull()){
			customer.setGender(gender);
		}
		
		//PETIND
		CustomerMasterPetInd petInd = new CustomerMasterPetInd();
		petInd.setPetIndicator(rs.getString(CustomerMasterConstants.FLD_PETIND)!=null?rs.getString(CustomerMasterConstants.FLD_PETIND):CustomerMasterConstants.BLANK_VAL);
		petInd.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_PETUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PETUPDATE):CustomerMasterConstants.BLANK_VAL);
		petInd.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_PETSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PETSECCODE):CustomerMasterConstants.BLANK_VAL);
		petInd.setSourceCode(rs.getString(CustomerMasterConstants.FLD_PETSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PETSRCCODE):CustomerMasterConstants.BLANK_VAL);
		if(!petInd.isNull()){
			customer.setPetInd(petInd);
		}
		
		//DeceasedIND
		CustomerMasterDeceasedInd deceasedInd = new CustomerMasterDeceasedInd();
		deceasedInd.setDeceasedIndicator(rs.getString(CustomerMasterConstants.FLD_DEATHIND)!=null?rs.getString(CustomerMasterConstants.FLD_DEATHIND):CustomerMasterConstants.BLANK_VAL);
		deceasedInd.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_DEATHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_DEATHUPDATE):CustomerMasterConstants.BLANK_VAL);
		deceasedInd.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_DEATHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_DEATHSECCODE):CustomerMasterConstants.BLANK_VAL);
		deceasedInd.setSourceCode(rs.getString(CustomerMasterConstants.FLD_DEATHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_DEATHSRCCODE):CustomerMasterConstants.BLANK_VAL);
		if(!deceasedInd.isNull()){
			customer.setDeceasedInd(deceasedInd);
		}
			
		//EMAIL
		CustomerMasterEmail customerEmail = new CustomerMasterEmail();
		customerEmail.setEmailAddress(rs.getString(CustomerMasterConstants.FLD_EMAIL)!=null?rs.getString(CustomerMasterConstants.FLD_EMAIL):CustomerMasterConstants.BLANK_VAL);
		customerEmail.setEmailUsageType(rs.getString(CustomerMasterConstants.FLD_EMAILTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_EMAILTYPE):CustomerMasterConstants.BLANK_VAL);
		customerEmail.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_EMAILUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_EMAILUPDATE):CustomerMasterConstants.BLANK_VAL);
		customerEmail.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_EMAILSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_EMAILSECCODE):CustomerMasterConstants.BLANK_VAL);
		customerEmail.setSourceCode(rs.getString(CustomerMasterConstants.FLD_EMAILSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_EMAILSRCCODE):CustomerMasterConstants.BLANK_VAL);
		if(!customerEmail.isNull()){
			custAll.setEmail(customerEmail);
		}
		
		//LOCKIND
		CustomerMasterLockedInd lockedInd = new CustomerMasterLockedInd();
		lockedInd.setLockedIndicator(rs.getString(CustomerMasterConstants.FLD_LOCKIND)!=null?rs.getString(CustomerMasterConstants.FLD_LOCKIND):CustomerMasterConstants.BLANK_VAL);
		lockedInd.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_LOCKUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_LOCKUPDATE):CustomerMasterConstants.BLANK_VAL);
		lockedInd.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_LOCKSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_LOCKSECCODE):CustomerMasterConstants.BLANK_VAL);
		lockedInd.setSourceCode(rs.getString(CustomerMasterConstants.FLD_LOCKSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_LOCKSRCCODE):CustomerMasterConstants.BLANK_VAL);
		if(!lockedInd.isNull()){
			customer.setLockedInd(lockedInd);
		}		
		
	   //BIRTHDT
		CustomerMasterBirthDate customerBirthDate = new CustomerMasterBirthDate();
		customerBirthDate.setBirthdate(rs.getString(CustomerMasterConstants.FLD_BIRTHDATE)!=null?rs.getString(CustomerMasterConstants.FLD_BIRTHDATE):CustomerMasterConstants.BLANK_VAL);
		customerBirthDate.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_BIRTHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_BIRTHUPDATE):CustomerMasterConstants.BLANK_VAL);
		customerBirthDate.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_BIRTHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_BIRTHSECCODE):CustomerMasterConstants.BLANK_VAL);
		customerBirthDate.setSourceCode(rs.getString(CustomerMasterConstants.FLD_BIRTHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_BIRTHSRCCODE):CustomerMasterConstants.BLANK_VAL);
		if(!customerBirthDate.isNull()){
			custAll.setBirthDate(customerBirthDate);
		}
		
		//Address
		CustomerMasterAddress address = new CustomerMasterAddress();
		//PRADDR
		CustomerMasterAddressAttrNCOA permAddress = new CustomerMasterAddressAttrNCOA(CustomerMasterConstants.CM_ADDRESS_TYPE_P);
		permAddress.setAddressUsageType(rs.getString(CustomerMasterConstants.FLD_ADDRTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_ADDRTYPE):CustomerMasterConstants.BLANK_VAL);
		permAddress.setCASSFootnote(rs.getString(CustomerMasterConstants.FLD_PFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_PFTNOTE):CustomerMasterConstants.BLANK_VAL);
		permAddress.setCity(rs.getString(CustomerMasterConstants.FLD_PCUSTCITY)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTCITY):CustomerMasterConstants.BLANK_VAL);
		permAddress.setCountry(rs.getString(CustomerMasterConstants.FLD_PCUSTCOUNTRY)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTCOUNTRY):CustomerMasterConstants.BLANK_VAL);
		permAddress.setDPVFootnote(rs.getString(CustomerMasterConstants.FLD_PDPVFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_PDPVFTNOTE):CustomerMasterConstants.BLANK_VAL);
		permAddress.setDPVIndicator(rs.getString(CustomerMasterConstants.FLD_PDPVIND)!=null?rs.getString(CustomerMasterConstants.FLD_PDPVIND):CustomerMasterConstants.BLANK_VAL);
		permAddress.setLACSAddressFlag(rs.getString(CustomerMasterConstants.FLD_PLACSADDRFLAG)!=null?rs.getString(CustomerMasterConstants.FLD_PLACSADDRFLAG):CustomerMasterConstants.BLANK_VAL);
		permAddress.setLACSFootnote(rs.getString(CustomerMasterConstants.FLD_PLACSFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_PLACSFTNOTE):CustomerMasterConstants.BLANK_VAL);
		permAddress.setLACSReturnCode(rs.getString(CustomerMasterConstants.FLD_PLACSRTRNCODE)!=null?rs.getString("PLACSRTRNCODE"):CustomerMasterConstants.BLANK_VAL);
		permAddress.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_PADDRUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PADDRUPDATE):CustomerMasterConstants.BLANK_VAL);
		permAddress.setLatitude(rs.getString(CustomerMasterConstants.FLD_PLATITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_PLATITUDE):CustomerMasterConstants.BLANK_VAL);
		permAddress.setLongitude(rs.getString(CustomerMasterConstants.FLD_PLONGITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_PLONGITUDE):CustomerMasterConstants.BLANK_VAL);
		permAddress.setNCOAActionCode(rs.getString(CustomerMasterConstants.FLD_PNCOAACTCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAACTCODE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setNCOAANKCode(rs.getString(CustomerMasterConstants.FLD_PNCOAANKCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAANKCODE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setNCOAMoveDate(rs.getString(CustomerMasterConstants.FLD_PNCOAMVDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAMVDATE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setNCOAMoveType(rs.getString(CustomerMasterConstants.FLD_PNCOAMVTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAMVTYPE):CustomerMasterConstants.BLANK_VAL);	    
	    permAddress.setNCOANewAddressFlag(rs.getString(CustomerMasterConstants.FLD_PNCOANEWADDRFLG)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOANEWADDRFLG):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setNCOANIXIEFootnote(rs.getString(CustomerMasterConstants.FLD_PNCOANIXFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOANIXFTNOTE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setNCOAProcessDate(rs.getString(CustomerMasterConstants.FLD_PNCOAPRDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOAPRDATE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setNCOAReturnCode(rs.getString(CustomerMasterConstants.FLD_PNCOARTRNCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PNCOARTRNCODE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_PADDRSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PADDRSECCODE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setSourceCode(rs.getString(CustomerMasterConstants.FLD_PADDRSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PADDRSRCCODE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setStandardizationProcessDate(rs.getString(CustomerMasterConstants.FLD_PPRDATE)!=null?rs.getString(CustomerMasterConstants.FLD_PPRDATE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setState(rs.getString(CustomerMasterConstants.FLD_PCUSTSTATE)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTSTATE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setStreetLine1(rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE1)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE1):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setStreetLine2(rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE2)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTSTLINE2):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setUrbanizationCode(rs.getString(CustomerMasterConstants.FLD_PURBCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PURBCODE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setUSPSAddressType(rs.getString(CustomerMasterConstants.FLD_PADDRTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_PADDRTYPE):CustomerMasterConstants.BLANK_VAL);
	    permAddress.setZipCode(rs.getString(CustomerMasterConstants.FLD_PCUSTZIPCODE)!=null?rs.getString(CustomerMasterConstants.FLD_PCUSTZIPCODE):CustomerMasterConstants.BLANK_VAL);
	    if(!permAddress.isNull()){
	    	address.setPermAddress(permAddress);
	    }
	    
	    //home2Address
	    CustomerMasterAddressAttr home2Address = new CustomerMasterAddressAttr(CustomerMasterConstants.CM_ADDRESS_TYPE_2);
	    home2Address.setAddressUsageType(rs.getString(CustomerMasterConstants.FLD_ADDRTYPE2)!=null?rs.getString(CustomerMasterConstants.FLD_ADDRTYPE2):CustomerMasterConstants.BLANK_VAL);
	    home2Address.setCASSFootnote(rs.getString(CustomerMasterConstants.FLD_HFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_HFTNOTE):CustomerMasterConstants.BLANK_VAL);
	    home2Address.setCity(rs.getString(CustomerMasterConstants.FLD_HCUSTCITY)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTCITY):CustomerMasterConstants.BLANK_VAL);
	    home2Address.setCountry(rs.getString(CustomerMasterConstants.FLD_HCUSTCOUNTRY)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTCOUNTRY):CustomerMasterConstants.BLANK_VAL);
		home2Address.setDPVFootnote(rs.getString(CustomerMasterConstants.FLD_HDPVFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_HDPVFTNOTE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setDPVIndicator(rs.getString(CustomerMasterConstants.FLD_HDPVIND)!=null?rs.getString(CustomerMasterConstants.FLD_HDPVIND):CustomerMasterConstants.BLANK_VAL);
		home2Address.setLACSAddressFlag( rs.getString(CustomerMasterConstants.FLD_HLACSADDRFLAG)!=null?rs.getString(CustomerMasterConstants.FLD_HLACSADDRFLAG):CustomerMasterConstants.BLANK_VAL);
		home2Address.setLACSFootnote(rs.getString(CustomerMasterConstants.FLD_HLACSFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_HLACSFTNOTE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setLACSReturnCode(rs.getString(CustomerMasterConstants.FLD_HLACSRTRNCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HLACSRTRNCODE):CustomerMasterConstants.BLANK_VAL);		
	    home2Address.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_HADDRUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_HADDRUPDATE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setLongitude(rs.getString(CustomerMasterConstants.FLD_HLONGITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_HLONGITUDE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setLatitude(rs.getString(CustomerMasterConstants.FLD_HLATITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_HLATITUDE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_HADDRSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HADDRSECCODE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setSourceCode(rs.getString(CustomerMasterConstants.FLD_HADDRSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HADDRSRCCODE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setStandardizationProcessDate(rs.getString(CustomerMasterConstants.FLD_HPRDATE)!=null?rs.getString(CustomerMasterConstants.FLD_HPRDATE):CustomerMasterConstants.BLANK_VAL);		
	    home2Address.setStreetLine1(rs.getString(CustomerMasterConstants.FLD_HCUSTSTLINE1)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTSTLINE1):CustomerMasterConstants.BLANK_VAL);
		home2Address.setStreetLine2(rs.getString(CustomerMasterConstants.FLD_HCUSTSTLINE2)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTSTLINE2):CustomerMasterConstants.BLANK_VAL);		
		home2Address.setState(rs.getString(CustomerMasterConstants.FLD_HCUSTSTATE)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTSTATE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setUrbanizationCode(rs.getString(CustomerMasterConstants.FLD_HURBCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HURBCODE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setUSPSAddressType(rs.getString(CustomerMasterConstants.FLD_HADDRTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_HADDRTYPE):CustomerMasterConstants.BLANK_VAL);
		home2Address.setZipCode(rs.getString(CustomerMasterConstants.FLD_HCUSTZIPCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HCUSTZIPCODE):CustomerMasterConstants.BLANK_VAL);
		if(!home2Address.isNull()){
			address.setHome2Address(home2Address);
		}
		
		//WORKADDR
		CustomerMasterAddressAttr workAddress = new CustomerMasterAddressAttr(CustomerMasterConstants.CM_ADDRESS_TYPE_W);
		workAddress.setAddressUsageType(rs.getString(CustomerMasterConstants.FLD_ADDRTYPE3)!=null?rs.getString(CustomerMasterConstants.FLD_ADDRTYPE3):CustomerMasterConstants.BLANK_VAL);
		workAddress.setCASSFootnote(rs.getString(CustomerMasterConstants.FLD_WFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_WFTNOTE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setCity(rs.getString(CustomerMasterConstants.FLD_WCUSTCITY)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTCITY):CustomerMasterConstants.BLANK_VAL);
		workAddress.setCountry(rs.getString(CustomerMasterConstants.FLD_WCUSTCOUNTRY)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTCOUNTRY):CustomerMasterConstants.BLANK_VAL);
		workAddress.setDPVFootnote(rs.getString(CustomerMasterConstants.FLD_WDPVFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_WDPVFTNOTE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setDPVIndicator(rs.getString(CustomerMasterConstants.FLD_WDPVIND)!=null?rs.getString(CustomerMasterConstants.FLD_WDPVIND):CustomerMasterConstants.BLANK_VAL);
		workAddress.setLACSAddressFlag(rs.getString(CustomerMasterConstants.FLD_WLACSADDRFLAG)!=null?rs.getString(CustomerMasterConstants.FLD_WLACSADDRFLAG):CustomerMasterConstants.BLANK_VAL);
		workAddress.setLACSFootnote(rs.getString(CustomerMasterConstants.FLD_WLACSFTNOTE)!=null?rs.getString(CustomerMasterConstants.FLD_WLACSFTNOTE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setLACSReturnCode(rs.getString(CustomerMasterConstants.FLD_WLACSRTRNCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WLACSRTRNCODE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_WADDRUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_WADDRUPDATE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setLatitude(rs.getString(CustomerMasterConstants.FLD_WLATITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_WLATITUDE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setLongitude(rs.getString(CustomerMasterConstants.FLD_WLONGITUDE)!=null?rs.getString(CustomerMasterConstants.FLD_WLONGITUDE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_WADDRSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WADDRSECCODE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setSourceCode(rs.getString(CustomerMasterConstants.FLD_WADDRSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WADDRSRCCODE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setStandardizationProcessDate(rs.getString(CustomerMasterConstants.FLD_WPRDATE)!=null?rs.getString(CustomerMasterConstants.FLD_WPRDATE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setState(rs.getString(CustomerMasterConstants.FLD_WCUSTSTATE)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTSTATE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setStreetLine1(rs.getString(CustomerMasterConstants.FLD_WCUSTSTLINE1)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTSTLINE1):CustomerMasterConstants.BLANK_VAL);
		workAddress.setStreetLine2(rs.getString(CustomerMasterConstants.FLD_WCUSTSTLINE2)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTSTLINE2):CustomerMasterConstants.BLANK_VAL);
		workAddress.setUrbanizationCode(rs.getString(CustomerMasterConstants.FLD_WURBCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WURBCODE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setUSPSAddressType(rs.getString(CustomerMasterConstants.FLD_WADDRTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_WADDRTYPE):CustomerMasterConstants.BLANK_VAL);
		workAddress.setZipCode(rs.getString(CustomerMasterConstants.FLD_WCUSTZIPCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WCUSTZIPCODE):CustomerMasterConstants.BLANK_VAL);
		if(!workAddress.isNull()){
			address.setWorkAddress(workAddress);
		}
		
		custAll.setAddress(address);
			
		
		CustomerMasterEntSearchPhone phone = new CustomerMasterEntSearchPhone();
		
		//PRPHONE
		CustomerMasterPhoneAttr homePhone = new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_H);
		homePhone.setUsageType(rs.getString(CustomerMasterConstants.FLD_HPHTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_HPHTYPE):CustomerMasterConstants.BLANK_VAL);
		homePhone.setAreaCode(rs.getString(CustomerMasterConstants.FLD_HPHAREA)!=null?rs.getString(CustomerMasterConstants.FLD_HPHAREA):CustomerMasterConstants.BLANK_VAL);
		homePhone.setPhoneNumber(rs.getString(CustomerMasterConstants.FLD_HPHNUMBER)!=null?rs.getString(CustomerMasterConstants.FLD_HPHNUMBER):CustomerMasterConstants.BLANK_VAL);
		homePhone.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_HPHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_HPHUPDATE):CustomerMasterConstants.BLANK_VAL);
		homePhone.setSourceCode(rs.getString(CustomerMasterConstants.FLD_HPHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HPHSRCCODE):CustomerMasterConstants.BLANK_VAL);
		homePhone.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_HPHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_HPHSECCODE):CustomerMasterConstants.BLANK_VAL);
		if(!homePhone.isNull()){
			phone.setHomePhone(homePhone);
		}
		
		//cellPHONE
		CustomerMasterPhoneAttr cellPhone = new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_C);
		cellPhone.setUsageType(rs.getString(CustomerMasterConstants.FLD_CPHTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_CPHTYPE):CustomerMasterConstants.BLANK_VAL);
		cellPhone.setAreaCode(rs.getString(CustomerMasterConstants.FLD_CPHAREA)!=null?rs.getString(CustomerMasterConstants.FLD_CPHAREA):CustomerMasterConstants.BLANK_VAL);
		cellPhone.setPhoneNumber(rs.getString(CustomerMasterConstants.FLD_CPHNUMBER)!=null?rs.getString(CustomerMasterConstants.FLD_CPHNUMBER):CustomerMasterConstants.BLANK_VAL);
		cellPhone.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_CPHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_CPHUPDATE):CustomerMasterConstants.BLANK_VAL);
		cellPhone.setSourceCode(rs.getString(CustomerMasterConstants.FLD_CPHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_CPHSRCCODE):CustomerMasterConstants.BLANK_VAL);
		cellPhone.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_CPHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_CPHSECCODE):CustomerMasterConstants.BLANK_VAL);
		if(!cellPhone.isNull()){
			phone.setCellPhone(cellPhone);
		}
		
		//WKPHONE
		CustomerMasterPhoneAttr workPhone= new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_W);
		workPhone.setUsageType(rs.getString(CustomerMasterConstants.FLD_WPHTYPE)!=null?rs.getString(CustomerMasterConstants.FLD_WPHTYPE):CustomerMasterConstants.BLANK_VAL);
		workPhone.setAreaCode(rs.getString(CustomerMasterConstants.FLD_WPHAREA)!=null?rs.getString(CustomerMasterConstants.FLD_WPHAREA):CustomerMasterConstants.BLANK_VAL);
		workPhone.setPhoneNumber(rs.getString(CustomerMasterConstants.FLD_WPHNUMBER)!=null?rs.getString(CustomerMasterConstants.FLD_WPHNUMBER):CustomerMasterConstants.BLANK_VAL);
		workPhone.setLastUpdateDate(rs.getString(CustomerMasterConstants.FLD_WPHUPDATE)!=null?rs.getString(CustomerMasterConstants.FLD_WPHUPDATE):CustomerMasterConstants.BLANK_VAL);
		workPhone.setSourceCode(rs.getString(CustomerMasterConstants.FLD_WPHSRCCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WPHSRCCODE):CustomerMasterConstants.BLANK_VAL);
		workPhone.setSecurityClassCode(rs.getString(CustomerMasterConstants.FLD_WPHSECCODE)!=null?rs.getString(CustomerMasterConstants.FLD_WPHSECCODE):CustomerMasterConstants.BLANK_VAL);
		if(!workPhone.isNull()){
			phone.setWorkPhone(workPhone);
		}
		
		
		customer.setEID(rs.getString(CustomerMasterConstants.FLD_ENTITYID));		
		custAll.setPhone(phone);		
		customer.setCustAll(custAll);		
		customer.setGender(gender);			
		customer.setLockedInd(lockedInd);		
		
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return customer;		
		
	
		
	
	}


}
