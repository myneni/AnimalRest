package com.walgreens.cdi.vo.customer.attr;

import com.walgreens.cdi.util.CustomerMasterConstants;
public class CustomerMasterGender extends CustomerMasterAttributeStatus {
	//	 (Gender attribute)		
	private String genderCode;					//String (0/1)	Composite customer Gender.

	/**
	 * @return the custGender
	 */
	public String getGenderCode() {
		return genderCode;
	}

	/**
	 * @param custGender the custGender to set
	 */
	public void setGenderCode(String custGender) {
		this.genderCode = custGender;
	}
	
	public String toString() {
		String str="";
		str = "\nGender:\n____________________________________\n"+
		      " genderCode    =" + genderCode + "\n" +
		      " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
			  " securityClassCode   =" + getSecurityClassCode() + "\n" +
			  " sourceCode   =" + getSourceCode() + "\n" ;
		
					
         return str;
	}
	
	public String toCompString() {
		String str="";
		str = CustomerMasterConstants.DELIMITE_ATTR+ 
		       CustomerMasterConstants.COMP_ATTR_NAME_Gender+ CustomerMasterConstants.DELIMITE_FIELD +
		       genderCode + CustomerMasterConstants.DELIMITE_FIELD +
		       getLastUpdateDate()+CustomerMasterConstants.DELIMITE_FIELD +
			   getSecurityClassCode()+CustomerMasterConstants.DELIMITE_FIELD +
			   getSourceCode()+ CustomerMasterConstants.DELIMITE_FIELD ;
		
					
         return str;
	}

	public boolean isNull(){
		
		if(isNull(genderCode))
				return true;
		else
			return false;
	}
	
    private boolean isNull(String str){
    	if(str==null)
			return  true;
		if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
			return true;
		else
			return false;
	}
	
}
