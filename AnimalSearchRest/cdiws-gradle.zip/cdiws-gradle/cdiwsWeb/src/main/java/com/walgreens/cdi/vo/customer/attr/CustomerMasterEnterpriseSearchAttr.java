package com.walgreens.cdi.vo.customer.attr;

/**
 * This Class have EnterPrise Search attributed used in Search Response.
 */
public class CustomerMasterEnterpriseSearchAttr {
	private boolean limited;
	private CustomerMasterName name;
	private CustomerMasterBirthDate birthDate;
	private CustomerMasterEmail email;
	private CustomerMasterAddress address = new CustomerMasterAddress();
	private CustomerMasterEntSearchPhone phone = new CustomerMasterEntSearchPhone();

	public CustomerMasterEnterpriseSearchAttr() {

	}

	public CustomerMasterEnterpriseSearchAttr(boolean limited) {

		this.limited = limited;
		// TODO Auto-generated constructor stub
	}

	public CustomerMasterAddress getAddress() {
		return address;
	}

	public void setAddress(CustomerMasterAddress address) {
		this.address = address;
	}

	public CustomerMasterBirthDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(CustomerMasterBirthDate birthDate) {
		this.birthDate = birthDate;
	}

	public CustomerMasterEmail getEmail() {
		return email;
	}

	public void setEmail(CustomerMasterEmail email) {
		this.email = email;
	}

	public boolean isLimited() {
		return limited;
	}

	public void setLimited(boolean limited) {
		this.limited = limited;
	}

	public CustomerMasterEntSearchPhone getPhone() {
		return phone;
	}

	public void setPhone(CustomerMasterEntSearchPhone phone) {
		this.phone = phone;
	}

	public CustomerMasterName getName() {
		return name;
	}

	public void setName(CustomerMasterName name) {
		this.name = name;
	}

}
