package com.walgreens.cdi.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.walgreens.cdi.vo.CustomerMasterLinkageVO;

public class CustomerMasterLinkageRowsMapper implements ParameterizedRowMapper<CustomerMasterLinkageVO>{

	
		public CustomerMasterLinkageVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			CustomerMasterLinkageVO linkageVO = new CustomerMasterLinkageVO();
			linkageVO.setEntityId(rs.getString("EntityID"));
			linkageVO.setRefCode(rs.getString("REFCODE"));
			linkageVO.setRefID(rs.getString("REFID"));
			linkageVO.setSourceCode(rs.getString("SRCCODE"));
			linkageVO.setSourceID(rs.getString("SRCID"));
			linkageVO.setStatus(rs.getString("MEMSTAT"));
			return linkageVO;
		}	    

}
