package com.walgreens.cdi.vo;

public class CustomerMasterEntAttributesVO {

private String cdiKey;
private String cdiValue;
public String getCdiKey() {
	return cdiKey;
}
public void setCdiKey(String cdiKey) {
	this.cdiKey = cdiKey;
}
public String getCdiValue() {
	return cdiValue;
}
public void setCdiValue(String cdiValue) {
	this.cdiValue = cdiValue;
}

public boolean isNull(){
	
	if(isNull(cdiKey)&& 
		isNull(cdiValue)
		)
			return true;
	else
		return false;
}

private boolean isNull(String str){
   if(str==null)
	   return true;
	if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
		return true;
	else
		return false;
}




}