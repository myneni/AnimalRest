package com.walgreens.cdi.bo.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import walgreens.rap.webservices.security.server.ConsumerContext;
import walgreens.services.LoggingFacility;

import com.initiate.bean.ArrayOfMember;
import com.initiate.bean.Member;
import com.initiate.bean.MemberGetRequest;
import com.walgreens.cdi.bo.ICustomerMasterEnterpriseUpdateBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.CustomerMasterUtility;
import com.walgreens.cdi.util.SecurityResource;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseAttributesVO;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseProgramVO;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateResponse;
import com.walgreens.cdi.wsao.ICustomerMasterEnterpriseUpdateWSAO;

/**
 * 
 * This BO perform validation on input request and also handles exception. It
 * will return true on successful updation of record , otherwise an exception
 * will be thrown with message and error code.
 * 
 * @author 
 */

public class CustomerMasterEnterpriseUpdateBO extends BaseBO implements
		ICustomerMasterEnterpriseUpdateBO {

	private ICustomerMasterEnterpriseUpdateWSAO customerMasterEnterpriseUpdateWSAO;

	/**
	 * This method is used to update data of the corresponding source code
	 * 
	 * @param customerMasterEnterpriseUpdateRequest
	 * @return CustomerMasterEnterpriseUpdateResponse
	 * @throws SystemException
	 *             ,BusinessRuleViolationException
	 */
	public CustomerMasterEnterpriseUpdateResponse updateCustomerMasterEnterprise(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws SystemException, BusinessRuleViolationException {

		CustomerMasterEnterpriseUpdateResponse responseObj = new CustomerMasterEnterpriseUpdateResponse();
		try {
			validateRequestObject(customerMasterEnterpriseUpdateRequest);
			if (getCustomerMasterEnterpriseUpdateWSAO()
					.updateCustomerMasterEnterprise(
							customerMasterEnterpriseUpdateRequest)) {
				responseObj = populateEnterpriseUpdateResponseObject(customerMasterEnterpriseUpdateRequest);
			}

		} catch (JaxWsSoapFaultException e) {
			String exceptionCode = getExceptionCode(e);
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"THE CURRENT ERROR CODE :: " + exceptionCode);
			getWalgreensLogger().log(
					LoggingFacility.DEBUG,
					"THE CURRENT SRC CODE :: "
							+ customerMasterEnterpriseUpdateRequest
									.getSrcCode());
			if (exceptionCode != null) {
				if (exceptionCode
						.equals(CustomerMasterConstants.DO_NOT_THROW_EXCEPTION)) {
					exceptionCode = CustomerMasterConstants.EXCEPTION_UPDATE_DO_NOT_THROW;
					try {
						responseObj = populateEnterpriseUpdateResponseObject(customerMasterEnterpriseUpdateRequest);
					} catch (Exception exxe) {
						getWalgreensLogger().log(
								LoggingFacility.ERROR,
								"Inside catch within catch (inside enterpriseupdate bo) exception -> :"
										+ e.getMessage());
						throw new SystemException(
								CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2,
								e.getMessage());
					}
				} else if (exceptionCode
						.equals(CustomerMasterConstants.EC_EXCEPTION_PET_IND_REQUIRED)
						&& CustomerMasterConstants.RETRY_PET_SOURCES
								.contains(customerMasterEnterpriseUpdateRequest
										.getSrcCode() + ",")) {
					exceptionCode = CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET;
					throw new SystemException(
							CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET,
							e.getMessage());
				} else if (exceptionCode
						.equals(CustomerMasterConstants.EC_EXCEPTION_LOCK_IND_REQUIRED)
						&& CustomerMasterConstants.RETRY_LOCK_SOURCES
								.contains(customerMasterEnterpriseUpdateRequest
										.getSrcCode() + ",")) {
					exceptionCode = CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET;
					throw new SystemException(
							CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET,
							e.getMessage());
				}
				// Loyalty employee benefits
				else if (exceptionCode
						.equals(CustomerMasterConstants.LR_DETACH_PREVIOUS_PROGRAM)) {
					exceptionCode = CustomerMasterConstants.LR_DETACH_PREVIOUS_PROGRAM;
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.LR_DETACH_PREVIOUS_PROGRAM);
				} else if (exceptionCode
						.equals(CustomerMasterConstants.LR_DETACHING_NONEXISTING_PROGRAM)) {
					exceptionCode = CustomerMasterConstants.LR_DETACHING_NONEXISTING_PROGRAM;
					throw new BusinessRuleViolationException(
							CustomerMasterConstants.LR_DETACHING_NONEXISTING_PROGRAM);
				}
				// ENDS
				else {
					getWalgreensLogger().log(LoggingFacility.ERROR,
							e.getMessage());
					throw new SystemException(exceptionCode, e.getMessage());
				}
			} else {
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(
						CustomerMasterConstants.EC_UNKNOWN_EXCEPTION,
						e.getMessage());
			}
		} catch (BusinessRuleViolationException e) {
			throw e;
		} catch (Exception e) {
			throw new SystemException(
					CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2,
					e.getMessage());
		}
		return responseObj;
	}

	/**
	 * This method is used to check validations of the details entered.
	 * 
	 * @param customerMasterEnterpriseUpdateRequest
	 * @return
	 * @throws BusinessRuleViolationException
	 */
	public void validateRequestObject(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws BusinessRuleViolationException {
		ValidateCustomerMasterRequest
				.validateRequiredFields(customerMasterEnterpriseUpdateRequest);
		ValidateCustomerMasterRequest
				.validateInvalidFieldValues(customerMasterEnterpriseUpdateRequest);
		// LR Specific Validations
		if (customerMasterEnterpriseUpdateRequest.getSrcCode()
				.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_LR)
				&& null != customerMasterEnterpriseUpdateRequest.getBDate()
				&& !CustomerMasterConstants.BLANK_VAL
						.equalsIgnoreCase(customerMasterEnterpriseUpdateRequest
								.getBDate())) {
			ValidateCustomerMasterRequest
					.validateMinimumAgeRequired(customerMasterEnterpriseUpdateRequest
							.getBDate());
			ValidateCustomerMasterRequest
					.validateProgramDetails(customerMasterEnterpriseUpdateRequest);
		}

	}

	/**
	 * This method will be used to populate EnterpriseUpdateReposne Object by
	 * MemGet
	 * 
	 * @param customerMasterEnterpriseUpdateRequest
	 * @return
	 * @throws Exception
	 */
	public CustomerMasterEnterpriseUpdateResponse populateEnterpriseUpdateResponseObject(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws Exception {
		CustomerMasterEnterpriseUpdateResponse respObj = new CustomerMasterEnterpriseUpdateResponse();
		if (CustomerMasterConstants.SRC_CODE_LR
				.equalsIgnoreCase(customerMasterEnterpriseUpdateRequest
						.getSrcCode())) {
			MemberGetRequest memberGetRequest = new MemberGetRequest();
			memberGetRequest.setSrcCode(customerMasterEnterpriseUpdateRequest
					.getSrcCode().toUpperCase());
			memberGetRequest.setMemIdnum(customerMasterEnterpriseUpdateRequest
					.getSrcIdNum());
			memberGetRequest
					.setSrcCodeFilter(CustomerMasterConstants.SRC_CODE_FILTER);
			memberGetRequest.setEntType(CustomerMasterConstants.ENT_TYPE_ID);
			memberGetRequest
					.setMemType(CustomerMasterConstants.PATIENT_MEMBER_TYPE);
			memberGetRequest.setMemRecno(CustomerMasterConstants.ZERO);
			memberGetRequest.setEntRecno(CustomerMasterConstants.ZERO);
			memberGetRequest.setGetType(CustomerMasterConstants.AS_MEMBER);
			memberGetRequest.setRecStatFilter(CustomerMasterConstants.Active);
			memberGetRequest.setMemStatFilter(CustomerMasterConstants.Active);
			memberGetRequest
					.setSegCodeFilter(CustomerMasterConstants.SEG_CODE_ENT_ADD_UPDATE);

			String consumerAppId = ConsumerContext
					.getCurrentConsumerApplicationId();
			String initiateID = CustomerMasterConstants.BLANK_VAL;
			String initiatePWD = CustomerMasterConstants.BLANK_VAL;

			SecurityResource securityResource = SecurityResource.getInstance();
			initiateID = securityResource.getInitiateID(consumerAppId);
			initiatePWD = securityResource.getInitiatePassword(initiateID);

			// Set correlationId|MessageID| as argument
			memberGetRequest.setArgs(CustomerMasterUtility.generateLogString(
					getLoggingHandlerObj().getTrackingInfoProxyBean(),
					CustomerMasterConstants.BLANK_STRING,
					CustomerMasterConstants.BLANK_STRING));
			memberGetRequest.setUserName(initiateID);
			memberGetRequest.setUserPassword(initiatePWD);
			try {

				ArrayOfMember arrMemberRes = getCustomerMasterEnterpriseUpdateWSAO()
						.getMemberEnterpriseAddUpdateResponse(memberGetRequest);
				List<Member> memberList = arrMemberRes.getItem();
				Member[] memberRes = memberList.toArray(new Member[memberList
						.size()]);
				String attrCode = CustomerMasterConstants.BLANK_VAL;
				CustomerMasterEnterpriseProgramVO progVO = null;
				CustomerMasterEnterpriseAttributesVO attributeVO = null;
				int count = 0;

				ArrayList<CustomerMasterEnterpriseProgramVO> custProgIdArray = new ArrayList<CustomerMasterEnterpriseProgramVO>();
				ArrayList<CustomerMasterEnterpriseAttributesVO> custMasterAttrArray = new ArrayList<CustomerMasterEnterpriseAttributesVO>();
				if (memberRes[0].getMemIds() != null
						&& (memberRes[0].getMemIds().getItem().size() > 0)) {
					for (int index = 0; index < memberRes[0].getMemIds()
							.getItem().size(); index++) {
						attrCode = memberRes[0].getMemIds().getItem()
								.get(index).getAttrCode();

						if (CustomerMasterConstants.ATTR_CODE_PROGRAM
								.contains(attrCode)) {
							String status = memberRes[0].getMemIds().getItem()
									.get(index).getValues().getItem()
									.get(count++);
							progVO = new CustomerMasterEnterpriseProgramVO();
							progVO.setProgramStatus(status);
							String progId = memberRes[0].getMemIds().getItem()
									.get(index).getValues().getItem()
									.get(count++);
							String progStartDt = memberRes[0].getMemIds()
									.getItem().get(index).getValues().getItem()
									.get(count++);
							String progExpDate = memberRes[0].getMemIds()
									.getItem().get(index).getValues().getItem()
									.get(count++);
							String progCode = memberRes[0].getMemIds()
									.getItem().get(index).getValues().getItem()
									.get(count++);
							String progLstUpDt = memberRes[0].getMemIds()
									.getItem().get(index).getValues().getItem()
									.get(count++);
							progVO.setProgramId(progId);
							progVO.setProgStartDt(progStartDt);
							progVO.setProgExpDt(progExpDate);
							progVO.setProgramCode(progCode);
							progVO.setProgLstUpDt(progLstUpDt);
							custProgIdArray.add(progVO);
						}
						if ((attrCode
								.equals(CustomerMasterConstants.ATTR_CODE_CUSTGENATTR_CODE))) {
							attributeVO = new CustomerMasterEnterpriseAttributesVO();
							attributeVO.setCdiKey(memberRes[0].getMemIds()
									.getItem().get(index).getValues().getItem()
									.get(0));
							attributeVO.setCdiValue(memberRes[0].getMemIds()
									.getItem().get(index).getValues().getItem()
									.get(1));
							custMasterAttrArray.add(attributeVO);
						}
						count = 0;
					}
				}
				if (custMasterAttrArray.isEmpty()) {
					attributeVO = new CustomerMasterEnterpriseAttributesVO();
					attributeVO.setCdiKey(CustomerMasterConstants.BLANK_VAL);
					attributeVO.setCdiValue(CustomerMasterConstants.BLANK_VAL);
					custMasterAttrArray.add(attributeVO);
				}
				if (custProgIdArray.isEmpty()) {
					progVO = new CustomerMasterEnterpriseProgramVO();
					progVO.setProgramStatus(CustomerMasterConstants.BLANK_VAL);
					progVO.setProgramId(CustomerMasterConstants.BLANK_VAL);
					progVO.setProgStartDt(CustomerMasterConstants.BLANK_VAL);
					progVO.setProgExpDt(CustomerMasterConstants.BLANK_VAL);
					progVO.setProgramCode(CustomerMasterConstants.BLANK_VAL);
					progVO.setProgLstUpDt(CustomerMasterConstants.BLANK_VAL);
					custProgIdArray.add(progVO);
				}
				respObj.setMemStat(memberRes[0].getMemHead().getMemStat());
				respObj.setMemIdNum(memberRes[0].getMemHead().getMemIdnum());
				respObj.setCustArrayOfAttributes(custMasterAttrArray);
				respObj.setCustProgIdArray(custProgIdArray);

			} catch (Exception ex) {
				getWalgreensLogger()
						.log(LoggingFacility.ERROR,
								"Inside populateEnterpriseUpdateResponseObject (inside enterpriseupdate bo) exception -> :"
										+ ex.getMessage());
				throw new SystemException(
						CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2,
						ex.getMessage());
			}
		} else {
			respObj.setStatus(CustomerMasterConstants.REPOSNE_TRUE);
		}
		return respObj;
	}

	public ICustomerMasterEnterpriseUpdateWSAO getCustomerMasterEnterpriseUpdateWSAO() {
		return customerMasterEnterpriseUpdateWSAO;
	}

	public void setCustomerMasterEnterpriseUpdateWSAO(
			ICustomerMasterEnterpriseUpdateWSAO customerMasterEnterpriseUpdateWSAO) {
		this.customerMasterEnterpriseUpdateWSAO = customerMasterEnterpriseUpdateWSAO;
	}
}