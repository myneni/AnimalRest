package com.walgreens.cdi.service.impl;


import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterEntUpdateBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterEntUpdateService;
import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateResponse;


public class CustomerMasterEntUpdateService extends BaseService  implements ICustomerMasterEntUpdateService{
	
	private ICustomerMasterEntUpdateBO customerMasterEntUpdateBO;
	

	public CustomerMasterEntUpdateResponse updateCustomerMasterEnt(CustomerMasterEntUpdateRequest lyUpdateRequest) throws CDIException {
		
		CustomerMasterEntUpdateResponse responseObj = new CustomerMasterEntUpdateResponse();		
		try{
			responseObj= getcustomerMasterEntUpdateBO().updateCustomerMasterEnt(lyUpdateRequest);
			
		} catch (CDIException e) {
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
		return responseObj;
	}


	/**
	 * @return the searchBO
	 */
	public ICustomerMasterEntUpdateBO getcustomerMasterEntUpdateBO() {
		return customerMasterEntUpdateBO;
	}


	/**
	 * @param searchBO the searchBO to set
	 */
	public void setCustomerMasterEntUpdateBO(ICustomerMasterEntUpdateBO customerMasterEntUpdateBO) {
		this.customerMasterEntUpdateBO = customerMasterEntUpdateBO;
	}
	
	
	
}
