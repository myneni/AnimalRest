package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfEnterpriseCustomer;

public interface ICustomerMasterEnterpriseLookUpBO {
	/**
	 * This method is used to search the record based on the input provided.
	 * 
	 * @param enterpriseSearchRequest
	 * @return
	 * @throws SystemException
	 * @throws BusinessRuleViolationException
	 * @throws CDIException
	 */
	public ArrayOfEnterpriseCustomer lookUpCustomerMasterEnterprise(
			CustomerMasterEnterpriseLookUpRequest enterpriseSearchRequest)
			throws SystemException, BusinessRuleViolationException,
			CDIException;
}
