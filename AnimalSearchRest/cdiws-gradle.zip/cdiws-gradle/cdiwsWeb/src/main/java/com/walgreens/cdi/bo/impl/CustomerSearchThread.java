package com.walgreens.cdi.bo.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import walgreens.services.LoggingFacility;

import com.initiate.bean.ArrayOfMember;
import com.walgreens.cdi.util.CDILogger;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpResponse;
import com.walgreens.cdi.vo.TrackingInfoVO;
import com.walgreens.cdi.wsao.ICustomerMasterEnterpriseLookUpWSAO;
import com.walgreens.cdi.wsao.impl.CustomerMasterEnterpriseLookUpWSAO;


public class CustomerSearchThread extends Thread {	

	CustomerMasterEnterpriseLookUpResponse[] searchResponse = null;

	CustomerMasterEnterpriseLookUpBO lookUpBO;

	ICustomerMasterEnterpriseLookUpWSAO lookUpWSAO;

	CustomerMasterEnterpriseLookUpRequest customerMasterEnterpriseLookupRequest;

	String searchSource;
	String initiateID;
	String initiatePassWd;
	String cvType;
	
	CDILogger cdiLogger = null;
	int maxMemberCnt=0;
	TrackingInfoVO localTrackingInfoVo=null;

	CustomerSearchThread(
			CustomerMasterEnterpriseLookUpRequest customerMasterReq,
			String searchSource, CustomerMasterEnterpriseLookUpBO lookUpBO,
			ICustomerMasterEnterpriseLookUpWSAO lookUpWSAO,String cvType,
			String initiateID, String initiatePassWd,CDILogger _cdilogger,int maxMemberCnt,TrackingInfoVO localTrackingInfoVo) {
		this.customerMasterEnterpriseLookupRequest = customerMasterReq;
		this.searchSource = searchSource;
		this.lookUpBO = lookUpBO;
		this.lookUpWSAO = lookUpWSAO;
		this.initiateID = initiateID;
		this.initiatePassWd = initiatePassWd;
		this.cdiLogger = _cdilogger;
		this.cvType = cvType;
		this.maxMemberCnt=maxMemberCnt;
		this.localTrackingInfoVo=localTrackingInfoVo;
	}

	
	public void run() {	
		ArrayOfMember arrMemberRes = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss:S");
		long starttime= 0;
		long endtime = 0;
		
		try {
			
			 starttime = Calendar.getInstance().getTimeInMillis();
			 Date startTime = new Date();
			 cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|CDIWS to InitiateWS|"+(formatter.format(startTime))+"|");
			 //Code Changes Start CDI-368
			 //((CustomerMasterEnterpriseLookUpWSAO)lookUpWSAO).getLoggingHandlerObj().setTrackingInfoProxyBean(cdiLogger.getTrackingInfoProxyBean());
			 //Code Changes END CDI-368
		arrMemberRes = lookUpWSAO.getMemHeadfromCustomer(customerMasterEnterpriseLookupRequest,searchSource,initiateID, initiatePassWd, cvType,false ,localTrackingInfoVo);
		endtime = Calendar.getInstance().getTimeInMillis();
		 cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|InitiateWS to CDIWS|"+(endtime-starttime)+"|");
		
		if (CustomerMasterConstants.ENT_PV_TABLE_SEARCH) {
			searchResponse =lookUpWSAO.getDetailsFromCustomerPVtable(arrMemberRes, cvType,customerMasterEnterpriseLookupRequest.getReturnLinkages(),maxMemberCnt,"");
		} else {
			cdiLogger.log(LoggingFacility.INFO,
					"PV search disabled.Seraching in hub");
		}
		if (searchResponse == null) {
			cdiLogger.log(LoggingFacility.INFO,
					"No records in PV table.Seraching in CDI hub");
			
			Date startTime2 = new Date();
			starttime = Calendar.getInstance().getTimeInMillis();
			cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|CDIWS to InitiateWS|"+(formatter.format(startTime2))+"|");

			searchResponse = lookUpWSAO
					.lookUpCustomerMasterDynamic(customerMasterEnterpriseLookupRequest,searchSource, initiateID,initiatePassWd, cvType,maxMemberCnt,false,localTrackingInfoVo);
			endtime = Calendar.getInstance().getTimeInMillis();
			cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|InitiateWS to CDIWS|"+(endtime-starttime)+"|");
		}
		}
		 catch (Exception e) {
			 endtime = Calendar.getInstance().getTimeInMillis();
			 cdiLogger.log(LoggingFacility.INFO, "CustomerMasterEntLookUpServiceV2|InitiateWS to CDIWS|RUN TIME EXCEPTION|"+(endtime-starttime)+"|");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}	
}
