package com.walgreens.cdi.util;

import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import com.walgreens.cdi.util.LoggingHandler;
import com.walgreens.cdi.util.SOAPMessageHandler;
//Custom class that will logged inbound and outbound request 
public class CustomLoggingHandler implements
javax.xml.ws.handler.soap.SOAPHandler<SOAPMessageContext> {


	/**
	 * Method to enable logging of request and response
	 * 
	 * @param soapMessageContext
	 */
	public boolean handleMessage(SOAPMessageContext soapMessageContext) {
		if (soapMessageContext != null) {
			SOAPMessage msg = ((SOAPMessageContext) soapMessageContext)
					.getMessage();

			boolean outbound = (Boolean) soapMessageContext
					.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
			if (outbound) {

				

				//Method call for logging request and response.
				SOAPMessageHandler soapMessageHandler = (SOAPMessageHandler) walgreens.utils.ioc.BeanFactoryUtil
						.getFactory().getBean("soapMessageHandler");
				soapMessageHandler.handleMessage(soapMessageContext);
				
				// Method call for logging request and response.
				LoggingHandler loggingHandler = (LoggingHandler) walgreens.utils.ioc.BeanFactoryUtil
						.getFactory().getBean("loggingHandler");
				loggingHandler.handleMessage(soapMessageContext);

			} else {
				//Method call for logging request and response.
				SOAPMessageHandler soapMessageHandler = (SOAPMessageHandler) walgreens.utils.ioc.BeanFactoryUtil
						.getFactory().getBean("soapMessageHandler");
				soapMessageHandler.handleMessage(soapMessageContext);
				
				// Method call for logging request and response.
				LoggingHandler loggingHandler = (LoggingHandler) walgreens.utils.ioc.BeanFactoryUtil
						.getFactory().getBean("loggingHandler");
				loggingHandler.handleMessage(soapMessageContext);
			}
		}
		return true;
	}

	@Override
	public void close(MessageContext arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean handleFault(SOAPMessageContext arg0) {
		// TODO Auto-generated method stub
		LoggingHandler loggingHandler = (LoggingHandler) walgreens.utils.ioc.BeanFactoryUtil
				.getFactory().getBean("loggingHandler");
		return loggingHandler.handleFault(arg0);
	}

	@Override
	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}


}
