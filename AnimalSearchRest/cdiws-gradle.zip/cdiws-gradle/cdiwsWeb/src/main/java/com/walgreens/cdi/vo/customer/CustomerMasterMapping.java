/**
 * 
 */
package com.walgreens.cdi.vo.customer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import madison.mpi.MemHead;
import madison.mpi.MemRow;
import madison.mpi.MemRowList;
import madison.mpi.RowIterator;
import madison.mpi.SegDef;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import walgreens.rap.webservices.security.server.ConsumerContext;

import com.initiate.bean.ArrayOfMemIdsWs;
import com.initiate.bean.ArrayOfMember;
import com.initiate.bean.ArrayOfXsdString;
import com.initiate.bean.IdentityHubPort;
import com.initiate.bean.MemIdsWs;
import com.initiate.bean.Member;
import com.initiate.bean.MemberGetRequest;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.CustomerMasterUtility;
import com.walgreens.cdi.util.SecurityResource;
import com.walgreens.cdi.vo.CustomerMasterEntAttributesVO;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpResponse;
import com.walgreens.cdi.vo.CustomerMasterEntSearchProgramVO;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpResponse;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseSearch;
import com.walgreens.cdi.vo.CustomerMasterResponse;
import com.walgreens.cdi.vo.TrackingInfoVO;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttrNCOA;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterBirthDate;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterDeceasedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEmail;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterGender;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterHubLinkageRec;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterHubLinkageRecInternal;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLinkageDetail;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLockedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterName;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterOrigin;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPetInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPhoneAttr;



/**
 * @author picketta,lzhang
 * 
 */
public class CustomerMasterMapping {

	/**
	 * 
	 */
	private static Logger logger = Logger
			.getLogger(CustomerMasterMapping.class);

	public CustomerMasterMapping() {
		
	}

	/**
	 * Mapping Member [] to Customer with clapping the same EID to single
	 * composite view
	 * 
	 * @param memberRes
	 * @return
	 */
	public static CustomerMasterResponse[] mapToCustomer(Member[] memberRes,
			String cvwName, int maxRowReturn,TrackingInfoVO trackingInfoVO) throws  BusinessRuleViolationException{
		logger
		.log(
				Level.DEBUG,
				"CustomerMaster ::  mapToCustomer () :Start Mapping from member result to customer objects");

CustomerMasterResponse[] customerMasterResponse = null;
CustomerMasterHubLinkageRecInternal[] customerMasterlinkage = null;
int custCountIndex = 0;
int custLinkIndex = 0;
boolean isNew = false;
String addSearcCriteriaFlag = CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_NO;
if (memberRes != null) {
	if (memberRes.length >= CustomerMasterConstants.MAX_ROWS) {
		addSearcCriteriaFlag = CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_YES;
	}

}

if (memberRes != null || memberRes.length == 0) {
	// Phone Alignment Changes: variable Declarations
	String hPhPriority = CustomerMasterConstants.BLANK_STRING;
	String cPhPriority = CustomerMasterConstants.BLANK_STRING;
	String wPhPriority = CustomerMasterConstants.BLANK_STRING;
	customerMasterResponse = new CustomerMasterResponse[memberRes.length];
	customerMasterlinkage = new CustomerMasterHubLinkageRecInternal[memberRes.length];
	for (int i = 0; i < memberRes.length; i++) {

		
		String currCustEid = Long.toString(memberRes[i].getMemHead()
				.getEntRecno());
		Short currMatchScore = memberRes[i].getMemHead()
				.getMatchScore();			
		String sourceCode=memberRes[i].getMemHead().getSrcCode();//Added For Hub Search defect
		CustomerMaster customer = null;

		if (i == 0) {
			custCountIndex = i;
			custLinkIndex = custCountIndex;
			isNew = true;
			
			customerMasterResponse[custCountIndex] = new CustomerMasterResponse();
			customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();					
			logger.log(Level.DEBUG, "New 0" + "custCountIndex="
					+ custCountIndex);
		} else {

			for (int j = 0; j < custCountIndex + 1; j++) {
				if (currCustEid
						.equalsIgnoreCase(customerMasterResponse[j]
								.getCdiCustomer().getEID())) {
					custLinkIndex = j;
					customer = customerMasterResponse[j]
							.getCdiCustomer();
								

					if (currMatchScore > Short.valueOf(customer
							.getMatchScore())) {
						customer.setMatchScore(Short
								.toString(currMatchScore));
					}
					isNew = false;
					
					logger.log(Level.DEBUG, "old " + "custCountIndex="
							+ custCountIndex + "j=" + j + ", i=" + i);
					break;
				} else
					isNew = true;
			}

			if (isNew) {
				
				custCountIndex = custCountIndex + 1;
				custLinkIndex = custCountIndex;
				customerMasterResponse[custCountIndex] = new CustomerMasterResponse();
				customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();						
				logger.log(Level.DEBUG, "new " + "custCountIndex="
						+ custCountIndex + "i=" + i);
			}
		}
		if (isNew) {
			customer = new CustomerMaster();
			customer.setEID(currCustEid);
			customer.setMatchScore(Short.toString(currMatchScore));
			customer.setSourceCode(sourceCode); //Added For Hub Search defect
			customerMasterlinkage[custCountIndex].setEid(currCustEid);
			ArrayList<CustomerMasterLinkageDetail> linkageDetail = getIDLinkages(memberRes[i].getMemHead().getMemIdnum(),memberRes[i].getMemHead().getSrcCode(),trackingInfoVO);
			customerMasterlinkage[custCountIndex]
					.setLinkageDetail(linkageDetail);
			

		}

		
		String secCode = "";
		ArrayOfMemIdsWs arraymemIdsWs = memberRes[i].getMemIds();
		MemIdsWs[] memIdsWs = null;
		if (arraymemIdsWs != null) {
			if(arraymemIdsWs.getItem()!=null)
			 {
				
				  List<MemIdsWs> memberList = arraymemIdsWs.getItem();
				  memIdsWs=memberList.toArray(new MemIdsWs[memberList.size()]);
				   
				  logger.log(Level.DEBUG, "new " + "memIdsWs.size"
							+ memIdsWs.length);
			 }
			for (int j = 0; memIdsWs != null && j < memIdsWs.length; j++) {
				ArrayOfXsdString memIdsWsValues = memIdsWs[j]
						.getValues();						

				if (CustomerMasterConstants.ATTR_CODE_NAME
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerName(memIdsWsValues).isNull())) {
						customer.getCustAll().setName(
								mapCustomerName(memIdsWsValues));
						customer.getCustAll().getName()
								.setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
						customer.getCustAll().getName().setSourceCode(
								memIdsWs[j].getSrcCode());
						
					} 
				} else if (CustomerMasterConstants.ATTR_CODE_GENDER
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerGender(memIdsWsValues).isNull())) {
						customer
								.setGender(mapCustomerGender(memIdsWsValues));
						customer.getGender().setLastUpdateDate(
								cvrtLstUpdDate(memIdsWs[j]
										.getSrcLtime()));
						customer.getGender().setSourceCode(
								memIdsWs[j].getSrcCode());
					}

				} else if (CustomerMasterConstants.ATTR_CODE_LAST_UPDATE_DATE
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (mapCustomerLastUpdateDate(memIdsWsValues) != null) {
						customer
								.setLastUpdateDate(mapCustomerLastUpdateDate(memIdsWsValues));

					}

				} else if (CustomerMasterConstants.ATTR_CODE_PET_IND
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerPetInd(memIdsWsValues).isNull())) {
						customer
								.setPetInd(mapCustomerPetInd(memIdsWsValues));
						customer.getPetInd().setLastUpdateDate(
								cvrtLstUpdDate(memIdsWs[j]
										.getSrcLtime()));
						customer.getPetInd().setSourceCode(
								memIdsWs[j].getSrcCode());
					}

				} else if (CustomerMasterConstants.ATTR_CODE_DEATH_IND
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerDeathInd(memIdsWsValues).isNull())) {
						customer
								.setDeceasedInd(mapCustomerDeathInd(memIdsWsValues));
						customer.getDeceasedInd().setLastUpdateDate(
								cvrtLstUpdDate(memIdsWs[j]
										.getSrcLtime()));
						customer.getDeceasedInd().setSourceCode(
								memIdsWs[j].getSrcCode());
					}

				} else if (CustomerMasterConstants.ATTR_CODE_SEC_CODE
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					secCode = mapCustomerSECCode(memIdsWsValues);
					customer.setSecCode(secCode);

				} else if (CustomerMasterConstants.ATTR_CODE_EMAIL
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerEmail(memIdsWsValues).isNull())) {
						customer.getCustAll().setEmail(
								mapCustomerEmail(memIdsWsValues));
						customer.getCustAll().getEmail()
								.setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
						customer.getCustAll().getEmail().setSourceCode(
								memIdsWs[j].getSrcCode());

						
					}

				} else if (CustomerMasterConstants.ATTR_CODE_LOCK_IND
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerLockedInd(memIdsWsValues).isNull())) {
						customer
								.setLockedInd(mapCustomerLockedInd(memIdsWsValues));
						customer.getLockedInd().setLastUpdateDate(
								cvrtLstUpdDate(memIdsWs[j]
										.getSrcLtime()));
						customer.getLockedInd().setSourceCode(
								memIdsWs[j].getSrcCode());
					}

				} else if (CustomerMasterConstants.ATTR_CODE_BIRTH_DT
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {

					if (!(mapCustomerBirthDate(memIdsWsValues).isNull())) {
						customer.getCustAll().setBirthDate(
								mapCustomerBirthDate(memIdsWsValues));
						customer.getCustAll().getBirthDate()
								.setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
						customer
								.getCustAll()
								.getBirthDate()
								.setSourceCode(memIdsWs[j].getSrcCode());
					}

				} else if (CustomerMasterConstants.ATTR_CODE_CUST_ORGN
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {

					if (!(mapCustomerOrigin(memIdsWsValues).isNull())) {
						customer
								.setOrigin(mapCustomerOrigin(memIdsWsValues));
						customer.getOrigin().setLastUpdateDate(
								cvrtLstUpdDate(memIdsWs[j]
										.getSrcLtime()));
						customer.getOrigin().setSourceCode(
								memIdsWs[j].getSrcCode());
					}

				}

				else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerAddressNOCA(memIdsWsValues,
							CustomerMasterConstants.CM_ADDRESS_TYPE_P)
							.isNull())) {

						customer
								.getCustAll()
								.getAddress()
								.setPermAddress(
										mapCustomerAddressNOCA(
												memIdsWsValues,
												CustomerMasterConstants.CM_ADDRESS_TYPE_P));
						customer.getCustAll().getAddress()
								.getPermAddress().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
						customer.getCustAll().getAddress()
								.getPermAddress().setSourceCode(
										memIdsWs[j].getSrcCode());
					}
				} else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS_2
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerAddress(memIdsWsValues,
							CustomerMasterConstants.CM_ADDRESS_TYPE_2)
							.isNull())) {
						customer
								.getCustAll()
								.getAddress()
								.setHome2Address(
										mapCustomerAddress(
												memIdsWsValues,
												CustomerMasterConstants.CM_ADDRESS_TYPE_2));
						customer.getCustAll().getAddress()
								.getHome2Address().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
						customer.getCustAll().getAddress()
								.getHome2Address().setSourceCode(
										memIdsWs[j].getSrcCode());

					}

				} else if (CustomerMasterConstants.ATTR_CODE_WK_ADDRESS
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerAddress(memIdsWsValues,
							CustomerMasterConstants.CM_ADDRESS_TYPE_W)
							.isNull())) {
						customer
								.getCustAll()
								.getAddress()
								.setWorkAddress(
										mapCustomerAddress(
												memIdsWsValues,
												CustomerMasterConstants.CM_ADDRESS_TYPE_W));
						customer.getCustAll().getAddress()
								.getWorkAddress().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
						customer.getCustAll().getAddress()
								.getWorkAddress().setSourceCode(
										memIdsWs[j].getSrcCode());

					}

				} else if (CustomerMasterConstants.ATTR_CODE_PR_PHONE
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerPhone(memIdsWsValues,
							CustomerMasterConstants.CM_PHONE_TYPE_H)
							.isNull())) {
						customer
								.getCustAll()
								.getPhone()
								.setHomePhone(
										mapCustomerPhone(
												memIdsWsValues,
												CustomerMasterConstants.CM_PHONE_TYPE_H));
						customer.getCustAll().getPhone().getHomePhone()
								.setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
						customer
								.getCustAll()
								.getPhone()
								.getHomePhone()
								.setSourceCode(memIdsWs[j].getSrcCode());

					}

				} else if (CustomerMasterConstants.ATTR_CODE_CELL_PHONE
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerPhone(memIdsWsValues,
							CustomerMasterConstants.CM_PHONE_TYPE_C)
							.isNull())) {
						customer
								.getCustAll()
								.getPhone()
								.setCellPhone(
										mapCustomerPhone(
												memIdsWsValues,
												CustomerMasterConstants.CM_PHONE_TYPE_C));
						customer.getCustAll().getPhone().getCellPhone()
								.setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
						customer
								.getCustAll()
								.getPhone()
								.getCellPhone()
								.setSourceCode(memIdsWs[j].getSrcCode());

					}

				} else if (CustomerMasterConstants.ATTR_CODE_WK_PHONE
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					if (!(mapCustomerPhone(memIdsWsValues,
							CustomerMasterConstants.CM_PHONE_TYPE_W)
							.isNull())) {
						customer
								.getCustAll()
								.getPhone()
								.setWorkPhone(
										mapCustomerPhone(
												memIdsWsValues,
												CustomerMasterConstants.CM_PHONE_TYPE_W));
						customer.getCustAll().getPhone().getWorkPhone()
								.setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
						customer
								.getCustAll()
								.getPhone()
								.getWorkPhone()
								.setSourceCode(memIdsWs[j].getSrcCode());

					}

				}

				else if (CustomerMasterConstants.ATTR_CODE_TRUST_ID
						.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
					CustomerMasterLinkageDetail linkDetail = mapCustomerTrustID(memIdsWsValues);
					ArrayList<CustomerMasterLinkageDetail> myRefLink = customerMasterlinkage[custLinkIndex]
							.getLinkageDetail();
					CustomerMasterLinkageDetail temp = (CustomerMasterLinkageDetail) myRefLink
							.get(myRefLink.size() - 1);
					temp.setRefCode(linkDetail.getRefCode());
					temp.setRefID(linkDetail.getRefID());
					myRefLink.set(myRefLink.size() - 1, temp);

				}
									// Phone ALignment Changes: Fetch Phone Priorities
						else if (CustomerMasterConstants.ATTR_CODE_HPHMETADATA
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							hPhPriority = memIdsWsValues
									.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTATTR_FIELD1);
						} else if (CustomerMasterConstants.ATTR_CODE_CPHMETADATA
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							cPhPriority = memIdsWsValues
									.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTATTR_FIELD1);
						} else if (CustomerMasterConstants.ATTR_CODE_WPHMETADATA
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							wPhPriority = memIdsWsValues
									.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTATTR_FIELD1);
						}
						// Phone Alignment CHanges End				
			}
		}
		if (customer != null) {
			setSecurityCode(secCode, customer);
			// Method To Set Phone Meta data (Phone Priorities)
					setPhoneMetaData(hPhPriority, cPhPriority, wPhPriority,
							customer);
			if (!isNull(cvwName)
					&& cvwName
							.equalsIgnoreCase(CustomerMasterConstants.CVW_NAME_LIMITED)) {
				customer.getCustLim().setLimited(true);
				customer.getCustLim().setAddress(
						customer.getCustAll().getAddress());
				customer.getCustLim().setBirthDate(
						customer.getCustAll().getBirthDate());
				customer.getCustLim().setEmail(
						customer.getCustAll().getEmail());
				customer.getCustLim().setName(
						customer.getCustAll().getName());
				customer.getCustLim().setPhone(
						customer.getCustAll().getPhone());
				customer.getCustAll().setLimited(true);

			}

		}
		customerMasterResponse[custLinkIndex].setCdiCustomer(customer);

	}
}
//Code change start  For Hub Search defect
//This code will remove LR from objects contribution in demographic details
int currentIndex=0;
int length=custCountIndex+1;
for (int counter = 0; counter < length; counter++) 
{
	//Riteaid boolean added.
	boolean isaddCustomer=false;
	if(CustomerMasterConstants.LR_SRC.contains(customerMasterResponse[counter].getCdiCustomer().getSourceCode().toUpperCase()))
	{
		custCountIndex--;
		customerMasterResponse[counter].getCdiCustomer().setSourceCode(null);				
	}			
	else
	{
		//Riteaid change to suppress Riteaid customers if application id is IC+ --starts
		
		
		if(trackingInfoVO.getApplicationID()!=null && (CustomerMasterConstants.APPID_RITEAID.contains(trackingInfoVO.getApplicationID().toUpperCase()) && trackingInfoVO.getApplicationID().length()>1))
		{
			
			for(CustomerMasterLinkageDetail tmpObj1:customerMasterlinkage[counter].getLinkageDetail())
			{
				if(CustomerMasterConstants.SRC_CODE_FILTER_CUSTOMER_LOOKUP.contains(tmpObj1.getSourceCode()))
				{	
					String patternName=CustomerMasterConstants.PREFIX+trackingInfoVO.getApplicationID();
					try{
					if(!(CustomerMasterConstants.SRC_CODE_EE.equalsIgnoreCase(tmpObj1.getSourceCode()) && tmpObj1.getSourceID().toUpperCase().matches(String.valueOf(CustomerMasterConstants.class.getField(patternName).get(null)))))
					{
						isaddCustomer=true;
						break;
					}
					}
					catch(Exception e)
					{}
				}
				
			}
		}
		else
		 {
			isaddCustomer=true;
		 }
		if(isaddCustomer)
		{	
			customerMasterResponse[currentIndex].setCdiCustomer(customerMasterResponse[counter].getCdiCustomer());
			customerMasterlinkage [currentIndex]=customerMasterlinkage[counter];
			currentIndex++;
			if(customerMasterResponse[counter].getCdiCustomer().getSourceCode()!=null){
				customerMasterResponse[counter].getCdiCustomer().setSourceCode(null);}
		}
		else
		{
			custCountIndex--;
		}
	}	
}
//Riteaid change to suppress Riteaid customers if application id is IC+ --ends
//Code change end  For Hub Search defect
CustomerMasterResponse[] customerMasterResponseFinal = null;
if (customerMasterResponse.length > 0) {
	if (maxRowReturn == 0)// not specifying the max returns, then
							// return all
	{
		customerMasterResponseFinal = new CustomerMasterResponse[custCountIndex + 1];
	} else if (maxRowReturn >= custCountIndex + 1) {
		customerMasterResponseFinal = new CustomerMasterResponse[custCountIndex + 1];
	} else if (maxRowReturn < custCountIndex + 1) {
		customerMasterResponseFinal = new CustomerMasterResponse[maxRowReturn];
	}
//	Code change Start  For Hub Search defect
	if (customerMasterResponseFinal.length == 0) {
		throw new BusinessRuleViolationException(
				CustomerMasterConstants.ELIGIBILITY_SEARCH_NULL_RESPONSE);

	}//Code change end  For Hub Search defect
	for (int k = 0; k < customerMasterResponseFinal.length; k++) {
		// System.out.println(k+"="+customerMasterResponse[k].getCdiCustomer().toString());
		customerMasterResponseFinal[k] = customerMasterResponse[k];
		CustomerMasterHubLinkageRec customerLinkageRecFinal = new CustomerMasterHubLinkageRec();
		customerLinkageRecFinal.setEid(customerMasterlinkage[k]
				.getEid());
		CustomerMasterLinkageDetail[] customerLinkageDetail = new CustomerMasterLinkageDetail[customerMasterlinkage[k]
				.getLinkageDetail().size()];
		for (int j = 0; j < customerMasterlinkage[k].getLinkageDetail()
				.size(); j++) {
			customerLinkageDetail[j] = customerMasterlinkage[k]
					.getLinkageDetail().get(j);

		}
		customerLinkageRecFinal.setLinkageDetail(customerLinkageDetail);
		customerMasterResponseFinal[k].getCdiCustomer()
				.setHubLinkageRec(customerLinkageRecFinal);
		customerMasterResponseFinal[k]
				.setAddCriteriaFlag(addSearcCriteriaFlag);
	}
}
logger
		.log(
				Level.DEBUG,
				"CustomerMaster ::  mapToCustomer () :End of  Mapping from member result to customer objects");

return customerMasterResponseFinal;

}
// Phone ALignment Changes: Set phone metadata start
	/**
	 * Method to set Phone Meta Data in Custome Home/Cell/Work Phones.
	 * @param hPhPriority
	 * @param cPhPriority
	 * @param wPhPriority
	 * @param customer
	 */
	
	private static void setPhoneMetaData(String hPhPriority, String cPhPriority, String wPhPriority, CustomerMaster customer) {
		if(customer.getCustAll().getPhone()!=null)
		{
			if(customer.getCustAll().getPhone().getHomePhone()!=null && customer.getCustAll().getPhone().getHomePhone().getPhonePriority()==null)
			{
				customer.getCustAll().getPhone().getHomePhone().setPhonePriority(hPhPriority);
			}
			if(customer.getCustAll().getPhone().getCellPhone()!=null && customer.getCustAll().getPhone().getCellPhone().getPhonePriority()==null)
			{
				customer.getCustAll().getPhone().getCellPhone().setPhonePriority(cPhPriority);
			}
			if(customer.getCustAll().getPhone().getWorkPhone()!=null && customer.getCustAll().getPhone().getWorkPhone().getPhonePriority()==null)
			{
				customer.getCustAll().getPhone().getWorkPhone().setPhonePriority(wPhPriority);
			}
		}
	}
	// Phone ALignment Changes: Set phone metadata end
	// Phone ALignment Changes: Set phone metadata start
			/**
			 * Method to set Phone Meta Data in Custome Home/Cell/Work Phones.
			 * @param hPhPriority
			 * @param cPhPriority
			 * @param wPhPriority
			 * @param customer
			 */
			
			private static void setPhoneMetaData(String hPhPriority, String cPhPriority, String wPhPriority, CustomerMasterEnterpriseSearch customer) {
				if(customer.getCustAll().getPhone()!=null)
				{
					if(customer.getCustAll().getPhone().getHomePhone()!=null && customer.getCustAll().getPhone().getHomePhone().getPhonePriority()==null)
					{
						customer.getCustAll().getPhone().getHomePhone().setPhonePriority(hPhPriority);
					}
					if(customer.getCustAll().getPhone().getCellPhone()!=null && customer.getCustAll().getPhone().getCellPhone().getPhonePriority()==null)
					{
						customer.getCustAll().getPhone().getCellPhone().setPhonePriority(cPhPriority);
					}
					if(customer.getCustAll().getPhone().getWorkPhone()!=null && customer.getCustAll().getPhone().getWorkPhone().getPhonePriority()==null)
					{
						customer.getCustAll().getPhone().getWorkPhone().setPhonePriority(wPhPriority);
					}
				}
			}
			// Phone ALignment Changes: Set phone metadata end
	/**
	 * This method maps the memIdsWsValues to the Customer Name of customer
	 */
	private static CustomerMasterName mapCustomerName(
			ArrayOfXsdString memIdsWsValues) {
		CustomerMasterName customerName = new CustomerMasterName();
		customerName.setFirstName(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_NAME_FIRST));
		customerName.setMiddleName(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_NAME_MIDDLE));
		customerName.setLastName(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_NAME_LAST));
		customerName.setPrefixName((memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTNAME_ONMPREFIX)));
		customerName.setSuffixName(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTNAME_ONMSUFFIX));

		return customerName;
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Gender of customer
	 */
	private static CustomerMasterGender mapCustomerGender(
			ArrayOfXsdString memIdsWsValues) {
		CustomerMasterGender customerGender = new CustomerMasterGender();
		customerGender.setGenderCode(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_GENDER_IND));
		return customerGender;
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Last Update Date of
	 * customer
	 */
	private static String mapCustomerLastUpdateDate(
			ArrayOfXsdString memIdsWsValues) {
		return memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_LAST_UPDATE_DATE);
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Pet Indicator of
	 * customer
	 */
	private static CustomerMasterPetInd mapCustomerPetInd(
			ArrayOfXsdString memIdsWsValues) {
		CustomerMasterPetInd customerPetInd = new CustomerMasterPetInd();
		customerPetInd.setPetIndicator(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_PET_IND));

		return customerPetInd;
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Deceased Indicator of
	 * customer
	 */
	private static CustomerMasterDeceasedInd mapCustomerDeathInd(
			ArrayOfXsdString memIdsWsValues) {
		CustomerMasterDeceasedInd customerDeathInd = new CustomerMasterDeceasedInd();
		customerDeathInd.setDeceasedIndicator(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_DEATH_IND));

		return customerDeathInd;
	}

	/**
	 * This method maps the memIdsWsValues to the Customer SEC Code of customer
	 */
	private static String mapCustomerSECCode(ArrayOfXsdString memIdsWsValues) {
		return memIdsWsValues.getItem().get(CustomerMasterConstants.CM_SEC_CODE);
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Email of customer
	 */
	private static CustomerMasterEmail mapCustomerEmail(
			ArrayOfXsdString memIdsWsValues) {
		CustomerMasterEmail customerEmail = new CustomerMasterEmail();
		customerEmail.setEmailAddress(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_EMAIL_ADDRESS));

		return customerEmail;
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Locked Indicator Date
	 * of customer
	 */
	private static CustomerMasterLockedInd mapCustomerLockedInd(
			ArrayOfXsdString memIdsWsValues) {
		CustomerMasterLockedInd customerLockedInd = new CustomerMasterLockedInd();
		customerLockedInd.setLockedIndicator(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_LOCKED_IND));

		return customerLockedInd;
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Birth Date of
	 * customer
	 */
	private static CustomerMasterBirthDate mapCustomerBirthDate(
			ArrayOfXsdString memIdsWsValues) {
		CustomerMasterBirthDate customerBirthDate = new CustomerMasterBirthDate();
		customerBirthDate.setBirthdate(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_BIRTH_DATE));

		return customerBirthDate;
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Origin of customer
	 */
	private static CustomerMasterOrigin mapCustomerOrigin(
			ArrayOfXsdString memIdsWsValues) {
		CustomerMasterOrigin customerOrigin = new CustomerMasterOrigin();
		customerOrigin.setOriginCode(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_ORIGIN_CODE));
		customerOrigin.setStoreIndicator(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_ORIGIN_STORE_IND));
		return customerOrigin;
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Addresses of customer
	 * For Home2 and Work Address Mapping
	 */
	private static CustomerMasterAddressAttr mapCustomerAddress(
			ArrayOfXsdString memIdsWsValues, String addressType) {

		CustomerMasterAddressAttr custAddress = null;
		custAddress = new CustomerMasterAddressAttr(addressType);

		custAddress
				.setStreetLine1(memIdsWsValues
						.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTSTLINE1));
		custAddress
				.setStreetLine2(memIdsWsValues
						.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTSTLINE2));
		custAddress.setCity(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTCITY));
		custAddress.setState(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTSTATE));
		custAddress
				.setZipCode(memIdsWsValues
						.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTZIPCODE));
		custAddress
				.setCountry(memIdsWsValues
						.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTCOUNTRY));
		custAddress.setUSPSAddressType(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR2_ADDRTYPE));
		custAddress.setDPVFootnote(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_DPVFTNOTE));
		custAddress.setDPVIndicator(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_DPVIND));
		custAddress.setCASSFootnote(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_FTNOTE));
		custAddress.setLatitude(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LATITUDE));
		custAddress.setLongitude(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LONGITUDE));
		custAddress.setStandardizationProcessDate(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_PRDATE));
		custAddress.setUrbanizationCode(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_URBCODE));
		custAddress
				.setLACSAddressFlag(memIdsWsValues
						.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LACSADDRFLAG));
		custAddress.setLACSFootnote(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LACSFTNOTE));
		custAddress
				.setLACSReturnCode(memIdsWsValues
						.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LACSRTRNCODE));

		return custAddress;
	}

	// For Permanent Address Mapping
	private static CustomerMasterAddressAttrNCOA mapCustomerAddressNOCA(
			ArrayOfXsdString memIdsWsValues, String addressType) {

	
		CustomerMasterAddressAttrNCOA custAddress = null;

		if (addressType.equals(CustomerMasterConstants.CM_ADDRESS_TYPE_P)) {
			custAddress = new CustomerMasterAddressAttrNCOA(addressType);
			// Mapping NCOA

			custAddress
					.setNCOAActionCode(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOAACTCODE));
			custAddress
					.setNCOAANKCode(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOAANKCODE));
			custAddress
					.setNCOAMoveDate(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOAMVDATE));
			custAddress
					.setNCOAMoveType(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOAMVTYPE));
			custAddress
					.setNCOANewAddressFlag(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOANEWADDRFLG));
			custAddress
					.setNCOANIXIEFootnote(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOANIXFTNOTE));
			custAddress
					.setNCOAProcessDate(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOAPRDATE));
			custAddress
					.setNCOAReturnCode(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOARTRNCODE));

		}
		// overlay 7 fields using NCOA
		if (!isNull(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOAZIPCODE))) {

			custAddress
					.setStreetLine1(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOASTLINE1));
			custAddress
					.setStreetLine2(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOASTLINE2));
			custAddress
					.setCity(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOACITY));
			custAddress
					.setState(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOASTATE));
			custAddress
					.setZipCode(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOAZIPCODE));
			custAddress
					.setUSPSAddressType(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOAADDRTYPE));
			custAddress
					.setUrbanizationCode(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_NCOAURBCODE));

		} else {
			custAddress
					.setStreetLine1(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTSTLINE1));
			custAddress
					.setStreetLine2(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTSTLINE2));
			custAddress
					.setCity(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTCITY));
			custAddress
					.setState(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTSTATE));
			custAddress
					.setZipCode(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTZIPCODE));
			custAddress
					.setUSPSAddressType(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR2_ADDRTYPE));
			custAddress
					.setUrbanizationCode(memIdsWsValues
							.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_URBCODE));
		}
		custAddress
				.setCountry(memIdsWsValues
						.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_CUSTCOUNTRY));
		custAddress.setDPVFootnote(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_DPVFTNOTE));
		custAddress.setDPVIndicator(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_DPVIND));
		custAddress.setCASSFootnote(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_FTNOTE));
		custAddress.setLatitude(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LATITUDE));
		custAddress.setLongitude(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LONGITUDE));
		custAddress.setStandardizationProcessDate(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_PRDATE));
		custAddress
				.setLACSAddressFlag(memIdsWsValues
						.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LACSADDRFLAG));
		custAddress.setLACSFootnote(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LACSFTNOTE));
		custAddress
				.setLACSReturnCode(memIdsWsValues
						.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTADDR_LACSRTRNCODE));

		return custAddress;
	}

	private static CustomerMasterLinkageDetail mapCustomerLinkage(Member member) {
		CustomerMasterLinkageDetail customerMasterLinkageDetail = new CustomerMasterLinkageDetail();
		customerMasterLinkageDetail.setSourceCode(member.getMemHead()
				.getSrcCode());
		customerMasterLinkageDetail.setSourceID(member.getMemHead()
				.getMemIdnum());
		customerMasterLinkageDetail.setStatus(member.getMemHead().getMemStat());
		return customerMasterLinkageDetail;
	}

	private static CustomerMasterLinkageDetail mapRefCustomerLinkage(
			MemRow member) {
		CustomerMasterLinkageDetail customerMasterLinkageDetail = new CustomerMasterLinkageDetail();
		customerMasterLinkageDetail.setSourceCode(member.getMemHead()
				.getSrcCode());
		customerMasterLinkageDetail.setSourceID(member.getMemHead()
				.getMemIdnum());
		customerMasterLinkageDetail.setStatus(member.getMemHead().getMemStat());
		return customerMasterLinkageDetail;
	}

	private static CustomerMasterLinkageDetail mapCustomerTrustID(
			ArrayOfXsdString memIdsWsValues) {
		CustomerMasterLinkageDetail customerMasterLinkageDetail = new CustomerMasterLinkageDetail();
		customerMasterLinkageDetail.setRefCode(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTATTR3_FIELD1));
		customerMasterLinkageDetail.setRefID(memIdsWsValues
				.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTATTR3_FIELD2));

		return customerMasterLinkageDetail;
	}

	/**
	 * This method maps the memIdsWsValues to the Customer Phones of customer
	 */
	private static CustomerMasterPhoneAttr mapCustomerPhone(
			ArrayOfXsdString memIdsWsValues, String phoneType) {
		CustomerMasterPhoneAttr customerPhoneAttr = new CustomerMasterPhoneAttr(
				phoneType);
		customerPhoneAttr.setAreaCode(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_PHONE_AREA_CODE));
		customerPhoneAttr.setPhoneNumber(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_PHONE_NUMBER));

		return customerPhoneAttr;
	}

	private static void setSecurityCode(String tempSecCode,
			CustomerMaster customer) {
		String secCode_I = CustomerMasterConstants.SECURITY_CLASS_CODE_I;
		String secCode_H = CustomerMasterConstants.SECURITY_CLASS_CODE_H;
		String secCode_P = CustomerMasterConstants.SECURITY_CLASS_CODE_P;
		String secCode = "";
		// System.out.println("\nsecCode1="+secCode);

		if (customer.getGender() != null)
			customer.getGender().setSecurityClassCode(secCode_I);

		if (customer.getLockedInd() != null)
			customer.getLockedInd().setSecurityClassCode(secCode_I);

		if (customer.getPetInd() != null)
			customer.getPetInd().setSecurityClassCode(secCode_I);

		if (customer.getDeceasedInd() != null)
			customer.getDeceasedInd().setSecurityClassCode(secCode_I);

		if (customer.getOrigin() != null) {
			if (!isNull(tempSecCode)
					&& customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC))
				customer.getOrigin().setSecurityClassCode(tempSecCode);
			else if (customer.getOrigin().getSourceCode().equalsIgnoreCase(
					CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_SF)
					|| customer.getOrigin().getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
			} else if (customer.getOrigin().getSourceCode().equalsIgnoreCase(
					CustomerMasterConstants.SRC_CODE_PC)
					){
				secCode = secCode_P;
			} else if (customer.getOrigin().getSourceCode().equalsIgnoreCase(
					CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getOrigin().getSecurityClassCode()))
				customer.getOrigin().setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getName() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getName().setSecurityClassCode(
						tempSecCode);
			else if (customer.getCustAll().getName().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SF)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_RI)								) {
				secCode = secCode_H;
			} else if (customer.getCustAll().getName().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_PC)) 
			{
				secCode = secCode_P;
			} else if (customer.getCustAll().getName().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getName().getSecurityClassCode()))
				customer.getCustAll().getName().setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getEmail() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getEmail().setSecurityClassCode(
						tempSecCode);
			else if (customer.getCustAll().getEmail().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SF)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
			} else if (customer.getCustAll().getEmail().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_PC)
					) {
				secCode = secCode_P;
			} else if (customer.getCustAll().getEmail().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getEmail().getSecurityClassCode()))
				customer.getCustAll().getEmail().setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getBirthDate() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC)) {
				customer.getCustAll().getBirthDate().setSecurityClassCode(
						tempSecCode);
			} else if (customer.getCustAll().getBirthDate().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getBirthDate().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getBirthDate().getSourceCode()
											.equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
			} else if (customer.getCustAll().getBirthDate().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_PC)
					) {
				secCode = secCode_P;
			} else if (customer.getCustAll().getBirthDate().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}

			if (isNull(customer.getCustAll().getBirthDate()
					.getSecurityClassCode()))
				customer.getCustAll().getBirthDate().setSecurityClassCode(
						secCode);
		}

		if (customer.getCustAll().getAddress().getPermAddress() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getAddress().getPermAddress()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getAddress().getPermAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getAddress().getPermAddress()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getAddress().getPermAddress()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
			} else if (customer.getCustAll().getAddress().getPermAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					) {
				secCode = secCode_P;
			} else if (customer.getCustAll().getAddress().getPermAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getAddress().getPermAddress()
					.getSecurityClassCode()))
				customer.getCustAll().getAddress().getPermAddress()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getAddress().getHome2Address() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getAddress().getHome2Address()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getAddress().getHome2Address()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getAddress().getHome2Address()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getAddress().getHome2Address()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
			} else if (customer.getCustAll().getAddress().getHome2Address()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					) {
				secCode = secCode_P;
			} else if (customer.getCustAll().getAddress().getHome2Address()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getAddress().getHome2Address()
					.getSecurityClassCode()))
				customer.getCustAll().getAddress().getHome2Address()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getAddress().getWorkAddress() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getAddress().getWorkAddress()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getAddress().getWorkAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getAddress().getWorkAddress()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getAddress().getWorkAddress()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
			} else if (customer.getCustAll().getAddress().getWorkAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
				) {
				secCode = secCode_P;
			} else if (customer.getCustAll().getAddress().getWorkAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getAddress().getWorkAddress()
					.getSecurityClassCode()))
				customer.getCustAll().getAddress().getWorkAddress()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getPhone().getHomePhone() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getPhone().getHomePhone()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getPhone().getHomePhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getPhone().getHomePhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getPhone().getHomePhone()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
			} else if (customer.getCustAll().getPhone().getHomePhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					) {
				secCode = secCode_P;
			} else if (customer.getCustAll().getPhone().getHomePhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getPhone().getHomePhone()
					.getSecurityClassCode()))
				customer.getCustAll().getPhone().getHomePhone()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getPhone().getCellPhone() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getPhone().getCellPhone()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getPhone().getCellPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getPhone().getCellPhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getPhone().getCellPhone()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
			} else if (customer.getCustAll().getPhone().getCellPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					) {
				secCode = secCode_P;
			} else if (customer.getCustAll().getPhone().getCellPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getPhone().getCellPhone()
					.getSecurityClassCode()))
				customer.getCustAll().getPhone().getCellPhone()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getPhone().getWorkPhone() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getPhone().getWorkPhone()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getPhone().getWorkPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getPhone().getWorkPhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getPhone().getWorkPhone()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
			} else if (customer.getCustAll().getPhone().getWorkPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					) {
				secCode = secCode_P;
			} else if (customer.getCustAll().getPhone().getWorkPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getPhone().getWorkPhone()
					.getSecurityClassCode()))
				customer.getCustAll().getPhone().getWorkPhone()
						.setSecurityClassCode(secCode);
		}

	}

	private static String cvrtLstUpdDate(String lastUpdateDate) {
		String convertedDate;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
			Date systemDate = sdf.parse(lastUpdateDate);
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			// sdf2.setTimeZone(TimeZone.getTimeZone("GMT"));
			convertedDate = sdf2.format(systemDate);
		} catch (ParseException e) {
			convertedDate = "";
			e.printStackTrace();
		}

		return convertedDate;
	}

	public static CustomerMasterEntLookUpResponse[] mapToEntCustomer(
			Member[] memberRes, String cvwName, int maxRowReturn,
			String showLinkage) {

		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToEntCustomer () :Start Mapping from member result to customer objects");
		CustomerMasterEntLookUpResponse[] customerMasterResponse = null;
		CustomerMasterHubLinkageRecInternal[] customerMasterlinkage = null;
		int custCountIndex = 0;
		int custLinkIndex = 0;
		boolean isNew = false;

		if (memberRes != null || memberRes.length == 0) {

			customerMasterResponse = new CustomerMasterEntLookUpResponse[memberRes.length];
			customerMasterlinkage = new CustomerMasterHubLinkageRecInternal[memberRes.length];
			for (int i = 0; i < memberRes.length; i++) {

				logger.log(Level.DEBUG,
						"CustomerMaster ::  mapToCustomer ()::\n" + "member="
								+ i + ":: "
								+ memberRes[i].getMemHead().getEntRecno() + "|"
								+ memberRes[i].getMemHead().getMemRecno() + "|"
								+ memberRes[i].getMemHead().getSrcCode() + "|"
								+ memberRes[i].getMemHead().getSrcRecno() + "|"
								+ memberRes[i].getMemHead().getMemIdnum() + "|"
								+ memberRes[i].getMemHead().getMemStat() + "|"
								+ memberRes[i].getMemHead().getMatchScore());

				String currCustEid = Long.toString(memberRes[i].getMemHead()
						.getEntRecno());
				
				Short currMatchScore = memberRes[i].getMemHead().getMatchScore();

				CustomerMasterEntSearch customer = null;

				if (i == 0) {
					custCountIndex = i;
					custLinkIndex = custCountIndex;
					isNew = true;
					customerMasterResponse[custCountIndex] = new CustomerMasterEntLookUpResponse();
					customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();
					logger.log(Level.DEBUG, "New 0" + "custCountIndex="
							+ custCountIndex);
				} else {

					for (int j = 0; j < custCountIndex + 1; j++) {
						if (currCustEid
								.equalsIgnoreCase(customerMasterResponse[j]
										.getEntCustomer().getEID())) {
							custLinkIndex = j;
							customer = customerMasterResponse[j]
									.getEntCustomer();
							customerMasterlinkage[j].getLinkageDetail().add(
									mapCustomerLinkage(memberRes[i]));

							if (currMatchScore > Short.valueOf(customer
									.getMatchScore())) {
								customer.setMatchScore(Short
										.toString(currMatchScore));
							}
							isNew = false;

							logger.log(Level.DEBUG, "old " + "custCountIndex="
									+ custCountIndex + "j=" + j + ", i=" + i);
							break;
						} else
							isNew = true;
					}

					if (isNew) {

						custCountIndex = custCountIndex + 1;
						custLinkIndex = custCountIndex;
						customerMasterResponse[custCountIndex] = new CustomerMasterEntLookUpResponse();
						customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();

						logger.log(Level.DEBUG, "new " + "custCountIndex="
								+ custCountIndex + "i=" + i);
					}
				}
				if (isNew) {
					customer = new CustomerMasterEntSearch();
					customer.setEID(currCustEid);
					customer.setMatchScore(Short.toString(currMatchScore));
					customerMasterlinkage[custCountIndex].setEid(currCustEid);
					ArrayList<CustomerMasterLinkageDetail> linkageDetail = new ArrayList<CustomerMasterLinkageDetail>();
					linkageDetail.add(mapCustomerLinkage(memberRes[i]));
					customerMasterlinkage[custCountIndex]
							.setLinkageDetail(linkageDetail);

				}

				// System.out.println("*****customerMasterlinkage
				// content******\n" + "i," + i +", "+
				// customerMasterlinkage[custLinkIndex].getLinkageDetail());

				String secCode = "";
				ArrayOfMemIdsWs arraymemIdsWs = memberRes[i].getMemIds();
				MemIdsWs[] memIdsWs = null;

				if (arraymemIdsWs != null) {
					
					  List<MemIdsWs> memberList = arraymemIdsWs.getItem();
					  memIdsWs=memberList.toArray(new MemIdsWs[memberList.size()]);
					
					

					for (int j = 0; memIdsWs != null && j < arraymemIdsWs.getItem().size(); j++) {
						ArrayOfXsdString memIdsWsValues = memIdsWs[j]
								.getValues();
						//System.out.println((j + 1) + ". \tAttribute Code :: test2" + memIdsWs[j].getAttrCode());
						// mapCustomerPrintRecords(memIdsWsValues);

						if (CustomerMasterConstants.ATTR_CODE_NAME
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerName(memIdsWsValues).isNull())) {
								customer.getCustAll().setName(
										mapCustomerName(memIdsWsValues));
								customer.getCustAll().getName()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getName().setSourceCode(
										memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_GENDER
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerGender(memIdsWsValues).isNull())) {
								customer
										.setGender(mapCustomerGender(memIdsWsValues));
								customer.getGender().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getGender().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_PET_IND
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPetInd(memIdsWsValues).isNull())) {
								customer
										.setPetInd(mapCustomerPetInd(memIdsWsValues));
								customer.getPetInd().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getPetInd().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_DEATH_IND
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerDeathInd(memIdsWsValues).isNull())) {
								customer
										.setDeceasedInd(mapCustomerDeathInd(memIdsWsValues));
								customer.getDeceasedInd().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getDeceasedInd().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_EMAIL
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerEmail(memIdsWsValues).isNull())) {
								customer.getCustAll().setEmail(
										mapCustomerEmail(memIdsWsValues));
								customer.getCustAll().getEmail()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getEmail().setSourceCode(
										memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_LOCK_IND
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerLockedInd(memIdsWsValues).isNull())) {
								customer
										.setLockedInd(mapCustomerLockedInd(memIdsWsValues));
								customer.getLockedInd().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getLockedInd().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_BIRTH_DT
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {

							if (!(mapCustomerBirthDate(memIdsWsValues).isNull())) {
								customer.getCustAll().setBirthDate(
										mapCustomerBirthDate(memIdsWsValues));
								customer.getCustAll().getBirthDate()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getBirthDate()
										.setSourceCode(memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerAddressNOCA(memIdsWsValues,
									CustomerMasterConstants.CM_ADDRESS_TYPE_P)
									.isNull())) {

								customer
										.getCustAll()
										.getAddress()
										.setPermAddress(
												mapCustomerAddressNOCA(
														memIdsWsValues,
														CustomerMasterConstants.CM_ADDRESS_TYPE_P));
								customer.getCustAll().getAddress()
										.getPermAddress().setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getAddress()
										.getPermAddress().setSourceCode(
												memIdsWs[j].getSrcCode());
							}
						} else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS_2
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerAddress(memIdsWsValues,
									CustomerMasterConstants.CM_ADDRESS_TYPE_2)
									.isNull())) {
								customer
										.getCustAll()
										.getAddress()
										.setHome2Address(
												mapCustomerAddress(
														memIdsWsValues,
														CustomerMasterConstants.CM_ADDRESS_TYPE_2));
								customer.getCustAll().getAddress()
										.getHome2Address().setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getAddress()
										.getHome2Address().setSourceCode(
												memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_WK_ADDRESS
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerAddress(memIdsWsValues,
									CustomerMasterConstants.CM_ADDRESS_TYPE_W)
									.isNull())) {
								customer
										.getCustAll()
										.getAddress()
										.setWorkAddress(
												mapCustomerAddress(
														memIdsWsValues,
														CustomerMasterConstants.CM_ADDRESS_TYPE_W));
								customer.getCustAll().getAddress()
										.getWorkAddress().setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getAddress()
										.getWorkAddress().setSourceCode(
												memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_PR_PHONE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPhone(memIdsWsValues,
									CustomerMasterConstants.CM_PHONE_TYPE_H)
									.isNull())) {
								customer
										.getCustAll()
										.getPhone()
										.setHomePhone(
												mapCustomerPhone(
														memIdsWsValues,
														CustomerMasterConstants.CM_PHONE_TYPE_H));
								customer.getCustAll().getPhone().getHomePhone()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getPhone()
										.getHomePhone()
										.setSourceCode(memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_CELL_PHONE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPhone(memIdsWsValues,
									CustomerMasterConstants.CM_PHONE_TYPE_C)
									.isNull())) {
								customer
										.getCustAll()
										.getPhone()
										.setCellPhone(
												mapCustomerPhone(
														memIdsWsValues,
														CustomerMasterConstants.CM_PHONE_TYPE_C));
								customer.getCustAll().getPhone().getCellPhone()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getPhone()
										.getCellPhone()
										.setSourceCode(memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_WK_PHONE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPhone(memIdsWsValues,
									CustomerMasterConstants.CM_PHONE_TYPE_W)
									.isNull())) {
								customer
										.getCustAll()
										.getPhone()
										.setWorkPhone(
												mapCustomerPhone(
														memIdsWsValues,
														CustomerMasterConstants.CM_PHONE_TYPE_W));
								customer.getCustAll().getPhone().getWorkPhone()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getPhone()
										.getWorkPhone()
										.setSourceCode(memIdsWs[j].getSrcCode());

							}

						}

						else if (CustomerMasterConstants.ATTR_CODE_TRUST_ID
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							CustomerMasterLinkageDetail linkDetail = mapCustomerTrustID(memIdsWsValues);
							ArrayList<CustomerMasterLinkageDetail> myRefLink = customerMasterlinkage[custLinkIndex]
									.getLinkageDetail();
							CustomerMasterLinkageDetail temp = (CustomerMasterLinkageDetail) myRefLink
									.get(myRefLink.size() - 1);
							temp.setRefCode(linkDetail.getRefCode());
							temp.setRefID(linkDetail.getRefID());
							myRefLink.set(myRefLink.size() - 1, temp);

						}

					}
				}
				if (customer != null) {
					setEntSearchSecurityCode(secCode, customer);
					if (!isNull(cvwName)
							&& cvwName
									.equalsIgnoreCase(CustomerMasterConstants.CVW_NAME_LIMITED)) {
						customer.getCustLim().setLimited(true);
						customer.getCustLim().setAddress(
								customer.getCustAll().getAddress());
						customer.getCustLim().setBirthDate(
								customer.getCustAll().getBirthDate());
						customer.getCustLim().setEmail(
								customer.getCustAll().getEmail());
						customer.getCustLim().setName(
								customer.getCustAll().getName());
						customer.getCustLim().setPhone(
								customer.getCustAll().getPhone());
						customer.getCustAll().setLimited(true);

					}

				}
				customer.setSrcCode(memberRes[i].getMemHead().getSrcCode());
				customer.setMemberId(memberRes[i].getMemHead().getMemIdnum());
				customer
						.setMemberStatus(memberRes[i].getMemHead().getMemStat());

				customerMasterResponse[custLinkIndex].setEntCustomer(customer);

			}
		}

		CustomerMasterEntLookUpResponse[] customerMasterResponseFinal = null;
		if (customerMasterResponse.length > 0) {
			if (maxRowReturn == 0)// not specifying the max returns, then
									// return all
			{
				customerMasterResponseFinal = new CustomerMasterEntLookUpResponse[custCountIndex + 1];
			} else if (maxRowReturn >= custCountIndex + 1) {
				customerMasterResponseFinal = new CustomerMasterEntLookUpResponse[custCountIndex + 1];
			} else if (maxRowReturn < custCountIndex + 1) {
				customerMasterResponseFinal = new CustomerMasterEntLookUpResponse[maxRowReturn];
			}
			if (showLinkage
					.equalsIgnoreCase(CustomerMasterConstants.VALUE_TRUE)) {
				for (int k = 0; k < customerMasterResponseFinal.length; k++) {
					customerMasterResponseFinal[k] = customerMasterResponse[k];
					CustomerMasterHubLinkageRec customerLinkageRecFinal = new CustomerMasterHubLinkageRec();
					customerLinkageRecFinal.setEid(customerMasterlinkage[k]
							.getEid());
					CustomerMasterLinkageDetail[] customerLinkageDetail = new CustomerMasterLinkageDetail[customerMasterlinkage[k]
							.getLinkageDetail().size()];
					for (int j = 0; j < customerMasterlinkage[k]
							.getLinkageDetail().size(); j++) {
						customerLinkageDetail[j] = customerMasterlinkage[k]
								.getLinkageDetail().get(j);

					}
					customerLinkageRecFinal
							.setLinkageDetail(customerLinkageDetail);
					customerMasterResponseFinal[k].getEntCustomer()
							.setHubLinkageRec(customerLinkageRecFinal);

				}
			} else {
				for (int k = 0; k < customerMasterResponseFinal.length; k++) {
					customerMasterResponseFinal[k] = customerMasterResponse[k];
				}
			}
		}
		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToEntCustomer () :End of  Mapping from member result to customer objects");

		return customerMasterResponseFinal;

	}

	private static void setEntSearchSecurityCode(String tempSecCode,
			CustomerMasterEntSearch customer) {

		String secCode_I = CustomerMasterConstants.SECURITY_CLASS_CODE_I;
		String secCode_H = CustomerMasterConstants.SECURITY_CLASS_CODE_H;
		String secCode_P = CustomerMasterConstants.SECURITY_CLASS_CODE_P;
		String secCode = "";

		if (customer.getGender() != null)
			customer.getGender().setSecurityClassCode(secCode_I);

		if (customer.getLockedInd() != null)
			customer.getLockedInd().setSecurityClassCode(secCode_I);

		if (customer.getPetInd() != null)
			customer.getPetInd().setSecurityClassCode(secCode_I);

		if (customer.getDeceasedInd() != null)
			customer.getDeceasedInd().setSecurityClassCode(secCode_I);

		if (customer.getCustAll().getName() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getName().setSecurityClassCode(
						tempSecCode);
			else if (customer.getCustAll().getName().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
				|| customer.getCustAll().getName().getSourceCode()
				.equalsIgnoreCase(
						CustomerMasterConstants.SRC_CODE_SF)
						|| customer.getCustAll().getName().getSourceCode()
						.equalsIgnoreCase(
								CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code modification start for Guest checkout
			} else if (customer.getCustAll().getName().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getName().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				//code modification end for Guest checkout
			} else if (customer.getCustAll().getName().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getName().getSecurityClassCode()))
				customer.getCustAll().getName().setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getEmail() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getEmail().setSecurityClassCode(
						tempSecCode);
			else if (customer.getCustAll().getEmail().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getEmail().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getEmail().getSourceCode()
											.equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getEmail().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getEmail().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getEmail().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getEmail().getSecurityClassCode()))
				customer.getCustAll().getEmail().setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getBirthDate() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC)) {
				customer.getCustAll().getBirthDate().setSecurityClassCode(
						tempSecCode);
			} else if (customer.getCustAll().getBirthDate().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getBirthDate().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getBirthDate().getSourceCode()
											.equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				//code change start for GC
			} else if (customer.getCustAll().getBirthDate().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_PC)
					
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getBirthDate().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getBirthDate().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}

			// customer.getCustAll().getBirthDate().setSecurityClassCode(secCode);
			if (isNull(customer.getCustAll().getBirthDate()
					.getSecurityClassCode()))
				customer.getCustAll().getBirthDate().setSecurityClassCode(
						secCode);
		}

		if (customer.getCustAll().getAddress().getPermAddress() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getAddress().getPermAddress()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getAddress().getPermAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getAddress().getPermAddress()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getAddress().getPermAddress()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getAddress().getPermAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getAddress().getPermAddress().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getAddress().getPermAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getAddress().getPermAddress()
					.getSecurityClassCode()))
				customer.getCustAll().getAddress().getPermAddress()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getAddress().getHome2Address() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getAddress().getHome2Address()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getAddress().getHome2Address()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getAddress().getHome2Address()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getAddress().getHome2Address()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getAddress().getHome2Address()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getAddress().getHome2Address().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				// code change end for GC
			} else if (customer.getCustAll().getAddress().getHome2Address()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getAddress().getHome2Address()
					.getSecurityClassCode()))
				customer.getCustAll().getAddress().getHome2Address()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getAddress().getWorkAddress() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getAddress().getWorkAddress()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getAddress().getWorkAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getAddress().getWorkAddress()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getAddress().getWorkAddress()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				//code change start for GC
			} else if (customer.getCustAll().getAddress().getWorkAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getAddress().getWorkAddress().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getAddress().getWorkAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getAddress().getWorkAddress()
					.getSecurityClassCode()))
				customer.getCustAll().getAddress().getWorkAddress()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getPhone().getHomePhone() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getPhone().getHomePhone()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getPhone().getHomePhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getPhone().getHomePhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getPhone().getHomePhone()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getPhone().getHomePhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getPhone().getHomePhone().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getPhone().getHomePhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getPhone().getHomePhone()
					.getSecurityClassCode()))
				customer.getCustAll().getPhone().getHomePhone()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getPhone().getCellPhone() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getPhone().getCellPhone()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getPhone().getCellPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getPhone().getCellPhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getPhone().getCellPhone()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getPhone().getCellPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getPhone().getCellPhone().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				//code change end for GC
				
			} else if (customer.getCustAll().getPhone().getCellPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getPhone().getCellPhone()
					.getSecurityClassCode()))
				customer.getCustAll().getPhone().getCellPhone()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getPhone().getWorkPhone() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getPhone().getWorkPhone()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getPhone().getWorkPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getPhone().getWorkPhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getPhone().getWorkPhone()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getPhone().getWorkPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getPhone().getWorkPhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getPhone().getWorkPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getPhone().getWorkPhone()
					.getSecurityClassCode()))
				customer.getCustAll().getPhone().getWorkPhone()
						.setSecurityClassCode(secCode);
		}

	}

	public static CustomerMasterEntLookUpResponse[] mapToLoyaltyCustomer(
			Member[] memberRes, String cvwName) {
	//	System.out.println ("Inside mapToLoyaltyCustomer");

		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToLoyaltyCustomer () :Start Mapping from member result to customer objects");
		CustomerMasterEntLookUpResponse[] customerMasterResponse = null;
		int custCountIndex = 0;

		if (memberRes != null || memberRes.length == 0) {

			customerMasterResponse = new CustomerMasterEntLookUpResponse[memberRes.length];

			for (int i = 0; i < memberRes.length; i++) {

				logger.log(Level.DEBUG,
						"CustomerMaster ::  mapToCustomer ()::\n" + "member="
								+ i + ":: "
								+ memberRes[i].getMemHead().getEntRecno() + "|"
								+ memberRes[i].getMemHead().getMemRecno() + "|"
								+ memberRes[i].getMemHead().getSrcCode() + "|"
								+ memberRes[i].getMemHead().getSrcRecno() + "|"
								+ memberRes[i].getMemHead().getMemIdnum() + "|"
								+ memberRes[i].getMemHead().getMemStat() + "|"
								+ memberRes[i].getMemHead().getMatchScore());
				
				String currCustEid = Long.toString(memberRes[i].getMemHead()
						.getEntRecno());
				
				Short currMatchScore = memberRes[i].getMemHead().getMatchScore();				

				customerMasterResponse[custCountIndex] = new CustomerMasterEntLookUpResponse();
				CustomerMasterEntSearch customer = new CustomerMasterEntSearch();
				customer.setSrcCode(memberRes[i].getMemHead().getSrcCode());
				customer.setMemberId(memberRes[i].getMemHead().getMemIdnum());
				customer.setEID(currCustEid);
				customer.setMatchScore(Short.toString(currMatchScore));
				customer
						.setMemberStatus(memberRes[i].getMemHead().getMemStat());
				String secCode = "";
				ArrayOfMemIdsWs arraymemIdsWs = memberRes[i].getMemIds();
				MemIdsWs[] memIdsWs = null;

				if (arraymemIdsWs != null) {
					  List<MemIdsWs> memberList = arraymemIdsWs.getItem();
					  memIdsWs=memberList.toArray(new MemIdsWs[memberList.size()]);

					for (int j = 0; memIdsWs != null && j < memIdsWs.length; j++) {
						ArrayOfXsdString memIdsWsValues = memIdsWs[j]
								.getValues();
						//System.out.println((j + 1) + ". \tAttribute Code ::"	+ memIdsWs[j].getAttrCode());
						//mapCustomerPrintRecords(memIdsWsValues);

						if (CustomerMasterConstants.ATTR_CODE_NAME
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerName(memIdsWsValues).isNull())) {
								customer.getCustAll().setName(
										mapCustomerName(memIdsWsValues));
								customer.getCustAll().getName()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getName().setSourceCode(
										memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_GENDER
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerGender(memIdsWsValues).isNull())) {
								customer
										.setGender(mapCustomerGender(memIdsWsValues));
								customer.getGender().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getGender().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_PET_IND
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPetInd(memIdsWsValues).isNull())) {
								customer
										.setPetInd(mapCustomerPetInd(memIdsWsValues));
								customer.getPetInd().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getPetInd().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_DEATH_IND
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerDeathInd(memIdsWsValues).isNull())) {
								customer
										.setDeceasedInd(mapCustomerDeathInd(memIdsWsValues));
								customer.getDeceasedInd().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getDeceasedInd().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_EMAIL
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerEmail(memIdsWsValues).isNull())) {
								customer.getCustAll().setEmail(
										mapCustomerEmail(memIdsWsValues));
								customer.getCustAll().getEmail()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getEmail().setSourceCode(
										memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_LOCK_IND
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerLockedInd(memIdsWsValues).isNull())) {
								customer
										.setLockedInd(mapCustomerLockedInd(memIdsWsValues));
								customer.getLockedInd().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getLockedInd().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_BIRTH_DT
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {

							if (!(mapCustomerBirthDate(memIdsWsValues).isNull())) {
								customer.getCustAll().setBirthDate(
										mapCustomerBirthDate(memIdsWsValues));
								customer.getCustAll().getBirthDate()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getBirthDate()
										.setSourceCode(memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
						//	System.out.println("Inside PR Address Zip Code");
							if (!(mapCustomerAddressNOCA(memIdsWsValues,
									CustomerMasterConstants.CM_ADDRESS_TYPE_P)
									.isNullEnterpriseLookup())) {
							//	System.out.println("Inside PR Address Zip Code");

								customer
										.getCustAll()
										.getAddress()
										.setPermAddress(
												mapCustomerAddressNOCA(
														memIdsWsValues,
														CustomerMasterConstants.CM_ADDRESS_TYPE_P));
								customer.getCustAll().getAddress()
										.getPermAddress().setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getAddress()
										.getPermAddress().setSourceCode(
												memIdsWs[j].getSrcCode());
							}
						} else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS_2
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerAddress(memIdsWsValues,
									CustomerMasterConstants.CM_ADDRESS_TYPE_2)
									.isNullEnterpriseLookup())) {
								customer
										.getCustAll()
										.getAddress()
										.setHome2Address(
												mapCustomerAddress(
														memIdsWsValues,
														CustomerMasterConstants.CM_ADDRESS_TYPE_2));
								customer.getCustAll().getAddress()
										.getHome2Address().setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getAddress()
										.getHome2Address().setSourceCode(
												memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_WK_ADDRESS
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerAddress(memIdsWsValues,
									CustomerMasterConstants.CM_ADDRESS_TYPE_W)
									.isNullEnterpriseLookup())) {
								customer
										.getCustAll()
										.getAddress()
										.setWorkAddress(
												mapCustomerAddress(
														memIdsWsValues,
														CustomerMasterConstants.CM_ADDRESS_TYPE_W));
								customer.getCustAll().getAddress()
										.getWorkAddress().setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getAddress()
										.getWorkAddress().setSourceCode(
												memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_PR_PHONE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPhone(memIdsWsValues,
									CustomerMasterConstants.CM_PHONE_TYPE_H)
									.isNull())) {
								customer
										.getCustAll()
										.getPhone()
										.setHomePhone(
												mapCustomerPhone(
														memIdsWsValues,
														CustomerMasterConstants.CM_PHONE_TYPE_H));
								customer.getCustAll().getPhone().getHomePhone()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getPhone()
										.getHomePhone()
										.setSourceCode(memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_CELL_PHONE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPhone(memIdsWsValues,
									CustomerMasterConstants.CM_PHONE_TYPE_C)
									.isNull())) {
								customer
										.getCustAll()
										.getPhone()
										.setCellPhone(
												mapCustomerPhone(
														memIdsWsValues,
														CustomerMasterConstants.CM_PHONE_TYPE_C));
								customer.getCustAll().getPhone().getCellPhone()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getPhone()
										.getCellPhone()
										.setSourceCode(memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_WK_PHONE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPhone(memIdsWsValues,
									CustomerMasterConstants.CM_PHONE_TYPE_W)
									.isNull())) {
								customer
										.getCustAll()
										.getPhone()
										.setWorkPhone(
												mapCustomerPhone(
														memIdsWsValues,
														CustomerMasterConstants.CM_PHONE_TYPE_W));
								customer.getCustAll().getPhone().getWorkPhone()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getPhone()
										.getWorkPhone()
										.setSourceCode(memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_PROGRAM
								.contains(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPrograms(memIdsWsValues,
									memIdsWs[j]).isNull())) {
								customer.getProgramArray().add(
										mapCustomerPrograms(memIdsWsValues,
												memIdsWs[j]));
								CustomerMasterEntSearchProgramVO progVo = customer
										.getProgramArray().get(
												customer.getProgramArray()
														.size() - 1);
								if (progVo.getProgramStatus().equalsIgnoreCase(
										CustomerMasterConstants.STATUS_PENDING)) {
									customer
											.setMemberStatus(CustomerMasterConstants.STATUS_PENDING);
								}

							}
						} else if (CustomerMasterConstants.ATTR_CODE_CUSTGENATTR_CODE
								.contains(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerAttributes(memIdsWsValues)
									.isNull())) {
								customer.getAttributeArray().add(
										mapCustomerAttributes(memIdsWsValues));

							}
						}
					}
				}
				if (customer != null) {
					setEntSearchSecurityCode(secCode, customer);
					if (!isNull(cvwName)
							&& cvwName
									.equalsIgnoreCase(CustomerMasterConstants.CVW_NAME_LIMITED)) {
						customer.getCustLim().setLimited(true);
						customer.getCustLim().setAddress(
								customer.getCustAll().getAddress());
						customer.getCustLim().setBirthDate(
								customer.getCustAll().getBirthDate());
						customer.getCustLim().setEmail(
								customer.getCustAll().getEmail());
						customer.getCustLim().setName(
								customer.getCustAll().getName());
						customer.getCustLim().setPhone(
								customer.getCustAll().getPhone());
						customer.getCustAll().setLimited(true);

					}

				}
				customerMasterResponse[custCountIndex++]
						.setEntCustomer(customer);

			}
		}

		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToLoyaltyCustomer () :End of  Mapping from member result to customer objects");

return customerMasterResponse;

	}

	/**
	 * This method maps the memIdsWsValues to the program VO of customer
	 */
	private static CustomerMasterEntSearchProgramVO mapCustomerPrograms(
			ArrayOfXsdString memIdsWsValues, MemIdsWs memIdsWs) {
		CustomerMasterEntSearchProgramVO customerProg = new CustomerMasterEntSearchProgramVO();
		customerProg.setProgramCode(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_PROG_PROGRAMCODE));
		customerProg.setProgramId(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_PROG_PROGRAMIDENT));
		customerProg.setProgramStatus(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_PROG_PROGRAMSTATUS));
		customerProg.setProgStartDt((memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_PROG_PROGRAMSTARTDT)));
		customerProg.setProgEndDt(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_PROG_PROGRAMENDDT));		
		customerProg.setProgLstUpDt(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_PROG_PROGRAMLASTUPDATDT));
		return customerProg;
	}

	/**
	 * This method maps the memIdsWsValues to the ATTRIBUTE vo of customer
	 */
	private static CustomerMasterEntAttributesVO mapCustomerAttributes(
			ArrayOfXsdString memIdsWsValues) {

		CustomerMasterEntAttributesVO customerAttr = new CustomerMasterEntAttributesVO();

		customerAttr.setCdiKey(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_ATTR_KEY));
		customerAttr.setCdiValue(memIdsWsValues
				.getItem().get(CustomerMasterConstants.CM_ATTR_VALUE));

		return customerAttr;
	}

	public static CustomerMasterEntLookUpResponse[] mapRefHubCustomer(
			MemRowList memberRes, String cvwName, int maxRowReturn,
			String showLinkage) {

		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToEntCustomer () :Start Mapping from member result to customer objects");
		CustomerMasterEntLookUpResponse[] customerMasterResponse = null;
		CustomerMasterHubLinkageRecInternal[] customerMasterlinkage = null;
		int custCountIndex = 0;
		int custLinkIndex = 0;
		boolean isNew = false;
		String srcCode = null;
		String currCustEid = null;
		Short currMatchScore = 0;
		String memberID = null;
		String memStatus = null;

		Map memberMap = buildMemberList(memberRes);
		customerMasterResponse = new CustomerMasterEntLookUpResponse[memberMap
				.size()];
		customerMasterlinkage = new CustomerMasterHubLinkageRecInternal[memberMap
				.size()];
		try {

			Set newSet = memberMap.keySet();
			Iterator itr = newSet.iterator();
			int i = 0;
			while (itr.hasNext()) {
				long key = (Long) itr.next();

				MemRowList memberRowList = (MemRowList) memberMap.get(key);
				//int i = 0;
				if (memberRowList != null || memberRowList.size() == 0) {

					CustomerMasterEntSearch customer = null;
					RowIterator iter = memberRowList.rows();

					while (iter.hasMoreRows()) {
						MemRow memRow = (MemRow) iter.nextRow();
						SegDef inSegDef = memRow.getSegDef();
						if (memRow instanceof MemHead) {

							logger.log(Level.DEBUG,
									"CustomerMaster ::  mapToCustomer ()::\n"
											+ "member="
											+ i
											+ ":: "
											+ memRow.getMemHead().getEntRecno()
											+ "|"
											+ memRow.getMemHead().getMemRecno()
											+ "|"
											+ memRow.getMemHead().getSrcCode()
											+ "|"
											+ memRow.getMemHead().getSrcRecno()
											+ "|"
											+ memRow.getMemHead().getMemIdnum()
											+ "|"
											+ memRow.getMemHead().getMemStat()
											+ "|"
											+ memRow.getMemHead()
													.getMatchScore());

							currCustEid = Long.toString(memRow.getMemHead()
									.getEntRecno());
							
							currMatchScore = memRow.getMemHead().getMatchScore();
							srcCode = memRow.getMemHead().getSrcCode();
							memberID = memRow.getMemHead().getMemIdnum();
							memStatus = memRow.getMemHead().getMemStat();
							// }

							if (i == 0) {
								custCountIndex = i;
								custLinkIndex = custCountIndex;
								isNew = true;
								customerMasterResponse[custCountIndex] = new CustomerMasterEntLookUpResponse();
								customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();
								logger.log(Level.DEBUG, "New 0"
										+ "custCountIndex=" + custCountIndex);
							} else {

								for (int j = 0; j < custCountIndex + 1; j++) {
									if (currCustEid
											.equalsIgnoreCase(customerMasterResponse[j]
													.getEntCustomer().getEID())) {
										custLinkIndex = j;
										customer = customerMasterResponse[j]
												.getEntCustomer();
										customerMasterlinkage[j]
												.getLinkageDetail()
												.add(
														mapRefCustomerLinkage(memRow));

										if (currMatchScore > Short
												.valueOf(customer
														.getMatchScore())) {
											customer.setMatchScore(Short
													.toString(currMatchScore));
										}
										isNew = false;

										logger.log(Level.DEBUG, "old "
												+ "custCountIndex="
												+ custCountIndex + "j=" + j
												+ ", i=" + i);
										break;
									} else
										isNew = true;
								}

								if (isNew) {

									custCountIndex = custCountIndex + 1;
									custLinkIndex = custCountIndex;
									customerMasterResponse[custCountIndex] = new CustomerMasterEntLookUpResponse();
									customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();

									logger.log(Level.DEBUG, "new "
											+ "custCountIndex="
											+ custCountIndex + "i=" + i);
								}
							}
							if (isNew) {
								customer = new CustomerMasterEntSearch();
								customer.setEID(currCustEid);
								customer.setMatchScore(Short
										.toString(currMatchScore));
								customerMasterlinkage[custCountIndex]
										.setEid(currCustEid);
								ArrayList<CustomerMasterLinkageDetail> linkageDetail = new ArrayList<CustomerMasterLinkageDetail>();
								linkageDetail
										.add(mapRefCustomerLinkage(memRow));
								customerMasterlinkage[custCountIndex]
										.setLinkageDetail(linkageDetail);

							}
						}

						else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTNAME)) {
							CustomerMasterName customerName = new CustomerMasterName();
							customerName
									.setFirstName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMFIRST));
							customerName
									.setMiddleName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMMIDDLE));
							customerName
									.setLastName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMLAST));
							customerName
									.setPrefixName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMPREFIX));
							customerName
									.setSuffixName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMSUFFIX));
							customer.getCustAll().setName(customerName);
							// customer.getCustAll().getName().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
							customer.getCustAll().getName().setSourceCode(
									srcCode);

						} else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTADDR)) {
							CustomerMasterAddressAttrNCOA custAddress = null;

							custAddress = new CustomerMasterAddressAttrNCOA(
									CustomerMasterConstants.CM_ADDRESS_TYPE_P);
							// Mapping NCOA

							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_STREET_ADDRESS1)) {
								custAddress
										.setStreetLine1(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_STREET_ADDRESS1));
							}
							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_STREET_ADDRESS2)) {
								custAddress
										.setStreetLine2(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_STREET_ADDRESS2));
							}
							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_CITY)) {
								custAddress
										.setCity(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_CITY));
							}
							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_STATE)) {
								custAddress
										.setState(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_STATE));
							}
							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_ZIP)) {
								custAddress
										.setZipCode(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_ZIP));
							}

							customer.getCustAll().getAddress().setPermAddress(
									custAddress);
							//customer.getCustAll().getAddress().getPermAddress().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
							customer.getCustAll().getAddress().getPermAddress()
									.setSourceCode(srcCode);

						}

						else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTATTR1)) {
							if (memRow
									.getAsString(
											CustomerMasterConstants.ATTRCODE)
									.equalsIgnoreCase(
											CustomerMasterConstants.ATTR_CODE_GENDER)) {

								CustomerMasterGender customerGender = new CustomerMasterGender();
								customerGender
										.setGenderCode(memRow
												.getAsString(CustomerMasterConstants.ATTRVAL));
								customer.setGender(customerGender);
								// customer.getGender().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
								customer.getGender().setSourceCode(srcCode);
							} else if (memRow
									.getAsString(
											CustomerMasterConstants.ATTRCODE)
									.equalsIgnoreCase(
											CustomerMasterConstants.ATTR_CODE_PET_IND)) {

								CustomerMasterPetInd customerPetInd = new CustomerMasterPetInd();
								customerPetInd
										.setPetIndicator(memRow
												.getAsString(CustomerMasterConstants.ATTRVAL));
								customer.setPetInd(customerPetInd);
								// customer.getPetInd().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
								customer.getPetInd().setSourceCode(srcCode);
							} else if (memRow
									.getAsString(
											CustomerMasterConstants.ATTRCODE)
									.equalsIgnoreCase(
											CustomerMasterConstants.ATTR_CODE_EMAIL)) {

								CustomerMasterEmail customerEmail = new CustomerMasterEmail();
								customerEmail
										.setEmailAddress(memRow
												.getAsString(CustomerMasterConstants.ATTRVAL));
								customer.getCustAll().setEmail(customerEmail);
								//customer.getCustAll().getEmail().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
								customer.getCustAll().getEmail().setSourceCode(
										srcCode);
							} else if (memRow
									.getAsString(
											CustomerMasterConstants.ATTRCODE)
									.equalsIgnoreCase(
											CustomerMasterConstants.ATTR_CODE_REFDEATHIND)) {

								CustomerMasterDeceasedInd customerDeathInd = new CustomerMasterDeceasedInd();
								customerDeathInd
										.setDeceasedIndicator(memRow
												.getAsString(CustomerMasterConstants.ATTRVAL));
								customer.setDeceasedInd(customerDeathInd);
								//customer.getDeceasedInd().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
								customer.getDeceasedInd()
										.setSourceCode(srcCode);
							}
						}

						else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTDATE)) {

							CustomerMasterBirthDate customerBirthDate = new CustomerMasterBirthDate();
							customerBirthDate
									.setBirthdate(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_DATEVAL));
							customer.getCustAll().setBirthDate(
									customerBirthDate);
							//customer.getCustAll().getBirthDate().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
							customer.getCustAll().getBirthDate().setSourceCode(
									srcCode);

						} else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTPHONE)) {

							CustomerMasterPhoneAttr customerPhoneAttr = new CustomerMasterPhoneAttr(
									CustomerMasterConstants.CM_PHONE_TYPE_H);
							customerPhoneAttr
									.setAreaCode(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_PHAREA));
							customerPhoneAttr
									.setPhoneNumber(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_PHNUMBER));
							customer.getCustAll().getPhone().setHomePhone(
									customerPhoneAttr);
							//customer.getCustAll().getPhone().getHomePhone().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
							customer.getCustAll().getPhone().getHomePhone()
									.setSourceCode(srcCode);

						}
					}

					customer.setSrcCode(srcCode);
					customer.setMemberId(memberID);
					customer.setMemberStatus(memStatus);

					customerMasterResponse[custLinkIndex]
							.setEntCustomer(customer);

				}
				i++;
			}

		} catch (Exception e) {
			logger.error("There is an Error in mapping fields for ref member"
					+ e.getMessage());

		}

		CustomerMasterEntLookUpResponse[] customerMasterResponseFinal = null;
		if (customerMasterResponse.length > 0) {
			if (maxRowReturn == 0)//not specifying the  max returns, then return all 
			{
				customerMasterResponseFinal = new CustomerMasterEntLookUpResponse[custCountIndex + 1];
			} else if (maxRowReturn >= custCountIndex + 1) {
				customerMasterResponseFinal = new CustomerMasterEntLookUpResponse[custCountIndex + 1];
			} else if (maxRowReturn < custCountIndex + 1) {
				customerMasterResponseFinal = new CustomerMasterEntLookUpResponse[maxRowReturn];
			}
			if (showLinkage
					.equalsIgnoreCase(CustomerMasterConstants.VALUE_TRUE)) {
				for (int k = 0; k < customerMasterResponseFinal.length; k++) {
					customerMasterResponseFinal[k] = customerMasterResponse[k];
					CustomerMasterHubLinkageRec customerLinkageRecFinal = new CustomerMasterHubLinkageRec();
					customerLinkageRecFinal.setEid(customerMasterlinkage[k]
							.getEid());
					CustomerMasterLinkageDetail[] customerLinkageDetail = new CustomerMasterLinkageDetail[customerMasterlinkage[k]
							.getLinkageDetail().size()];
					for (int j = 0; j < customerMasterlinkage[k]
							.getLinkageDetail().size(); j++) {
						customerLinkageDetail[j] = customerMasterlinkage[k]
								.getLinkageDetail().get(j);

					}
					customerLinkageRecFinal
							.setLinkageDetail(customerLinkageDetail);
					customerMasterResponseFinal[k].getEntCustomer()
							.setHubLinkageRec(customerLinkageRecFinal);

				}
			} else {
				for (int k = 0; k < customerMasterResponseFinal.length; k++) {
					customerMasterResponseFinal[k] = customerMasterResponse[k];
				}
			}
		}
		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToEntCustomer () :End of  Mapping from member result to customer objects");

		return customerMasterResponseFinal;

	}

	/**
	 * This method prints the memIdsWsValues index number and value
	 */
	public static void mapCustomerPrintRecords(ArrayOfXsdString memIdsWsValues) {

		System.out.println("***********************************************");
		System.out.println("Number of records found :: "
				+ memIdsWsValues.getItem().size());
		for (int k = 0; k < memIdsWsValues.getItem().size(); k++) {
			System.out.println(k + ".\t" + memIdsWsValues.getItem().get(k) + " ");
		}
		System.out
				.println("***********************************************\n\n");
	}

	private static boolean isNull(String str) {
		if (str == null)
			return true;
		if (str.equalsIgnoreCase("null") || str.equalsIgnoreCase(""))
			return true;
		else
			return false;
	}

	private static Map<Long, MemRowList> buildMemberList(MemRowList memberList) {

		Map<Long, MemRowList> memberMapList = new HashMap<Long, MemRowList>();

		for (int i = 0; i < memberList.size(); i++) {
			MemRow currentRow = memberList.rowAt(i);
			if (memberMapList.containsKey(currentRow.getMemRecno())) {
				if (currentRow instanceof MemHead) {

					MemRowList tempList = memberMapList.get(currentRow
							.getMemRecno());
					MemRow tempMemRow = tempList.rowAt(0);
					tempList.removeRowAt(0);
					tempList.addRowAt(0, currentRow);
					tempList.addRow(tempMemRow);

					memberMapList.put(currentRow.getMemRecno(), tempList);
				} else {
					memberMapList.get(currentRow.getMemRecno()).addRow(
							currentRow);
				}
			} else {
				memberMapList.put(currentRow.getMemRecno(), new MemRowList());
				memberMapList.get(currentRow.getMemRecno()).addRow(currentRow);
			}
		}
		return memberMapList;
	}
	
	public static ArrayList<CustomerMasterLinkageDetail> getIDLinkages(String srcID, String srcCode,TrackingInfoVO trackingInfoVO){
		ClassPathResource res = new ClassPathResource("WSConsumer.xml");
		XmlBeanFactory factory = new XmlBeanFactory(res);
		IdentityHubPort identityHubBean=(IdentityHubPort) factory.getBean("identityHubBean");


		logger.log(Level.DEBUG, "Starting  Method CustomerMasterGetWSAO::cdiMapGetRequest()");

		MemberGetRequest memberGetRequest = new MemberGetRequest();
//code change start for synch id reDesign
		memberGetRequest.setEntType(CustomerMasterConstants.ENT_TYPE_ID);
		// Log Enhancement change
		memberGetRequest.setArgs(CustomerMasterUtility.generateLogString(
				trackingInfoVO, CustomerMasterConstants.ALL_SRC_CV,
				CustomerMasterConstants.FILTER_NAME_SUBSEQUENT_MEMGET));
		// code change end for synch id reDesign
		memberGetRequest.setMemType(CustomerMasterConstants.PATIENT_MEMBER_TYPE);
		memberGetRequest.setMemRecno(CustomerMasterConstants.ZERO);
		memberGetRequest.setEntRecno(CustomerMasterConstants.ZERO);		
		memberGetRequest.setGetType(CustomerMasterConstants.AS_ENTITY);	
		memberGetRequest.setRecStatFilter(CustomerMasterConstants.Active);
		memberGetRequest.setMemStatFilter(CustomerMasterConstants.ACTIVE_MERGE);
		memberGetRequest.setSegCodeFilter(CustomerMasterConstants.SEG_CODE_MEMHEAD);		
		memberGetRequest.setMemIdnum(srcID);		
		memberGetRequest.setSrcCode(srcCode);
		
		String consumerAppId = ConsumerContext.getCurrentConsumerApplicationId();		
		String initiateID="";
		String initiatePWD="";
		SecurityResource securityResource =SecurityResource.getInstance();
		initiateID=securityResource.getInitiateID(consumerAppId);
		initiatePWD=securityResource.getInitiatePassword(initiateID);
		System.out.println("initiateID>>"+initiateID+"initiatePWD>>"+initiatePWD);
		
		memberGetRequest.setUserName(initiateID);
		memberGetRequest.setUserPassword(initiatePWD);
		memberGetRequest.setCvwName(CustomerMasterConstants.CVW_NAME_ALL);		
		memberGetRequest.setSrcCodeFilter(CustomerMasterConstants.SRC_CODE_FILTER_LOOKUP_LINKAGE);		
		
		ArrayOfMember arrMemberRes = identityHubBean.getMember(memberGetRequest);
		List<Member> memberList=arrMemberRes.getItem();
		Member[] memberRes = memberList.toArray(new Member[memberList.size()]);
		ArrayList<CustomerMasterLinkageDetail> customerMasterlinkage = new ArrayList<CustomerMasterLinkageDetail>();
		for(int i=0;i<memberRes.length;i++){
		Member member = memberRes[i];
		CustomerMasterLinkageDetail linkageDetl = mapCustomerLinkage(member);
		customerMasterlinkage.add(linkageDetl);
		}
		
		return customerMasterlinkage;
	}
	//code Change Start for PC Real Time
	public static CustomerMasterEnterpriseLookUpResponse[] mapToEnterpriseCustomer(
			Member[] memberRes, String cvwName, int maxRowReturn,
			String showLinkage,String applicationId,String cvType) {

		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToEntCustomer () :Start Mapping from member result to customer objects");
		CustomerMasterEnterpriseLookUpResponse[] customerMasterResponse = null;
		CustomerMasterHubLinkageRecInternal[] customerMasterlinkage = null;
		int custCountIndex = 0;
		int custLinkIndex = 0;
		boolean isNew = false;

		String addSearcCriteriaFlag = CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_NO;
		if (memberRes != null) {
			if (memberRes.length >= maxRowReturn) {
				addSearcCriteriaFlag = CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_YES;
			}

		}
		
		if (memberRes != null || memberRes.length == 0) {
			// Phone Alignment Changes: variable Declarations
			String hPhPriority = CustomerMasterConstants.BLANK_STRING;
			String cPhPriority = CustomerMasterConstants.BLANK_STRING;
			String wPhPriority = CustomerMasterConstants.BLANK_STRING;
			customerMasterResponse = new CustomerMasterEnterpriseLookUpResponse[memberRes.length];
			customerMasterlinkage = new CustomerMasterHubLinkageRecInternal[memberRes.length];
			for (int i = 0; i < memberRes.length; i++) {
				boolean includeSrcInLinkage=true; //Variable added  for PCC CR 
				logger.log(Level.DEBUG,
						"CustomerMaster ::  mapToCustomer ()::\n" + "member="
								+ i + ":: "
								+ memberRes[i].getMemHead().getEntRecno() + "|"
								+ memberRes[i].getMemHead().getMemRecno() + "|"
								+ memberRes[i].getMemHead().getSrcCode() + "|"
								+ memberRes[i].getMemHead().getSrcRecno() + "|"
								+ memberRes[i].getMemHead().getMemIdnum() + "|"
								+ memberRes[i].getMemHead().getMemStat() + "|"
								+ memberRes[i].getMemHead().getMatchScore());

				String currCustEid = Long.toString(memberRes[i].getMemHead()
						.getEntRecno());
				
				Short currMatchScore = memberRes[i].getMemHead().getMatchScore();

				CustomerMasterEnterpriseSearch customer = null;
				// code changes start for PCC CR 
					if(applicationId!=null && CustomerMasterConstants.NON_AUTHORIZE_APPLICATION_ID_HIPAA.contains(applicationId))
					{
						includeSrcInLinkage=false;
						if(CustomerMasterConstants.NON_TRUSTED_SOURCES.contains(memberRes[i].getMemHead().getSrcCode()))
						{
							includeSrcInLinkage=true;
						}
					}
					// code changes end for PCC CR 
				if (i == 0) {
					custCountIndex = i;
					custLinkIndex = custCountIndex;
					isNew = true;
					customerMasterResponse[custCountIndex] = new CustomerMasterEnterpriseLookUpResponse();
					customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();
					logger.log(Level.DEBUG, "New 0" + "custCountIndex="
							+ custCountIndex);
				} else {

					for (int j = 0; j < custCountIndex + 1; j++) {
						if (currCustEid
								.equalsIgnoreCase(customerMasterResponse[j]
										.getEntCustomer().getEID())) {
							custLinkIndex = j;
							customer = customerMasterResponse[j].getEntCustomer();
							// code changes start for PCC CR 
						    if((applicationId!=null && CustomerMasterConstants.NON_AUTHORIZE_APPLICATION_ID_HIPAA.contains(applicationId)&& includeSrcInLinkage)|| includeSrcInLinkage)
						    {	
							  customerMasterlinkage[j].getLinkageDetail().add(
										mapCustomerLinkage(memberRes[i]));	
						    }
						 // code changes end for PCC CR 
							if (currMatchScore > Short.valueOf(customer
									.getMatchScore())) {
								customer.setMatchScore(Short
										.toString(currMatchScore));
							}
							isNew = false;

							logger.log(Level.DEBUG, "old " + "custCountIndex="
									+ custCountIndex + "j=" + j + ", i=" + i);
							break;
						} else
							isNew = true;
					}

					if (isNew) {

						custCountIndex = custCountIndex + 1;
						custLinkIndex = custCountIndex;
						customerMasterResponse[custCountIndex] = new CustomerMasterEnterpriseLookUpResponse();
						customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();

						logger.log(Level.DEBUG, "new " + "custCountIndex="
								+ custCountIndex + "i=" + i);
					}
				}
				if (isNew) {
					customer = new CustomerMasterEnterpriseSearch();
					customer.setEID(currCustEid);
					customer.setMatchScore(Short.toString(currMatchScore));
					customerMasterlinkage[custCountIndex].setEid(currCustEid);
					ArrayList<CustomerMasterLinkageDetail> linkageDetail = new ArrayList<CustomerMasterLinkageDetail>();
					// code changes start for PCC CR 
					if((applicationId!=null && !CustomerMasterConstants.NON_AUTHORIZE_APPLICATION_ID_HIPAA.contains(applicationId) && includeSrcInLinkage) || includeSrcInLinkage)
				    {
						linkageDetail.add(mapCustomerLinkage(memberRes[i]));
				    }
					// code changes ends for PCC CR 
						customerMasterlinkage[custCountIndex]
								.setLinkageDetail(linkageDetail);
								
					

				}

				// System.out.println("*****customerMasterlinkage
				// content******\n" + "i," + i +", "+
				// customerMasterlinkage[custLinkIndex].getLinkageDetail());

				String secCode = "";
				ArrayOfMemIdsWs arraymemIdsWs = memberRes[i].getMemIds();
				MemIdsWs[] memIdsWs = null;

				if (arraymemIdsWs != null) {
					
					  List<MemIdsWs> memberList = arraymemIdsWs.getItem();
					  memIdsWs=memberList.toArray(new MemIdsWs[memberList.size()]);
					
					

					for (int j = 0; memIdsWs != null && j < arraymemIdsWs.getItem().size(); j++) {
						ArrayOfXsdString memIdsWsValues = memIdsWs[j]
								.getValues();
						//System.out.println((j + 1) + ". \tAttribute Code :: test2" + memIdsWs[j].getAttrCode());
						// mapCustomerPrintRecords(memIdsWsValues);

						if (CustomerMasterConstants.ATTR_CODE_NAME
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerName(memIdsWsValues).isNull())) {
								customer.getCustAll().setName(
										mapCustomerName(memIdsWsValues));
								customer.getCustAll().getName()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getName().setSourceCode(
										memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_GENDER
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerGender(memIdsWsValues).isNull())) {
								customer
										.setGender(mapCustomerGender(memIdsWsValues));
								customer.getGender().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getGender().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} 
						else if (CustomerMasterConstants.ATTR_CODE_LAST_UPDATE_DATE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (mapCustomerLastUpdateDate(memIdsWsValues) != null) {
								customer
										.setLastUpdateDate(mapCustomerLastUpdateDate(memIdsWsValues));

							}

						}
						else if (CustomerMasterConstants.ATTR_CODE_PET_IND
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPetInd(memIdsWsValues).isNull())) {
								customer
										.setPetInd(mapCustomerPetInd(memIdsWsValues));
								customer.getPetInd().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getPetInd().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_DEATH_IND
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerDeathInd(memIdsWsValues).isNull())) {
								customer
										.setDeceasedInd(mapCustomerDeathInd(memIdsWsValues));
								customer.getDeceasedInd().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getDeceasedInd().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_EMAIL
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerEmail(memIdsWsValues).isNull())) {
								customer.getCustAll().setEmail(
										mapCustomerEmail(memIdsWsValues));
								customer.getCustAll().getEmail()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getEmail().setSourceCode(
										memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_LOCK_IND
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerLockedInd(memIdsWsValues).isNull())) {
								customer
										.setLockedInd(mapCustomerLockedInd(memIdsWsValues));
								customer.getLockedInd().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getLockedInd().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						} else if (CustomerMasterConstants.ATTR_CODE_BIRTH_DT
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {

							if (!(mapCustomerBirthDate(memIdsWsValues).isNull())) {
								customer.getCustAll().setBirthDate(
										mapCustomerBirthDate(memIdsWsValues));
								customer.getCustAll().getBirthDate()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getBirthDate()
										.setSourceCode(memIdsWs[j].getSrcCode());
							}

						} 
						else if (CustomerMasterConstants.ATTR_CODE_CUST_ORGN
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {

							if (!(mapCustomerOrigin(memIdsWsValues).isNull())) {
								customer
										.setOrigin(mapCustomerOrigin(memIdsWsValues));
								customer.getOrigin().setLastUpdateDate(
										cvrtLstUpdDate(memIdsWs[j]
												.getSrcLtime()));
								customer.getOrigin().setSourceCode(
										memIdsWs[j].getSrcCode());
							}

						}
						else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerAddressNOCA(memIdsWsValues,
									CustomerMasterConstants.CM_ADDRESS_TYPE_P)
									.isNull())) {

								customer
										.getCustAll()
										.getAddress()
										.setPermAddress(
												mapCustomerAddressNOCA(
														memIdsWsValues,
														CustomerMasterConstants.CM_ADDRESS_TYPE_P));
								customer.getCustAll().getAddress()
										.getPermAddress().setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getAddress()
										.getPermAddress().setSourceCode(
												memIdsWs[j].getSrcCode());
							}
						} else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS_2
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerAddress(memIdsWsValues,
									CustomerMasterConstants.CM_ADDRESS_TYPE_2)
									.isNull())) {
								customer
										.getCustAll()
										.getAddress()
										.setHome2Address(
												mapCustomerAddress(
														memIdsWsValues,
														CustomerMasterConstants.CM_ADDRESS_TYPE_2));
								customer.getCustAll().getAddress()
										.getHome2Address().setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getAddress()
										.getHome2Address().setSourceCode(
												memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_WK_ADDRESS
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerAddress(memIdsWsValues,
									CustomerMasterConstants.CM_ADDRESS_TYPE_W)
									.isNull())) {
								customer
										.getCustAll()
										.getAddress()
										.setWorkAddress(
												mapCustomerAddress(
														memIdsWsValues,
														CustomerMasterConstants.CM_ADDRESS_TYPE_W));
								customer.getCustAll().getAddress()
										.getWorkAddress().setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer.getCustAll().getAddress()
										.getWorkAddress().setSourceCode(
												memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_PR_PHONE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPhone(memIdsWsValues,
									CustomerMasterConstants.CM_PHONE_TYPE_H)
									.isNull())) {
								customer
										.getCustAll()
										.getPhone()
										.setHomePhone(
												mapCustomerPhone(
														memIdsWsValues,
														CustomerMasterConstants.CM_PHONE_TYPE_H));
								customer.getCustAll().getPhone().getHomePhone()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getPhone()
										.getHomePhone()
										.setSourceCode(memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_CELL_PHONE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPhone(memIdsWsValues,
									CustomerMasterConstants.CM_PHONE_TYPE_C)
									.isNull())) {
								customer
										.getCustAll()
										.getPhone()
										.setCellPhone(
												mapCustomerPhone(
														memIdsWsValues,
														CustomerMasterConstants.CM_PHONE_TYPE_C));
								customer.getCustAll().getPhone().getCellPhone()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getPhone()
										.getCellPhone()
										.setSourceCode(memIdsWs[j].getSrcCode());

							}

						} else if (CustomerMasterConstants.ATTR_CODE_WK_PHONE
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							if (!(mapCustomerPhone(memIdsWsValues,
									CustomerMasterConstants.CM_PHONE_TYPE_W)
									.isNull())) {
								customer
										.getCustAll()
										.getPhone()
										.setWorkPhone(
												mapCustomerPhone(
														memIdsWsValues,
														CustomerMasterConstants.CM_PHONE_TYPE_W));
								customer.getCustAll().getPhone().getWorkPhone()
										.setLastUpdateDate(
												cvrtLstUpdDate(memIdsWs[j]
														.getSrcLtime()));
								customer
										.getCustAll()
										.getPhone()
										.getWorkPhone()
										.setSourceCode(memIdsWs[j].getSrcCode());

							}

						}

						else if (CustomerMasterConstants.ATTR_CODE_TRUST_ID
								.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							CustomerMasterLinkageDetail linkDetail = mapCustomerTrustID(memIdsWsValues);
							ArrayList<CustomerMasterLinkageDetail> myRefLink = customerMasterlinkage[custLinkIndex]
									.getLinkageDetail();
							CustomerMasterLinkageDetail temp = (CustomerMasterLinkageDetail) myRefLink
									.get(myRefLink.size() - 1);
							temp.setRefCode(linkDetail.getRefCode());
							temp.setRefID(linkDetail.getRefID());
							myRefLink.set(myRefLink.size() - 1, temp);

						}
						// Phone ALignment Changes: Fetch Phone Priorities
						else if (CustomerMasterConstants.ATTR_CODE_HPHMETADATA
								.equalsIgnoreCase(memIdsWs[j].getAttrCode()) && CustomerMasterConstants.CVTYPE_HIPPA.equalsIgnoreCase(cvType)) {
							hPhPriority = memIdsWsValues
									.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTATTR_FIELD1);
						} else if (CustomerMasterConstants.ATTR_CODE_CPHMETADATA
								.equalsIgnoreCase(memIdsWs[j].getAttrCode()) && CustomerMasterConstants.CVTYPE_HIPPA.equalsIgnoreCase(cvType)) {
							cPhPriority = memIdsWsValues
									.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTATTR_FIELD1);
						} else if (CustomerMasterConstants.ATTR_CODE_WPHMETADATA
								.equalsIgnoreCase(memIdsWs[j].getAttrCode()) && CustomerMasterConstants.CVTYPE_HIPPA.equalsIgnoreCase(cvType)) {
							wPhPriority = memIdsWsValues
									.getItem().get(CustomerMasterConstants.FLDSEQNO_CUSTATTR_FIELD1);
						}
						
						// Phone Alignment CHanges End	

					}
				}
				if (customer != null) {
					setEntSearchSecurityCodeEnterprise(secCode, customer);
					// Method To Set Phone Meta data (Phone Priorities)
					if(CustomerMasterConstants.CVTYPE_HIPPA.equalsIgnoreCase(cvType))
					 setPhoneMetaData(hPhPriority, cPhPriority, wPhPriority,customer);
				}
				customer.setSrcCode(memberRes[i].getMemHead().getSrcCode());
				customer.setMemberId(memberRes[i].getMemHead().getMemIdnum());
				customer
						.setMemberStatus(memberRes[i].getMemHead().getMemStat());

				customerMasterResponse[custLinkIndex].setEntCustomer(customer);

			}
		}
		//Riteaid change to suppress Riteaid customers if application id is IC+ --starts
		if(CustomerMasterConstants.CVTYPE_HIPPA.equalsIgnoreCase(cvType))
		{
			int currentIndex=0;
			int length=custCountIndex+1;
			for (int counter = 0; counter < length; counter++) 
			{
				//Riteaid boolean added.
				boolean isaddCustomer=false;
				if(applicationId!=null && (CustomerMasterConstants.APPID_RITEAID.contains(applicationId.toUpperCase()) && applicationId.length()>1))
					{
						for(CustomerMasterLinkageDetail tmpObj1:customerMasterlinkage[counter].getLinkageDetail())
						{
							if(CustomerMasterConstants.SRC_CODE_FILTER_CUSTOMER_LOOKUP.contains(tmpObj1.getSourceCode()))
							{	
								String patternName=CustomerMasterConstants.PREFIX+applicationId;
								try{
								if(!(CustomerMasterConstants.SRC_CODE_EE.equalsIgnoreCase(tmpObj1.getSourceCode()) && tmpObj1.getSourceID().toUpperCase().matches(String.valueOf(CustomerMasterConstants.class.getField(patternName).get(null)))))
								{
									isaddCustomer=true;
									break;
								}
								}
								catch(Exception e)
								{}
							}
							
						}
					}
					else
					 {
						isaddCustomer=true;
					 }
					if(isaddCustomer)
					{	
						customerMasterResponse[currentIndex].setEntCustomer(customerMasterResponse[counter].getEntCustomer());
						customerMasterlinkage [currentIndex]=customerMasterlinkage[counter];
						currentIndex++;
						if(customerMasterResponse[counter].getEntCustomer().getSrcCode()!=null){
							customerMasterResponse[counter].getEntCustomer().setSrcCode(null);}
					}
					else
					{
						custCountIndex--;
					}
			}	
			
			//Riteaid change to suppress Riteaid customers if application id is IC+ --ends

		}	
		CustomerMasterEnterpriseLookUpResponse[] customerMasterResponseFinal = null;
		if (customerMasterResponse.length > 0) {
			if (maxRowReturn == 0)// not specifying the max returns, then
									// return all
			{
				customerMasterResponseFinal = new CustomerMasterEnterpriseLookUpResponse[custCountIndex + 1];
			} else if (maxRowReturn >= custCountIndex + 1) {
				customerMasterResponseFinal = new CustomerMasterEnterpriseLookUpResponse[custCountIndex + 1];
			} else if (maxRowReturn < custCountIndex + 1) {
				customerMasterResponseFinal = new CustomerMasterEnterpriseLookUpResponse[maxRowReturn];
			}
			if (showLinkage
					.equalsIgnoreCase(CustomerMasterConstants.VALUE_TRUE)) {
				for (int k = 0; k < customerMasterResponseFinal.length; k++) {
					customerMasterResponseFinal[k] = customerMasterResponse[k];
					CustomerMasterHubLinkageRec customerLinkageRecFinal = new CustomerMasterHubLinkageRec();
					customerLinkageRecFinal.setEid(customerMasterlinkage[k]
							.getEid());
					CustomerMasterLinkageDetail[] customerLinkageDetail = new CustomerMasterLinkageDetail[customerMasterlinkage[k]
							.getLinkageDetail().size()];
					for (int j = 0; j < customerMasterlinkage[k]
							.getLinkageDetail().size(); j++) {
						customerLinkageDetail[j] = customerMasterlinkage[k]
								.getLinkageDetail().get(j);

					}
					customerLinkageRecFinal
							.setLinkageDetail(customerLinkageDetail);
					customerMasterResponseFinal[k].getEntCustomer()
							.setHubLinkageRec(customerLinkageRecFinal);
					customerMasterResponseFinal[k].setResultExceedInd(addSearcCriteriaFlag);

				}
			} else {
				for (int k = 0; k < customerMasterResponseFinal.length; k++) {
					customerMasterResponseFinal[k] = customerMasterResponse[k];
					customerMasterResponseFinal[k].setResultExceedInd(addSearcCriteriaFlag);
				}
			}
		}
		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToEntCustomer () :End of  Mapping from member result to customer objects");

		return customerMasterResponseFinal;

	}
	private static void setEntSearchSecurityCodeEnterprise(String tempSecCode,
			CustomerMasterEnterpriseSearch customer)
			{
			

		String secCode_I = CustomerMasterConstants.SECURITY_CLASS_CODE_I;
		String secCode_H = CustomerMasterConstants.SECURITY_CLASS_CODE_H;
		String secCode_P = CustomerMasterConstants.SECURITY_CLASS_CODE_P;
		String secCode = "";

		if (customer.getGender() != null)
			customer.getGender().setSecurityClassCode(secCode_I);

		if (customer.getLockedInd() != null)
			customer.getLockedInd().setSecurityClassCode(secCode_I);

		if (customer.getPetInd() != null)
			customer.getPetInd().setSecurityClassCode(secCode_I);

		if (customer.getDeceasedInd() != null)
			customer.getDeceasedInd().setSecurityClassCode(secCode_I);

		if (customer.getCustAll().getName() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getName().setSecurityClassCode(
						tempSecCode);
			else if (customer.getCustAll().getName().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
				|| customer.getCustAll().getName().getSourceCode()
				.equalsIgnoreCase(
						CustomerMasterConstants.SRC_CODE_SF)
						|| customer.getCustAll().getName().getSourceCode()
						.equalsIgnoreCase(
								CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code modification start for Guest checkout
			} else if (customer.getCustAll().getName().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getName().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getName().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				//code modification end for Guest checkout
			} else if (customer.getCustAll().getName().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getName().getSecurityClassCode()))
				customer.getCustAll().getName().setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getEmail() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getEmail().setSecurityClassCode(
						tempSecCode);
			else if (customer.getCustAll().getEmail().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getEmail().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getEmail().getSourceCode()
											.equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getEmail().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getEmail().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getEmail().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getEmail().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getEmail().getSecurityClassCode()))
				customer.getCustAll().getEmail().setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getBirthDate() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC)) {
				customer.getCustAll().getBirthDate().setSecurityClassCode(
						tempSecCode);
			} else if (customer.getCustAll().getBirthDate().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getBirthDate().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getBirthDate().getSourceCode()
											.equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				//code change start for GC
			} else if (customer.getCustAll().getBirthDate().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_PC)
					
					|| customer.getCustAll().getBirthDate().getSourceCode()
							.equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getBirthDate().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getBirthDate().getSourceCode()
					.equalsIgnoreCase(CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}

			// customer.getCustAll().getBirthDate().setSecurityClassCode(secCode);
			if (isNull(customer.getCustAll().getBirthDate()
					.getSecurityClassCode()))
				customer.getCustAll().getBirthDate().setSecurityClassCode(
						secCode);
		}

		if (customer.getCustAll().getAddress().getPermAddress() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getAddress().getPermAddress()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getAddress().getPermAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getAddress().getPermAddress()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getAddress().getPermAddress()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getAddress().getPermAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getAddress().getPermAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getAddress().getPermAddress().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getAddress().getPermAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getAddress().getPermAddress()
					.getSecurityClassCode()))
				customer.getCustAll().getAddress().getPermAddress()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getAddress().getHome2Address() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getAddress().getHome2Address()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getAddress().getHome2Address()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getAddress().getHome2Address()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getAddress().getHome2Address()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getAddress().getHome2Address()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getAddress().getHome2Address()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getAddress().getHome2Address().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				// code change end for GC
			} else if (customer.getCustAll().getAddress().getHome2Address()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getAddress().getHome2Address()
					.getSecurityClassCode()))
				customer.getCustAll().getAddress().getHome2Address()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getAddress().getWorkAddress() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getAddress().getWorkAddress()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getAddress().getWorkAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getAddress().getWorkAddress()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getAddress().getWorkAddress()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				//code change start for GC
			} else if (customer.getCustAll().getAddress().getWorkAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getAddress().getWorkAddress()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getAddress().getWorkAddress().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getAddress().getWorkAddress()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getAddress().getWorkAddress()
					.getSecurityClassCode()))
				customer.getCustAll().getAddress().getWorkAddress()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getPhone().getHomePhone() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getPhone().getHomePhone()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getPhone().getHomePhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getPhone().getHomePhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getPhone().getHomePhone()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getPhone().getHomePhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getPhone().getHomePhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getPhone().getHomePhone().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getPhone().getHomePhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getPhone().getHomePhone()
					.getSecurityClassCode()))
				customer.getCustAll().getPhone().getHomePhone()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getPhone().getCellPhone() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getPhone().getCellPhone()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getPhone().getCellPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getPhone().getCellPhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getPhone().getCellPhone()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getPhone().getCellPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getPhone().getCellPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getPhone().getCellPhone().getSourceCode()
									.equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				//code change end for GC
				
			} else if (customer.getCustAll().getPhone().getCellPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getPhone().getCellPhone()
					.getSecurityClassCode()))
				customer.getCustAll().getPhone().getCellPhone()
						.setSecurityClassCode(secCode);
		}

		if (customer.getCustAll().getPhone().getWorkPhone() != null) {
			if (!isNull(tempSecCode)
					&& customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EC))
				customer.getCustAll().getPhone().getWorkPhone()
						.setSecurityClassCode(tempSecCode);
			else if (customer.getCustAll().getPhone().getWorkPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_IC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_SM)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_TC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_HC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_GW)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CH)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_CM)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_EE)
					|| customer.getCustAll().getPhone().getWorkPhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_SF)
											|| customer.getCustAll().getPhone().getWorkPhone()
											.getSourceCode().equalsIgnoreCase(
													CustomerMasterConstants.SRC_CODE_RI)) {
				secCode = secCode_H;
				
				//code change start for GC
			} else if (customer.getCustAll().getPhone().getWorkPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_PC)
					|| customer.getCustAll().getPhone().getWorkPhone()
							.getSourceCode().equalsIgnoreCase(
									CustomerMasterConstants.SRC_CODE_LR)|| customer.getCustAll().getPhone().getWorkPhone()
									.getSourceCode().equalsIgnoreCase(
											CustomerMasterConstants.SRC_CODE_GC)) {
				secCode = secCode_P;
				
				//code change end for GC
			} else if (customer.getCustAll().getPhone().getWorkPhone()
					.getSourceCode().equalsIgnoreCase(
							CustomerMasterConstants.SRC_CODE_EC)) {
				secCode = tempSecCode;
			}
			if (isNull(customer.getCustAll().getPhone().getWorkPhone()
					.getSecurityClassCode()))
				customer.getCustAll().getPhone().getWorkPhone()
						.setSecurityClassCode(secCode);
		}

	
			}
	
	public static CustomerMasterEnterpriseLookUpResponse[] mapRefHubCustomerEnterprise(
			MemRowList memberRes, String cvwName, int maxRowReturn,
			String showLinkage) {

		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToEntCustomer () :Start Mapping from member result to customer objects");
		CustomerMasterEnterpriseLookUpResponse[] customerMasterResponse = null;
		CustomerMasterHubLinkageRecInternal[] customerMasterlinkage = null;
		int custCountIndex = 0;
		int custLinkIndex = 0;
		boolean isNew = false;
		String srcCode = null;
		String currCustEid = null;
		Short currMatchScore = 0;
		String memberID = null;
		String memStatus = null;

		Map memberMap = buildMemberList(memberRes);
		customerMasterResponse = new CustomerMasterEnterpriseLookUpResponse[memberMap
				.size()];
		customerMasterlinkage = new CustomerMasterHubLinkageRecInternal[memberMap
				.size()];
		String addSearcCriteriaFlag = CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_NO;
		if (memberRes != null) {
			if (memberRes.size() >= maxRowReturn) {
				addSearcCriteriaFlag = CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_YES;
			}

		}
		
		
		
		try {

			Set newSet = memberMap.keySet();
			Iterator itr = newSet.iterator();
			int i = 0;
			while (itr.hasNext()) {
				long key = (Long) itr.next();

				MemRowList memberRowList = (MemRowList) memberMap.get(key);
				//int i = 0;
				if (memberRowList != null || memberRowList.size() == 0) {

					CustomerMasterEnterpriseSearch customer = null;
					RowIterator iter = memberRowList.rows();

					while (iter.hasMoreRows()) {
						MemRow memRow = (MemRow) iter.nextRow();
						SegDef inSegDef = memRow.getSegDef();
						if (memRow instanceof MemHead) {

							logger.log(Level.DEBUG,
									"CustomerMaster ::  mapToCustomer ()::\n"
											+ "member="
											+ i
											+ ":: "
											+ memRow.getMemHead().getEntRecno()
											+ "|"
											+ memRow.getMemHead().getMemRecno()
											+ "|"
											+ memRow.getMemHead().getSrcCode()
											+ "|"
											+ memRow.getMemHead().getSrcRecno()
											+ "|"
											+ memRow.getMemHead().getMemIdnum()
											+ "|"
											+ memRow.getMemHead().getMemStat()
											+ "|"
											+ memRow.getMemHead()
													.getMatchScore());

							currCustEid = Long.toString(memRow.getMemHead()
									.getEntRecno());
							
							currMatchScore = memRow.getMemHead().getMatchScore();
							srcCode = memRow.getMemHead().getSrcCode();
							memberID = memRow.getMemHead().getMemIdnum();
							memStatus = memRow.getMemHead().getMemStat();
							// }

							if (i == 0) {
								custCountIndex = i;
								custLinkIndex = custCountIndex;
								isNew = true;
								customerMasterResponse[custCountIndex] = new CustomerMasterEnterpriseLookUpResponse();
								customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();
								logger.log(Level.DEBUG, "New 0"
										+ "custCountIndex=" + custCountIndex);
							} else {

								for (int j = 0; j < custCountIndex + 1; j++) {
									if (currCustEid
											.equalsIgnoreCase(customerMasterResponse[j]
													.getEntCustomer().getEID())) {
										custLinkIndex = j;
										customer = customerMasterResponse[j]
												.getEntCustomer();
										customerMasterlinkage[j]
												.getLinkageDetail()
												.add(
														mapRefCustomerLinkage(memRow));

										if (currMatchScore > Short
												.valueOf(customer
														.getMatchScore())) {
											customer.setMatchScore(Short
													.toString(currMatchScore));
										}
										isNew = false;

										logger.log(Level.DEBUG, "old "
												+ "custCountIndex="
												+ custCountIndex + "j=" + j
												+ ", i=" + i);
										break;
									} else
										isNew = true;
								}

								if (isNew) {

									custCountIndex = custCountIndex + 1;
									custLinkIndex = custCountIndex;
									customerMasterResponse[custCountIndex] = new CustomerMasterEnterpriseLookUpResponse();
									customerMasterlinkage[custCountIndex] = new CustomerMasterHubLinkageRecInternal();

									logger.log(Level.DEBUG, "new "
											+ "custCountIndex="
											+ custCountIndex + "i=" + i);
								}
							}
							if (isNew) {
								customer = new CustomerMasterEnterpriseSearch();
								customer.setEID(currCustEid);
								customer.setMatchScore(Short
										.toString(currMatchScore));
								customerMasterlinkage[custCountIndex]
										.setEid(currCustEid);
								ArrayList<CustomerMasterLinkageDetail> linkageDetail = new ArrayList<CustomerMasterLinkageDetail>();
								linkageDetail
										.add(mapRefCustomerLinkage(memRow));
								customerMasterlinkage[custCountIndex]
										.setLinkageDetail(linkageDetail);

							}
						}

						else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTNAME)) {
							CustomerMasterName customerName = new CustomerMasterName();
							customerName
									.setFirstName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMFIRST));
							customerName
									.setMiddleName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMMIDDLE));
							customerName
									.setLastName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMLAST));
							customerName
									.setPrefixName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMPREFIX));
							customerName
									.setSuffixName(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_ONMSUFFIX));
							customer.getCustAll().setName(customerName);
							// customer.getCustAll().getName().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
							customer.getCustAll().getName().setSourceCode(
									srcCode);

						} else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTADDR)) {
							CustomerMasterAddressAttrNCOA custAddress = null;

							custAddress = new CustomerMasterAddressAttrNCOA(
									CustomerMasterConstants.CM_ADDRESS_TYPE_P);
							// Mapping NCOA

							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_STREET_ADDRESS1)) {
								custAddress
										.setStreetLine1(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_STREET_ADDRESS1));
							}
							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_STREET_ADDRESS2)) {
								custAddress
										.setStreetLine2(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_STREET_ADDRESS2));
							}
							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_CITY)) {
								custAddress
										.setCity(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_CITY));
							}
							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_STATE)) {
								custAddress
										.setState(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_STATE));
							}
							if (null != memRow
									.getAsString(CustomerMasterConstants.FIELD_NAME_ZIP)) {
								custAddress
										.setZipCode(memRow
												.getAsString(CustomerMasterConstants.FIELD_NAME_ZIP));
							}

							customer.getCustAll().getAddress().setPermAddress(
									custAddress);
							//customer.getCustAll().getAddress().getPermAddress().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
							customer.getCustAll().getAddress().getPermAddress()
									.setSourceCode(srcCode);

						}

						else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTATTR1)) {
							if (memRow
									.getAsString(
											CustomerMasterConstants.ATTRCODE)
									.equalsIgnoreCase(
											CustomerMasterConstants.ATTR_CODE_GENDER)) {

								CustomerMasterGender customerGender = new CustomerMasterGender();
								customerGender
										.setGenderCode(memRow
												.getAsString(CustomerMasterConstants.ATTRVAL));
								customer.setGender(customerGender);
								// customer.getGender().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
								customer.getGender().setSourceCode(srcCode);
							} else if (memRow
									.getAsString(
											CustomerMasterConstants.ATTRCODE)
									.equalsIgnoreCase(
											CustomerMasterConstants.ATTR_CODE_PET_IND)) {

								CustomerMasterPetInd customerPetInd = new CustomerMasterPetInd();
								customerPetInd
										.setPetIndicator(memRow
												.getAsString(CustomerMasterConstants.ATTRVAL));
								customer.setPetInd(customerPetInd);
								// customer.getPetInd().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
								customer.getPetInd().setSourceCode(srcCode);
							} else if (memRow
									.getAsString(
											CustomerMasterConstants.ATTRCODE)
									.equalsIgnoreCase(
											CustomerMasterConstants.ATTR_CODE_EMAIL)) {

								CustomerMasterEmail customerEmail = new CustomerMasterEmail();
								customerEmail
										.setEmailAddress(memRow
												.getAsString(CustomerMasterConstants.ATTRVAL));
								customer.getCustAll().setEmail(customerEmail);
								//customer.getCustAll().getEmail().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
								customer.getCustAll().getEmail().setSourceCode(
										srcCode);
							} else if (memRow
									.getAsString(
											CustomerMasterConstants.ATTRCODE)
									.equalsIgnoreCase(
											CustomerMasterConstants.ATTR_CODE_REFDEATHIND)) {

								CustomerMasterDeceasedInd customerDeathInd = new CustomerMasterDeceasedInd();
								customerDeathInd
										.setDeceasedIndicator(memRow
												.getAsString(CustomerMasterConstants.ATTRVAL));
								customer.setDeceasedInd(customerDeathInd);
								//customer.getDeceasedInd().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
								customer.getDeceasedInd()
										.setSourceCode(srcCode);
							}
						}

						else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTDATE)) {

							CustomerMasterBirthDate customerBirthDate = new CustomerMasterBirthDate();
							customerBirthDate
									.setBirthdate(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_DATEVAL));
							customer.getCustAll().setBirthDate(
									customerBirthDate);
							//customer.getCustAll().getBirthDate().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
							customer.getCustAll().getBirthDate().setSourceCode(
									srcCode);

						} else if (memRow.getRowSegCode().equalsIgnoreCase(
								CustomerMasterConstants.SEGMENT_CODE_CUSTPHONE)) {

							CustomerMasterPhoneAttr customerPhoneAttr = new CustomerMasterPhoneAttr(
									CustomerMasterConstants.CM_PHONE_TYPE_H);
							customerPhoneAttr
									.setAreaCode(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_PHAREA));
							customerPhoneAttr
									.setPhoneNumber(memRow
											.getAsString(CustomerMasterConstants.FIELD_NAME_PHNUMBER));
							customer.getCustAll().getPhone().setHomePhone(
									customerPhoneAttr);
							//customer.getCustAll().getPhone().getHomePhone().setLastUpdateDate(cvrtLstUpdDate(memRow.getAsString(CustomerMasterConstants.SRCL_TIME)));
							customer.getCustAll().getPhone().getHomePhone()
									.setSourceCode(srcCode);

						}
					}

					customer.setSrcCode(srcCode);
					customer.setMemberId(memberID);
					customer.setMemberStatus(memStatus);

					customerMasterResponse[custLinkIndex]
							.setEntCustomer(customer);
					

				}
				i++;
			}

		} catch (Exception e) {
			logger.error("There is an Error in mapping fields for ref member"
					+ e.getMessage());

		}

		CustomerMasterEnterpriseLookUpResponse[] customerMasterResponseFinal = null;
		if (customerMasterResponse.length > 0) {
			if (maxRowReturn == 0)//not specifying the  max returns, then return all 
			{
				customerMasterResponseFinal = new CustomerMasterEnterpriseLookUpResponse[custCountIndex + 1];
			} else if (maxRowReturn >= custCountIndex + 1) {
				customerMasterResponseFinal = new CustomerMasterEnterpriseLookUpResponse[custCountIndex + 1];
			} else if (maxRowReturn < custCountIndex + 1) {
				customerMasterResponseFinal = new CustomerMasterEnterpriseLookUpResponse[maxRowReturn];
			}
			if (showLinkage
					.equalsIgnoreCase(CustomerMasterConstants.VALUE_TRUE)) {
				for (int k = 0; k < customerMasterResponseFinal.length; k++) {
					customerMasterResponseFinal[k] = customerMasterResponse[k];
					CustomerMasterHubLinkageRec customerLinkageRecFinal = new CustomerMasterHubLinkageRec();
					customerLinkageRecFinal.setEid(customerMasterlinkage[k]
							.getEid());
					CustomerMasterLinkageDetail[] customerLinkageDetail = new CustomerMasterLinkageDetail[customerMasterlinkage[k]
							.getLinkageDetail().size()];
					for (int j = 0; j < customerMasterlinkage[k]
							.getLinkageDetail().size(); j++) {
						customerLinkageDetail[j] = customerMasterlinkage[k]
								.getLinkageDetail().get(j);

					}
					customerLinkageRecFinal
							.setLinkageDetail(customerLinkageDetail);
					customerMasterResponseFinal[k].getEntCustomer()
							.setHubLinkageRec(customerLinkageRecFinal);
					customerMasterResponseFinal[k].setResultExceedInd(addSearcCriteriaFlag);
				}
				
			} else {
				for (int k = 0; k < customerMasterResponseFinal.length; k++) {
					customerMasterResponseFinal[k] = customerMasterResponse[k];
					customerMasterResponseFinal[k].setResultExceedInd(addSearcCriteriaFlag);
				}
				
				
			}
			
		}
		logger
				.log(
						Level.DEBUG,
						"CustomerMaster ::  mapToEntCustomer () :End of  Mapping from member result to customer objects");

		return customerMasterResponseFinal;

	}
	public static CustomerMasterEnterpriseLookUpResponse[] mapToLoyaltyEnterPriseCustomer(
			Member[] memberRes, String cvwName,int maxMemberCnt)
	{

		//	System.out.println ("Inside mapToLoyaltyCustomer");

			logger
					.log(
							Level.DEBUG,
							"CustomerMaster ::  mapToLoyaltyCustomer () :Start Mapping from member result to customer objects");
			CustomerMasterEnterpriseLookUpResponse[] customerMasterResponse = null;
			int custCountIndex = 0;
			String addSearcCriteriaFlag = CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_NO;
			if (memberRes != null) {
				if (memberRes.length >= maxMemberCnt) {
					addSearcCriteriaFlag = CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_YES;
				}

			}
			if (memberRes != null || memberRes.length == 0) {

				customerMasterResponse = new CustomerMasterEnterpriseLookUpResponse[memberRes.length];

				for (int i = 0; i < memberRes.length; i++) {

					logger.log(Level.DEBUG,
							"CustomerMaster ::  mapToCustomer ()::\n" + "member="
									+ i + ":: "
									+ memberRes[i].getMemHead().getEntRecno() + "|"
									+ memberRes[i].getMemHead().getMemRecno() + "|"
									+ memberRes[i].getMemHead().getSrcCode() + "|"
									+ memberRes[i].getMemHead().getSrcRecno() + "|"
									+ memberRes[i].getMemHead().getMemIdnum() + "|"
									+ memberRes[i].getMemHead().getMemStat() + "|"
									+ memberRes[i].getMemHead().getMatchScore());
					
					String currCustEid = Long.toString(memberRes[i].getMemHead()
							.getEntRecno());
					
					Short currMatchScore = memberRes[i].getMemHead().getMatchScore();				

					customerMasterResponse[custCountIndex] = new CustomerMasterEnterpriseLookUpResponse();
					customerMasterResponse[custCountIndex].setResultExceedInd(addSearcCriteriaFlag);
					CustomerMasterEnterpriseSearch customer = new CustomerMasterEnterpriseSearch();
					customer.setSrcCode(memberRes[i].getMemHead().getSrcCode());
					customer.setMemberId(memberRes[i].getMemHead().getMemIdnum());
					customer.setEID(currCustEid);
					customer.setMatchScore(Short.toString(currMatchScore));
					customer
							.setMemberStatus(memberRes[i].getMemHead().getMemStat());
					String secCode = "";
					ArrayOfMemIdsWs arraymemIdsWs = memberRes[i].getMemIds();
					MemIdsWs[] memIdsWs = null;

					if (arraymemIdsWs != null) {
						  List<MemIdsWs> memberList = arraymemIdsWs.getItem();
						  memIdsWs=memberList.toArray(new MemIdsWs[memberList.size()]);

						for (int j = 0; memIdsWs != null && j < memIdsWs.length; j++) {
							ArrayOfXsdString memIdsWsValues = memIdsWs[j]
									.getValues();
							//System.out.println((j + 1) + ". \tAttribute Code ::"	+ memIdsWs[j].getAttrCode());
							//mapCustomerPrintRecords(memIdsWsValues);

							if (CustomerMasterConstants.ATTR_CODE_NAME
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerName(memIdsWsValues).isNull())) {
									customer.getCustAll().setName(
											mapCustomerName(memIdsWsValues));
									customer.getCustAll().getName()
											.setLastUpdateDate(
													cvrtLstUpdDate(memIdsWs[j]
															.getSrcLtime()));
									customer.getCustAll().getName().setSourceCode(
											memIdsWs[j].getSrcCode());

								}

							} else if (CustomerMasterConstants.ATTR_CODE_GENDER
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerGender(memIdsWsValues).isNull())) {
									customer
											.setGender(mapCustomerGender(memIdsWsValues));
									customer.getGender().setLastUpdateDate(
											cvrtLstUpdDate(memIdsWs[j]
													.getSrcLtime()));
									customer.getGender().setSourceCode(
											memIdsWs[j].getSrcCode());
								}

							} else if (CustomerMasterConstants.ATTR_CODE_PET_IND
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerPetInd(memIdsWsValues).isNull())) {
									customer
											.setPetInd(mapCustomerPetInd(memIdsWsValues));
									customer.getPetInd().setLastUpdateDate(
											cvrtLstUpdDate(memIdsWs[j]
													.getSrcLtime()));
									customer.getPetInd().setSourceCode(
											memIdsWs[j].getSrcCode());
								}

							} else if (CustomerMasterConstants.ATTR_CODE_DEATH_IND
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerDeathInd(memIdsWsValues).isNull())) {
									customer
											.setDeceasedInd(mapCustomerDeathInd(memIdsWsValues));
									customer.getDeceasedInd().setLastUpdateDate(
											cvrtLstUpdDate(memIdsWs[j]
													.getSrcLtime()));
									customer.getDeceasedInd().setSourceCode(
											memIdsWs[j].getSrcCode());
								}

							} else if (CustomerMasterConstants.ATTR_CODE_EMAIL
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerEmail(memIdsWsValues).isNull())) {
									customer.getCustAll().setEmail(
											mapCustomerEmail(memIdsWsValues));
									customer.getCustAll().getEmail()
											.setLastUpdateDate(
													cvrtLstUpdDate(memIdsWs[j]
															.getSrcLtime()));
									customer.getCustAll().getEmail().setSourceCode(
											memIdsWs[j].getSrcCode());

								}

							} else if (CustomerMasterConstants.ATTR_CODE_LOCK_IND
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerLockedInd(memIdsWsValues).isNull())) {
									customer
											.setLockedInd(mapCustomerLockedInd(memIdsWsValues));
									customer.getLockedInd().setLastUpdateDate(
											cvrtLstUpdDate(memIdsWs[j]
													.getSrcLtime()));
									customer.getLockedInd().setSourceCode(
											memIdsWs[j].getSrcCode());
								}

							} else if (CustomerMasterConstants.ATTR_CODE_BIRTH_DT
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {

								if (!(mapCustomerBirthDate(memIdsWsValues).isNull())) {
									customer.getCustAll().setBirthDate(
											mapCustomerBirthDate(memIdsWsValues));
									customer.getCustAll().getBirthDate()
											.setLastUpdateDate(
													cvrtLstUpdDate(memIdsWs[j]
															.getSrcLtime()));
									customer
											.getCustAll()
											.getBirthDate()
											.setSourceCode(memIdsWs[j].getSrcCode());
								}

							} else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
							//	System.out.println("Inside PR Address Zip Code");
								if (!(mapCustomerAddressNOCA(memIdsWsValues,
										CustomerMasterConstants.CM_ADDRESS_TYPE_P)
										.isNullEnterpriseLookup())) {
								//	System.out.println("Inside PR Address Zip Code");

									customer
											.getCustAll()
											.getAddress()
											.setPermAddress(
													mapCustomerAddressNOCA(
															memIdsWsValues,
															CustomerMasterConstants.CM_ADDRESS_TYPE_P));
									customer.getCustAll().getAddress()
											.getPermAddress().setLastUpdateDate(
													cvrtLstUpdDate(memIdsWs[j]
															.getSrcLtime()));
									customer.getCustAll().getAddress()
											.getPermAddress().setSourceCode(
													memIdsWs[j].getSrcCode());
								}
							} else if (CustomerMasterConstants.ATTR_CODE_PR_ADDRESS_2
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerAddress(memIdsWsValues,
										CustomerMasterConstants.CM_ADDRESS_TYPE_2)
										.isNullEnterpriseLookup())) {
									customer
											.getCustAll()
											.getAddress()
											.setHome2Address(
													mapCustomerAddress(
															memIdsWsValues,
															CustomerMasterConstants.CM_ADDRESS_TYPE_2));
									customer.getCustAll().getAddress()
											.getHome2Address().setLastUpdateDate(
													cvrtLstUpdDate(memIdsWs[j]
															.getSrcLtime()));
									customer.getCustAll().getAddress()
											.getHome2Address().setSourceCode(
													memIdsWs[j].getSrcCode());

								}

							} else if (CustomerMasterConstants.ATTR_CODE_WK_ADDRESS
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerAddress(memIdsWsValues,
										CustomerMasterConstants.CM_ADDRESS_TYPE_W)
										.isNullEnterpriseLookup())) {
									customer
											.getCustAll()
											.getAddress()
											.setWorkAddress(
													mapCustomerAddress(
															memIdsWsValues,
															CustomerMasterConstants.CM_ADDRESS_TYPE_W));
									customer.getCustAll().getAddress()
											.getWorkAddress().setLastUpdateDate(
													cvrtLstUpdDate(memIdsWs[j]
															.getSrcLtime()));
									customer.getCustAll().getAddress()
											.getWorkAddress().setSourceCode(
													memIdsWs[j].getSrcCode());

								}

							} else if (CustomerMasterConstants.ATTR_CODE_PR_PHONE
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerPhone(memIdsWsValues,
										CustomerMasterConstants.CM_PHONE_TYPE_H)
										.isNull())) {
									customer
											.getCustAll()
											.getPhone()
											.setHomePhone(
													mapCustomerPhone(
															memIdsWsValues,
															CustomerMasterConstants.CM_PHONE_TYPE_H));
									customer.getCustAll().getPhone().getHomePhone()
											.setLastUpdateDate(
													cvrtLstUpdDate(memIdsWs[j]
															.getSrcLtime()));
									customer
											.getCustAll()
											.getPhone()
											.getHomePhone()
											.setSourceCode(memIdsWs[j].getSrcCode());

								}

							} else if (CustomerMasterConstants.ATTR_CODE_CELL_PHONE
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerPhone(memIdsWsValues,
										CustomerMasterConstants.CM_PHONE_TYPE_C)
										.isNull())) {
									customer
											.getCustAll()
											.getPhone()
											.setCellPhone(
													mapCustomerPhone(
															memIdsWsValues,
															CustomerMasterConstants.CM_PHONE_TYPE_C));
									customer.getCustAll().getPhone().getCellPhone()
											.setLastUpdateDate(
													cvrtLstUpdDate(memIdsWs[j]
															.getSrcLtime()));
									customer
											.getCustAll()
											.getPhone()
											.getCellPhone()
											.setSourceCode(memIdsWs[j].getSrcCode());

								}

							} else if (CustomerMasterConstants.ATTR_CODE_WK_PHONE
									.equalsIgnoreCase(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerPhone(memIdsWsValues,
										CustomerMasterConstants.CM_PHONE_TYPE_W)
										.isNull())) {
									customer
											.getCustAll()
											.getPhone()
											.setWorkPhone(
													mapCustomerPhone(
															memIdsWsValues,
															CustomerMasterConstants.CM_PHONE_TYPE_W));
									customer.getCustAll().getPhone().getWorkPhone()
											.setLastUpdateDate(
													cvrtLstUpdDate(memIdsWs[j]
															.getSrcLtime()));
									customer
											.getCustAll()
											.getPhone()
											.getWorkPhone()
											.setSourceCode(memIdsWs[j].getSrcCode());

								}

							} else if (CustomerMasterConstants.ATTR_CODE_PROGRAM
									.contains(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerPrograms(memIdsWsValues,
										memIdsWs[j]).isNull())) {
									customer.getProgramArray().add(
											mapCustomerPrograms(memIdsWsValues,
													memIdsWs[j]));
									CustomerMasterEntSearchProgramVO progVo = customer
											.getProgramArray().get(
													customer.getProgramArray()
															.size() - 1);
									if (progVo.getProgramStatus().equalsIgnoreCase(
											CustomerMasterConstants.STATUS_PENDING)) {
										customer
												.setMemberStatus(CustomerMasterConstants.STATUS_PENDING);
									}

								}
							} else if (CustomerMasterConstants.ATTR_CODE_CUSTGENATTR_CODE
									.contains(memIdsWs[j].getAttrCode())) {
								if (!(mapCustomerAttributes(memIdsWsValues)
										.isNull())) {
									customer.getAttributeArray().add(
											mapCustomerAttributes(memIdsWsValues));

								}
							}
						}
					}
					if (customer != null) {
						setEntSearchSecurityCodeEnterprise(secCode, customer);
					}
					customerMasterResponse[custCountIndex++]
							.setEntCustomer(customer);

				}
			}

			logger
					.log(
							Level.DEBUG,
							"CustomerMaster ::  mapToLoyaltyCustomer () :End of  Mapping from member result to customer objects");

			return customerMasterResponse;

		
		
	}
	//code Change END for PC Real Time

}
