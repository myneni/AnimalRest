/**
 * 
 */
package com.walgreens.cdi.exception;

import javax.xml.ws.WebFault;

/**
 * @author atul.prabhu
 *
 */

public class CDIException extends Exception {
    
	private CDIExceptionFault faultInfo;
    /**
     * @return the errorCode
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * @param errorCode the errorCode to set
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public CDIException() {
        
    }
    
    /**
     * 
     */
    private static final long serialVersionUID = 4062675509936781422L;

    private String message = null;

    private String detailMessage = null;
    
    protected String errorCode;
    
    public CDIException(String errorCode) {
        super(errorCode);
        this.errorCode= errorCode;
    }
    
    public CDIException(String errorCode, String message) {
        super();
        this.errorCode= errorCode;
        detailMessage = message;
    }
    
    public CDIException(String errorCode, String message,String userMessage) {
        super(errorCode);
        
        this.detailMessage = message;
        this.message = userMessage;
    }

    /**
     * @return the detailMessage
     */
    public String getDetailMessage() {
        return detailMessage;
    }


    /**
     * @param detailMessage
     *            the detailMessage to set
     */
    public void setDetailMessage(String detailMessage) {
        this.detailMessage = detailMessage;
    }


    /**
     * @return the message
     */
    public String getMsg() {
        return message;
    }


    /**
     * @param message
     *            the message to set
     */
    public void setMsg(String message) {
        this.message = message;
    }
    

}
