package com.walgreens.cdi.bo.impl;

import java.util.ArrayList;

import com.walgreens.cdi.bo.ICustomerMasterEntMemberIdGenerateBO;
import com.walgreens.cdi.dao.impl.CustomerMasterEntMemberIdGenerateDAO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.CustomerMasterUtility;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateRequest;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateResponse;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateSequence;

public class CustomerMasterEntMemberIdGenerateBO extends BaseBO implements
		ICustomerMasterEntMemberIdGenerateBO {
	private CustomerMasterUtility util = new CustomerMasterUtility();

	private CustomerMasterEntMemberIdGenerateDAO customerMasterEntMemberIdGenerateDAO;

	private CustomerMasterEntMemberIdGenerateSequence customerMasterEntMemberIdGenerateSequence = null;

	public CustomerMasterEntMemberIdGenerateResponse callMemberIDGenerator(
			CustomerMasterEntMemberIdGenerateRequest memberIDRequest)
			throws SystemException, BusinessRuleViolationException {

		new ValidateCustomerMasterRequest().validateRequestProgramCode(memberIDRequest);
		CustomerMasterEntMemberIdGenerateResponse customerMasterMemberIDResponse = new CustomerMasterEntMemberIdGenerateResponse();
		ArrayList<CustomerMasterEntMemberIdGenerateSequence> progCodeResponseArray = new ArrayList<CustomerMasterEntMemberIdGenerateSequence>();
		for (int i = 0; i < memberIDRequest.getProgCodeArray().size(); i++) {
			CustomerMasterEntMemberIdGenerateSequence customerMasterEntMemberIdGenerateSequence = new CustomerMasterEntMemberIdGenerateSequence();
			String progCode = memberIDRequest.getProgCodeArray().get(i)
					.getProgCode();
			customerMasterEntMemberIdGenerateSequence
					.setCurrentSequence(getCustomerMasterEntMemberIdGenerateDAO()
							.getMemberIDNumber(progCode));
			//getWalgreensLogger().log(1, "Member ID value::"+ customerMasterEntMemberIdGenerateSequence.getCurrentSequence());
			if (customerMasterEntMemberIdGenerateSequence.getCurrentSequence() == null || customerMasterEntMemberIdGenerateSequence.getCurrentSequence().equals(""))
			{
				throw new BusinessRuleViolationException(
						CustomerMasterConstants.KEY_GENERATION_ID_ERROR);
			}
			progCodeResponseArray
					.add(customerMasterEntMemberIdGenerateSequence);

		}
		customerMasterMemberIDResponse
				.setProgCodeReponseArray(progCodeResponseArray);

		return customerMasterMemberIDResponse;

	}	   
	

	public CustomerMasterEntMemberIdGenerateDAO getCustomerMasterEntMemberIdGenerateDAO() {
		return customerMasterEntMemberIdGenerateDAO;
	}

	public void setCustomerMasterEntMemberIdGenerateDAO(
			CustomerMasterEntMemberIdGenerateDAO customerMasterEntMemberIdGenerateDAO) {
		this.customerMasterEntMemberIdGenerateDAO = customerMasterEntMemberIdGenerateDAO;
	}



	public CustomerMasterEntMemberIdGenerateSequence getCustomerMasterEntMemberIdGenerateSequence() {
		return customerMasterEntMemberIdGenerateSequence;
	}

	public void setCustomerMasterEntMemberIdGenerateSequence(
			CustomerMasterEntMemberIdGenerateSequence customerMasterEntMemberIdGenerateSequence) {
		this.customerMasterEntMemberIdGenerateSequence = customerMasterEntMemberIdGenerateSequence;
	}
}
