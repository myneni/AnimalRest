package com.walgreens.cdi.vo;

import java.util.ArrayList;

public class CustomerMasterEntMemberIdGenerateRequest {
	
	private ArrayList<CustomerMasterEntMemberIdGenerateVO> progCodeArray=new ArrayList<CustomerMasterEntMemberIdGenerateVO>();

	public ArrayList<CustomerMasterEntMemberIdGenerateVO> getProgCodeArray() {
		return progCodeArray;
	}

	public void setProgCodeArray(
			ArrayList<CustomerMasterEntMemberIdGenerateVO> progCodeArray) {
		this.progCodeArray = progCodeArray;
	}

}
