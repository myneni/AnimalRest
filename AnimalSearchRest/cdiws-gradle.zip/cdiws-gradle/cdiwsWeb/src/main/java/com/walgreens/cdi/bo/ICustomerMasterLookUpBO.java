package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfCustomer;
/**
 * This bo is an interface for exposing lookUpCustomerMaster and validateRequestObject at BO level.
 * 
 *
 */
public interface ICustomerMasterLookUpBO {
	
		public ArrayOfCustomer lookUpCustomerMaster(CustomerMasterLookUpRequest customerMasterLookUpRequest) throws SystemException, BusinessRuleViolationException;

		public void validateRequestObject(CustomerMasterLookUpRequest customerMasterLookUpRequest) throws BusinessRuleViolationException;

}
