package com.walgreens.cdi.vo;

import com.walgreens.cdi.util.CustomerMasterConstants;

public class CustomerMasterEntSearchProgramVO {

	private String programCode;
	private String programId;
	private String programStatus;
	private String progEndDt;
	private String progStartDt;
	private String progLstUpDt;	
	
	public String getProgEndDt() {
		return progEndDt;
	}
	public void setProgEndDt(String progEndDt) {
		this.progEndDt = progEndDt;
	}
	public String getProgLstUpDt() {
		return progLstUpDt;
	}
	public void setProgLstUpDt(String progLstUpDt) {
		this.progLstUpDt = progLstUpDt;
	}
	public String getProgramCode() {
		return programCode;
	}
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	public String getProgramId() {
		return programId;
	}
	public void setProgramId(String programId) {
		this.programId = programId;
	}
	public String getProgramStatus() {
		return programStatus;
	}
	public void setProgramStatus(String programStatus) {
		this.programStatus = programStatus;
	}
	public String getProgStartDt() {
		return progStartDt;
	}
	public void setProgStartDt(String progStartDt) {
		this.progStartDt = progStartDt;
	}
	
public boolean isNull(){
		
		if(isNull(programCode)&& 
			isNull(programId)&&
			isNull(programStatus)&&
			isNull(progEndDt)&&
			isNull(progStartDt)&&
			isNull(progLstUpDt))
				return true;
		else
			return false;
	}

private boolean isNull(String str){
	   if(str==null)
		   return true;
		if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
			return true;
		else
			return false;
	}

public boolean isAcceptableProgStatus(){
	if(!isNull()&& CustomerMasterConstants.ACCEPTABLE_PROG_STATUS_VALUE.contains(programStatus))		
		   return true;
	else
		return false;
}
	
}
