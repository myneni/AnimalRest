package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterMergeRequest;


public interface ICustomerMasterMergeService {
	
	public boolean mergeCustomerMaster(CustomerMasterMergeRequest CustomerMasterMergeRequest) throws CDIException;
		

}
