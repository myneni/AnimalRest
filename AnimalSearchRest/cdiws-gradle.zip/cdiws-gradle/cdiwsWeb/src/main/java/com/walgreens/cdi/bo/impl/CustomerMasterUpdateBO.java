package com.walgreens.cdi.bo.impl;

import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterUpdateBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterUpdateRequest;
import com.walgreens.cdi.wsao.ICustomerMasterUpdateWSAO;
/**
 * This BO perform validation on input request and also handles exception. It
 * will return true on successful Insert/Update of  record , otherwise an
 * exception will be thrown with message and error code.
 * 
 * @author
 */
public class CustomerMasterUpdateBO extends BaseBO implements
		ICustomerMasterUpdateBO {

	private ICustomerMasterUpdateWSAO customerMasterUpdateWSAO;
	/**
	 * This method will perform validation and if validation is successful then it call WSAO layer Update method
	 * 
	 * @param customerMasterUpdateRequest
	 * @return boolean
	 * @throws SystemException,BusinessRuleViolationException
	 */
	public boolean updateCustomerMaster(
			CustomerMasterUpdateRequest customerMasterUpdateRequest)
			throws SystemException, BusinessRuleViolationException {

		try {
			validateRequestObject(customerMasterUpdateRequest);
			return getCustomerMasterUpdateWSAO().updateCustomerMaster(
					customerMasterUpdateRequest);
		} catch (JaxWsSoapFaultException e) {
			String exceptionCode = getExceptionCode(e);
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"THE CURRENT ERROR CODE :: " + exceptionCode);
			getWalgreensLogger().log(
					LoggingFacility.DEBUG,
					"THE CURRENT SRC CODE :: "
							+ customerMasterUpdateRequest.getSrcCode());
			if (exceptionCode != null) {
				if (exceptionCode
						.equals(CustomerMasterConstants.DO_NOT_THROW_EXCEPTION)) {
					return true;
				} else if (exceptionCode
						.equals(CustomerMasterConstants.EC_EXCEPTION_PET_IND_REQUIRED)
						&& CustomerMasterConstants.RETRY_PET_SOURCES
								.contains(customerMasterUpdateRequest
										.getSrcCode()
										+ ",")) {
					exceptionCode = CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET;
					throw new SystemException(
							CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET,
							e.getMessage());
				} else if (exceptionCode
						.equals(CustomerMasterConstants.EC_EXCEPTION_LOCK_IND_REQUIRED)
						&& CustomerMasterConstants.RETRY_LOCK_SOURCES
								.contains(customerMasterUpdateRequest
										.getSrcCode()
										+ ",")) {
					exceptionCode = CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET;
					throw new SystemException(
							CustomerMasterConstants.EC_EXCEPTION_RETRY_LOCK_PET,
							e.getMessage());
				} else {
					getWalgreensLogger().log(LoggingFacility.ERROR,
							e.getMessage());
					throw new SystemException(exceptionCode, e.getMessage());
				}
			} else {
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(
						CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e
								.getMessage());
			}
		} catch (BusinessRuleViolationException e) {
			throw e;
		} catch (Exception e) {
			throw new SystemException(
					CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, e
							.getMessage());
		}
	}

	
	/**
	 * @return the updateWSAO
	 */
	public ICustomerMasterUpdateWSAO getCustomerMasterUpdateWSAO() {
		return customerMasterUpdateWSAO;
	}


	/**
	 * @param customerMasterUpdateWSAO to set
	 */
	public void setCustomerMasterUpdateWSAO(ICustomerMasterUpdateWSAO customerMasterUpdateWSAO) {
		this.customerMasterUpdateWSAO = customerMasterUpdateWSAO;
	}
	/**
	 * This method calls the validation method validateRequiredFields and validateInvalidFieldValues
	 * (customerMasterUpdateRequest) for mandatory field validation
	 * 
	 * @param customerMasterUpdateRequest
	 * @return boolean
	 * @throws BusinessRuleViolationException
	 */

	public void validateRequestObject(
			CustomerMasterUpdateRequest customerMasterUpdateRequest)
			throws BusinessRuleViolationException {

		ValidateCustomerMasterRequest
				.validateRequiredFields(customerMasterUpdateRequest);
		ValidateCustomerMasterRequest
				.validateInvalidFieldValues(customerMasterUpdateRequest);
		
	}



}
