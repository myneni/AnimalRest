package com.walgreens.cdi.vo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.walgreens.cdi.vo.customer.attr.CustomerMasterDeceasedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEnterpriseSearchAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterGender;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterHubLinkageRec;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLockedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterOrigin;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPetInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterRefEIDLinkage;
//This VO class is used CustomerMasterEnterPriseSearch Response
public class CustomerMasterEnterpriseSearch {
	private String EID;
	private Date compositeDateTime = Calendar.getInstance().getTime();
	private String matchScore;
	private String memberStatus;
	private String srcCode;
	private String memberId;
	private CustomerMasterEnterpriseSearchAttr custAll = new CustomerMasterEnterpriseSearchAttr(
			false);
	private CustomerMasterGender gender;
	private CustomerMasterPetInd petInd;
	private CustomerMasterDeceasedInd deceasedInd;
	private CustomerMasterLockedInd lockedInd;
	private CustomerMasterHubLinkageRec hubLinkageRec;
	private String lastUpdateDate;
	private ArrayList<CustomerMasterEntSearchProgramVO> programArray = new ArrayList<CustomerMasterEntSearchProgramVO>();
	private ArrayList<CustomerMasterEntAttributesVO> attributeArray = new ArrayList<CustomerMasterEntAttributesVO>();
	private CustomerMasterRefEIDLinkage linkageRefEID;
	private CustomerMasterOrigin origin;
	private String secCode;

	public Date getCompositeDateTime() {
		return compositeDateTime;
	}

	public void setCompositeDateTime(Date compositeDateTime) {
		this.compositeDateTime = compositeDateTime;
	}

	public CustomerMasterEnterpriseSearchAttr getCustAll() {
		return custAll;
	}

	public void setCustAll(CustomerMasterEnterpriseSearchAttr custAll) {
		this.custAll = custAll;
	}

	public CustomerMasterDeceasedInd getDeceasedInd() {
		return deceasedInd;
	}

	public void setDeceasedInd(CustomerMasterDeceasedInd deceasedInd) {
		this.deceasedInd = deceasedInd;
	}

	public String getEID() {
		return EID;
	}

	public void setEID(String eid) {
		EID = eid;
	}

	public CustomerMasterGender getGender() {
		return gender;
	}

	public void setGender(CustomerMasterGender gender) {
		this.gender = gender;
	}

	public CustomerMasterLockedInd getLockedInd() {
		return lockedInd;
	}

	public void setLockedInd(CustomerMasterLockedInd lockedInd) {
		this.lockedInd = lockedInd;
	}

	public String getMatchScore() {
		return matchScore;
	}

	public void setMatchScore(String matchScore) {
		this.matchScore = matchScore;
	}

	public CustomerMasterPetInd getPetInd() {
		return petInd;
	}

	public void setPetInd(CustomerMasterPetInd petInd) {
		this.petInd = petInd;
	}

	public String getMemberStatus() {
		return memberStatus;
	}

	public void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}

	public ArrayList<CustomerMasterEntAttributesVO> getAttributeArray() {
		return attributeArray;
	}

	public void setAttributeArray(
			ArrayList<CustomerMasterEntAttributesVO> attributeArray) {
		this.attributeArray = attributeArray;
	}

	public ArrayList<CustomerMasterEntSearchProgramVO> getProgramArray() {
		return programArray;
	}

	public void setProgramArray(
			ArrayList<CustomerMasterEntSearchProgramVO> programArray) {
		this.programArray = programArray;
	}

	public void addProgramArray(
			ArrayList<CustomerMasterEntSearchProgramVO> programArray) {
		if (this.programArray == null) {
			this.programArray = new ArrayList<CustomerMasterEntSearchProgramVO>();
		}
		this.programArray.addAll(programArray);
	}

	public CustomerMasterHubLinkageRec getHubLinkageRec() {
		return hubLinkageRec;
	}

	public void setHubLinkageRec(CustomerMasterHubLinkageRec hubLinkageRec) {
		this.hubLinkageRec = hubLinkageRec;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getSrcCode() {
		return srcCode;
	}

	public void setSrcCode(String srcCode) {
		this.srcCode = srcCode;
	}
	/**
	 * @return the linkageRefEID
	 */
	public CustomerMasterRefEIDLinkage getLinkageRefEID() {
		return linkageRefEID;
	}
	/**
	 * @param linkageRefEID the linkageRefEID to set
	 */
	public void setLinkageRefEID(CustomerMasterRefEIDLinkage linkageRefEID) {
		this.linkageRefEID = linkageRefEID;
	}
	
	/**
	 * @return the origin
	 */
	public CustomerMasterOrigin getOrigin() {
		return origin;
	}
	/**
	 * @param origin the origin to set
	 */
	public void setOrigin(CustomerMasterOrigin origin) {
		this.origin = origin;
	}
	
	/**
	 * @return the lastUpdateDate
	 */
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}
	/**
	 * @param lastUpdateDate the lastUpdateDate to set
	 */
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	
	/**
	 * @return the secCode
	 */
	public String getSecCode() {
		return secCode;
	}
	/**
	 * @param secCode the secCode to set
	 */
	public void setSecCode(String secCode) {
		this.secCode = secCode;
	}

}
