/**
 * 
 */
package com.walgreens.cdi.vo.customer.attr;

import java.util.Date;

/**
 * @author Picketta
 *
 */
public class CustomerMasterAttributeStatus {
	private String   lastUpdateDate;		//Date/Time (0/1)	AllSource Perm LastUpdateDate for customer Name.
	private String securityClassCode;//String (0/1)	AllSource Perm SecurityClassCode for customer Name.
	private String sourceCode;		//String (0/1)	AllSource Perm SourceCode for customer Name.
	
	/**
	 * @return the lastUpdateDate
	 */
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}
	/**
	 * @param lastUpdateDate the lastUpdateDate to set
	 */
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	/**
	 * @return the securityClassCode
	 */
	public String getSecurityClassCode() {
		return securityClassCode;
	}
	/**
	 * @param securityClassCode the securityClassCode to set
	 */
	public void setSecurityClassCode(String securityClassCode) {
		this.securityClassCode = securityClassCode;
	}
	/**
	 * @return the sourceCode
	 */
	public String getSourceCode() {
		return sourceCode;
	}
	/**
	 * @param sourceCode the sourceCode to set
	 */
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	
	public String toString() {
		String str="";
		str = " lastUpdateDate    =" + lastUpdateDate + "\n"+
			  " securityClassCode   =" + securityClassCode + "\n" +
			  " sourceCode   =" + sourceCode + "\n" ;
					
         return str;
	}
	
}
