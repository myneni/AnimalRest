package com.walgreens.cdi.bo.impl;

import com.walgreens.cdi.util.CustomerMasterConstants;

import walgreens.services.LoggingFacility;
import walgreens.utils.logging.WalgreensLog4JImpl;

/**
 * This class is the base class for the business objects. All business objects
 * will extend this Base class. It contains log4j logging which can be directly
 * used by the inheriting classes
 * @author amal.arindam
 * @version 1.0
 */
public class BaseBO {

    /**
     * Referring to the WalgreensLog4JImpl
     */
    private WalgreensLog4JImpl walgreensLogger;
    private com.walgreens.cdi.util.LoggingHandler loggingHandlerObj; //Added For EIS Change
    /**
     * @return the walgreensLogger
     */
    public WalgreensLog4JImpl getWalgreensLogger() {
        return walgreensLogger;
    }


    /**
     * @param walgreensLogger
     *            the walgreensLogger to set
     */
    public void setWalgreensLogger(WalgreensLog4JImpl walgreensLogger) {
        this.walgreensLogger = walgreensLogger;
    }
   

	public com.walgreens.cdi.util.LoggingHandler getLoggingHandlerObj() {
		return loggingHandlerObj;
	}

	public void setLoggingHandlerObj(
			com.walgreens.cdi.util.LoggingHandler loggingHandlerObj) {
		this.loggingHandlerObj = loggingHandlerObj;
	} 
    
	 /**
    * This method sets the Error code  based on the type of
    * Exception which Initiate gives
    * @param exception
    * @return
    */
   public  String  getExceptionCode(Exception exception){
	   if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_BUCKETS_FOUND.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_NO_BUCKETS_FOUND;
       }
	   //@ANKIT - FOR EXCEPTION HANDLING Employee Benefits
       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_DETACH_PREVIOUS_CARD.trim())){
           return CustomerMasterConstants.LR_DETACH_PREVIOUS_PROGRAM;
       }
       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_DETACH_NOTEXIST_CARD.trim())){
           return CustomerMasterConstants.LR_DETACHING_NONEXISTING_PROGRAM;
       }
	   //ENDS
       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_CANDIDATES_FOUND.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_NO_CANDIDATES_FOUND;
       }
       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_LOCK_IND_REQUIRED.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_LOCK_IND_REQUIRED;
       }
       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_PET_IND_REQUIRED.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_PET_IND_REQUIRED;
       }
       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_SEC_CODE_REQUIRED.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_SEC_CODE_REQUIRED;
       }
       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_UPDATE_WILL_OCCUR.trim())){
           return CustomerMasterConstants.DO_NOT_THROW_EXCEPTION;
       }
       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_MEMBER_RECORD_FOUND.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_NO_CANDIDATES_FOUND;
       }
       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_COULD_NOT_SEND_MSG.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_COULD_NOT_SEND_MSG;
       }
       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_UNABLE_INS_UPD_1.trim())
    		   && exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_UNABLE_INS_UPD_2.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_UNABLE_INS_UPD;
       }
       // AP 05/03/2010 -- Unable to insert audit data error catch
       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_UNABLE_INSERT_AUDIT_DATA.trim())
    		   || exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_UNABLE_INSERT_AUDIT_DATA_2.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_UNABLE_INSERT_AUDIT_DATA;
       }
	   
	   // Added by Shruti - SIR# 2490	
       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_UNABLE_INS_UPD_DEL.trim()) || exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_MEMPUT_FAIL.trim())){
    	   getWalgreensLogger().log(LoggingFacility.ERROR, "Exception from InitiateWS:"+exception.getMessage());
           return CustomerMasterConstants.EC_EXCEPTION_UNABLE_INS_UPD;
       }
       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_HUB_MAY_BE_DOWN.trim())){
           return CustomerMasterConstants.EC_EXCEPTION_HUB_MAY_BE_DOWN;
       }
	   //Added  For Exception Handling For merged/Deleted Member
       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_UPDATE_MERGED_MEMBER)){
           return CustomerMasterConstants.DO_NOT_THROW_EXCEPTION;
       }
       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_UPDATE_DELTED_MEMBER)){
           return CustomerMasterConstants.DO_NOT_THROW_EXCEPTION;
       }
	   //	 END  For Exception Handling For merged/Deleted Member
	   //Ecomm Change Start
       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_CV_CONTROL_REQUIRED)){
           return CustomerMasterConstants.EC_EXCEPTION_CV_CONTROL_REQUIRED;
       }
	   ////Ecomm Change END
       else{
    	   getWalgreensLogger().log(LoggingFacility.ERROR, "Exception from InitiateWS:"+exception.getMessage());
    	   return CustomerMasterConstants.EC_UNKNOWN_EXCEPTION;
       }
   }

}
