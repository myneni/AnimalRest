package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateRequest;
import com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateResponse;
import com.walgreens.cdi.vo.CustomerMasterMemberIDRequest;
import com.walgreens.cdi.vo.CustomerMasterMemberIDResponse;


public interface ICustomerMasterEntMemberIdGenerateService {
	
	public CustomerMasterEntMemberIdGenerateResponse 
	generateCustomerEntMemberId(CustomerMasterEntMemberIdGenerateRequest customerMasterEntMemberIdGenerateRequest) throws CDIException;

}
