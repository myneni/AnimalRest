package com.walgreens.cdi.vo.customer.attr;
import com.walgreens.cdi.util.*;

public class CustomerMasterPhoneAttr extends CustomerMasterAttributeStatus {
	private String usageType;
	private String areaCode;
	private String phoneNumber;
	
	// Phone Alignment Changes start
	private String phonePriority;
	
	public String getPhonePriority() {
		return phonePriority;
	}

	public void setPhonePriority(String phonePriority) {
		this.phonePriority = phonePriority;
	}
	//Phone Alignment Changes End
	
	public CustomerMasterPhoneAttr(String usageType){
		super();
		this.usageType = usageType;
	}
	
	public CustomerMasterPhoneAttr(){
		super();
	}
	
	/**
	 * @return the areaCode
	 */
	public String getAreaCode() {
		return areaCode;
	}
	/**
	 * @param areaCode the areaCode to set
	 */
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 * @return the usageType
	 */
	public String getUsageType() {
		return usageType;
	}
	/**
	 * @param usageType the usageType to set
	 */
	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}
	
	public String toString() {
		String str = "";
	
		 str = "  UsageType :" + usageType + "\n" +
		 		" AreaCode :"  + areaCode + "\n" +
		 		" PhoneNumber :" + phoneNumber + "\n"+
		 		  " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
				  " securityClassCode   =" + getSecurityClassCode() + "\n" +
				  " sourceCode   =" + getSourceCode() + "\n" ;
			
		 
	
		return str;
	}
	public String toCompString() {
		String str="";
		str = CustomerMasterConstants.DELIMITE_FIELD +
		      usageType + CustomerMasterConstants.DELIMITE_FIELD +
		 	  areaCode + CustomerMasterConstants.DELIMITE_FIELD +
		 	  phoneNumber + CustomerMasterConstants.DELIMITE_FIELD +
		 	  getLastUpdateDate() + CustomerMasterConstants.DELIMITE_FIELD +
			  getSecurityClassCode()+ CustomerMasterConstants.DELIMITE_FIELD +
			  getSourceCode()+ CustomerMasterConstants.DELIMITE_FIELD ;
		
         return str;
	}
	
     public boolean isNull(){
		
		if(isNull(areaCode)&& isNull(phoneNumber))
				return true;
		else
			return false;
	}
	
	 private boolean isNull(String str){
		     if(str==null)
				return  true;
			if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
				return true;
			else
				return false;
		}
		
		
	
	
	
}
