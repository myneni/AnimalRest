package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterUnDeleteRequest;

/**
 * This service is an interface for exposing EC UnDelete method at service
 * level.
 * 
 * @param customerMasterUnDeleteRequest
 * @return boolean
 * @throws SystemException
 * @author
 * 
 */
public interface ICustomerMasterUnDeleteService {
	 boolean unDeleteCustomerMaster(
			CustomerMasterUnDeleteRequest customerMasterUnDeleteRequest)
			throws CDIException;

}
