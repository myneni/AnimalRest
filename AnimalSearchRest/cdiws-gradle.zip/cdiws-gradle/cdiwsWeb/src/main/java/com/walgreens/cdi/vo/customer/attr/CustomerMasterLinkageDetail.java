/**
 * 
 */
package com.walgreens.cdi.vo.customer.attr;

import com.walgreens.cdi.util.CustomerMasterConstants;


/**
 * @author Lzhang
 *
 */
public class CustomerMasterLinkageDetail {
		
	
	private String sourceID;
	private String sourceCode;
	private String status; 
	private String refID;
	private String refCode;
	public String getSourceID() {
		return sourceID;
	}
	public void setSourceID(String sourceID) {
		this.sourceID = sourceID;
	}
	public String getRefID() {
		return refID;
	}
	public void setRefID(String refID) {
		this.refID = refID;
	}
	public String getSourceCode() {
		return sourceCode;
	}
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	} 
	
	public String toString() {
		String str="";
		str = " sourceID    =" + sourceID + "\n" +
		      " sourceCode    =" + sourceCode + "\n" +
		      " status    =" + status + "\n" +
		      " refID    =" + refID + "\n" +
		      " refCode    =" + refCode + "\n";
		      ;
			
         return str;
	}
	
	public String toCompString() {
		
		String str="";
		str =  CustomerMasterConstants.DELIMITE_FIELD + 
		       sourceID +   CustomerMasterConstants.DELIMITE_FIELD +
		       sourceCode  + CustomerMasterConstants.DELIMITE_FIELD +
		       status +  CustomerMasterConstants.DELIMITE_FIELD +
		       refID +   CustomerMasterConstants.DELIMITE_FIELD +
		       refCode +   CustomerMasterConstants.DELIMITE_FIELD;
		    	
         return str;
	}
	public String getRefCode() {
		return refCode;
	}
	public void setRefCode(String refCode) {
		this.refCode = refCode;
	}
}
