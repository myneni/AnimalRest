package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterIcunmergeRequest;


public interface ICustomerMasterIcunmergeService {
	
	public boolean icunmergeCustomerMaster(CustomerMasterIcunmergeRequest customerMasterIcunmergeRequest) throws CDIException;
		

}
