package com.walgreens.cdi.vo;

/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author 
 * 
 */
public class CustomerMasterMergeVO {

	 //private java.lang.String entType;
	    private java.lang.String memIdnumObs;
	    private java.lang.String memIdnumSrv;
	  //  private java.lang.String memType;
	    private java.lang.String srcCodeObs;
	    private java.lang.String srcCodeSrv;
//	  User Name
		private String userNm;
		// User Password
		private String userPassword;
		
		
		/**
		 * 
		 * @return userNm
		 */
		public String getUserNm() {
			return userNm;
		}
		/**
		 * This method is used to set the user name
		 * @param userNm
		 */
		public void setUserNm(String userNm) {
			this.userNm = userNm;
		}
		/**
		 * 
		 * @return userPassword
		 */
		public String getUserPassword() {
			return userPassword;
		}
		/**
		 * This method is used to set the user password
		 * @param userPassword
		 */
		public void setUserPassword(String userPassword) {
			this.userPassword = userPassword;
		}
		
		
	    
	 /*   public java.lang.String getEntType() {
	        return entType;
	    }

	    public void setEntType(java.lang.String entType) {
	        this.entType = entType;
	    }*/

	    public java.lang.String getMemIdnumObs() {
	        return memIdnumObs;
	    }

	    public void setMemIdnumObs(java.lang.String memIdnumObs) {
	        this.memIdnumObs = memIdnumObs;
	    }

	    public java.lang.String getMemIdnumSrv() {
	        return memIdnumSrv;
	    }

	    public void setMemIdnumSrv(java.lang.String memIdnumSrv) {
	        this.memIdnumSrv = memIdnumSrv;
	    }

	   /* public java.lang.String getMemType() {
	        return memType;
	    }

	    public void setMemType(java.lang.String memType) {
	        this.memType = memType;
	    }*/

	    public java.lang.String getSrcCodeObs() {
	        return srcCodeObs;
	    }

	    public void setSrcCodeObs(java.lang.String srcCodeObs) {
	        this.srcCodeObs = srcCodeObs;
	    }

	    public java.lang.String getSrcCodeSrv() {
	        return srcCodeSrv;
	    }

	    public void setSrcCodeSrv(java.lang.String srcCodeSrv) {
	        this.srcCodeSrv = srcCodeSrv;
	    }

}
