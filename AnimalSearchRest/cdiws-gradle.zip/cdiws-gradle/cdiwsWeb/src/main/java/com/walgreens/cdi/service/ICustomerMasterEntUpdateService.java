package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterEntUpdateResponse;
import com.walgreens.cdi.vo.CustomerMasterUpdateRequest;


public interface ICustomerMasterEntUpdateService {
	
	public CustomerMasterEntUpdateResponse updateCustomerMasterEnt(CustomerMasterEntUpdateRequest lyUpdateRequest) throws CDIException ;
		

}
