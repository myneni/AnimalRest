package com.walgreens.cdi.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.regex.Pattern;

import com.initiate.bean.ArrayOfXsdString;
import com.walgreens.cdi.vo.TrackingInfoVO;

public class CustomerMasterUtility {

	public static boolean isEmpty(String str) {
		if (str == null)
			return true;
		if ("".equals(str.trim())) {
			return true;
		} else
			return false;
	}

	/**
	 * 
	 * @param strArray
	 * @return
	 */
	@SuppressWarnings("unused")
	public static ArrayOfXsdString getArrayOfXsdString(String[] strArray) {
		ArrayOfXsdString arr = new ArrayOfXsdString();
		arr.getItem().addAll(Arrays.asList(strArray));
		return arr;
	}

	@SuppressWarnings("unused")
	public static boolean isNull(String str) {

		if (str.equalsIgnoreCase("null") || str == null
				|| str.equalsIgnoreCase(""))
			return true;
		else
			return false;
	}

	public static boolean containsNonNumeric(String str) {
		if (Pattern.matches(".*[^0-9].*", str)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean containsNumeric(String str) {
		if (Pattern.matches(".*\\p{Digit}.*", str)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean containsNonAlphaCharacter(String str) {
		if (Pattern.matches(".*[^a-zA-Z].*", str)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean containsSpecialCharacter(String str) {
		if (Pattern.matches(".*[^a-zA-Z0-9].*", str)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean exceedsMaxLength(String str, int maxLength) {
		if (str.length() > maxLength) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean notAcceptableValue(String str, String acceptableStr) {
		if (!acceptableStr.contains(str.toUpperCase())) {
			return true;
		} else {
			return false;
		}
	}

	public static String getCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat(
				CustomerMasterConstants.DEFAULT_DATE_FORMAT);
		Date date = new Date();
		// System.out.println("Date :::::" + dateFormat.format(date));
		return dateFormat.format(date);

	}

	public static String getAttributeCodeFromProgramCode(String programCode) {
		String attrCode = "";
		if (null != programCode && (!(programCode == ""))) {
			programCode = programCode.toUpperCase();
			// System.out.println("Program Code in masterutil>>"+programCode);
			if (programCode.equals(CustomerMasterConstants.PROGRAMCODE_AARP)) {
				attrCode = CustomerMasterConstants.ATTR_CODE_AARP;
			} else if (programCode
					.equals(CustomerMasterConstants.PROGRAMCODE_EEDR)) {
				attrCode = CustomerMasterConstants.ATTR_CODE_EMPL;
			} else if (programCode
					.equals(CustomerMasterConstants.PROGRAMCODE_EEWAG)) {
				attrCode = CustomerMasterConstants.ATTR_CODE_EMPL;
			} else if (programCode
					.equals(CustomerMasterConstants.PROGRAMCODE_LYCD)) {
				attrCode = CustomerMasterConstants.ATTR_CODE_LYCD;
			}
			/*
			 * else
			 * if(programCode.equals(CustomerMasterConstants.PROGRAMCODE_PSC)) {
			 * attrCode=CustomerMasterConstants.ATTR_CODE_PSC; }
			 */
			else if (programCode
					.equals(CustomerMasterConstants.PROGRAMCODE_VCD)) {
				attrCode = CustomerMasterConstants.ATTR_CODE_VCD;
			}
			// @k@ for program GGPR
			else if (programCode
					.equals(CustomerMasterConstants.PROGRAMCODE_GGPR)) {
				attrCode = CustomerMasterConstants.ATTR_CODE_GGPR;
			}
			// @K@ ends
		}

		return attrCode;
	}

	public static String getProgramCodeFromAttributeCode(String attrCode) {
		String programCode = "";
		if (null != attrCode && (!(attrCode == "")))
			if (attrCode.equals(CustomerMasterConstants.ATTR_CODE_AARP)) {
				programCode = CustomerMasterConstants.PROGRAMCODE_AARP;
			} else if (attrCode.equals(CustomerMasterConstants.ATTR_CODE_EMPL)) {
				programCode = CustomerMasterConstants.PROGRAMCODE_EEDR;
			} else if (attrCode.equals(CustomerMasterConstants.ATTR_CODE_EMPL)) {
				programCode = CustomerMasterConstants.PROGRAMCODE_EEWAG;
			} else if (attrCode.equals(CustomerMasterConstants.ATTR_CODE_LYCD)) {
				programCode = CustomerMasterConstants.PROGRAMCODE_LYCD;
			}
			/*
			 * else if(attrCode.equals(CustomerMasterConstants.ATTR_CODE_PSC)) {
			 * programCode=CustomerMasterConstants.PROGRAMCODE_PSC; }
			 */
			else if (attrCode.equals(CustomerMasterConstants.ATTR_CODE_VCD)) {
				programCode = CustomerMasterConstants.PROGRAMCODE_VCD;
			}
			// @k@ added for GGPR
			else if (attrCode.equals(CustomerMasterConstants.ATTR_CODE_GGPR)) {
				programCode = CustomerMasterConstants.PROGRAMCODE_GGPR;
			}
		// @k@
		return programCode;
	}

	public boolean compareDate(String startDate, String endDate,
			String progLastUpdate) {
		boolean status = false;
		try {

			GregorianCalendar gcDate1 = new GregorianCalendar();
			GregorianCalendar gcDate2 = new GregorianCalendar();
			GregorianCalendar gcDate3 = new GregorianCalendar();

			String DATE_FORMAT = CustomerMasterConstants.PROGRAM_DATE_FORMAT;
			java.text.SimpleDateFormat convertedSDF = new SimpleDateFormat(
					CustomerMasterConstants.PROGRAM_DATE_FORMAT);
			convertedSDF.setTimeZone(TimeZone.getTimeZone("GMT"));

			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(
					DATE_FORMAT);

			Date date1 = sdf.parse(startDate);
			Date date2 = sdf.parse(endDate);
			Date date3 = sdf.parse(progLastUpdate);

			gcDate1.setTime(date1);
			gcDate2.setTime(date2);
			gcDate3.setTime(date3);
			try {
				date1 = sdf.parse(convertedSDF.format(gcDate1.getTime()));
				date2 = sdf.parse(convertedSDF.format(gcDate2.getTime()));
				date3 = sdf.parse(convertedSDF.format(gcDate3.getTime()));
			} catch (ParseException pex) {
				status = false;
			}

			if (date1.before(date2)) {
				status = true;
			} else
				status = false;
		} catch (Exception e) {
			status = false;
			// e.printStackTrace();
		}

		return status;
	}

	/*
	 * Method has created to handle soft delete of Birth Date for Enterprise
	 * Add/Update Service.
	 */

	public boolean hasSoftDeleteKey(String str) {
		if (!CustomerMasterUtility.isEmpty(str)
				&& str.equals(CustomerMasterConstants.SOFT_DELETE_CODE)) {
			return true;
		} else {
			return false;
		}
	}

	// Method to generate check digit from LuhModTenAlgo
	public static int getCheckDigitValueFromLuhModTenAlgo(String mAccountNumber) {
		//Code change start to be compatible with Java8 Start. mAccountNumber will be always 9 digit string
		//String[] acctNoStrAr = mAccountNumber.split("");
		String[] acctNoStrAr = new String[mAccountNumber.length()];
	    for(int i = 0; i < mAccountNumber.length(); i++)
	    {
	    	acctNoStrAr[i] = String.valueOf(mAccountNumber.charAt(i));
	    }
	    //Code change END to be compatible with Java8 
		int result = -99;
		try {
			result = Integer.parseInt(acctNoStrAr[0])
					+ calcDoubledValues(acctNoStrAr[1])
					+ Integer.parseInt(acctNoStrAr[2])
					+ calcDoubledValues(acctNoStrAr[3])
					+ Integer.parseInt(acctNoStrAr[4])
					+ calcDoubledValues(acctNoStrAr[5])
					+ Integer.parseInt(acctNoStrAr[6])
					+ calcDoubledValues(acctNoStrAr[7])
					+ Integer.parseInt(acctNoStrAr[8]);

		} catch (NullPointerException npe) {
			System.out.println("Failed on NPE (" + mAccountNumber + "): "
					+ npe.getMessage());
		} catch (Exception e) {
			System.out.println("Failed (" + mAccountNumber + "): "
					+ e.getMessage());
		}
		int remainder = result % 10;
		if (remainder == 0) {
			return remainder;
		} else {
			return 10 - remainder;
		}

	}

	/*
	 * Following method will calculateDouble values of passed parameter which is
	 * used in checkkDigit Value geneartion - LR Addd update
	 */
	public static int calcDoubledValues(String mVal) {

		// logger.log(Level.DEBUG, "Inside calcDoubledValues method" + mVal);
		int doubleValue = Integer.valueOf(mVal) * 2;
		int returnValue = 0;
		try {
			while (doubleValue > 0) {
				int temp = doubleValue % 10;
				returnValue = returnValue + temp;
				doubleValue = doubleValue / 10;
			}

		} catch (NullPointerException npe) {
			System.out.println("Failed calcDoubledValues npe (" + mVal + "): "
					+ npe.getMessage());
			// npe.printStackTrace();
		} catch (Exception e) {
			System.out.println("Failed calcDoubledValues: " + e.getMessage());
			// e.printStackTrace();
		}
		return returnValue;
	}

	/* Method will return dynamic Virtual Card Number based on LuhMod10Algo Algo */
	public static String generateDynamicVirtualCardNumber(String Sequencer_VCD) {
		String cardRange = CustomerMasterConstants.VCD_CARD_RANGE;
		int checkDigit = 0;
		String loyalyCardNumberFromSequence = Sequencer_VCD;
		try {

			if (loyalyCardNumberFromSequence.length() < CustomerMasterConstants.GENERATED_NO_LEN) {
				int len = loyalyCardNumberFromSequence.length();
				len = CustomerMasterConstants.GENERATED_NO_LEN - len;
				for (int i = 0; i < len; i++) {
					loyalyCardNumberFromSequence = "0"
							+ loyalyCardNumberFromSequence;
				}

			}
			checkDigit = getCheckDigitValueFromLuhModTenAlgo(loyalyCardNumberFromSequence);	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		return (cardRange + loyalyCardNumberFromSequence + String
				.valueOf(checkDigit));
	}
	
	/**
	 * Log Enhancement change: Method to generate log string using
	 * exArgs|correlationID|MessageID|FilreName
	 * 
	 * @param trackingInfoVO
	 * @param exArgs
	 * @param filterName
	 * @return
	 */
	public static String generateLogString(TrackingInfoVO trackingInfoVO,
			String exArgs, String filterName) {
		StringBuffer logString = new StringBuffer();
		return (logString.append(exArgs).append(
				CustomerMasterConstants.PIPE_DELIMITER).append(
				trackingInfoVO.getCorrelationID()).append(
				CustomerMasterConstants.PIPE_DELIMITER).append(
				trackingInfoVO.getMessageID()).append(
				CustomerMasterConstants.PIPE_DELIMITER).append(filterName))
				.toString();
	}
}
