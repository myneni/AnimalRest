package com.walgreens.cdi.vo;

import com.walgreens.cdi.vo.customer.CustomerMaster;


/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author 
 * 
 */
public class CustomerMasterResponse {
	private CustomerMaster cdiCustomer = new CustomerMaster();
	private String addCriteriaFlag;

	/**
	 * @return the cdiCustomer
	 */
	public CustomerMaster getCdiCustomer() {
		return cdiCustomer;
	}

	/**
	 * @param cdiCustomer the cdiCustomer to set
	 */
	public void setCdiCustomer(CustomerMaster cdiCustomer) {
		this.cdiCustomer = cdiCustomer;
	}

	public String getAddCriteriaFlag() {
		return addCriteriaFlag;
	}

	public void setAddCriteriaFlag(String addCriteriaFlag) {
		this.addCriteriaFlag = addCriteriaFlag;
	}
	
	
	
}
