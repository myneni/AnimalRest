package com.walgreens.cdi.service.impl;

///////////////////////////////////////////////////////////////////
// Remove before deploying
import walgreens.services.LoggingFacility;

import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.bo.ICustomerMasterEntLookUpBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterEntLookUpService;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfEntCustomer;



public class CustomerMasterEntLookUpService extends BaseService  implements ICustomerMasterEntLookUpService{
	
	private ICustomerMasterEntLookUpBO customerMasterEntLookUpBO;
	
	
public ArrayOfEntCustomer lookUpCustomerMasterEnt(CustomerMasterEntLookUpRequest customerMasterLookUpRequest) throws CDIException{
		
		//System.out.println("Start Calling CustomerMasterEntLookUpService::lookUpCustomerMasterEnt() method");
		ArrayOfEntCustomer arrayEntCustomer=new ArrayOfEntCustomer();
		try{

			//return getCustomerMasterEntLookUpBO().lookUpCustomerMasterEnt(customerMasterLookUpRequest);
			arrayEntCustomer=getCustomerMasterEntLookUpBO().lookUpCustomerMasterEnt(customerMasterLookUpRequest);
		} catch (CDIException e) {
            	getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return null;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
		return arrayEntCustomer;
}


public ICustomerMasterEntLookUpBO getCustomerMasterEntLookUpBO() {
	return customerMasterEntLookUpBO;
}


public void setCustomerMasterEntLookUpBO(
		ICustomerMasterEntLookUpBO customerMasterEntLookUpBO) {
	this.customerMasterEntLookUpBO = customerMasterEntLookUpBO;
}




	
	


}
