package com.walgreens.cdi.dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterLookUpVO;
import com.walgreens.cdi.vo.customer.CustomerMaster;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddress;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttrNCOA;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterBirthDate;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterDeceasedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterEmail;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterGender;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLockedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterName;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterOrigin;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPetInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPhone;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPhoneAttr;

public class CustomerMasterLookUpRowsMapper implements ParameterizedRowMapper<CustomerMasterLookUpVO>{
	
	String globalSQL = null;
	long lastTime = 0L;
	public CustomerMasterLookUpRowsMapper(){
	}
	
	public CustomerMasterLookUpRowsMapper(String sql, long st){
		globalSQL = sql;
		lastTime = st;
	}

	public CustomerMasterLookUpVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerMasterLookUpVO oRecord = null;
		try
		{
		CustomerMaster customer = new CustomerMaster();
		CustomerMasterAttr custAll = new CustomerMasterAttr();
		
//		Set Name
		CustomerMasterName name = new CustomerMasterName();
		name.setFirstName(rs.getString("FIRSTNAME")!=null?rs.getString("FIRSTNAME"):"");
		name.setMiddleName(rs.getString("MIDDLENAME")!=null?rs.getString("MIDDLENAME"):"");
		name.setLastName(rs.getString("LASTNAME")!=null?rs.getString("LASTNAME"):"");
		name.setPrefixName(rs.getString("PrefixName")!=null?rs.getString("PrefixName"):"");	
		name.setSuffixName(rs.getString("SUFFIXNAME")!=null?rs.getString("SuffixName"):"");	
		name.setLastUpdateDate(rs.getString("NameUpdate")!=null?rs.getString("NameUpdate"):"");
		name.setSourceCode(rs.getString("NamSrcCode")!=null?rs.getString("NamSrcCode"):"");
		name.setSecurityClassCode(rs.getString("NamSecCode")!=null?rs.getString("NamSecCode"):"");
		
		if (!name.isNull()){
			custAll.setName(name);
		}
		//set Gender				
		CustomerMasterGender gender = new CustomerMasterGender();
		gender.setSecurityClassCode(rs.getString("GenderSecCode")!=null?rs.getString("GenderSecCode"):"");
		gender.setGenderCode(rs.getString("Gender")!=null?rs.getString("Gender"):"");
		gender.setLastUpdateDate(rs.getString("GenderUpdate")!=null?rs.getString("GenderUpdate"):"");
		gender.setSourceCode(rs.getString("GenderSrcCode")!=null?rs.getString("GenderSrcCode"):"");
		
		if(!gender.isNull()){
			customer.setGender(gender);
		}
		//PETIND
		CustomerMasterPetInd petInd = new CustomerMasterPetInd();
		petInd.setPetIndicator(rs.getString("PetInd")!=null?rs.getString("PetInd"):"");
		petInd.setLastUpdateDate(rs.getString("PetUpdate")!=null?rs.getString("PetUpdate"):"");
		petInd.setSecurityClassCode(rs.getString("PetSecCode")!=null?rs.getString("PetSecCode"):"");
		petInd.setSourceCode(rs.getString("PetSrcCode")!=null?rs.getString("PetSrcCode"):"");
		if(!petInd.isNull()){
			customer.setPetInd(petInd);
		}
		//DeceasedIND
		CustomerMasterDeceasedInd deceasedInd = new CustomerMasterDeceasedInd();
		deceasedInd.setDeceasedIndicator(rs.getString("DeathInd")!=null?rs.getString("DeathInd"):"");
		deceasedInd.setLastUpdateDate(rs.getString("DeathUpdate")!=null?rs.getString("DeathUpdate"):"");
		deceasedInd.setSecurityClassCode(rs.getString("DeathSecCode")!=null?rs.getString("DeathSecCode"):"");
		deceasedInd.setSourceCode(rs.getString("DeathSrcCode")!=null?rs.getString("DeathSrcCode"):"");
		if(!deceasedInd.isNull()){
			customer.setDeceasedInd(deceasedInd);
		}
		//EMAIL
		CustomerMasterEmail customerEmail = new CustomerMasterEmail();
		customerEmail.setEmailAddress(rs.getString("Email")!=null?rs.getString("Email"):"");
		//customerEmail.setEmailUsageType(rs.getString("EmailTYPE"));
		customerEmail.setLastUpdateDate(rs.getString("EmailUpdate")!=null?rs.getString("EmailUpdate"):"");
		customerEmail.setSecurityClassCode(rs.getString("EmailSecCode")!=null?rs.getString("EmailSecCode"):"");
		customerEmail.setSourceCode(rs.getString("EmailSrcCode")!=null?rs.getString("EmailSrcCode"):"");
		if(!customerEmail.isNull()){
			custAll.setEmail(customerEmail);
		}
		//LOCKIND
		CustomerMasterLockedInd lockedInd = new CustomerMasterLockedInd();
		lockedInd.setLockedIndicator(rs.getString("LockInd")!=null?rs.getString("LockInd"):"");
		lockedInd.setLastUpdateDate(rs.getString("LockUpdate")!=null?rs.getString("LockUpdate"):"");
		lockedInd.setSecurityClassCode(rs.getString("LockSecCode")!=null?rs.getString("LockSecCode"):"");
		lockedInd.setSourceCode(rs.getString("LockSrcCode")!=null?rs.getString("LockSrcCode"):"");
		if(!lockedInd.isNull()){
			customer.setLockedInd(lockedInd);
		}	
	   //BIRTHDT
		CustomerMasterBirthDate customerBirthDate = new CustomerMasterBirthDate();
		customerBirthDate.setBirthdate(rs.getString("BirthDate")!=null?rs.getString("BirthDate"):"");
		customerBirthDate.setLastUpdateDate(rs.getString("BirthUpdate")!=null?rs.getString("BirthUpdate"):"");
		customerBirthDate.setSecurityClassCode(rs.getString("BirthSecCode")!=null?rs.getString("BirthSecCode"):"");
		customerBirthDate.setSourceCode(rs.getString("BirthSrcCode")!=null?rs.getString("BirthSrcCode"):"");
		if(!customerBirthDate.isNull()){
			custAll.setBirthDate(customerBirthDate);
		}
		//CUSTORGN
		
		CustomerMasterOrigin origin = new CustomerMasterOrigin();
		origin.setOriginCode(rs.getString("STOREORIG")!=null?rs.getString("STOREORIG"):"");
		origin.setStoreIndicator(rs.getString("STOREIND")!=null?rs.getString("STOREIND"):"");
		origin.setLastUpdateDate(rs.getString("STOREUPDATE")!=null?rs.getString("STOREUPDATE"):"");
		origin.setSecurityClassCode(rs.getString("STORESECCODE")!=null?rs.getString("STORESECCODE"):"");
		origin.setSourceCode(rs.getString("STORESRCCODE")!=null?rs.getString("STORESRCCODE"):"");
		if(!origin.isNull()){
			customer.setOrigin(origin);
		}
	//Address
		CustomerMasterAddress address = new CustomerMasterAddress();
		//PRADDR
		CustomerMasterAddressAttrNCOA permAddress = new CustomerMasterAddressAttrNCOA(CustomerMasterConstants.CM_ADDRESS_TYPE_P);
		permAddress.setAddressUsageType(rs.getString("AddrType")!=null?rs.getString("AddrType"):"");
		permAddress.setCASSFootnote(rs.getString("PFTNOTE")!=null?rs.getString("PFTNOTE"):"");
		permAddress.setCity(rs.getString("PCUSTCITY")!=null?rs.getString("PCUSTCITY"):"");
		permAddress.setCountry(rs.getString("PCUSTCOUNTRY")!=null?rs.getString("PCUSTCOUNTRY"):"");
		permAddress.setDPVFootnote(rs.getString("PDPVFTNOTE")!=null?rs.getString("PDPVFTNOTE"):"");
		permAddress.setDPVIndicator(rs.getString("PDPVIND")!=null?rs.getString("PDPVIND"):"");
		permAddress.setLACSAddressFlag(rs.getString("PLACSADDRFLAG")!=null?rs.getString("PLACSADDRFLAG"):"");
		permAddress.setLACSFootnote(rs.getString("PLACSFTNOTE")!=null?rs.getString("PLACSFTNOTE"):"");
		permAddress.setLACSReturnCode(rs.getString("PLACSRTRNCODE")!=null?rs.getString("PLACSRTRNCODE"):"");
		permAddress.setLastUpdateDate(rs.getString("PAddrUpdate")!=null?rs.getString("PAddrUpdate"):"");
		permAddress.setLatitude(rs.getString("PLATITUDE")!=null?rs.getString("PLATITUDE"):"");
		permAddress.setLongitude(rs.getString("PLONGITUDE")!=null?rs.getString("PLONGITUDE"):"");
		permAddress.setNCOAActionCode(rs.getString("PNcoaActCode")!=null?rs.getString("PNcoaActCode"):"");
	    permAddress.setNCOAANKCode(rs.getString("PNcoaAnkCode")!=null?rs.getString("PNcoaAnkCode"):"");
	    permAddress.setNCOAMoveDate(rs.getString("PNcoaMvDate")!=null?rs.getString("PNcoaMvDate"):"");
	    permAddress.setNCOAMoveType(rs.getString("PNcoaMvTYPE")!=null?rs.getString("PNcoaMvTYPE"):"");	    
	    permAddress.setNCOANewAddressFlag(rs.getString("PNcoaNewADDRFLG")!=null?rs.getString("PNcoaNewADDRFLG"):"");
	    permAddress.setNCOANIXIEFootnote(rs.getString("PNcoaNixFtNote")!=null?rs.getString("PNcoaNixFtNote"):"");
	    permAddress.setNCOAProcessDate(rs.getString("PNCoaPrDate")!=null?rs.getString("PNCoaPrDate"):"");
	    permAddress.setNCOAReturnCode(rs.getString("PNcoaRTrnCode")!=null?rs.getString("PNcoaRTrnCode"):"");
	    permAddress.setSecurityClassCode(rs.getString("PAddrSEcCode")!=null?rs.getString("PAddrSEcCode"):"");
	    permAddress.setSourceCode(rs.getString("PAddrSrcCode")!=null?rs.getString("PAddrSrcCode"):"");
	    permAddress.setStandardizationProcessDate(rs.getString("PPRDATE")!=null?rs.getString("PPRDATE"):"");
	    permAddress.setState(rs.getString("PCUSTSTATE")!=null?rs.getString("PCUSTSTATE"):"");
	    permAddress.setStreetLine1(rs.getString("PCUSTSTLINE1")!=null?rs.getString("PCUSTSTLINE1"):"");
	    permAddress.setStreetLine2(rs.getString("PCUSTSTLINE2")!=null?rs.getString("PCUSTSTLINE2"):"");
	    permAddress.setUrbanizationCode(rs.getString("PURBCODE")!=null?rs.getString("PURBCODE"):"");
	    permAddress.setUSPSAddressType(rs.getString("PADDRTYPE")!=null?rs.getString("PADDRTYPE"):"");
	    permAddress.setZipCode(rs.getString("PCUSTZIPCODE")!=null?rs.getString("PCUSTZIPCODE"):"");
	    if(!permAddress.isNull()){
	    	address.setPermAddress(permAddress);
	    }
	    //PRADDR2
	    CustomerMasterAddressAttr home2Address = new CustomerMasterAddressAttr(CustomerMasterConstants.CM_ADDRESS_TYPE_2);
	    home2Address.setAddressUsageType(rs.getString("ADDRTYPE2")!=null?rs.getString("ADDRTYPE2"):"");
	    home2Address.setCASSFootnote(rs.getString("HFTNOTE")!=null?rs.getString("HFTNOTE"):"");
	    home2Address.setCity(rs.getString("HCustCity")!=null?rs.getString("HCustCity"):"");
	    home2Address.setCountry(rs.getString("HCustCountry")!=null?rs.getString("HCustCountry"):"");
		home2Address.setDPVFootnote(rs.getString("HdpvftNote")!=null?rs.getString("HdpvftNote"):"");
		home2Address.setDPVIndicator(rs.getString("HDpvInd")!=null?rs.getString("HDpvInd"):"");
		home2Address.setLACSAddressFlag( rs.getString("HLacsAddrFlag")!=null?rs.getString("HLacsAddrFlag"):"");
		home2Address.setLACSFootnote(rs.getString("HLacsFtNote")!=null?rs.getString("HLacsFtNote"):"");
		home2Address.setLACSReturnCode(rs.getString("HLacsRtrnCode")!=null?rs.getString("HLacsRtrnCode"):"");		
	    home2Address.setLastUpdateDate(rs.getString("HADDRUPDATE")!=null?rs.getString("HADDRUPDATE"):"");
		home2Address.setLongitude(rs.getString("HLongitude")!=null?rs.getString("HLongitude"):"");
		home2Address.setLatitude(rs.getString("HLATITUDE")!=null?rs.getString("HLATITUDE"):"");
		home2Address.setSecurityClassCode(rs.getString("HADDRSECCODE")!=null?rs.getString("HADDRSECCODE"):"");
		home2Address.setSourceCode(rs.getString("HADDRSRCCODE")!=null?rs.getString("HADDRSRCCODE"):"");
		home2Address.setStandardizationProcessDate(rs.getString("HPRDATE")!=null?rs.getString("HPRDATE"):"");
	    home2Address.setStreetLine1(rs.getString("HCustStLine1")!=null?rs.getString("HCustStLine1"):"");
		home2Address.setStreetLine2(rs.getString("HCustStLine2")!=null?rs.getString("HCustStLine2"):"");		
		home2Address.setState(rs.getString("HCustState")!=null?rs.getString("HCustState"):"");
		home2Address.setUrbanizationCode(rs.getString("HURBCODE")!=null?rs.getString("HURBCODE"):"");
		home2Address.setUSPSAddressType(rs.getString("HADDRTYPE")!=null?rs.getString("HADDRTYPE"):"");
		home2Address.setZipCode(rs.getString("HCustZipCode")!=null?rs.getString("HCustZipCode"):"");
		if(!home2Address.isNull()){
			address.setHome2Address(home2Address);
		}
		//WORKADDR
		CustomerMasterAddressAttr workAddress = new CustomerMasterAddressAttr(CustomerMasterConstants.CM_ADDRESS_TYPE_W);
		workAddress.setAddressUsageType(rs.getString("ADDRTYPE3")!=null?rs.getString("ADDRTYPE3"):"");
		workAddress.setCASSFootnote(rs.getString("WFTNOTE")!=null?rs.getString("WFTNOTE"):"");
		workAddress.setCity(rs.getString("WCUSTCITY")!=null?rs.getString("WCUSTCITY"):"");
		workAddress.setCountry(rs.getString("WCUSTCOUNTRY")!=null?rs.getString("WCUSTCOUNTRY"):"");
		workAddress.setDPVFootnote(rs.getString("WDPVFTNOTE")!=null?rs.getString("WDPVFTNOTE"):"");
		workAddress.setDPVIndicator(rs.getString("WDPVIND")!=null?rs.getString("WDPVIND"):"");
		workAddress.setLACSAddressFlag(rs.getString("WLACSADDRFLAG")!=null?rs.getString("WLACSADDRFLAG"):"");
		workAddress.setLACSFootnote(rs.getString("WLACSFTNOTE")!=null?rs.getString("WLACSFTNOTE"):"");
		workAddress.setLACSReturnCode(rs.getString("WLACSRTRNCODE")!=null?rs.getString("WLACSRTRNCODE"):"");
		workAddress.setLastUpdateDate(rs.getString("WADDRUPDATE")!=null?rs.getString("WADDRUPDATE"):"");
		workAddress.setLatitude(rs.getString("WLATITUDE")!=null?rs.getString("WLATITUDE"):"");
		workAddress.setLongitude(rs.getString("WLONGITUDE")!=null?rs.getString("WLONGITUDE"):"");
		workAddress.setSecurityClassCode(rs.getString("WADDRSECCODE")!=null?rs.getString("WADDRSECCODE"):"");
		workAddress.setSourceCode(rs.getString("WADDRSRCCODE")!=null?rs.getString("WADDRSRCCODE"):"");
		workAddress.setStandardizationProcessDate(rs.getString("WPRDATE")!=null?rs.getString("WPRDATE"):"");
		workAddress.setState(rs.getString("WCUSTSTATE")!=null?rs.getString("WCUSTSTATE"):"");
		workAddress.setStreetLine1(rs.getString("WCUSTSTLINE1")!=null?rs.getString("WCUSTSTLINE1"):"");
		workAddress.setStreetLine2(rs.getString("WCUSTSTLINE2")!=null?rs.getString("WCUSTSTLINE2"):"");
		workAddress.setUrbanizationCode(rs.getString("WURBCODE")!=null?rs.getString("WURBCODE"):"");
		workAddress.setUSPSAddressType(rs.getString("WADDRTYPE")!=null?rs.getString("WADDRTYPE"):"");
		workAddress.setZipCode(rs.getString("WCUSTZIPCODE")!=null?rs.getString("WCUSTZIPCODE"):"");
		if(!workAddress.isNull()){
			address.setWorkAddress(workAddress);
		}
		custAll.setAddress(address);
		
		CustomerMasterPhone phone = new CustomerMasterPhone();
	
		//cellPHONE
			CustomerMasterPhoneAttr cellPhone = new CustomerMasterPhoneAttr(
					CustomerMasterConstants.CM_PHONE_TYPE_C);
			cellPhone.setUsageType(populateValue(rs
					.getString(CustomerMasterConstants.CPHTYPE)));
			cellPhone.setAreaCode(populateValue(rs
					.getString(CustomerMasterConstants.CPHAREA)));
			cellPhone.setPhoneNumber(populateValue(rs
					.getString(CustomerMasterConstants.CPHNUMBER)));
			cellPhone.setLastUpdateDate(populateValue(rs
					.getString(CustomerMasterConstants.CPHUPDATE)));
			cellPhone.setSourceCode(populateValue(rs
					.getString(CustomerMasterConstants.CPHSRCCODE)));
			cellPhone.setSecurityClassCode(populateValue(rs
					.getString(CustomerMasterConstants.CPHSECCODE)));
			cellPhone
					.setPhonePriority(rs
							.getString(CustomerMasterConstants.CPHPRIORITY) != null ? rs
							.getString(CustomerMasterConstants.CPHPRIORITY)
							: CustomerMasterConstants.PRIOR_PRIMARY);
			if (!cellPhone.isNull()) {
				phone.setCellPhone(cellPhone);
			}
			
				// PRPHONE
			CustomerMasterPhoneAttr homePhone = new CustomerMasterPhoneAttr(
					CustomerMasterConstants.CM_PHONE_TYPE_H);
			homePhone.setUsageType(populateValue(rs
					.getString(CustomerMasterConstants.HPHTYPE)));
			homePhone.setAreaCode(populateValue(rs
					.getString(CustomerMasterConstants.HPHAREA)));
			homePhone.setPhoneNumber(populateValue(rs
					.getString(CustomerMasterConstants.HPHNUMBER)));
			homePhone.setLastUpdateDate(populateValue(rs
					.getString(CustomerMasterConstants.HPHUPDATE)));
			homePhone.setSourceCode(populateValue(rs
					.getString(CustomerMasterConstants.HPHSRCCODE)));
			homePhone.setSecurityClassCode(populateValue(rs
					.getString(CustomerMasterConstants.HPHSECCODE)));
			homePhone
					.setPhonePriority(rs
							.getString(CustomerMasterConstants.HPHPRIORITY) != null ? rs
							.getString(CustomerMasterConstants.HPHPRIORITY)
							: (cellPhone.isNull() ? CustomerMasterConstants.PRIOR_PRIMARY
									: CustomerMasterConstants.PRIOR_ALT1));
			if (!homePhone.isNull()) {
				phone.setHomePhone(homePhone);
			}
			
		// WKPHONE
			CustomerMasterPhoneAttr workPhone = new CustomerMasterPhoneAttr(
					CustomerMasterConstants.CM_PHONE_TYPE_W);
			workPhone.setUsageType(populateValue(rs
					.getString(CustomerMasterConstants.WPHTYPE)));
			workPhone.setAreaCode(populateValue(rs
					.getString(CustomerMasterConstants.WPHAREA)));
			workPhone.setPhoneNumber(populateValue(rs
					.getString(CustomerMasterConstants.WPHNUMBER)));
			workPhone.setLastUpdateDate(populateValue(rs
					.getString(CustomerMasterConstants.WPHUPDATE)));
			workPhone.setSourceCode(populateValue(rs
					.getString(CustomerMasterConstants.WPHSRCCODE)));
			workPhone.setSecurityClassCode(populateValue(rs
					.getString(CustomerMasterConstants.WPHSECCODE)));
			// Phone Alignment Change
			String wphPrior = rs.getString(CustomerMasterConstants.WPHPRIORITY);
			if (wphPrior != null)
				workPhone.setPhonePriority(wphPrior);
			else if (!cellPhone.isNull() && !homePhone.isNull()) {
				workPhone.setPhonePriority(CustomerMasterConstants.PRIOR_ALT2);
			} else if (cellPhone.isNull() && homePhone.isNull()) {
				workPhone
						.setPhonePriority(CustomerMasterConstants.PRIOR_PRIMARY);
			} else {
				workPhone.setPhonePriority(CustomerMasterConstants.PRIOR_ALT1);
			}
			
			if (!workPhone.isNull()) {
				phone.setWorkPhone(workPhone);
			}
		custAll.setPhone(phone);
		customer.setCustAll(custAll);
		customer.setEID(rs.getString("ENTITYID"));
		customer.setGender(gender);
		customer.setLockedInd(lockedInd);
		customer.setSecCode("H"); //No Info Available-- Put "H" as per Larry
		
		oRecord = new CustomerMasterLookUpVO();
		
		oRecord.setCdiCustomer(customer);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return oRecord;		
		
	}
	private static String populateValue(String colValue) {
		if (colValue != null)
			return colValue;
		else
			return CustomerMasterConstants.BLANK_STRING;
	}

}
