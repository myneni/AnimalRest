package com.walgreens.cdi.vo.customer.attr;
import com.walgreens.cdi.util.CustomerMasterConstants;


public class CustomerMasterLockedInd extends CustomerMasterAttributeStatus {
	//	 (Deceased Indicator attribute)		
	private String lockedIndicator;					//Date (0/1)	Composite customer DeceasedIndicator.

	/**
	 * @return the lockedIndicator
	 */
	public String getLockedIndicator() {
		return lockedIndicator;
	}

	/**
	 * @param lockedIndicator the lockedIndicator to set
	 */
	public void setLockedIndicator(String custDeceasedIndicator) {
		this.lockedIndicator = custDeceasedIndicator;
	}
	
	public String toString() {
		String str="";
		str = "\nLockedIndicator:\n____________________________________\n"+
		      " lockedIndicator    =" + lockedIndicator + "\n" +
		      " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
			  " securityClassCode   =" + getSecurityClassCode() + "\n" +
			  " sourceCode   =" + getSourceCode() + "\n" ;
		
					
         return str;
	}
	
	public String toCompString() {
		String str="";
		 str = CustomerMasterConstants.DELIMITE_ATTR +
		   CustomerMasterConstants.COMP_ATTR_NAME_Lock+ CustomerMasterConstants.DELIMITE_FIELD +
		   lockedIndicator + CustomerMasterConstants.DELIMITE_FIELD +
		   getLastUpdateDate() + CustomerMasterConstants.DELIMITE_FIELD +
		   getSecurityClassCode() + CustomerMasterConstants.DELIMITE_FIELD +
		   getSourceCode() + CustomerMasterConstants.DELIMITE_FIELD ;
		
					
         return str;
	}
         
         public boolean isNull(){
 			
 			if(isNull(lockedIndicator))
 					return true;
 			else
 				return false;
 		}
 		
 		 private boolean isNull(String str){
 		     	if(str==null)
				   return  true;
 				if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
 					return true;
 				else
 					return false;
 			}

	
	

}
