package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterUnDeleteRequest;

/**
 * This bo is an interface for exposing EC UnDelete method at BO level.
 * 
 * @param customerMasterUnDeleteRequest
 * @return boolean
 * @throws SystemException
 * @throws BusinessRuleViolationException
 */
public interface ICustomerMasterUnDeleteBO {

	 boolean unDeleteCustomerMaster(
			CustomerMasterUnDeleteRequest custUndelReq)
			throws SystemException, BusinessRuleViolationException;

}
