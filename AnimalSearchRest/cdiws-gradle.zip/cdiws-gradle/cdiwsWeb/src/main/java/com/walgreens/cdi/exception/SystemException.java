package com.walgreens.cdi.exception;

/**
 * This exception is thrown for all other exceptions other than
 * BusinessRuleViolation Exception
 * @author amal.arindam
 */
public class SystemException extends CDIException {
    /**
     * 
     */
    private static final long serialVersionUID = -8014078630711757921L;

    private Exception actualException;
    
  
    /**
     * No arg constructor
     */
    public SystemException(Exception e) {
        this.actualException = e;
    }
    
    
    public SystemException(String errorCode,  String detailedMessage) {
        super(errorCode, detailedMessage);
    }
    
    public SystemException(String errorCode, String detailMessage, String message) {
        super(errorCode,detailMessage,message);
        this.errorCode=errorCode;   
    }

    public Exception getException() {
        return actualException;
    }

      
    
}
