package com.walgreens.cdi.service.impl;

///////////////////////////////////////////////////////////////////
// Remove before deploying

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.util.Domain;

import com.walgreens.cdi.bo.ICustomerMasterLookUpBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterLookUpService;
import com.walgreens.cdi.vo.CustomerMasterLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfCustomer;

/**
 * This service class will handle any exception thrown from BO layer , or else
 * return the Response of lookUp of CustomerMaster.
 * 
 * @author
 * 
 */

public class CustomerMasterLookUpService extends BaseService  implements ICustomerMasterLookUpService{
	
	private ICustomerMasterLookUpBO customerMasterLookUpBO;
	
	
public ArrayOfCustomer lookUpCustomerMaster(CustomerMasterLookUpRequest customerMasterLookUpRequest) throws CDIException{
		
		try{
			return getcustomerMasterLookUpBO().lookUpCustomerMaster(customerMasterLookUpRequest);
		} catch (CDIException e) {
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return null;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
}

	/**
	 * @return the searchBO
	 */
	public ICustomerMasterLookUpBO getcustomerMasterLookUpBO() {
		return customerMasterLookUpBO;
	}


	/**
	 * @param searchBO the searchBO to set
	 */
	public void setCustomerMasterLookUpBO(ICustomerMasterLookUpBO customerMasterLookUpBO) {
		this.customerMasterLookUpBO = customerMasterLookUpBO;
	}
	
}
