/*
 * This is an auto-generated class for the service object. Please do not modify this class.
*/
package com.walgreens.cdi.service.webservices;

import javax.jws.WebService;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.CDIExceptionFault;
import com.walgreens.cdi.exception.CDIException_Exception;


//This is service implementation class exposed as web service using bounce plug-in. 
//As a part of WAS Migration Changes are in the new parameters addition for the @WebService tag, the new @SoapBinding tag, 
// and  replacing the @WebResult tag in the called methods with @WebMethod tags.


@WebService (targetNamespace="http://webservices.service.cdi.walgreens.com/", 
serviceName="CustomerMasterUpdateServiceWSService", 
portName="CustomerMasterUpdateServiceWSPort", 
wsdlLocation="WEB-INF/WSDL/CustomerMasterUpdateServiceWSService.wsdl")
@javax.jws.soap.SOAPBinding(style = javax.jws.soap.SOAPBinding.Style.DOCUMENT)
@javax.jws.HandlerChain(file="/WSHandlerChain.xml")
public class CustomerMasterUpdateServiceWS{
    private com.walgreens.cdi.service.impl.CustomerMasterUpdateService _service = null;

    @javax.jws.WebMethod(exclude=true)
    private com.walgreens.cdi.service.impl.CustomerMasterUpdateService getService() {
        if(_service == null){
             _service = (com.walgreens.cdi.service.impl.CustomerMasterUpdateService)walgreens.utils.ioc.BeanFactoryUtil.getFactory().getBean("customerMasterUpdateService");
        }
        return _service;
    }

    public @javax.jws.WebMethod boolean updateCustomerMaster(com.walgreens.cdi.vo.CustomerMasterUpdateRequest arg0) throws com.walgreens.cdi.exception.CDIException_Exception{
    	try {
    	return getService().updateCustomerMaster( arg0);
    	}
    	catch (CDIException e) {
    		CDIExceptionFault fault = new CDIExceptionFault();
			fault.setErrorCode(e.getErrorCode());
			fault.setDetailMessage(e.getDetailMessage());
			
			fault.setMsg(e.getMsg());
			throw new CDIException_Exception(e.getMessage(), fault);
    	}
    }
}
