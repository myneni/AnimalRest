package com.walgreens.cdi.vo;

/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author
 * 
 */

public class CustomerMasterUnDeleteRequest {

	// Customer Id
	private String sourceId;

	// Source code of customer record
	private String sourceCode;

	/**
	 * 
	 * @return sourceCode
	 */
	public String getSourceCode() {
		return sourceCode;
	}

	/**
	 * This method is used to set the source code
	 * 
	 * @param sourceCode
	 */

	public void setSourceCode(final String sourceCode) {
		this.sourceCode = sourceCode;
	}

	/**
	 * 
	 * @return custId
	 */

	public String getSourceId() {
		return sourceId;
	}

	/**
	 * This method is used to set the customer Id
	 * 
	 * @param custId
	 */

	public void setSourceId(final String sourceId) {
		this.sourceId = sourceId;
	}

}
