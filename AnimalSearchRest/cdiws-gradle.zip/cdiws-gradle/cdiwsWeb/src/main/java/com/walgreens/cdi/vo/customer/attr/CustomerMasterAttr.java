package com.walgreens.cdi.vo.customer.attr;
import com.walgreens.cdi.util.CustomerMasterConstants;


public class CustomerMasterAttr {
	private boolean limited;
	private CustomerMasterName name; // = new CustomerMasterName();
	private CustomerMasterBirthDate birthDate ;//= new CustomerMasterBirthDate();
	private CustomerMasterEmail email;// = new CustomerMasterEmail();
	private CustomerMasterAddress address = new CustomerMasterAddress();
	private CustomerMasterPhone phone = new CustomerMasterPhone();
	
	
	/**
	 * 
	 */
	public CustomerMasterAttr() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CustomerMasterAttr(boolean limited) {
		super();
		this.limited = limited;
		// TODO Auto-generated constructor stub
	}


	public CustomerMasterAddress getAddress() {
		return address;
	}


	public void setAddress(CustomerMasterAddress address) {
		this.address = address;
	}


	public CustomerMasterBirthDate getBirthDate() {
		return birthDate;
	}


	public void setBirthDate(CustomerMasterBirthDate birthDate) {
		this.birthDate = birthDate;
	}


	public CustomerMasterEmail getEmail() {
		return email;
	}


	public void setEmail(CustomerMasterEmail email) {
		this.email = email;
	}


	public boolean isLimited() {
		return limited;
	}


	public void setLimited(boolean limited) {
		this.limited = limited;
	}


	public CustomerMasterName getName() {
		return name;
	}


	public void setName(CustomerMasterName name) {
		this.name = name;
	}


	public CustomerMasterPhone getPhone() {
		return phone;
	}


	public void setPhone(CustomerMasterPhone phone) {
		this.phone = phone;
	}

	public String toString() {
		String str="";
		
		if ( limited == false)
			str = "\n\n $$$$$$$$$$$$$$$$   All  Source $$$$$$$$$$$$$$$$$$\n";
	   else
		str = "\n\n $$$$$$$$$$$$$$$$  Limited Source $$$$$$$$$$$$$$$$$$\n";

		
	    if (name != null)
	    	str = str + name.toString() ;
	    
	    if (birthDate != null)
	    	str = str +  birthDate.toString() ;
	    
	    if (email != null)
	    	str = str +  email.toString() ; 
	    
	    if (address != null)
	    	str = str +  address.toString() ; 	
		
	    if (phone != null)
	    	str = str +  phone.toString() ; 	
		
	
         return str;
	}
	
	public String toCompString() {
		String str="";
		
		if ( limited == false)
			str = CustomerMasterConstants.DELIMITE_ATTR 
			+  CustomerMasterConstants.COMP_ATTR_NAME_CWVNAME  + CustomerMasterConstants.DELIMITE_FIELD+ 
			   CustomerMasterConstants.COMP_ATTR_NAME_CWV_ALL+ CustomerMasterConstants.DELIMITE_FIELD;
	    else
	    	str = CustomerMasterConstants.DELIMITE_ATTR 
			+  CustomerMasterConstants.COMP_ATTR_NAME_CWVNAME  + CustomerMasterConstants.DELIMITE_FIELD+ 
			   CustomerMasterConstants.COMP_ATTR_NAME_CWV_LMT+ CustomerMasterConstants.DELIMITE_FIELD; 
		
	    if (name != null)
	    	str = str + name.toCompString() ;
	    
	    if (birthDate != null)
	    	str = str +  birthDate.toCompString() ;
	    
	    if (email != null)
	    	str = str +  email.toCompString() ; 
	    
	    if (address != null)
	    	str = str +  address.toCompString() ; 	
		
	    if (phone != null)
	    	str = str +  phone.toCompString() ; 	
		
	
         return str;
	}
	
}
