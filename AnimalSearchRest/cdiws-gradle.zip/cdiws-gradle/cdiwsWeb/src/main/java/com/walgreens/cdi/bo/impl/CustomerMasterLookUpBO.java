package com.walgreens.cdi.bo.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import walgreens.services.LoggingFacility;

import com.initiate.bean.ArrayOfMember;
import com.initiate.bean.Member;
import com.walgreens.cdi.bo.ICustomerMasterLookUpBO;
import com.walgreens.cdi.dao.ICustomerMasterLookUpDAO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterLinkageVO;
import com.walgreens.cdi.vo.CustomerMasterLookUpVO;
import com.walgreens.cdi.vo.CustomerMasterResponse;
import com.walgreens.cdi.vo.CustomerMasterLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfCustomer;
import com.walgreens.cdi.vo.customer.CustomerMaster;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterHubLinkageRec;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLinkageDetail;
import com.walgreens.cdi.wsao.ICustomerMasterLookUpWSAO;
/**
 * This BO perform validation on input request and also handles exception. It
 * will return ArrayOfCustomer on successful lookup of  record , otherwise an
 * exception will be thrown with message and error code.
 * 
 * @author
 */

public class CustomerMasterLookUpBO extends BaseBO implements ICustomerMasterLookUpBO {
	
	private ICustomerMasterLookUpWSAO customerMasterLookUpWSAO;
	private ICustomerMasterLookUpDAO customerMasterLookUpDAO;
	/**
	 * This method will perform validation and if validation is successful then it call WSAO layer lookup method
	 * 
	 * @param customerMasterLookUpRequest
	 * @return boolean
	 * @throws SystemException,BusinessRuleViolationException
	 */
	public ArrayOfCustomer lookUpCustomerMaster(CustomerMasterLookUpRequest customerMasterLookUpRequest) throws SystemException, BusinessRuleViolationException {
		try{
			validateRequestObject(customerMasterLookUpRequest);
		     
			//Riteaid change added to get application Id
			String applicationID=getLoggingHandlerObj().getTrackingInfoProxyBean().getApplicationID();;
			
			//Riteaid change end
			
			CustomerMasterResponse [] 	cdiSearchResponse = null;
			boolean pvSearchFlag = CustomerMasterConstants.ENABLE_PV_SEARCH;//this flag is used if lookup will be through PV tables or not
			if(pvSearchFlag)
			{
				//Start code for DB search
				getWalgreensLogger().log(LoggingFacility.INFO,"Persistent Composite Search is Enabled:");
				
				long st=System.currentTimeMillis();
				ArrayOfMember arrMemberRes = getCustomerMasterLookUpWSAO().getMemHead(customerMasterLookUpRequest);
				long et=System.currentTimeMillis();
				long t = et-st;
				getWalgreensLogger().log(LoggingFacility.DEBUG,"Total time taken in calling memhead "+t);
				
				try{
					List<Member> memberList=arrMemberRes.getItem();
					Member[] memberRes = memberList.toArray(new Member[memberList.size()]);
					long entRecno = 0;			
					List<CustomerMasterLookUpVO> list = null;
					int memCount = memberRes.length;
					Map<String, Member> memberMap = new HashMap<String, Member>();		
					Set<Long> eidSet = new LinkedHashSet<Long>();
					getWalgreensLogger().log(LoggingFacility.DEBUG,"Member count from memhead "+memCount);
					for(int i=0; i<memCount;i++)
					{
						entRecno =  memberRes[i].getMemHead().getEntRecno();
						Short currMatchScore=memberRes[i].getMemHead().getMatchScore();
						
						//If entRecno is not present add it
						if(memberMap.get(""+entRecno ) == null )
						{
							memberMap.put(""+entRecno, memberRes[i]);
						}						
						//check if entRecno already present in the map then compare the match score overwrite with higher matchscore 
						else if (memberMap.get(""+entRecno) != null && currMatchScore > Short.valueOf(memberMap.get(""+entRecno).getMemHead().getMatchScore()))
						{
							memberMap.put(""+entRecno, memberRes[i]);
						}
						if(applicationID!=null && (CustomerMasterConstants.APPID_RITEAID.contains(applicationID.toUpperCase()) && applicationID.length()>1 ))
						{
							String patternName=CustomerMasterConstants.PREFIX+applicationID;
							if(!(CustomerMasterConstants.SRC_CODE_EE.equalsIgnoreCase(memberRes[i].getMemHead().getSrcCode()) && memberRes[i].getMemHead().getMemIdnum().toUpperCase().matches(String.valueOf(CustomerMasterConstants.class.getField(patternName).get(null)))))
						    {
								eidSet.add(entRecno);
						    }
						}
						else
							
						{
								
								
								eidSet.add(entRecno);
							
						}
					}
					int uniqueEidCount = eidSet.size();
					getWalgreensLogger().log(LoggingFacility.DEBUG,"Eid List for PV look up "+eidSet);
					st=System.currentTimeMillis();
					list = getCustomerMasterLookUpDAO().getCompView(eidSet); 	
					et=System.currentTimeMillis();
					t = et-st;
					getWalgreensLogger().log(LoggingFacility.DEBUG,"Total time taken in getting Composite view details from PV Table "+t);
					
					
					if(uniqueEidCount != list.size())
					{
						pvSearchFlag = false;
						
						getWalgreensLogger().log(LoggingFacility.INFO,"Table cdi_emca_cv_id does not have all the EID details associated with this search");
						getWalgreensLogger().log(LoggingFacility.INFO,"Turned off PV search for this search request");
					}
					else
					{
						st=System.currentTimeMillis();
						List<CustomerMasterLinkageVO> linkageList =  getCustomerMasterLookUpDAO().getLinkage(eidSet);
						et=System.currentTimeMillis();
						t = et-st;
						getWalgreensLogger().log(LoggingFacility.DEBUG,"Total time taken in getting Linkage details from PV Table "+t);
						String addCriteriaFlag=CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_NO;
						if ( memCount>=CustomerMasterConstants.MAX_ROWS )
				    	{
							addCriteriaFlag=CustomerMasterConstants.ADD_SEARCH_CRITERIA_FLAG_YES;
				    	}
						Map<String, CustomerMasterLookUpVO> custLookUpVOMap = new HashMap<String, CustomerMasterLookUpVO>();
						for(int i=0;i<list.size();i++)
						{
							CustomerMasterLookUpVO custLookUpVO = list.get(i);
							custLookUpVOMap.put(custLookUpVO.getCdiCustomer().getEID(), custLookUpVO);
							
						}
						cdiSearchResponse = new CustomerMasterResponse[list.size()];
						int i=0;
						Iterator itr = eidSet.iterator();
						while(itr.hasNext())					
						{
							entRecno =  memberRes[i].getMemHead().getEntRecno();
							CustomerMasterLookUpVO custLookUpVO = custLookUpVOMap.get(""+itr.next());
							CustomerMaster custMst = custLookUpVO.getCdiCustomer();
							String eid = custMst.getEID();
							Member mem = memberMap.get(eid);
							custLookUpVO.getCdiCustomer().setMatchScore(Short.toString(mem.getMemHead().getMatchScore()));
							CustomerMasterHubLinkageRec hubLinkageRec = getLinkageDetails(eid, linkageList);
							if(hubLinkageRec!=null){
								custLookUpVO.getCdiCustomer().setHubLinkageRec(hubLinkageRec);
								getWalgreensLogger().log(LoggingFacility.DEBUG,"Linkage found in table CDI_LINKAGE_CV_ID for EID "+eid);
							}else{								
								pvSearchFlag = false;//If linkage not found for any eid set PVSearchFlas flase		
								getWalgreensLogger().log(LoggingFacility.INFO,"Linkage Not found in table for EID "+eid +" Turned off PV search for this search request");	
							    break;
							}
							cdiSearchResponse[i]=new CustomerMasterResponse();
							cdiSearchResponse[i].setAddCriteriaFlag(addCriteriaFlag);
							cdiSearchResponse[i].setCdiCustomer(custLookUpVO.getCdiCustomer());
							getWalgreensLogger().log(LoggingFacility.DEBUG,"EID Iteration "+i);
							i++;
						}			
					}
					}
				catch(Exception e)
				{
					getWalgreensLogger().log(LoggingFacility.ERROR, "There is an Error in PV Search..Turning off PV search for this search request");
					pvSearchFlag = false;
					getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
					e.printStackTrace();
				}
				
				//End Code for DB search
			}
//			Do Normal Look Up through initiateWS
			if(!pvSearchFlag)
			{
				getWalgreensLogger().log(LoggingFacility.INFO,"Seraching through Original Search");
				cdiSearchResponse = getCustomerMasterLookUpWSAO().lookUpCustomerMaster(customerMasterLookUpRequest);
				
				
			}
			
			
			//CustomerMasterResponse [] cdiSearchResponse = getcustomerMasterLookUpWSAO().lookUpCustomerMaster(customerMasterLookUpRequest);
			ArrayOfCustomer arr = new ArrayOfCustomer();
			arr.setItem(cdiSearchResponse);
			CustomerMasterLookUpVO.setPvSearchFlag(pvSearchFlag);
			return arr;
		} catch (JaxWsSoapFaultException e) {
			String exceptionCode = getExceptionCode(e);
			if(exceptionCode != null){
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(exceptionCode,e.getMessage());
			}else{
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e.getMessage());
			}
		}catch(BusinessRuleViolationException e){
			throw e;
		}catch(Exception e){
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
			throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, e.getMessage());
			
			
		}
	}

	 /**
     * This method sets the Error code  based on the type of
     * Exception which Initiate gives
     * @param exception
     * @return
     */
    public  String  getExceptionCode(Exception exception){
        if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_BUCKETS_FOUND.trim())){
            return CustomerMasterConstants.EC_EXCEPTION_NO_BUCKETS_FOUND;
        }
        else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_CANDIDATES_FOUND.trim())){
            return CustomerMasterConstants.EC_EXCEPTION_NO_CANDIDATES_FOUND;
        }
        else{
            return null;
        }
    }

	/**
	 * @return the searchWSAO
	 */
	public ICustomerMasterLookUpWSAO getCustomerMasterLookUpWSAO() {
		return customerMasterLookUpWSAO;
	}


	/**
	 * @param searchWSAO the searchWSAO to set
	 */
	public void setCustomerMasterLookUpWSAO(ICustomerMasterLookUpWSAO customerMasterLookUpWSAO) {
		this.customerMasterLookUpWSAO = customerMasterLookUpWSAO;
	}

	public void validateRequestObject(CustomerMasterLookUpRequest customerMasterLookUpRequest) throws BusinessRuleViolationException {
		//ValidateCustomerMasterRequest.validateRequiredFields(customerMasterLookUpRequest);
		//ValidateCustomerMasterRequest.validateInvalidCharacters(customerMasterLookUpRequest);
	}
	
	public ICustomerMasterLookUpDAO getCustomerMasterLookUpDAO() {
		return customerMasterLookUpDAO;
	}

	public void setCustomerMasterLookUpDAO(
			ICustomerMasterLookUpDAO customerMasterLookUpDAO) {
		this.customerMasterLookUpDAO = customerMasterLookUpDAO;
	}
	
	private CustomerMasterHubLinkageRec getLinkageDetails(String eid, List<CustomerMasterLinkageVO> linkageList)
	{
		CustomerMasterHubLinkageRec hubLinkage = new CustomerMasterHubLinkageRec();
		hubLinkage.setEid(eid);
		List<CustomerMasterLinkageDetail> linkageDetail = new ArrayList<CustomerMasterLinkageDetail>();
		
		for (int i=0; i<linkageList.size();i++)
		{
			if (eid.equals(linkageList.get(i).getEntityId())){
				CustomerMasterLinkageDetail obj = new CustomerMasterLinkageDetail();
				obj.setRefCode(linkageList.get(i).getRefCode());
				obj.setRefID(linkageList.get(i).getRefID());
				obj.setSourceCode(linkageList.get(i).getSourceCode());
				obj.setSourceID(linkageList.get(i).getSourceID());
				obj.setStatus(linkageList.get(i).getStatus());
				linkageDetail.add(obj);
			}
		}
		CustomerMasterLinkageDetail[] linkageArr = new CustomerMasterLinkageDetail[linkageDetail.size()];
		hubLinkage.setLinkageDetail(linkageDetail.toArray(linkageArr));
		return hubLinkage;
	}

}
