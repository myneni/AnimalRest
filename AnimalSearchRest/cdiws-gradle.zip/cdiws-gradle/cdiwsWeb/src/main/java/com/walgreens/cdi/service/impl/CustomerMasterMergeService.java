package com.walgreens.cdi.service.impl;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterMergeBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterMergeService;
import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterMergeRequest;


public class CustomerMasterMergeService extends BaseService  implements ICustomerMasterMergeService{
	
	private ICustomerMasterMergeBO customerMasterMergeBO;
	

	public boolean mergeCustomerMaster(CustomerMasterMergeRequest customerMasterMergeRequest) throws CDIException {
		try{
			return getcustomerMasterMergeBO().mergeCustomerMaster(customerMasterMergeRequest);
		} catch (CDIException e) {
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return false;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
		
	}


	/**
	 * @return the searchBO
	 */
	public ICustomerMasterMergeBO getcustomerMasterMergeBO() {
		return customerMasterMergeBO;
	}


	/**
	 * @param searchBO the searchBO to set
	 */
	public void setCustomerMasterMergeBO(ICustomerMasterMergeBO customerMasterMergeBO) {
		this.customerMasterMergeBO = customerMasterMergeBO;
	}

}
