package com.walgreens.cdi.exception;

/**
 * This  is the Base Exception class.Consists of all the fields
 * which need to be populated in SOAP fault.
 * All exceptions are required to extend this.
 * 
 * Date : 07/02/2009
 * @author siddhartha.basu
 *
 */
        
public abstract class BaseException extends Exception {
    private String detailedMessage;
    private String usertMessage;
    protected String errorCode;
  

public BaseException(String errorCode){
    super(errorCode);
    
}
    

    public BaseException(String errorCode, String message)
    {
        super();
        this.errorCode= errorCode;
        detailedMessage = message;
    }
    
    
    
    public BaseException(String errorCode, String message,String userMessage)
    {
        super(errorCode);
      
        detailedMessage = message;
         usertMessage = userMessage;
    }
    

    /**
     * @return the detailedMessage
     */
    public String getDetailedMessage() {
        return detailedMessage;
    }

    /**
     * @param detailedMessage the detailedMessage to set
     */
    public void setDetailedMessage(String detailedMessage) {
        this.detailedMessage = detailedMessage;
    }

    /**
     * @return the usertMessage
     */
    public String getUsertMessage() {
        return usertMessage;
    }

    /**
     * @param usertMessage the usertMessage to set
     */
    public void setUsertMessage(String usertMessage) {
        this.usertMessage = usertMessage;
    }
    public void setErrorCode(String errorCode)
    {
       this.errorCode = errorCode;
    }


    /**
     * @return the errorCode
     */
    public String getErrorCode() {
        return errorCode;
    }

}
