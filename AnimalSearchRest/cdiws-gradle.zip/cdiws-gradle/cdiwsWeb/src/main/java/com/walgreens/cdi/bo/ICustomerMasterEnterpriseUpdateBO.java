package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateResponse;

public interface ICustomerMasterEnterpriseUpdateBO {

	/**
	 * This method is used to check the validations corresponding to the details
	 * entered
	 * 
	 * @param customerMasterEnterpriseUpdateRequest
	 * @throws BusinessRuleViolationException
	 */
	public void validateRequestObject(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws BusinessRuleViolationException;

	/**
	 * This method is used to update the data.
	 * 
	 * @param customerMasterEnterpriseUpdateRequest
	 * @return
	 * @throws SystemException
	 * @throws BusinessRuleViolationException
	 */
	public CustomerMasterEnterpriseUpdateResponse updateCustomerMasterEnterprise(
			CustomerMasterEnterpriseUpdateRequest customerMasterEnterpriseUpdateRequest)
			throws SystemException, BusinessRuleViolationException;
}
