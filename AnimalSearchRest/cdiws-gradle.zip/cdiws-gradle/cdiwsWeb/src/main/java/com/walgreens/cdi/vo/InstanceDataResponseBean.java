package com.walgreens.cdi.vo;

import java.util.List;

public class InstanceDataResponseBean {

    //private List<InstanceDataVO> instanceDataVOs;

    private String resultString;

   // private String dataSourceName;

    private String logLevel;


   /*public List<InstanceDataVO> getInstanceDataVOs() {
        return instanceDataVOs;
    }


    public void setInstanceDataVOs(List<InstanceDataVO> instanceDataVOs) {
        this.instanceDataVOs = instanceDataVOs;
    }*/


    public String getResultString() {
        return resultString;
    }


    public void setResultString(String resultString) {
        this.resultString = resultString;
    }


   /* public String getDataSourceName() {
        return dataSourceName;
    }


    public void setDataSourceName(String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }
*/

    /**
     * @return the logLevel
     */
    public String getLogLevel() {
        return logLevel;
    }


    /**
     * @param logLevel
     *            the logLevel to set
     */
    public void setLogLevel(String logLevel) {
        this.logLevel = logLevel;
    }
}
