package com.walgreens.cdi.bo.impl;

import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterMergeBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterMergeRequest;
import com.walgreens.cdi.wsao.ICustomerMasterMergeWSAO;

public class CustomerMasterMergeBO extends BaseBO implements ICustomerMasterMergeBO {
	
	private ICustomerMasterMergeWSAO mergeWSAO;
	
	
	public boolean mergeCustomerMaster(CustomerMasterMergeRequest customerMasterMergeRequest) throws SystemException, BusinessRuleViolationException{
	
		try{
			validateRequestObject(customerMasterMergeRequest);		
			return getcustomerMasterMergeWSAO().mergeCustomerMaster(customerMasterMergeRequest);
		}catch (JaxWsSoapFaultException e) {
			String exceptionCode = getExceptionCode(e);
			if(exceptionCode != null){
					getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
					throw new SystemException(exceptionCode,e.getMessage());
			}else{
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e.getMessage());
			}
		}catch(BusinessRuleViolationException e){
			throw e;
		}catch(Exception e){
			throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, e.getMessage());
		}
	}


	/**
	 * @return the searchWSAO
	 */
	public ICustomerMasterMergeWSAO getcustomerMasterMergeWSAO() {
		return mergeWSAO;
	}


	/**
	 * @param searchWSAO the searchWSAO to set
	 */
	public void setCustomerMasterMergeWSAO(ICustomerMasterMergeWSAO mergeWSAO) {
		this.mergeWSAO = mergeWSAO;
	}

	
	public void validateRequestObject(CustomerMasterMergeRequest customerMasterMergeRequest) throws BusinessRuleViolationException {
		ValidateCustomerMasterRequest.validateRequiredFields(customerMasterMergeRequest);
		ValidateCustomerMasterRequest.validateInvalidFieldValues(customerMasterMergeRequest);	
	}
    
	  public  String  getExceptionCode(Exception exception){
		   if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_MERGE_CANT_LOCK_ENTLNKEM.trim())){
	           return CustomerMasterConstants.EC_EXCEPTION_RETRY_CONCURRENT_MERGE;
	       }else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_MERGE_CANT_SERIALIZE.trim())){
	           return CustomerMasterConstants.EC_EXCEPTION_RETRY_CONCURRENT_MERGE;
	           
	       }else{
	    	   return super.getExceptionCode(exception);
	       }
	   }
	
	
	

}
