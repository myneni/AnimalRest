package com.walgreens.cdi.util;

/**
 * @author 328500
 * @version 1.x Previous Releases till R53
 * @version 2.0 R54 - SynchID Redesign Baseline
 * @version 2.1 R54 - Ecomm Guest Checkout
 * @version 2.2 R54 - ERX Changes  
 */

public class CustomerMasterConstants {

	public static final Long ZERO = 0L;

	public static final String AUD_MODE_NONE = "AUDNONE";

	public static final String ENT_TYPE_ID = "ID";

	public static final String PATIENT_MEMBER_TYPE = "PERSON";

	public static final String AS_MEMBER = "ASMEMBER";

	public static final String AS_ENTITY = "ASENTITY";

	public static final String Active = "A";

	public static final String ACTIVE_MERGE = "A,M";

	// Variable modified for synch ID reDesign
	public static final String SEG_CODE_HEAD_ATTRALL = "MEMHEAD,CUSTNAME,CUSTADDR,CUSTADDR2,"
			+ "CUSTATTR,CUSTATTR1,CUSTATTR2,CUSTATTR3,CUSTDATE,CUSTPHONE"; 
				
																				
	public static final String MEMBER_STATUS_ACTIVE = "A";

	public static final String RECORD_STATUS_ACTIVE = "A";

	public static final String SEGMENT_CODE_CUSTIDENT = "CUSTIDENT";

	public static final String SEGMENT_CODE_CUSTADDR = "CUSTADDR";

	public static final String SEGMENT_CODE_CUSTADDR_2 = "CUSTADDR2";

	public static final String SEGMENT_CODE_CUSTATTR = "CUSTATTR";

	public static final String SEGMENT_CODE_CUSTNAME = "CUSTNAME";

	public static final String SEGMENT_CODE_CUSTATTR1 = "CUSTATTR1";

	public static final String SEGMENT_CODE_CUSTATTR2 = "CUSTATTR2";

	public static final String SEGMENT_CODE_CUSTATTR3 = "CUSTATTR3";

	public static final String SEGMENT_CODE_CUSTPHONE = "CUSTPHONE";

	public static final String SEGMENT_CODE_CUSTDATE = "CUSTDATE";

	public static final String FIELD_NAME_ONMFIRST = "onmFirst";

	public static final String FIELD_NAME_ONMMIDDLE = "onmMiddle";

	public static final String FIELD_NAME_ONMLAST = "onmLast";

	public static final String FIELD_NAME_ONMSUFFIX = "onmSuffix";

	public static final String FIELD_NAME_ONMPREFIX = "onmPrefix";

	public static final String FIELD_NAME_ATTRVAL = "attrVal";

	public static final String FIELD_NAME_DATEVAL = "dateVal";

	public static final String FIELD_NAME_PHAREA = "phArea";

	public static final String FIELD_NAME_PHNUMBER = "phNumber";

	public static final String FIELD_NAME_STATE = "custState"; // as per new

	// data model

	public static final String FIELD_NAME_STREET_ADDRESS1 = "custStline1"; // as

	// per
	// new
	// data
	// model

	public static final String FIELD_NAME_STREET_ADDRESS2 = "custStline2"; // as

	// per
	// new
	// data
	// model

	public static final String FIELD_NAME_CITY = "custCity"; // as per new

	// data model

	public static final String FIELD_NAME_ZIP = "custZipcode"; // as per new

	// data model

	public static final String FIELD_NAME_COUNTRY = "custCountry"; // as per

	// new data
	// model v25

	public static final String FIELD_NAME_ADDR_TYPE = "addrtype"; // as per

	// new data
	// model v25

	public static final String FIELD_NAME_DPV_FT_NOOTE = "dpvftnote"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_DPV_IND = "dpvind"; // as per new

	// data model
	// v25

	public static final String FIELD_NAME_FT_NOTE = "ftnote"; // as per new

	// data model
	// v25

	public static final String FIELD_NAME_LATITUDE = "latitude"; // as per

	// new data
	// model v25

	public static final String FIELD_NAME_LONGITUDE = "longitude"; // as per

	// new data
	// model v25

	public static final String FIELD_NAME_PR_DATE = "prdate"; // as per new

	// data model
	// v25

	public static final String FIELD_NAME_URB_CODE = "urbcode"; // as per new

	// data model
	// v25

	public static final String FIELD_NAME_LACS_ADDR_FLAG = "lacsaddrflag"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_LACS_FT_NOTE = "lacsftnote"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_LACS_RTRN_CODE = "lacsrtrncode"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_STATE = "ncoaState"; // as per

	// new data
	// model v25

	public static final String FIELD_NAME_NCOA_STREET_ADDRESS1 = "ncoaStline1"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_STREET_ADDRESS2 = "ncoaStline2"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_CITY = "ncoaCity"; // as per

	// new data
	// model v25

	public static final String FIELD_NAME_NCOA_ZIP = "ncoaZipcode"; // as per

	// new data
	// model v25

	public static final String FIELD_NAME_NCOA_ADDR_TYPE = "ncoaaddrtype"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_ACT_CODE = "ncoaactcode"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_ANK_CODE = "ncoaankcode"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_MV_DATE = "ncoamvdate"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_MV_TYPE = "ncoamvtype"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_NEW_ADDR_FLAG = "ncoanewaddrflg"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_NIX_FT_NOTE = "ncoanixftnote"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_PR_DATE = "ncoaprdate"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_RTRN_CODE = "ncoartrncode"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD_NAME_NCOA_URB_CODE = "ncoaurbcode"; // as

	// per
	// new
	// data
	// model
	// v25

	public static final String FIELD1 = "field1"; // as per new data model

	public static final String FIELD2 = "field2"; // as per new data model

	public static final String FIELD_NAME_PLAN_ID = "patPlanID";

	public static final String FIELD_NAME_GEN_REC_NBR = "genRecNum";

	public static final String PUT_TYPE_INSERT_ONLY = "INSERT_ONLY";

	public static final String PUT_TYPE_UPDATE_ONLY = "UPDATE_ONLY";

	public static final String PUT_TYPE_INSERT_UPDATE = "INSERT_UPDATE";

	public static final int UPDATE_MODE_INSERT_ONLY = 0;

	public static final int UPDATE_MODE_UPDATE_ONLY = 1;

	public static final String MEM_MODE_ATTR_COMP = "ATTRCOMP";

	public static final String MEM_MODE_PARTIAL = "PARTIAL";

	public static final String MATCH_MODE_IMMEDIATE = "IMMEDIATE";

	/*
	 * Attribute Codes
	 */
	public static final String ATTR_CODE_NAME = "NAME";

	public static final String ATTR_CODE_BIRTH_DT = "BIRTHDT";

	public static final String ATTR_CODE_PR_PHONE = "PRPHONE";

	public static final String ATTR_CODE_CELL_PHONE = "SCPHONE";

	public static final String ATTR_CODE_WK_PHONE = "WKPHONE";

	public static final String ATTR_CODE_SC_PHONE = "SCPHONE";

	public static final String ATTR_CODE_PR_ADDRESS = "PRADDR";

	public static final String ATTR_CODE_PR_ADDRESS_2 = "PRADDR2";

	public static final String ATTR_CODE_WK_ADDRESS = "WKADDR";

	public static final String ATTR_CODE_CUST_ORGN = "CUSTORGN";

	public static final String ATTR_CODE_HOH_REL = "HOHREL";

	public static final String ATTR_CODE_GENDER = "GENDER";

	public static final String ATTR_CODE_EMAIL = "EMAIL";

	public static final String ATTR_CODE_ECICMEMID = "ECICMEMID";

	public static final String ATTR_CODE_PCECMEMID = "PCECMEMID";

	public static final String ATTR_CODE_CREATE_DATE = "CREATEDATE";

	public static final String ATTR_CODE_LAST_UPDATE_DATE = "LSTUPDDATE";

	public static final String ATTR_CODE_HOH_REL_CODE = "HOHRELCDE";

	public static final String ATTR_CODE_PET_IND = "PETIND";

	public static final String ATTR_CODE_DEATH_IND = "DEATHIND";

	public static final String ATTR_CODE_SEC_CODE = "SECCODE";

	// public static final String ATTR_CODE_PAT_INSUR_INFO = "PATINSURINFO";

	public static final String ATTR_CODE_LOCK_IND = "LOCKIND";

	public static final String ATTR_CODE_TRUST_ID = "TRUSTID";

	public static final String ATTR_CODE_REFDEATHIND = "REFDEATHIND";

	/**
	 * Customer Mapping Codes
	 */
	// MAPPING FOR NAME
	public static final int CM_NAME_LAST = 0;

	public static final int CM_NAME_FIRST = 1;

	public static final int CM_NAME_MIDDLE = 2;

	// MAP THE REMAINING 4 FIELDS FOR NAME

	// MAPPING FOR PHONE
	public static final int CM_PHONE_AREA_CODE = 1;

	public static final int CM_PHONE_NUMBER = 2;

	// MAPPING FOR CUSTOMER ORIGIN
	public static final int CM_ORIGIN_CODE = 0;

	public static final int CM_ORIGIN_STORE_IND = 1;

	// MAPPING FOR BIRTH DATE
	public static final int CM_BIRTH_DATE = 0;

	// MAPPING FOR LOCKED IND
	public static final int CM_LOCKED_IND = 0;

	// MAPPING FOR EMAIL
	public static final int CM_EMAIL_ADDRESS = 0;

	// MAPPING FOR DEATH IND
	public static final int CM_DEATH_IND = 0;

	// MAPPING FOR PET IND
	public static final int CM_PET_IND = 0;

	// MAPPING FOR GENDER IND
	public static final int CM_GENDER_IND = 0;

	// MAPPING FOR LAST UPDATE DATE
	public static final int CM_LAST_UPDATE_DATE = 0;

	// MAPPING FOR SEC IND
	public static final int CM_SEC_CODE = 0;

	/**
	 * CUSTOMER MAPPING PHONE AND ADDRESS TYPES
	 */
	public static final String CM_ADDRESS_TYPE_P = "P";

	public static final String CM_ADDRESS_TYPE_2 = "2";

	public static final String CM_ADDRESS_TYPE_W = "W";

	public static final String CM_PHONE_TYPE_H = "H";

	public static final String CM_PHONE_TYPE_C = "C";

	public static final String CM_PHONE_TYPE_W = "W";

	public static final String CM_PHONE_TYPE_S = "S";

	public static final String SECURITY_CLASS_CODE_H = "H";

	public static final String SECURITY_CLASS_CODE_P = "P";

	public static final String SECURITY_CLASS_CODE_I = "I";

	public static final String CVW_NAME_ALL = "ALLS";

	public static final String CVW_NAME_LIMITED = "ALLL";

	public static final String CVW_NAME_BOTH = "ALLBB";

	public static final String SRC_CODE_IC = "IC";

	public static final String SRC_CODE_EC = "EC";

	public static final String SRC_CODE_PC = "PC";

	public static final String SRC_CODE_SM = "SM";

	/* Added new TC & HC source system */
	public static final String SRC_CODE_TC = "TC";

	public static final String SRC_CODE_HC = "HC";

	/* Added new TC & HC source system */
	/* Added new GW source system */
	public static final String SRC_CODE_GW = "GW";
	
	public static final String SRC_CODE_CH = "CH";
	
	public static final String SRC_CODE_CM = "CM";
	
	public static final String SRC_CODE_EE = "EE";
	
	public static final String SRC_CODE_SF = "SF";
	/* Added new RI source system */
	public static final String SRC_CODE_RI = "RI";

	public static final String SRC_USRNAME = "system";

	public static final String SRC_USRPWD = "system";

	public static final String SRC_IC_USRNAME = "system";

	public static final String SRC_IC_USRPWD = "system";

	public static final String SRC_EC_USRNAME = "system";

	public static final String SRC_EC_USRPWD = "system";

	public static final String SKIP_STRING = "~";

	public static final String USER_NAME_SYS = "sys";

	public static final String USER_NAME_SYSTEM = "system";

	public static final Short APPCODE_OK = 0;

	public static final Short APPCODE_MISSING_DATA = 10;

	public static final Short APPCODE_NO_ROWS = 100;

	public static final Short APPCODE_DATABASE_ERROR = 340;

	/* Max row count change for all source systems */
	public static final int MAX_ROWS = 20;

	public static final short MIN_SCORE = 40;

	public static final String ADD_SEARCH_CRITERIA_FLAG_YES = "Y";

	public static final String ADD_SEARCH_CRITERIA_FLAG_NO = "N";

	// Mapping for Permanent Address
	public static final short FLDSEQNO_CUSTADDR_CUSTSTLINE1 = 0;

	public static final short FLDSEQNO_CUSTADDR_CUSTSTLINE2 = 1;

	public static final short FLDSEQNO_CUSTADDR_CUSTSTLINE3 = 2;

	public static final short FLDSEQNO_CUSTADDR_CUSTSTLINE4 = 3;

	public static final short FLDSEQNO_CUSTADDR_CUSTCITY = 4;

	public static final short FLDSEQNO_CUSTADDR_CUSTSTATE = 5;

	public static final short FLDSEQNO_CUSTADDR_CUSTZIPCODE = 6;

	public static final short FLDSEQNO_CUSTADDR_CUSTCOUNTRY = 7;

	public static final short FLDSEQNO_CUSTADDR_FTNOTE = 8;

	public static final short FLDSEQNO_CUSTADDR_ADDRTYPE = 9;

	public static final short FLDSEQNO_CUSTADDR_PRDATE = 10;

	public static final short FLDSEQNO_CUSTADDR_LACSADDRFLAG = 11;

	public static final short FLDSEQNO_CUSTADDR_LACSFTNOTE = 12;

	public static final short FLDSEQNO_CUSTADDR_LACSRTRNCODE = 13;

	public static final short FLDSEQNO_CUSTADDR_URBCODE = 14;

	public static final short FLDSEQNO_CUSTADDR_LONGITUDE = 15;

	public static final short FLDSEQNO_CUSTADDR_LATITUDE = 16;

	public static final short FLDSEQNO_CUSTADDR_DPVFTNOTE = 17;

	public static final short FLDSEQNO_CUSTADDR_DPVIND = 18;

	public static final short FLDSEQNO_CUSTADDR_NCOASTLINE1 = 19;

	public static final short FLDSEQNO_CUSTADDR_NCOASTLINE2 = 20;

	public static final short FLDSEQNO_CUSTADDR_NCOASTLINE3 = 21;

	public static final short FLDSEQNO_CUSTADDR_NCOASTLINE4 = 22;

	public static final short FLDSEQNO_CUSTADDR_NCOACITY = 23;

	public static final short FLDSEQNO_CUSTADDR_NCOASTATE = 24;

	public static final short FLDSEQNO_CUSTADDR_NCOAZIPCODE = 25;

	public static final short FLDSEQNO_CUSTADDR_NCOAURBCODE = 26;

	public static final short FLDSEQNO_CUSTADDR_NCOAACTCODE = 27;

	public static final short FLDSEQNO_CUSTADDR_NCOAANKCODE = 28;

	public static final short FLDSEQNO_CUSTADDR_NCOAADDRTYPE = 29;

	public static final short FLDSEQNO_CUSTADDR_NCOAMVTYPE = 30;

	public static final short FLDSEQNO_CUSTADDR_NCOANIXFTNOTE = 31;

	public static final short FLDSEQNO_CUSTADDR_NCOANEWADDRFLG = 32;

	public static final short FLDSEQNO_CUSTADDR_NCOARTRNCODE = 33;

	public static final short FLDSEQNO_CUSTADDR_NCOAMVDATE = 34;

	public static final short FLDSEQNO_CUSTADDR_NCOAPRDATE = 35;

	// Mapping for CUSTADDR2 ( Home2 and Work Address)
	public static final short FLDSEQNO_CUSTADDR2_CUSTSTLINE1 = 0;

	public static final short FLDSEQNO_CUSTADDR2_CUSTSTLINE2 = 1;

	public static final short FLDSEQNO_CUSTADDR2_CUSTSTLINE3 = 2;

	public static final short FLDSEQNO_CUSTADDR2_CUSTSTLINE4 = 3;

	public static final short FLDSEQNO_CUSTADDR2_CUSTCITY = 4;

	public static final short FLDSEQNO_CUSTADDR2_CUSTSTATE = 5;

	public static final short FLDSEQNO_CUSTADDR2_CUSTZIPCODE = 6;

	public static final short FLDSEQNO_CUSTADDR2_CUSTCOUNTRY = 7;

	public static final short FLDSEQNO_CUSTADDR2_FTNOTE = 8;

	public static final short FLDSEQNO_CUSTADDR2_ADDRTYPE = 9;

	public static final short FLDSEQNO_CUSTADDR2_PRDATE = 10;

	public static final short FLDSEQNO_CUSTADDR2_LACSADDRFLAG = 11;

	public static final short FLDSEQNO_CUSTADDR2_LACSFTNOTE = 12;

	public static final short FLDSEQNO_CUSTADDR2_LACSRTRNCODE = 13;

	public static final short FLDSEQNO_CUSTADDR2_URBCODE = 14;

	public static final short FLDSEQNO_CUSTADDR2_LONGITUDE = 15;

	public static final short FLDSEQNO_CUSTADDR2_LATITUDE = 16;

	public static final short FLDSEQNO_CUSTADDR2_DPVFTNOTE = 17;

	public static final short FLDSEQNO_CUSTADDR2_DPVIND = 18;

	// Mapping for CUSTADDR3 (Reference Address)
	public static final short FLDSEQNO_CUSTADDR3_CUSTSTLINE1 = 0;

	public static final short FLDSEQNO_CUSTADDR3_CUSTSTLINE2 = 1;

	public static final short FLDSEQNO_CUSTADDR3_CUSTSTLINE3 = 2;

	public static final short FLDSEQNO_CUSTADDR3_CUSTSTLINE4 = 3;

	public static final short FLDSEQNO_CUSTADDR3_CUSTCITY = 4;

	public static final short FLDSEQNO_CUSTADDR3_CUSTSTATE = 5;

	public static final short FLDSEQNO_CUSTADDR3_CUSTZIPCODE = 6;

	public static final short FLDSEQNO_CUSTADDR3_CUSTCOUNTRY = 7;

	// Mapping for CUSTATTR( CUSTORGN, PATINSURINFO )
	public static final short FLDSEQNO_CUSTATTR_FIELD1 = 0;

	public static final short FLDSEQNO_CUSTATTR_FIELD2 = 1;

	// Mapping for CUSTATTR1 ( CREATEDATE, DEATHIND, ECICMEMID, EMAIL, GENDER,
	// LOCKIND, LSTUPDDATE.
	// PCECMEMID, PETIND, SECCODE
	public static final short FLDSEQNO_CUSTATTR1_ATTRVAL = 0;

	// Mapping for COMPVIEWFLAG, REFDEATHIND, REFPRISONIND, TRUSTID
	public static final short FLDSEQNO_CUSTATTR2_ATTRVAL = 0;

	// Optional
	public static final short FLDSEQNO_CUSTATTR3_FIELD1 = 0;

	public static final short FLDSEQNO_CUSTATTR3_FIELD2 = 1;

	// Mapping for BIRTHDT
	public static final short FLDSEQNO_CUSTDATE_DATEVAL = 0;

	// Mapping for NAME
	public static final short FLDSEQNO_CUSTNAME_ONMLAST = 0;

	public static final short FLDSEQNO_CUSTNAME_ONMFIRST = 1;

	public static final short FLDSEQNO_CUSTNAME_ONMMIDDLE = 2;

	public static final short FLDSEQNO_CUSTNAME_ONMPREFIX = 3;

	public static final short FLDSEQNO_CUSTNAME_ONMSUFFIX = 4;

	public static final short FLDSEQNO_CUSTNAME_ONMDEGREE = 5;

	public static final short FLDSEQNO_CUSTNAME_ONMTITLE = 6;

	// Mapping for Phone (CELLPHONE, PRPHONE, SCPHONE, WKPHONE )
	public static final short FLDSEQNO_CUSTPHONE_PHICC = 0;

	public static final short FLDSEQNO_CUSTPHONE_PHAREA = 1;

	public static final short FLDSEQNO_CUSTPHONE_PHNUMBER = 2;

	public static final short FLDSEQNO_CUSTPHONE_PHEXTN = 3;

	public static final short FLDSEQNO_CUSTPHONE_PHCMNT = 4;

	// Mapping for REFPHONE
	public static final short FLDSEQNO_CUSTPHONE2_PHICC = 0;

	public static final short FLDSEQNO_CUSTPHONE2_PHAREA = 1;

	public static final short FLDSEQNO_CUSTPHONE2_PHNUMBER = 2;

	public static final short FLDSEQNO_CUSTPHONE2_PHEXTN = 3;

	public static final short FLDSEQNO_CUSTPHONE2_PHCMNT = 4;

	// Composite View
	public static final String DELIMITE_ATTR = "~";

	public static final String DELIMITE_FIELD = "|";

	public static final String DELIMITE_LINK_REP = "*";

	public static final String COMP_ATTR_NAME_DEATHIND = "DEATHIND";

	public static final String COMP_ATTR_NAME_Gender = "GENDER";

	public static final String COMP_ATTR_NAME_Email = "EMAIL";

	public static final String COMP_ATTR_NAME_Name = "NAME";

	public static final String COMP_ATTR_NAME_PRADDR = "PRADDR";

	public static final String COMP_ATTR_NAME_PHONE = "PHONE";

	public static final String COMP_ATTR_NAME_PermAddress = "PERMADDRESS";

	public static final String COMP_ATTR_NAME_WorkAddress = "WORKADDRESS";

	public static final String COMP_ATTR_NAME_Home2Address = "HOME2ADDRESS";

	public static final String COMP_ATTR_NAME_HomePhone = "HOMEPHONE";

	public static final String COMP_ATTR_NAME_CellPhone = "CELLPHONE";

	public static final String COMP_ATTR_NAME_WorkPhone = "WORKPHONE";

	public static final String COMP_ATTR_NAME_Birthday = "BIRTHDT";

	public static final String COMP_ATTR_NAME_Lock = "LOCK";

	public static final String COMP_ATTR_NAME_PETIND = "PETIND";

	public static final String COMP_ATTR_NAME_CUSTORGN = "CUSTORGN";

	public static final String COMP_ATTR_NAME_LINKAGE = "LINKAGE";

	public static final String COMP_ATTR_NAME_EID = "EID";

	public static final String COMP_ATTR_NAME_CWV_ALL = "ALLS";

	public static final String COMP_ATTR_NAME_CWV_LMT = "ALLL";

	public static final String COMP_ATTR_NAME_CWVNAME = "CWVNAME";

	public static final String CUSTOMER_MASTER_PROPERTIES = "com\\walgreens\\cdi\\properties\\Customer.master.error.properties";

	public static final int MAX_LENGTH_SOURCE_ID = 19;

	public static final int MAX_LENGTH_SOURCE_CODE = 2;

	public static final int MAX_LENGTH_LAST_UPDATE_DATE = 19;

	public static final int MAX_LENGTH_PET_IND = 1;

	public static final int MAX_LENGTH_LOCK_IND = 1;

	public static final int MAX_LENGTH_SEC_CLASS_CODE = 1;

	/* Added new TC & HC source system */
	//RE Source Removed from ACCEPTABLE_VALUES_SOURCE_CODE List
	public static final String ACCEPTABLE_VALUES_SOURCE_CODE = "IC,EC,PC,SM,TC,HC,GW,CH,CM,SF,RI,";

	//RE Source Removed from DEFAULT_PET_IND_N_SOURCES List
	public static final String DEFAULT_PET_IND_N_SOURCES = "EC,PC,SM,TC,GW,";

	public static final String DEFAULT_PET_IND_Y_SOURCES = "";
	
	//RE Source Removed from DEFAULT_LOCK_IND_N_SOURCES
	// EC removed from this filter for EC lock ind new requirement/fix
	public static final String DEFAULT_LOCK_IND_N_SOURCES = "PC,TC,HC,GW,CM,SF,";

	public static final String DEFAULT_LOCK_IND_Y_SOURCES = "";

	public static final String DEFAULT_SEC_CLASS_CODE_H_SOURCES = "IC,SM,TC,HC,GW,CH,CM,SF,RI,";

	// Changes have been made not to check Security Code, Lock Indicator and PET
	// indicator for Loyalty source and set to default as 'N' or 'P'.
	public static final String DEFAULT_SEC_CLASS_CODE_NO_CHECK = "LR,SF,";

	public static final String DEFAULT_PET_IND_NO_CHECK = "LR,";

	public static final String DEFAULT_LOCK_IND_NO_CHECK = "LR,SF,";

	/* Added new TC & HC source system */
	//RE Source Removed from DEFAULT_SEC_CLASS_CODE_P_SOURCES
	public static final String DEFAULT_SEC_CLASS_CODE_P_SOURCES = "PC,LR,";

	public static final String ACCEPTABLE_VALUES_LOCK_IND = "Y,N,H,R,";

	public static final String ACCEPTABLE_VALUES_PET_IND = "Y,N,";

	public static final String ACCEPTABLE_VALUES_SEC_CLASS_CODE = "H,P,";

	public static final String SEC_CLASS_CODE_H = "H";

	public static final String SEC_CLASS_CODE_P = "P";

	public static final String VALUE_Y = "Y";

	public static final String VALUE_N = "N";

	public static final String VALUE_H = "H";

	public static final String VALUE_R = "R";

	// ******************************************************
	// ERROR CODES
	// ******************************************************
	public static final String GET_EC_MANDATORY_FIELDS = "111000";

	public static final String GET_EC_MANDATORY_FIELDS_SRC_CODE = "111001";

	public static final String GET_EC_MANDATORY_FIELDS_SRC_ID = "111002";

	public static final String GET_EC_INVALID_CHAR_FIELDS_SRC_CODE = "111100";

	public static final String GET_EC_INVALID_CHAR_FIELDS_SRC_ID = "111101";

	public static final String GET_EC_INVALID_CHAR_FIELDS_EID = "111102";

	public static final String MERGE_EC_MANDATORY_FIELD_SRC_CODE_SRV = "111500";

	public static final String MERGE_EC_MANDATORY_FIELD_SRC_ID_SRV = "111501";

	public static final String MERGE_EC_MANDATORY_FIELD_SRC_CODE_OBS = "111502";

	public static final String MERGE_EC_MANDATORY_FIELD_SRC_ID_OBS = "111503";

	public static final String MERGE_EC_INVALID_CHAR_SRC_CODE_SRV = "111600";

	public static final String MERGE_EC_INVALID_CHAR_SRC_ID_SRV = "111601";

	public static final String MERGE_EC_INVALID_CHAR_SRC_CODE_OBS = "111602";

	public static final String MERGE_EC_INVALID_CHAR_SRC_ID_OBS = "111603";

	public static final String UPDATE_EC_MANDATORY_FIELD_SRC_CODE = "112000";

	public static final String UPDATE_EC_MANDATORY_FIELD_SRC_ID = "112001";

	public static final String UPDATE_EC_MANDATORY_FIELD_LST_UPD_DATE = "112002";

	public static final String UPDATE_EC_INVALID_CHAR_SRC_CODE = "112100";

	public static final String UPDATE_EC_INVALID_CHAR_SRC_ID = "112101";

	public static final String UPDATE_EC_INVALID_DATE_FORMAT_BRTH_DATE = "112200";

	public static final String UPDATE_EC_INVALID_DATE_FORMAT_LST_UPD_DATE = "112201";

	public static final String UPDATE_EC_INVALID_SRC_CODE = "112202";

	public static final String UPDATE_EC_INVALID_SRC_ID = "112203";

	public static final String UPDATE_EC_INVALID_PET_IND = "112204";

	public static final String UPDATE_EC_INVALID_LOCK_IND = "112205";

	public static final String UPDATE_EC_INVALID_SEC_CLASS_CODE = "112206";

	// sec code fix - amit
	public static final String UPDATE_EC_MANDATE_SEC_CLASS_CODE = "112005";

	public static final String ICUNMERGE_EC_MANDATORY_FIELD_SRC_ID_NEW = "114000";

	public static final String ICUNMERGE_EC_MANDATORY_FIELD_SRC_ID_SRV = "114001";

	public static final String ICUNMERGE_EC_MANDATORY_FIELD_LST_UPD_DATE = "114002";

	public static final String ICUNMERGE_EC_INVALID_CHAR_SRC_ID_NEW = "114100";

	public static final String ICUNMERGE_EC_INVALID_CHAR_SRC_ID_SRV = "114101";

	public static final String ICUNMERGE_EC_INVALID_DATE_FORMAT_LST_UPD_DATE = "114102";

	public static final String ICUNMERGE_EC_INVALID_SEC_CLASS_CODE = "114103";

	public static final String ICUNMERGE_EC_INVALID_PET_IND = "114104";

	public static final String ICUNMERGE_EC_INVALID_LOCK_IND = "114105";

	public static final String ICUNMERGE_EC_SURVIVOR_NOT_EXIST = "114200";

	public static final String ICUNMERGE_EC_EXCEPTION_NO_CANDIDATES_FOUND = "4200";

	public static final String ICUNMERGE_EC_EXCEPTION_LOCK_IND_REQUIRED = "4201";

	public static final String ICUNMERGE_EC_EXCEPTION_PET_IND_REQUIRED = "4202";

	public static final String ICUNMERGE_EC_EXCEPTION_SEC_CODE_REQUIRED = "4203";

	public static final String ICUNMERGE_EC_EXCEPTION_COULD_NOT_SEND_MSG = "4003";

	public static final String ICUNMERGE_EC_EXCEPTION_UNABLE_INS_UPD = "4004";

	public static final String ICUNMERGE_EC_EXCEPTION_HUB_MAY_BE_DOWN = "4005";

	public static final String ICUNMERGE_EC_MEMBER_EXIST = "4006";

	// Customer Delete Error code
	public static final String EC_DELETE_MANDATORY_FIELDS_SRC_CODE = "116000";

	public static final String EC_DELETE_MANDATORY_FIELDS_SRC_ID = "116001";

	public static final String EXCEPTION_NONE_REMAIN_AFTER_FILTER = "MemberException: com.initiate.bean.MemberException: MemberGet ERROR IXN failed: ENOREC[0]: member(s) found but none remain after being filtered.[5118]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberGet ERROR IXN failed: ENOREC[0]: member(s) found but none remain after being filtered.[5118]";

	// Initiate exception message for no candidates found
	public static final String EXCEPTION_NO_CANDIDATES_FOUND = "MemberException: com.initiate.bean.MemberException: MemberSearch ERROR IXN failed: ENOREC[0]: no candidates found.[5308]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberSearch ERROR IXN failed: ENOREC[0]: no candidates found.[5308]";

	public static final String EC_EXCEPTION_NO_CANDIDATES_FOUND = "3001";

	// Initiate exception message for no buckets found
	public static final String EXCEPTION_NO_BUCKETS_FOUND = "MemberException: com.initiate.bean.MemberException: MemberSearch ERROR IXN failed: ENOREC[0]: no buckets were generated from search input data. nothing to search.[5309]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberSearch ERROR IXN failed: ENOREC[0]: no buckets were generated from search input data. nothing to search.[5309]";

	public static final String EC_EXCEPTION_NO_BUCKETS_FOUND = "3002";

	// Initiate exceptions thrown for Lock ind, Pet Ind, and SEC Code
	public static final String EXCEPTION_LOCK_IND_REQUIRED = "MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Lock Indicator required[27]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Lock Indicator required[27]";

	public static final String EC_EXCEPTION_LOCK_IND_REQUIRED = "2003";

	public static final String EXCEPTION_PET_IND_REQUIRED = "MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Pet Indicator required[27]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Pet Indicator required[27]";

	public static final String EC_EXCEPTION_PET_IND_REQUIRED = "2004";

	public static final String EXCEPTION_SEC_CODE_REQUIRED = "MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Security Class Code required[27]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Security Class Code required[27]";

	public static final String EC_EXCEPTION_SEC_CODE_REQUIRED = "2005";

	public static final String EXCEPTION_MEMBER_EXIST_INSERT_ONLY_1 = "MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EEXISTS[0]:";

	public static final String EXCEPTION_MEMBER_EXIST_INSERT_ONLY_2 = "already exists and INSERT_ONLY.[6405];";

	public static final String EXCEPTION_NO_UPDATE_WILL_OCCUR = "MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Updated member data is older or the same as existing member data. No Update will occur.[27]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Updated member data is older or the same as existing member data. No Update will occur.[27]";

	// ADDED BY ANKIT for handling employee benefits handling
	public static final String EXCEPTION_DETACH_PREVIOUS_CARD = "MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Record Rejected.Invalid operation type.Either detach active previous program to add new program or program doesn't exist for requested action.[27]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Record Rejected.Invalid operation type.Either detach active previous program to add new program or program doesn't exist for requested action.[27]";

	public static final String EXCEPTION_DETACH_NOTEXIST_CARD = "MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Cannot Detach a program that does not exist. Record Rejected.[27]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: Cannot Detach a program that does not exist. Record Rejected.[27]";

	// ends
	public static final String EXCEPTION_NO_MEMBER_RECORD_FOUND = "MemberException: com.initiate.bean.MemberException: MemberGet ERROR IXN failed: ENOREC[0]: no member(s) found.[5116]; nested exception is javax.xml.ws.soap.SOAPFaultException: MemberException: com.initiate.bean.MemberException: MemberGet ERROR IXN failed: ENOREC[0]: no member(s) found.[5116]";

	public static final String EXCEPTION_COULD_NOT_SEND_MSG = "Could not send Message.; nested exception is javax.xml.ws.soap.SOAPFaultException: Could not send Message.";

	public static final String EC_EXCEPTION_COULD_NOT_SEND_MSG = "0002";

	public static final String EXCEPTION_UNABLE_INS_UPD_1 = "MemberPut ERROR IXN failed: EODBC[0]";

	public static final String EXCEPTION_UNABLE_INS_UPD_2 = "unable to insert/update/delete member data.[6413]";

	public static final String EC_EXCEPTION_UNABLE_INS_UPD = "0003";

	public static final String EXCEPTION_UNABLE_INS_UPD_DEL = "unable to insert/update/delete member data.";

	public static final String EXCEPTION_MEMPUT_FAIL = "putMemHead: IxnMemPut() failed.";

	public static final String EXCEPTION_HUB_MAY_BE_DOWN = "The Initiate Identity Hub Server may be down";

	public static final String EC_EXCEPTION_HUB_MAY_BE_DOWN = "0004";

	public static final String DO_NOT_THROW_EXCEPTION = "DO_NOT_THROW_EXCEPTION";

	public static final String EXCEPTION_MERGE_CANT_SERIALIZE = "can't serialize access for this transaction";

	public static final String EXCEPTION_MERGE_CANT_LOCK_ENTLNKEM = "unable to lock ENTLKEM table for entType 'id' during MEMMERGE";

	public static final String EC_EXCEPTION_RETRY_LOCK_PET = "0006";

	public static final String EC_EXCEPTION_RETRY_CONCURRENT_MERGE = "0005";

	



	// EC Delete Service
	public static final String EXCEPTION_EC_DELETE_RECORD_ALREADY_DELETED = "memStat='D'";

	public static final String EC_DELETE_EXCEPTION_RECORD_ALREADY_DELETED = "0008";

	public static final String EXCEPTION_EC_DELETE_INVALID_SRCCD = "MemberException: com.initiate.bean.MemberException: MemberDelete ERROR IXN request was invalid: : unknown srcCode";

	public static final String EC_DELETE_EXCEPTION_UNKNOWN_SRCCODE = "0009";

	public static final String EXCEPTION_EC_DELETE_RECORD_NOT_FOUND = "not found.[5114]";

	public static final String EC_DELETE_EXCEPTION_NO_RECORD_FOUND = "0010";

	public static final String EXCEPTION_EC_DELETE_HUB_MAY_BE_DOWN = "The Initiate Identity Hub Server may be down";

	public static final String EC_DELETE__EXCEPTION_HUB_MAY_BE_DOWN = "0011";

	public static final String EXCEPTION_EC_DELETE_COULD_NOT_SEND_MSG = "Could not send Message.; nested exception is javax.xml.ws.soap.SOAPFaultException: Could not send Message.";

	public static final String EC_DELETE_EXCEPTION_COULD_NOT_SEND_MSG = "0012";

	// Added for workflow improvemnet change - Predelete starts here
	



	// Added for workflow improvemnet change - Predelete ends here

	// AP 05/03/2010 -- Unable to insert audit data error catch
	public static final String EXCEPTION_UNABLE_INSERT_AUDIT_DATA = "MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EODBC[0]: unable to insert audit data.";

	public static final String EXCEPTION_UNABLE_INSERT_AUDIT_DATA_2 = "unable to insert audit data.";

	public static final String EC_EXCEPTION_UNABLE_INSERT_AUDIT_DATA = "0007";

	public static final String RETRY_PET_SOURCES = "IC,RI,";

	public static final String RETRY_LOCK_SOURCES = "IC,SM,RI,";

	public static final String EC_UNKNOWN_EXCEPTION = "0000";

	public static final String EC_UNKNOWN_EXCEPTION_2 = "0001";

	public static final String XML_TAG_APPID = "AppID";

	public static final String XML_TAG_ID = "ID";

	public static final String XML_TAG_CUSTOMER = "Consumer";

	public static final String XML_TAG_PASSWORD = "Password";

	public static final String XML_TAG_INITIATEID = "InitiateID";

	public static final String XML_INITIATE_SECURITY_MAP = "com\\walgreens\\cdi\\properties\\initiateKeyStore.xml";

	public static final String XML_APPID_INITIATEID_MAP = "com\\walgreens\\cdi\\properties\\mapAppIDtoInitiate.xml";

	// public static final String
	// XML_INITIATE_SECURITY_MAP="/usr/local/was61/CDIWSTestEAR/CDIWSTestEAR.ear/CDIWSTest.war/WEB-INF/classes/com/walgreens/cdi/properties/initiateKeyStore.xml";
	// public static final String
	// XML_APPID_INITIATEID_MAP="/usr/local/was61/CDIWSTestEAR/CDIWSTestEAR.ear/CDIWSTest.war/WEB-INF/classes/com/walgreens/cdi/properties/mapAppIDtoInitiate.xml";

	public static final String SOFT_DELETE_CODE = "-2147483646";

	public static final String LOG_4_J_PROPERTIES = "log4j.properties";

	public static final String TRACKTIMELOGGER = "TrackTimeLogger";

	/* Added new TC & HC source system */
	public static final String SRC_CODE_FILTER = "IC,SM,EC,TC,HC,GW,LR";

	/* Added new TC & HC source system */

	public static final String ELIGIBILITY_SEARCH_NULL_RESPONSE = "113001";

	public static final String MATCH_MODE_DONOTHING = "DONOTHING";

	public static final String SEG_CODE_MEMHEAD = "MEMHEAD";

	public static boolean ENABLE_PV_SEARCH = true;

	public static final String EMAIL_TO = "it-cdi-java@walgreens.com";

	public static final String EMAIL_FROM = "CDI_Admin@walgreens.com";

	// LR Specific Changes Starts here
	public static final String ATTR_CODE_CUSTGENATTR_CODE = "CUSTGENATTR";

	// public static final String ATTR_CODE_ENROLFORMID = "ENRLFORMID";
	public static final String STR_VERFICATION_CODE = "loyaltyEmployeeSecretCode";

	public static final String STR_FOREIGN_ID = "loyaltyEnrollmentFormId";

	public static final String STR_EECARDNO = "LoyaltyEmployeeCard";

	/* public static final String STR_PSCLROPTIN="PSCLoyaltyOptIn"; */
	public static final String STR_EEEMPLOYEETYPE = "LoyaltyEmployeeType";

	public static final String SEGMENT_CODE_CUSTPROGID = "CUSTPROGID";

	public static final String PROGRAM_STAT = "PROGRAMSTAT";

	public static final String PROGRAM_STARTDT = "PROGRAMSTARTDT";

	public static final String PROGRAM_ENDDT = "PROGRAMENDDT";

	public static final String PROGRAM_IDENT = "PROGRAMIDENT";

	public static final String PROGRAM_ACTION = "PROGRAMACTION";

	public static final String PROGRAM_LAST_UPDATE_DATE = "PROGRAMLASTUPDATEDATE";

	public static final String PROGRAM_LAST_UPDATE_DATE_PV = "PROGRAMLASTUPDATE";

	public static final String PROGRAM_STAT_DEFAULT_VALUE = "P";

	public static final String PROGRAM_STAT_ACTIVE_VALUE = "A";

	public static final String PROGRAM_DEFAULT_END_DATE = "2199-12-31 00:00:00";

	public static final String PROGRAM_IDENTIFIER_DEFAULT_VALUE = "-999";

	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static final String PROGRAM_ACTION_DEFAULT_VALUE = "Update";

	public static final String DEFAULT_TEMP_VALUE = "TEMP";

	public static final String PROGRAM_CODE = "PROGRAMCODE";

	public static final String PROGRAM_LASTUPDATE = "LASTUPDATE";

	public static final String PROGRAM_STATUS = "PROGRAMSTATUS";

	public static final String EESEC_CODE = "EESECRETCODE";

	public static final String ENROLL_FORMID = "ENRLFORMID";

	public static final String EECARDNO = "EECARDNO";

	/* public static final String PSCLROPTIN="PSCLROPTIN"; */
	public static final String EEEMPTYPE = "EEEMPLTYPE";

	public static final String PROGRAMCODE_AARP = "AARP";

	public static final String PROGRAMCODE_EEDR = "EEDR";

	public static final String PROGRAMCODE_EEWAG = "EEWAG";

	public static final String PROGRAMCODE_LYCD = "LYCD";

	/* public static final String PROGRAMCODE_PSC="PSC"; */
	public static final String PROGRAMCODE_VCD = "VCD";

	public static final String PROGRAMCODE_EMPL = "EMPL";

	public static final String PROGRAMCODE_MEMID = "MEMID";

	// @K@-Added for GGPR
	public static final String PROGRAMCODE_GGPR = "GGPR";

	public static final String ATTR_CODE_GGPR = "PROGIDGGPR";

	// @k@ ends

	public static final String ATTR_CODE_AARP = "PROGIDAARP";

	public static final String ATTR_CODE_EEDR = "PROGIDDREE";

	public static final String ATTR_CODE_EEWAG = "PROGIDWAGEE";

	public static final String ATTR_CODE_LYCD = "PROGIDLYCD";

	/* public static final String ATTR_CODE_PSC ="PROGIDPSC"; */
	public static final String ATTR_CODE_VCD = "PROGIDVIRTCD";

	public static final String ATTR_CODE_EMPL = "PROGIDEMPL";

	/*
	 * public static final String
	 * ACCEPTABLE_ENTUPDATE_PROGRAM_CODE_VALUES="AARP,EMPL,LYCD,PSC,VCD,";
	 */
	// @K@ changed by ankit
	public static final String ACCEPTABLE_ENTUPDATE_PROGRAM_CODE_VALUES = "AARP,EMPL,LYCD,VCD,DRCD,GGPR";

	// @k@ ends
	// Changed from "MEMHEAD,CUSTATTR1,CUSTATTR3,CUSTPROGID" to
	// "MEMHEAD,CUSTATTR3,CUSTPROGID"
	public static final String SEG_CODE_ENT_ADD_UPDATE = "MEMHEAD,CUSTATTR3,CUSTPROGID";

	public static final String ACCEPTABLE_ENTUPDATE_VALUES_SOURCE_CODE = "LR,";

	public static final String UPDATE_ENT_INVALID_SRC_CODE = "122207";

	public static final String PROGRAM_CODE_MISSING = "122208";

	public static final Integer MINIMUM_AGE_REQUIRED = 13;

	public static final String MINIMUM_AGE_VALIDATION = "122209";

	public static final String PROGRAM_IDENTIFIER_MISSING = "122210";

	public static final String NOT_A_VALID_PROGRAM_CODE_ADD_UPDATE = "122211";

	public static final String DUPLICATE_PROGCODE_PROGID = "122226";

	public static final String ENT_SEARCH_INVAL_MIN_MAX_MEM_ENT_MATCH_SCORE = "221011";

	public static final String ENT_SEARCH_INVAL_EXCLUDEHUB_CODE = "221008";

	public static boolean ALLOW_PROG_SEARCH = true;

	public static String EXCLUDE_HUB_ONSEARCH = null;

	// public static final String ENT_SEARCH_NULL_RESPONSE = "221001";
	public static final String ENT_SEARCH_MIN_CRITERIA = "221002";

	public static final String ENT_SEARCH_INVAL_CALIBRATION_CODE = "221003";

	public static final String ENT_SEARCH_ENT_MEM_SEARCHSRC_ABS = "221004";

	public static final String NOT_A_VALID_PROGRAM_CODE = "221005";

	public static final String NOT_A_VALID_PROGRAM_ID = "221006";

	public static final String ENT_SEARCH_EMPTY_CALIBRATION_CODE = "221007";

	public static final String ENT_SEARCH_INVAL_PHONENO_CODE = "221008";

	public static final String ENT_SEARCH_INVAL_ZIPCODE_CODE = "221009";

	public static final String MEM_SEARCH_INVAL_MAX_RESPONSE = "221010";

	public static final String MEM_SEARCH_INVAL_MIN_SCORE = "221011";

	public static final String ENT_SEARCH_INVAL_MAX_RESPONSE = "221012";

	public static final String ENT_SEARCH_INVAL_MIN_SCORE = "221013";

	public static final String ENT_SEARCH_INVAL_SRCCODE = "221014";

	public static final String ENT_SEARCH_INVAL_MEMSTATUS = "221015";

	public static final String MISSING_PROGRAM_CODE = "221016";

	public static final String MISSING_PROGRAM_ID = "221017";

	public static final String CALIBRATION_CODE = "A,B";

	public static final String REF_HUB = "REF";

	public static final String CDI_HUB = "CUST";

	public static final String CDI_ALLS_PV = "CDIALLS";

	public static final String REF_ALLS_PV = "REFALLS";

	public static final String TRUSTED_SRC = "IC,EC,SM,TC,HC,GW";
	//RE and LY Source Removed from ALL_SRC list
	public static final String ALL_SRC = "IC,PC,EC,SM,TC,HC,LR,GW,ES";

	/*
	 * public static final String
	 * ACCEPTABLE_ENTSEARCH_PROGRAM_CODE_VALUES="AARP,EEDR,EEWAG,LYCD,PSC,VCD,";
	 */
	// @k@ Added for GGPR
	public static final String ACCEPTABLE_ENTSEARCH_PROGRAM_CODE_VALUES = "AARP,LYCD,VCD,EMPL,GGPR";

	// @k@ ends
	public static final String ATTR_CODE_ATTRRECNO = "ATTRRECNO";

	public static final String COMA_DELIMITER = ",";

	public static final String PIPE_DELIMITER = "|";

	public static final String SPLIT_PIPE_DELIMITER = "\\|";

	public static final String VAL_YES = "Y";

	public static final String VAL_NO = "N";

	public static final String SEG_CODE_ALLS_CDI = "MEMHEAD,CUSTNAME,CUSTADDR,CUSTADDR2,CUSTATTR,CUSTATTR1,CUSTATTR2,CUSTATTR3,CUSTDATE,CUSTPHONE,CUSTPROGID";

	public static final String SEG_CODE_ALLS_REF = "MEMHEAD,CUSTNAME,CUSTADDR,CUSTATTR1,CUSTDATE,CUSTPHONE";

	public static final String SRC_CODE_LR = "LR";

	public static final String SRC_CODE_ES = "ES";

	/*
	 * public static final String ATTR_CODE_PROGRAM =
	 * "PROGIDEMPL,PROGIDPSC,PROGIDAARP,PROGIDLYCD,PROGIDVIRTCD";
	 */
	// @k@ added for GGPR
	public static final String ATTR_CODE_PROGRAM = "PROGIDEMPL,PROGIDAARP,PROGIDLYCD,PROGIDVIRTCD,PROGIDGGPR";

	// @k@
	public static final int CM_PROG_PROGRAMSTATUS = 0;

	public static final int CM_PROG_PROGRAMIDENT = 1;

	public static final int CM_PROG_PROGRAMSTARTDT = 2;

	public static final int CM_PROG_PROGRAMENDDT = 3;

	public static final int CM_PROG_PROGRAMCODE = 4;

	public static final int CM_PROG_PROGRAMLASTUPDATDT = 5;

	public static final int CM_ATTR_KEY = 0;

	public static final int CM_ATTR_VALUE = 1;

	public static final String SEARCH_CALIBRATION_CD_A = "A";

	public static final String SEARCH_CALIBRATION_CD_B = "B";

	public static final String SEARCH_CALIBRATION_CD_C = "C";

	

	public static final String SRC_TRUST = "TRUST";

	public static final String SRC_ALL = "ALL";
	//RE and LY Source Removed from ACCEPTABLE_SRCCODE_VALUE list
	
	//GC Source added  to  ACCEPTABLE_SRCCODE_VALUE list
	public static final String ACCEPTABLE_SRCCODE_VALUE = "IC|PC|EC|SM|TC|HC|LR|GW|ES|CM|SF|GC|RI|TRUST|ALL";

	public static final String ACCEPTABLE_PROG_STATUS_VALUE = "A,P";

	public static final String ACCEPTABLE_MEM_STATUS_VALUE = "A,D";

	public static final String STATUS_PENDING = "P";

	public static final String VALUE_TRUE = "True";

	public static final String VALUE_FALSE = "False";

	public static final String ARRAY_COUNT_MISMATCH = "122212";

	public static final String PROGRAM_CODE_NOT_MATCHING_WITHIN_ARRAY = "122213";

	public static final String PROGRAM_ID_NOT_MATCHING_WITHIN_ARRAY = "122214";

	public static final String VCD_WCARD_NUMBER = "627857";

	public static final String VCD_CARD_RANGE = "712";

	public static final int GENERATED_NO_LEN = 9;

	public static final String NOT_A_VALID_CDIKEY = "122215";

	public static final String CDIKEY_MISSING = "122216";

	/*
	 * public static final String
	 * ACCEPTABLE_CDI_KEY="LOYALTYEMPLOYEESECRETCODE,LOYALTYENROLLMENTFORMID,PSCLOYALTYOPTIN,PSCPAIDIND,LOYALTYEMPLOYEECARD,LOYALTYEMPLOYEETYPE";
	 */
	public static final String ACCEPTABLE_CDI_KEY = "LOYALTYEMPLOYEESECRETCODE,LOYALTYENROLLMENTFORMID,LOYALTYEMPLOYEECARD,LOYALTYEMPLOYEETYPE";

	public static final String VCD_SRCRECNO = "274";

	public static final String ACCEPTABLE_PROGRAM_ACTION_VALUES = "ADD,UPDATE,DETACH,INACTIVATE";

	public static final String INVALID_PROGRAM_ACTION_VALUE = "122217";

	public static final String ACCEPTABLE_PROGRAM_STATUS_VALUES = "A,I,D";

	public static final String INVALID_PROGRAM_STATUS_VALUE = "122218";

	public static final String PROGRAM_STATUS_A = "A";

	public static final String PROGRAM_STATUS_I = "I";

	public static final String PROGRAM_STATUS_D = "D";

	public static final String PROGRAM_DATES_MISSING = "122219";

	public static final String INVALID_PROGRAM_DATES = "122220";

	public static final String EXCEPTION_UPDATE_DO_NOT_THROW = "122221";

	public static final String PROGRAM_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static final String PROGRAM_EEDR = "EEDR";

	public static final String PROGRAM_EEWAG = "EEWAG";

	public static final String PROGRAM_EMPL = "EMPL";

	public static final String CDI_EMPL_KEY = "LOYALTYEMPLOYEETYPE";

	public static final String ATTRCODE = "attrCode";

	public static final String ATTRVAL = "attrval";

	public static final String SRCL_TIME = "srcLtime";

	public static final String INVALID_STRING = ",,";

	public static final short MAX_MATCH_SCORE = 128;

	public static boolean ENT_PV_TABLE_SEARCH = true;

	public static final String PROGRAM_ACTION_MISSING = "122222";

	public static final String PROGRAM_STATUS_MISSING = "122223";

	public static final String INVALID_OPERATION_TYPE = "122224";

	public static final String SEG_CODE_ENT_SEARCH_MEMHEAD = "MEMHEAD";

	



	public static final short PROGCODE_SEARCH_MIN_SCORE = 0;

	public static final String FLD_FIRSTNAME = "FIRSTNAME";

	public static final String FLD_MIDDLENAME = "MIDDLENAME";

	public static final String FLD_LASTNAME = "LASTNAME";

	public static final String FLD_PREFIXNAME = "PREFIXNAME";

	public static final String FLD_SUFFIXNAME = "SUFFIXNAME";

	public static final String FLD_NAMEUPDATE = "NAMEUPDATE";

	public static final String FLD_NAMSRCCODE = "NAMSRCCODE";

	public static final String FLD_NAMSECCODE = "NAMSECCODE";

	public static final String FLD_GENDERSECCODE = "GENDERSECCODE";

	public static final String FLD_GENDER = "GENDER";

	public static final String FLD_GENDERUPDATE = "GENDERUPDATE";

	public static final String FLD_GENDERSRCCODE = "GENDERSRCCODE";

	public static final String FLD_PETIND = "PETIND";

	public static final String FLD_PETUPDATE = "PETUPDATE";

	public static final String FLD_PETSECCODE = "PETSECCODE";

	public static final String FLD_PETSRCCODE = "PETSRCCODE";

	public static final String FLD_DEATHIND = "DEATHIND";

	public static final String FLD_DEATHUPDATE = "DEATHUPDATE";

	public static final String FLD_DEATHSECCODE = "DEATHSECCODE";

	public static final String FLD_DEATHSRCCODE = "DEATHSRCCODE";

	public static final String FLD_EMAIL = "EMAIL";

	public static final String FLD_EMAIL1 = "EMAIL1";

	public static final String FLD_EMAIL2 = "EMAIL2";

	public static final String FLD_EMAILTYPE = "EMAILTYPE";

	public static final String FLD_EMAILUPDATE = "EMAILUPDATE";

	public static final String FLD_EMAILSECCODE = "EMAILSECCODE";

	public static final String FLD_EMAILSRCCODE = "EMAILSRCCODE";

	public static final String FLD_LOCKIND = "LOCKIND";

	public static final String FLD_LOCKUPDATE = "LOCKUPDATE";

	public static final String FLD_LOCKSECCODE = "LOCKSECCODE";

	public static final String FLD_LOCKSRCCODE = "LOCKSRCCODE";

	public static final String FLD_BIRTHDATE = "BIRTHDATE";

	public static final String FLD_BIRTHUPDATE = "BIRTHUPDATE";

	public static final String FLD_BIRTHSECCODE = "BIRTHSECCODE";

	public static final String FLD_BIRTHSRCCODE = "BIRTHSRCCODE";

	public static final String FLD_ADDRTYPE = "ADDRTYPE";

	public static final String FLD_PFTNOTE = "PFTNOTE";

	public static final String FLD_PCUSTCITY = "PCUSTCITY";

	public static final String FLD_PCUSTCOUNTRY = "PCUSTCOUNTRY";

	public static final String FLD_PDPVFTNOTE = "PDPVFTNOTE";

	public static final String FLD_PDPVIND = "PDPVIND";

	public static final String FLD_PLACSADDRFLAG = "PLACSADDRFLAG";

	public static final String FLD_PLACSFTNOTE = "PLACSFTNOTE";

	public static final String FLD_PLACSRTRNCODE = "PLACSRTRNCODE";

	public static final String FLD_PADDRUPDATE = "PADDRUPDATE";

	public static final String FLD_PLATITUDE = "PLATITUDE";

	public static final String FLD_PLONGITUDE = "PLONGITUDE";

	public static final String FLD_PNCOAACTCODE = "PNCOAACTCODE";

	public static final String FLD_PNCOAANKCODE = "PNCOAANKCODE";

	public static final String FLD_PNCOAMVDATE = "PNCOAMVDATE";

	public static final String FLD_PNCOAMVTYPE = "PNCOAMVTYPE";

	public static final String FLD_PNCOANEWADDRFLG = "PNCOANEWADDRFLG";

	public static final String FLD_PNCOANIXFTNOTE = "PNCOANIXFTNOTE";

	public static final String FLD_PNCOAPRDATE = "PNCOAPRDATE";

	public static final String FLD_PNCOARTRNCODE = "PNCOARTRNCODE";

	public static final String FLD_PADDRSECCODE = "PADDRSECCODE";

	public static final String FLD_PADDRSRCCODE = "PADDRSRCCODE";

	public static final String FLD_PPRDATE = "PPRDATE";

	public static final String FLD_PCUSTSTATE = "PCUSTSTATE";

	public static final String FLD_PCUSTSTLINE1 = "PCUSTSTLINE1";

	public static final String FLD_PCUSTSTLINE2 = "PCUSTSTLINE2";

	public static final String FLD_PURBCODE = "PURBCODE";

	public static final String FLD_PADDRTYPE = "PADDRTYPE";

	public static final String FLD_PCUSTZIPCODE = "PCUSTZIPCODE";

	public static final String FLD_ADDRTYPE2 = "ADDRTYPE2";

	public static final String FLD_HFTNOTE = "HFTNOTE";

	public static final String FLD_HCUSTCITY = "HCUSTCITY";

	public static final String FLD_HCUSTCOUNTRY = "HCUSTCOUNTRY";

	public static final String FLD_HDPVFTNOTE = "HDPVFTNOTE";

	public static final String FLD_HDPVIND = "HDPVIND";

	public static final String FLD_HLACSADDRFLAG = "HLACSADDRFLAG";

	public static final String FLD_HLACSFTNOTE = "HLACSFTNOTE";

	public static final String FLD_HLACSRTRNCODE = "HLACSRTRNCODE";

	public static final String FLD_HADDRUPDATE = "HADDRUPDATE";

	public static final String FLD_HLONGITUDE = "HLONGITUDE";

	public static final String FLD_HLATITUDE = "HLATITUDE";

	public static final String FLD_HADDRSECCODE = "HADDRSECCODE";

	public static final String FLD_HADDRSRCCODE = "HADDRSRCCODE";

	public static final String FLD_HPRDATE = "HPRDATE";

	public static final String FLD_HCUSTSTLINE1 = "HCUSTSTLINE1";

	public static final String FLD_HCUSTSTLINE2 = "HCUSTSTLINE2";

	public static final String FLD_HCUSTSTATE = "HCUSTSTATE";

	public static final String FLD_HURBCODE = "HURBCODE";

	public static final String FLD_HADDRTYPE = "HADDRTYPE";

	public static final String FLD_HCUSTZIPCODE = "HCUSTZIPCODE";

	public static final String FLD_ADDRTYPE3 = "ADDRTYPE3";

	public static final String FLD_WFTNOTE = "WFTNOTE";

	public static final String FLD_WCUSTCITY = "WCUSTCITY";

	public static final String FLD_WCUSTCOUNTRY = "WCUSTCOUNTRY";

	public static final String FLD_WDPVFTNOTE = "WDPVFTNOTE";

	public static final String FLD_WDPVIND = "WDPVIND";

	public static final String FLD_WLACSADDRFLAG = "WLACSADDRFLAG";

	public static final String FLD_WLACSFTNOTE = "WLACSFTNOTE";

	public static final String FLD_WLACSRTRNCODE = "WLACSRTRNCODE";

	public static final String FLD_WADDRUPDATE = "WADDRUPDATE";

	public static final String FLD_WLONGITUDE = "WLONGITUDE";

	public static final String FLD_WLATITUDE = "WLATITUDE";

	public static final String FLD_WADDRSECCODE = "WADDRSECCODE";

	public static final String FLD_WADDRSRCCODE = "WADDRSRCCODE";

	public static final String FLD_WPRDATE = "WPRDATE";

	public static final String FLD_WCUSTSTLINE1 = "WCUSTSTLINE1";

	public static final String FLD_WCUSTSTLINE2 = "WCUSTSTLINE2";

	public static final String FLD_WCUSTSTATE = "WCUSTSTATE";

	public static final String FLD_WURBCODE = "WURBCODE";

	public static final String FLD_WADDRTYPE = "WADDRTYPE";

	public static final String FLD_WCUSTZIPCODE = "WCUSTZIPCODE";

	public static final String FLD_HPHTYPE = "HPHTYPE";

	public static final String FLD_HPHAREA = "HPHAREA";

	public static final String FLD_HPHNUMBER = "HPHNUMBER";

	public static final String FLD_HPHUPDATE = "HPHUPDATE";

	public static final String FLD_HPHSRCCODE = "HPHSRCCODE";

	public static final String FLD_HPHSECCODE = "HPHSECCODE";

	public static final String FLD_CPHTYPE = "CPHTYPE";

	public static final String FLD_CPHAREA = "CPHAREA";

	public static final String FLD_CPHNUMBER = "CPHNUMBER";

	public static final String FLD_CPHUPDATE = "CPHUPDATE";

	public static final String FLD_CPHSRCCODE = "CPHSRCCODE";

	public static final String FLD_CPHSECCODE = "CPHSECCODE";

	public static final String FLD_WPHTYPE = "WPHTYPE";

	public static final String FLD_WPHAREA = "WPHAREA";

	public static final String FLD_WPHNUMBER = "WPHNUMBER";

	public static final String FLD_WPHUPDATE = "WPHUPDATE";

	public static final String FLD_WPHSRCCODE = "WPHSRCCODE";

	public static final String FLD_WPHSECCODE = "WPHSECCODE";

	public static final String FLD_ENTITYID = "ENTITYID";

	public static final String FLD_SRCCODE = "SRCCODE";

	public static final String FLD_PRSNSEQNO = "PRSNSEQNO";

	// LR Specific Changes Ends here

	public static final String PROGRAM_ACTION_ADD = "ADD";

	public static final String PROGRAM_ACTION_UPDATE = "UPDATE";

	public static final String PROGRAM_ACTION_DETACH = "DETACH";

	public static final String PROGRAM_ACTION_INACTIVATE = "INACTIVATE";

	// for CustomerMasterMemberIdService.

	public static final String ID_SERVICE_PROGRAM_CODE_ISMISSING = "333001";

	public static final String DUPLICATE_PROGRAM_CODE = "333002";

	public static final String INVALID_ID_PROGRAM_CODE = "333004";

	public static final String KEY_GENERATION_ID_ERROR = "333005";

	// @Ankit - Added for Loyalty Attributes Handling
	public static final String MULTIPLE_LR_EMPL_ATTR = "122228";

	public static final String LR_EMPL_ATTR_INCOMPLETE = "122229";

	public static final String LR_DETACH_PREVIOUS_PROGRAM = "122230";

	public static final String LR_DETACHING_NONEXISTING_PROGRAM = "122231";

	public static final String LR_DETACH_REQUESTMISSING = "122232";

	public static final String LR_SOFTDELETE_REQUESTMISSING = "122333";

	public static final String LR_EMPL_BENEFIT_INCOMPLETE = "122334";

	public static final String MULTIPLE_EMPL_BENEFIT = "122335";

	// ends

	public static final String PROGRAM_DRCD = "DRCD";

	public static final String BDATE_FORMAT = "yyyy-MM-dd";

	public static final String BDATE_FORMAT_TIME = "yyyy-MM-dd HH:mm:ss";

	public static final String BDATE_AGE_FORMAT_ERROR = "122225";

	public static final String SRC_CODE_FILTER_CUSTOMER_LOOKUP = "IC,SM,EC,TC,HC,GW,CH,CM,EE,SF,RI,";

	public static final String ATTR_CODE_PHONE_REF = "PHONE";

	public static final String ATTR_CODE_PHONE1_REF = "PHONE1";

	public static final String ATTR_CODE_PHONE2_REF = "PHONE2";

	public static final String ATTR_CODE_BIRTH_DT_REF = "DOB";

	public static final String ATTR_CODE_ADDRESS_REF = "ADDR";
	
	//RE and LY Source Removed from ENT_SEARCH_SRC_CALCODE_A
	
	//GC added to  ent search source  list
	public static final String ENT_SEARCH_SRC_CALCODE_A = "IC,EC,SM,TC,HC,GW,CM,SF,GC,RI,PC";

	public static final String LR_SRC = "LR";

	public static final String SRC_CODE_FILTER_LOOKUP_LINKAGE = "IC,SM,EC,TC,HC,GW,LR,CH,CM,EE,SF,RI,";

	public static final int AREA_CODE_LENGTH = 3;

	public static final int PHONE_NUMBER_LENGTH = 7;

	public static final String INVALID_EMPL_COMBINATION = "122227";

	public static final String SEG_CODE_ENT_ADD_MEMBER_CHECK = "MEMHEAD,CUSTPROGID";

	public static final String EXCLUDE_BOTH_HUB = "NONE";

	public static final String ANON_DT = "19010101";

	public static final short CMP_MIN_SCORE = 80;

	public static final short ANON_MIN_SCORE = 42;

	public static final String BLANK_VAL = "";

	// for Address validation change
	public static final String ADDRESS_REMOVABLE_STRING = "#";

	public static final String BLANK_STRING = "";

	// for Address validation change

	// Added For Exception Handling For merged/Deleted Member
	public static final String EXCEPTION_UPDATE_MERGED_MEMBER = "memstat 'M' disallows updates for given attribute(s)";

	public static final String EXCEPTION_UPDATE_DELTED_MEMBER = "memstat 'D' disallows updates for given attribute(s)";

	// END For Exception Handling For merged/Deleted Member

	public static final String LOYALTY_PV_SEARCH_OFF_CHANELS_LIST = "EIS"; // Added

	// END For Exception Handling For merged/Deleted Member
	public static final String SRC_CODE_IGNORE_SOURCE_TS = "CH,";// Code

	// change
	// start
	// [SrcLTime
	// will be
	// set as
	// Current
	// Date Time
	// for CH
	// source]

	// Variable added for IC UnMerge changes.
	public static final String PUT_ARGUMENT_OVERRIDE_INSERTONLY = "OVERRIDE_INSERTONLY";

	public static final String PUT_ARGUMENT_OVERRIDE_ICUNMERGE = "OVERRIDE_ICUNMERGE";

	public static final String DEFAULT_TIMEZONE_GMT = "GMT";

	public static final String DEFAULT_DATE_FORMAT_OTHER = "yyyy-MM-dd hh:mm:ss a";

	public static final String RULE_TYPE_NON_IDENTITY = "D";

	public static final String ICUNMERGE_SUCCESS_ERROR_MSG = "NI Rules placed successfully between";
//	Variable addition start for ECOMM Validation changes
	
	public static final String ACCEPTABLE_VALUE_CV_CONTROL="0,1,3,NULL,BLANK,"; //3 added as ECOMM defect Fix
	public static final String INVALID_CV_CONTROL_VAL="112207";
	public static final String ATTR_CODE_CVCONTROL = "CVCONTROL";
	public static final String EC_EXCEPTION_CV_CONTROL_REQUIRED = "2208";
	public static final String EXCEPTION_CV_CONTROL_REQUIRED = "MemberException: com.initiate.bean.MemberException: MemberPut ERROR IXN failed: EHANDLER[0]: error in pre interaction callback: CVControl is Required Field.[27]"; 
	public static final String GW_SEARCH_APPILCATION_ID_LIST="GW,";
	public static final String GW_CVCONTROL_VAL = "2";
	public static final String STRING_NULL = "NULL";
	public static final String STRING_BLANK = "BLANK";
	public static final String CVCONTROL_SRC = "EC";
	public static final String WARNCODE_CVCONTROL_NONAUTHENTICATE="W112209|";
	public static final String WARNMSG_CVCONTROL_NONAUTHENTICATE = "|Non-authenticated user is attempting to update the cvControl flag";
//	Variable addition End for ECOMM Validation changes
//	Error code added for Undelete service
	public static final String EXCEPTION_EC_UNDELETE_RECORD_ALREADY_ACTIVE = "member not deleted, memStat='A'";

	public static final String EC_UNDELETE_EXCEPTION_RECORD_ALREADY_ACTIVE = "0014";
	
	public static final String EXCEPTION_EC_UNDELETE_INVALID_SRCCD = " MemberException: com.initiate.bean.MemberException: MemberUndelete ERROR IXN request was invalid: : unknown srcCode";
	
	//Error code added for Loyalty Exception Handling--START
	public static final String EXCEPTION_CODE_MEMBER_MERGE_UPDATE = "122337";
	public static final String EXCEPTION_CODE_MEMBER_DELETE_UPDATE = "122336";
	public static final String MEMBER_STATUS_MERGE = "M";
	public static final String MEMBER_STATUS_DELETE = "D";	
	//Error code added for Loyalty Exception Handling--END
	
	// Variable added for synch ID reDesign
	public static final String HIPPA_CV = "HIPPA_CV";
	public static final String ALL_SRC_CV = "ALL_SRC_CV";

	//constant added for Guest checkout 
	public static final String SRC_CODE_GC = "GC";
	
	//Constant added for ERX_SEARCH_PERFOMANCE_IMPROVEMENT
	public static final String ERX_SEARCH_APPILCATION_ID_LIST="ERX,";
	public static final short ERX_MIN_SCORE =60;
	public static final int ERX_MAX_ROWS=2;
	//Log Enhancement change start
	public static final String NEXT_LINE_DELIMITER="\n";
	public static final String SOAP_MESSAGE_DELIMITER="";
	public static final String FILTER_NAME_ORIGINAL_MEMPUT= "ORIGINAL MEMPUT";
	public static final String FILTER_NAME_SECONDARY_MEMPUT= "SECONDARY MEMPUT";
	public static final String FILTER_NAME_MEMHEAD_SEARCH= "MEMHEAD SEARCH";
	public static final String FILTER_NAME_DYNAMIC_SEARCH= "DYNAMIC SEARCH";
	public static final String FILTER_NAME_SUBSEQUENT_MEMGET="SUBSEQUENT MEMGET";
	//Log Enhancement change end
	
	// Phone Alignment changes start
	public static final String FIELD_NAME_PHPRIORITY = "field1";
	public static final String UPDATE_EC_INVALID_PHONE_PRIOR_CODE= "112209";
	public static final String ACCEPTABLE_VALUES_PHONE_PRIORITY="P,A1,A2,-2147483646";
	public static final String ATTR_CODE_HPHMETADATA = "HPHMETADATA";
	public static final String ATTR_CODE_CPHMETADATA = "CPHMETADATA";
	public static final String ATTR_CODE_WPHMETADATA = "WPHMETADATA";
	public static final String PRIOR_PRIMARY="P";
	public static final String PRIOR_ALT1="A1";
	public static final String PRIOR_ALT2="A2";
	public static final String HPHPRIORITY="HPHPRIORITY";
	public static final String CPHPRIORITY="CPHPRIORITY";
	public static final String WPHPRIORITY="WPHPRIORITY";
	public static final String HPHTYPE="HPhTYPE";
	public static final String HPHAREA="HPhArea";
	public static final String HPHNUMBER="HPhNumber";
	public static final String HPHUPDATE="HPhUpdate";
	public static final String HPHSRCCODE="HPhSrcCode";
	public static final String HPHSECCODE="HPhSEcCode";
	public static final String CPHTYPE="CPhTYPE";
	public static final String CPHAREA="CPhArea";
	public static final String CPHNUMBER="CPhNumber";
	public static final String CPHUPDATE="CPhUpdate";
	public static final String CPHSRCCODE="CPhSrcCode";
	public static final String CPHSECCODE="CPhSecCode";
	public static final String WPHTYPE="WPhTYPE";
	public static final String WPHAREA="WPhArea";
	public static final String WPHNUMBER="WPhNumber";
	public static final String WPHUPDATE="WPhUpdate";
	public static final String WPHSRCCODE="WPhSrcCode";
	public static final String WPHSECCODE="WPhSecCode";
	//Phone Alignment changes end
	// Initiate Upgrade Change
	public static final String UNMERGE_USER="UNMERGE";

	public static final String DATE_FORMAT="yyyy-MM-dd hh:mm:ss:S";
	public static final String ROW_IND_D="D";
	public static final String REPOSNE_TRUE="true";
	//pc realtime change starts
	public static final String SEARCH_TYPE_SEARCH_SRC_AND_CV_TYPE_SHOULD_NOT_BE_BLANK = "444001";
    public static final String INVALID_SEARCH_SRC = "444002";
    public static final String SEARCH_TYPE_CUSTOMER = "Customer";
    public static final String SEARCH_TYPE_CONSUMER = "Consumer";
    public static final String SEARCH_TYPE_BOTH = "Both";
    public static final String ACCEPTABLE_CUSTOMER_SRC = "TRUST,ALL,IC,PC,EC,SM,TC,HC,LR,GW,CM,SF,GC,RI,EE";
    public static final String ACCEPTABLE_CONSUMER_SRC  = "ES,AA,DC";
    public static final String SPLIT_COMA_DELIMITER = "\\,";
    public static final String CVTYPE_HIPPA = "Hipaa";
    public static final String CVTYPE_MARKETING = "Marketing";
    public static final String CVTYPE_LOYALTY = "Loyalty";
	public static final String ACCEPTABLE_ENTERPRISE_UPDATE_VALUES_SOURCE_CODE = "IC,EC,PC,SM,TC,HC,GW,CH,CM,SF,RI,LR,";
	public static final String ALLS_CUSTOMER_ENTTYPE = "ALLS_id";
	public static final String ENTERPRISE_SEARCH_SRC_CALCODE_ALL = "IC,EC,SM,TC,HC,GW,CM,SF,GC,RI,PC,LR,EE,";
	public static final String ACCEPTABLE_SEARCH_TYPE="CUSTOMER,CONSUMER,BOTH";
	public static final String ACCEPTABLE_CV_TYPE_CUSTOMER="HIPAA,MARKETING,LOYALTY";
	public static final String ACCEPTABLE_CV_TYPE_CONSUMER="DEFAULT";
	public static final String ACCEPTABLE_SEARCH_TYPE_ERROR = "444003";
	public static final String ACCEPTABLE_CV_TYPE_ERROR = "444004";
	public static final String DEFAULT_LOCK_IND_N_SOURCES_ENTERPRISE = "TC,HC,GW,CM,SF,";
	public static final String DEFAULT_SEC_CLASS_CODE_P_SOURCES_ENTERPRISE = "LR,";
	public static final String DEFAULT_PET_IND_N_SOURCES_ENTERPRISE = "EC,SM,TC,GW,";
	public static final String ALL_SOURCE_CV = "ALL_SOURCE_CV";
	public static final String INVALID_MIN_MATCH_SCORE="444005";
	public static final String INVALID_MAX_RESPONSE="444006";
	public static final String NOCHECK_LOCK_PET_SEC_IND_SOURCES = "PC,";
	//pc realtime change ENDS
	
	//PCC CR changes start
	public static final String NON_TRUSTED_SOURCES  = "'PC','LR','GC'";
	public static final String NON_AUTHORIZE_APPLICATION_ID_HIPAA="POMS";
	public static final String INVALID_SEARCH_CRITERIA="444007";
	//PCC CR changes ends
	//Riteaid change start
	// PREFIX_<ApplicationID> String will have Matching Pattern for Respective Application ID.For Example If Application ID is IC Pattern PREFIX_IC  will work
	//For Adding New Pattern 2 steps Required:
	//1- Add Pattern under PREFIX_<Application Id>
	//2-Append  New Application ID in  APPID_RITEAID String
	public static final String PREFIX_IC = "((RAD|PRM).*)"; 
    public static final String APPID_RITEAID = "IC";
    public static final String PREFIX = "PREFIX_";
    //Riteaid change end
    public static final String PHONE_NUMBER_1 ="1";
	public static final String PHONE_AREA_0 ="0";
	public static final String PHONE_AREA_1 ="1";
	public static final String SIMPLE_DATE_FORMAT="yyyy-MM-dd hh:mm:ss:S";
	public static final String SIMPLE_DATE_FORMAT_1="yyyy-MM-dd";
	public static final String SIMPLE_DATE_FORMAT_2 ="yyyyMMdd";
    public static final String MISSING_MIN_MATCH_SCORE = "444008";
    public static final String MISSING_MAX_ROWS_COUNT = "444009";
    public static final String ALLOW_PROG_SEARCH_SERVLET="ALLOW_PROG_SEARCH";
	public static final String EXCLUDE_HUB_ONSEARCH_SERVLET="EXCLUDE_HUB_ONSEARCH";
	public static final String PVSEARCH_FLAG_SERVLET="PVSEARCH_FLAG";
	public static final String USER="user";
	public static final String CDIUSER="cdiuser";
	public static final String MEMHEAD="MemHead";
	
	public static final String SELECT_QUERY_1="select ENTITYID,CVWTYPE,LASTNAME,FIRSTNAME,MIDDLENAME,PREFIXNAME,SUFFIXNAME,NAMEUPDATE,NAMSECCODE,NAMSRCCODE,BIRTHDATE,BIRTHUPDATE,BIRTHSECCODE,BIRTHSRCCODE,EMAILTYPE,EMAIL,EMAILUPDATE,EMAILSECCODE,EMAILSRCCODE,ADDRTYPE,PCUSTSTLINE1,PCUSTSTLINE2,PCUSTCITY,PCUSTSTATE,PCUSTZIPCODE,PCUSTCOUNTRY,PADDRTYPE,PDPVFTNOTE,PDPVIND,PFTNOTE,PLATITUDE,PLONGITUDE,PPRDATE,PURBCODE,PLACSADDRFLAG,PLACSFTNOTE,PLACSRTRNCODE,PNCOAACTCODE,PNCOAANKCODE,PNCOAMVDATE,PNCOAMVTYPE,PNCOANEWADDRFLG,PNCOANIXFTNOTE,PNCOAPRDATE,PNCOARTRNCODE,PADDRUPDATE,PADDRSECCODE,PADDRSRCCODE,ADDRTYPE2,HCUSTSTLINE1,HCUSTSTLINE2,HCUSTCITY,HCUSTSTATE,HCUSTZIPCODE,HCUSTCOUNTRY,HADDRTYPE,HDPVFTNOTE,HDPVIND,HFTNOTE,HLATITUDE,HLONGITUDE,HPRDATE,HURBCODE,HLACSADDRFLAG,HLACSFTNOTE,HLACSRTRNCODE,HADDRUPDATE,HADDRSECCODE,HADDRSRCCODE,ADDRTYPE3,WCUSTSTLINE1,WCUSTSTLINE2,WCUSTCITY,WCUSTSTATE,WCUSTZIPCODE,WCUSTCOUNTRY,WADDRTYPE,WDPVFTNOTE,WDPVIND,WFTNOTE,WLATITUDE,WLONGITUDE,WPRDATE,WURBCODE,WLACSADDRFLAG,WLACSFTNOTE,WLACSRTRNCODE,WADDRUPDATE,WADDRSECCODE,WADDRSRCCODE,HPHTYPE,HPHAREA,HPHNUMBER,HPHUPDATE,HPHSECCODE,HPHSRCCODE,CPHTYPE,CPHAREA,CPHNUMBER,CPHUPDATE,CPHSECCODE,CPHSRCCODE,WPHTYPE,WPHAREA,WPHNUMBER,WPHUPDATE,WPHSECCODE,WPHSRCCODE,GENDER,GENDERUPDATE,GENDERSECCODE,GENDERSRCCODE,PETIND,PETUPDATE,PETSECCODE,PETSRCCODE,DEATHIND,DEATHUPDATE,DEATHSECCODE,DEATHSRCCODE,LOCKIND,LOCKUPDATE,LOCKSECCODE,LOCKSRCCODE,STOREORIG,STOREIND,STOREUPDATE,STORESECCODE,STORESRCCODE,LASTUPDATE from CDI_EMCA_CV_ALL_SRC where ENTITYID in (";
	public static final String ERROR_SELECT_QUERY_1="Error while getting value from CDI_EMCA_CV_ALL_SRC table with ENTITYID:";
	
	public static final String SELECT_QUERY_2="select ENTITYID,SRCCODE,SRCID,MEMSTAT,TRANDATE,REFCODE,REFID from CDI_LINKAGE_CV_ALL_SRC where ENTITYID in (";
	public static final String AND_SOURCECODE_IN= " and srccode in (";
	public static final String SELECT_QUERY_3="select ENTITYID,SRCCODE,SRCID,MEMSTAT,TRANDATE,REFCODE,REFID from CDI_LINKAGE_CV_ALL_SRC where ENTITYID in (";
	public static final String ERROR_SELECT_QUERY_2="Error while getting value from cdi_linkage_cv_all_src table with ENTITYID:";
	
	public static final String SELECT_QUERY_4="select SRCCODE,SRCID,CVWTYPE,LASTNAME,FIRSTNAME,MIDDLENAME,PREFIXNAME,SUFFIXNAME,NAMEUPDATE,NAMSECCODE,NAMSRCCODE,BIRTHDATE,BIRTHUPDATE,BIRTHSECCODE,BIRTHSRCCODE,EMAILTYPE,EMAIL,EMAILUPDATE,EMAILSECCODE,EMAILSRCCODE,ADDRTYPE,PCUSTSTLINE1,PCUSTSTLINE2,PCUSTCITY,PCUSTSTATE,PCUSTZIPCODE,PCUSTCOUNTRY,PADDRTYPE,PDPVFTNOTE,PDPVIND,PFTNOTE,PLATITUDE,PLONGITUDE,PPRDATE,PURBCODE,PLACSADDRFLAG,PLACSFTNOTE,PLACSRTRNCODE,PNCOAACTCODE,PNCOAANKCODE,PNCOAMVDATE,PNCOAMVTYPE,PNCOANEWADDRFLG,PNCOANIXFTNOTE,PNCOAPRDATE,PNCOARTRNCODE,PADDRUPDATE,PADDRSECCODE,PADDRSRCCODE,ADDRTYPE2,HCUSTSTLINE1,HCUSTSTLINE2,HCUSTCITY,HCUSTSTATE,HCUSTZIPCODE,HCUSTCOUNTRY,HADDRTYPE,HDPVFTNOTE,HDPVIND,HFTNOTE,HLATITUDE,HLONGITUDE,HPRDATE,HURBCODE,HLACSADDRFLAG,HLACSFTNOTE,HLACSRTRNCODE,HADDRUPDATE,HADDRSECCODE,HADDRSRCCODE,ADDRTYPE3,WCUSTSTLINE1,WCUSTSTLINE2,WCUSTCITY,WCUSTSTATE,WCUSTZIPCODE,WCUSTCOUNTRY,WADDRTYPE,WDPVFTNOTE,WDPVIND,WFTNOTE,WLATITUDE,WLONGITUDE,WPRDATE,WURBCODE,WLACSADDRFLAG,WLACSFTNOTE,WLACSRTRNCODE,WADDRUPDATE,WADDRSECCODE,WADDRSRCCODE,HPHTYPE,HPHAREA,HPHNUMBER,HPHUPDATE,HPHSECCODE,HPHSRCCODE,CPHTYPE,CPHAREA,CPHNUMBER,CPHUPDATE,CPHSECCODE,CPHSRCCODE,WPHTYPE,WPHAREA,WPHNUMBER,WPHUPDATE,WPHSECCODE,WPHSRCCODE,GENDER,GENDERUPDATE,GENDERSECCODE,GENDERSRCCODE,PETIND,PETUPDATE,PETSECCODE,PETSRCCODE,DEATHIND,DEATHUPDATE,DEATHSECCODE,DEATHSRCCODE,LOCKIND,LOCKUPDATE,LOCKSECCODE,LOCKSRCCODE,STOREORIG,STOREIND,STOREUPDATE,STORESECCODE,STORESRCCODE,EESECRETCODE,EESECRETCODEUPDATE,EESECRETCODESECCODE,EESECRETCODESRCCODE,ENRLFORMID,ENRLFORMIDUPDATE,ENRLFORMIDSECCODE,ENRLFORMIDSRCCODE,EECARDNO,EECARDNOUPDATE,EECARDNOSECCODE,EECARDNOSRCCODE,PSCLROPTIN,PSCLROPTINUPDATE,PSCLROPTINSECCODE,PSCLROPTINSRCCCODE,LASTUPDATE from CDI_MMCA_CV_MEMBER where SRCCODE='";
	public static final String AND_SOURCEID= "and SRCID='";
	public static final String ERROR_SELECT_QUERY_4="Error while getting value from CDI_MMCA_CV_MEMBER table ";
	
	public static final String SELECT_QUERY_5="select SRCCODE,SRCID,PROGRAMSTATUS,PROGRAMCODE,PROGRAMIDENT,PROGRAMSTARTDT,PROGRAMENDDT,PROGRAMLASTUPDATE,TRANDATE from CDI_PRGM_CV_MEMBER where SRCCODE='";
	public static final String AND_SOURCEID_5= "and SRCID='";
	public static final String ERROR_SELECT_QUERY_5="Error while getting value from CDI_PRGM_CV_LOYALTY table:   ";
	
	public static final String SELECT_QUERY_6="select PRSNSEQNO,SRCCODE,LASTNAME,FIRSTNAME,MIDDLENAME,SUFFIXNAME,GENDER,BIRTHDATE,PCUSTSTLINE1,PCUSTSTLINE2,PCUSTCITY,PCUSTSTATE,PCUSTZIPCODE,HPHAREA,HPHNUMBER,EMAIL1,EMAIL2,LASTUPDATE from REF_MEM_DEMO_ID where SRCCODE='";
	public static final String AND_PRSNSEQNO_6="and PRSNSEQNO='";
	public static final String ERROR_SELECT_QUERY_6="Error while getting value from REF_MEM_DEMO_ID table :";
	
	public static final String SELECT_QUERY_7="select ENTITYID,CVWTYPE,LASTNAME,FIRSTNAME,MIDDLENAME,PREFIXNAME,SUFFIXNAME,NAMEUPDATE,NAMSECCODE,NAMSRCCODE,BIRTHDATE,BIRTHUPDATE,BIRTHSECCODE,BIRTHSRCCODE,EMAILTYPE,EMAIL,EMAILUPDATE,EMAILSECCODE,EMAILSRCCODE,ADDRTYPE,PCUSTSTLINE1,PCUSTSTLINE2,PCUSTCITY,PCUSTSTATE,PCUSTZIPCODE,PCUSTCOUNTRY,PADDRTYPE,PDPVFTNOTE,PDPVIND,PFTNOTE,PLATITUDE,PLONGITUDE,PPRDATE,PURBCODE,PLACSADDRFLAG,PLACSFTNOTE,PLACSRTRNCODE,PNCOAACTCODE,PNCOAANKCODE,PNCOAMVDATE,PNCOAMVTYPE,PNCOANEWADDRFLG,PNCOANIXFTNOTE,PNCOAPRDATE,PNCOARTRNCODE,PADDRUPDATE,PADDRSECCODE,PADDRSRCCODE,ADDRTYPE2,HCUSTSTLINE1,HCUSTSTLINE2,HCUSTCITY,HCUSTSTATE,HCUSTZIPCODE,HCUSTCOUNTRY,HADDRTYPE,HDPVFTNOTE,HDPVIND,HFTNOTE,HLATITUDE,HLONGITUDE,HPRDATE,HURBCODE,HLACSADDRFLAG,HLACSFTNOTE,HLACSRTRNCODE,HADDRUPDATE,HADDRSECCODE,HADDRSRCCODE,ADDRTYPE3,WCUSTSTLINE1,WCUSTSTLINE2,WCUSTCITY,WCUSTSTATE,WCUSTZIPCODE,WCUSTCOUNTRY,WADDRTYPE,WDPVFTNOTE,WDPVIND,WFTNOTE,WLATITUDE,WLONGITUDE,WPRDATE,WURBCODE,WLACSADDRFLAG,WLACSFTNOTE,WLACSRTRNCODE,WADDRUPDATE,WADDRSECCODE,WADDRSRCCODE,HPHTYPE,HPHAREA,HPHNUMBER,HPHUPDATE,HPHSECCODE,HPHSRCCODE,CPHTYPE,CPHAREA,CPHNUMBER,CPHUPDATE,CPHSECCODE,CPHSRCCODE,WPHTYPE,WPHAREA,WPHNUMBER,WPHUPDATE,WPHSECCODE,WPHSRCCODE,GENDER,GENDERUPDATE,GENDERSECCODE,GENDERSRCCODE,PETIND,PETUPDATE,PETSECCODE,PETSRCCODE,DEATHIND,DEATHUPDATE,DEATHSECCODE,DEATHSRCCODE,LOCKIND,LOCKUPDATE,LOCKSECCODE,LOCKSRCCODE,STOREORIG,STOREIND,STOREUPDATE,STORESECCODE,STORESRCCODE,LASTUPDATE,HPHPRIORITY,CPHPRIORITY,WPHPRIORITY from CDI_EMCA_CV_ID where ENTITYID in (";
	public static final String ERROR_SELECT_QUERY_7="Error while getting value from cdi_emca_cv_id table with ENTITYID:";

	public static final String SELECT_QUERY_8="select ENTITYID,SRCCODE,SRCID,MEMSTAT,TRANDATE,REFCODE,REFID from CDI_LINKAGE_CV_ID where ENTITYID in (";
	public static final String ERROR_SELECT_QUERY_8="Error while getting value from cdi_linkage_cv_id table with MEMRECNO:";
	public static final String DELETE_REQUEST ="Delete request for attributes that are not in the hub was found";
	public static final String REQUESTER_IP="  Requester IP: ";
	public static final String APPLICATION_SERVER = "\n  Application Server: ";
	public static final String APPLICATION_PORT = "\n  Application Port: ";
	public static final String APPLICATION_CONTEXT_PATH = "\n  Application Context Path: ";
	public static final String ALLOW_PROG_SRCH_TRUE = "\n  ALLOW_PROG_SEARCH flag set True";
	public static final String MAIL_PROG_SRCH_FLAG_UPDATED= "CDIWS Allow Program Search Flag Updated ---DO NOT REPLY";
	public static final String ALLOW_PROG_SRCH_FALSE="\n  ALLOW_PROG_SEARCH flag set False";
	public static final String PV_TABLE_FLAG_TRUE = "\n  PV_TABLE_SEARCH flag set True";
	public static final String MAIL_PV_FLAG_UPDATED = "CDIWS PV Search Flag Updated ---DO NOT REPLY";
	public static final String PV_TABLE_FLAG_FALSE = "\n  PV_TABLE_SEARCH flag set False";
	public static final String EXCLUDE_HUB_ON_SEARCH_FLAG= "\n  EXCLUDE_HUB_ONSEARCH Flag set to :";
	public static final String MAIL_EXCLUDE_HUB_FLAG_UPDATED="CDIWS Exclude Hub On Search Flag Updated ---DO NOT REPLY";
	public static final String CACHE_CONTROL= "Cache-Control";
	public static final String NO_CACHE ="no-cache";
	public static final String PRAGMA ="Pragma";
	public static final String EXPIRES ="Expires";
	public static final String CLOSING_BRACKET=")";
	public static final String SINGLE_QUOTES_SPACE="' ";
	public static final String SINGLE_QUOTES="'";
	public static final String PREFIX_NAME = "PrefixName";
	public static final String NAME_UPDATE = "NameUpdate";
	public static final String NAME_SRC_CODE = "NamSrcCode";
	public static final String NAME_SEC_CODE = "NamSecCode";
	public static final String GENDER_SEC_CODE ="GenderSecCode";
	public static final String GENDER = "Gender";
	public static final String GENDER_UPDATE = "GenderUpdate";
	public static final String GENDER_SRC_CODE = "GenderSrcCode";
	public static final String PETIND= "PetInd";
	public static final String PET_UPDATE= "PetUpdate";
	public static final String PET_SEC_CODE= "PetSecCode";
	public static final String PET_SRC_CODE= "PetSrcCode";
	public static final String DEATH_IND = "DeathInd";
	public static final String DEATH_UPDATE = "DeathUpdate";
	public static final String DEATH_SEC_CODE ="DeathSecCode";
	public static final String DEATH_SRC_CODE ="DeathSrcCode";
	public static final String EMAIL ="Email";
	public static final String EMAIL_UPDATE="EmailUpdate";
	public static final String EMAIL_SEC_CODE="EmailSecCode";
	public static final String EMAIL_SRC_CODE="EmailSrcCode";
	public static final String LOCK_IND = "LockInd";
	public static final String LOCK_UPDATE ="LockUpdate";
	public static final String LOCK_SEC_CODE = "LockSecCode";
	public static final String LOCK_SRC_CODE = "LockSrcCode";
	public static final String BIRTH_DATE= "BirthDate";
	public static final String BIRTH_UPDATE ="BirthUpdate";
	public static final String BIRTH_SEC_CODE="BirthSecCode";
	public static final String BIRTH_SRC_CODE="BirthSrcCode";
	public static final String STOREORIG ="STOREORIG";
	public static final String STOREIND ="STOREIND";
	public static final String STOREUPDATE ="STOREUPDATE";
	public static final String STORESECCODE ="STORESECCODE";
    public static final String STORESRCCODE ="STORESRCCODE"; 
    public static final String ADDR_TYPE ="AddrType";
    public static final String PFTNOTE= "PFTNOTE";
    public static final String PCUSTCITY ="PCUSTCITY";
    public static final String PCUSTCOUNTRY ="PCUSTCOUNTRY";
    public static final String PDPVFTNOTE ="PDPVFTNOTE";
    public static final String PDPVIND ="PDPVIND";
    public static final String PLACSADDRFLAG ="PLACSADDRFLAG";
    public static final String PLACSFTNOTE= "PLACSFTNOTE";
    public static final String PLACSRTRNCODE ="PLACSRTRNCODE";
    public static final String  PADDRUPDATE ="PAddrUpdate";
    public static final String PLATITUDE ="PLATITUDE";
    public static final String PLONGITUDE ="PLONGITUDE";
    public static final String PNCOA_ACT_CODE = "PNcoaActCode";
    public static final String PNCOA_ANK_CODE = "PNcoaAnkCode";
    public static final String PNCOA_MV_DATE="PNcoaMvDate";
    public static final String PNCOA_MV_TYPE="PNcoaMvTYPE";
    public static final String PNCOA_NEW_ADDR_FLG="PNcoaNewADDRFLG";
    public static final String PNCOA_NIX_FTNOTE= "PNcoaNixFtNote";
    public static final String PNCOA_PR_DATE= "PNCoaPrDate";
    public static final String PNCOA_RTRN_CODE= "PNcoaRTrnCode";
    public static final String PADDR_SEC_CODE = "PAddrSEcCode";
    public static final String PADDR_SRC_CODE= "PAddrSrcCode";
    public static final String PPRDATE= "PPRDATE";
    public static final String PCUSTSTATE= "PCUSTSTATE";
    public static final String PCUSTSTLINE1 = "PCUSTSTLINE1";
    public static final String PCUSTSTLINE2 = "PCUSTSTLINE2";
    public static final String PURBCODE = "PURBCODE";
    public static final String PADDRTYPE = "PADDRTYPE";
    public static final String PCUSTZIPCODE= "PCUSTZIPCODE"; 
    public static final String ADDRTYPE2 ="ADDRTYPE2";
    public static final String HFTNOTE  ="HFTNOTE";
    public static final String HCUST_CITY="HCustCity";
    public static final String HCUST_COUNTRY="HCustCountry";
    public static final String HDPV_FTNOTE="HdpvftNote";
    public static final String HDPV_IND="HDpvInd";
    public static final String HLACS_ADDR_FLAG="HLacsAddrFlag";
    public static final String HLACS_FTNOTE="HLacsFtNote";
    public static final String HLACS_RTRN_CODE="HLacsRtrnCode";
    public static final String HADDRUPDATE="HADDRUPDATE";
    public static final String HLONGITUDE="HLongitude";
    public static final String HLATITUDE="HLATITUDE";
    public static final String HADDRSECCODE="HADDRSECCODE";
    public static final String HADDRSRCCODE="HADDRSRCCODE";
    public static final String HPRDATE="HPRDATE";
    public static final String HCUST_STLINE1="HCustStLine1";
    public static final String HCUST_STLINE2="HCustStLine2";
    public static final String HCUST_STATE="HCustState";
    public static final String HURBCODE="HURBCODE";
    public static final String HADDRTYPE="HADDRTYPE";
    public static final String HCUST_ZIP_CODE="HCustZipCode";   
    public static final String ADDRTYPE3 ="ADDRTYPE3";
    public static final String WFTNOTE= "WFTNOTE";
    public static final String WCUSTCITY= "WCUSTCITY";
    public static final String WCUSTCOUNTRY= "WCUSTCOUNTRY";
    public static final String WDPVFTNOTE= "WDPVFTNOTE";
    public static final String WDPVIND= "WDPVIND";
    public static final String WLACSADDRFLAG= "WLACSADDRFLAG";
    public static final String WLACSFTNOTE= "WLACSFTNOTE";
    public static final String WLACSRTRNCODE= "WLACSRTRNCODE";
    public static final String WADDRUPDATE= "WADDRUPDATE";
    public static final String WLATITUDE= "WLATITUDE";
    public static final String WLONGITUDE= "WLONGITUDE";
    public static final String WADDRSECCODE= "WADDRSECCODE";
    public static final String WADDRSRCCODE= "WADDRSRCCODE";
    public static final String WPRDATE= "WPRDATE";
    public static final String WCUSTSTATE= "WCUSTSTATE";
    public static final String WCUSTSTLINE1= "WCUSTSTLINE1";
    public static final String WCUSTSTLINE2= "WCUSTSTLINE2";
    public static final String WURBCODE= "WURBCODE";
    public static final String WADDRTYPE= "WADDRTYPE";
    public static final String WCUSTZIPCODE= "WCUSTZIPCODE";
    public static final String SEC_CODE_H = "H";
	
}
