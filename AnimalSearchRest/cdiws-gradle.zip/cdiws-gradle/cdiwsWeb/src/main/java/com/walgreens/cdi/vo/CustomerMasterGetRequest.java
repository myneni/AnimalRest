package com.walgreens.cdi.vo;

/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author 
 * 
 */
public class CustomerMasterGetRequest {
	
	private String custSourceCode;
	private String custSourceID;
	private String custEID;
	private String CvWName;
	/**
	 * @return the custEID
	 */
	public String getCustEID() {
		return custEID;
	}
	/**
	 * @param custEID the custEID to set
	 */
	public void setCustEID(String custEID) {
		this.custEID = custEID;
	}
	/**
	 * @return the custSourceCode
	 */
	public String getCustSourceCode() {
		return custSourceCode;
	}
	/**
	 * @param custSourceCode the custSourceCode to set
	 */
	public void setCustSourceCode(String custSourceCode) {
		this.custSourceCode = custSourceCode;
	}
	/**
	 * @return the custSourceID
	 */
	public String getCustSourceID() {
		return custSourceID;
	}
	/**
	 * @param custSourceID the custSourceID to set
	 */
	public void setCustSourceID(String custSourceID) {
		this.custSourceID = custSourceID;
	}
	
	public String getCvWName() {
		return CvWName;
	}
	public void setCvWName(String cvWName) {
		CvWName = cvWName;
	}
	
	
}
