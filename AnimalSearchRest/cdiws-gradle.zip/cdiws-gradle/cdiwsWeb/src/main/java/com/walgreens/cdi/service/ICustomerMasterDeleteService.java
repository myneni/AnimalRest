package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterDeleteRequest;

/**
 * This service is an interface for exposing EC Delete method at service level.
 *
 * @author TCS
 *
 */
public interface ICustomerMasterDeleteService {

	public boolean deleteCustomerMaster(CustomerMasterDeleteRequest customerMasterDeleteRequest) throws CDIException;


}
