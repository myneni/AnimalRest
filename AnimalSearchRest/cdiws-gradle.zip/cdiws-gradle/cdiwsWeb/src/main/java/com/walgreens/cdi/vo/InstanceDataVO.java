package com.walgreens.cdi.vo;

public class InstanceDataVO {
	
	private String instanceNumber;
	private String instanceName;
	private String hostName;
	private String version;
	private String startupTime;
	private String status;
	private String parallel;
	private String threadNumber;
	private String archiver;
	private String logSwitchWait;
	private String logins;
	private String shutdownPending;
	private String databaseStatus;
	private String instanceRole;
	private String activeState;
	private String blocked;
	public String getActiveState() {
		return activeState;
	}
	public void setActiveState(String activeState) {
		this.activeState = activeState;
	}
	public String getArchiver() {
		return archiver;
	}
	public void setArchiver(String archiver) {
		this.archiver = archiver;
	}
	public String getBlocked() {
		return blocked;
	}
	public void setBlocked(String blocked) {
		this.blocked = blocked;
	}
	public String getDatabaseStatus() {
		return databaseStatus;
	}
	public void setDatabaseStatus(String databaseStatus) {
		this.databaseStatus = databaseStatus;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getInstanceName() {
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public String getInstanceNumber() {
		return instanceNumber;
	}
	public void setInstanceNumber(String instanceNumber) {
		this.instanceNumber = instanceNumber;
	}
	public String getInstanceRole() {
		return instanceRole;
	}
	public void setInstanceRole(String instanceRole) {
		this.instanceRole = instanceRole;
	}
	public String getLogins() {
		return logins;
	}
	public void setLogins(String logins) {
		this.logins = logins;
	}
	public String getLogSwitchWait() {
		return logSwitchWait;
	}
	public void setLogSwitchWait(String logSwitchWait) {
		this.logSwitchWait = logSwitchWait;
	}
	public String getParallel() {
		return parallel;
	}
	public void setParallel(String parallel) {
		this.parallel = parallel;
	}
	public String getShutdownPending() {
		return shutdownPending;
	}
	public void setShutdownPending(String shutdownPending) {
		this.shutdownPending = shutdownPending;
	}
	public String getStartupTime() {
		return startupTime;
	}
	public void setStartupTime(String startupTime) {
		this.startupTime = startupTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getThreadNumber() {
		return threadNumber;
	}
	public void setThreadNumber(String threadNumber) {
		this.threadNumber = threadNumber;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
	
}
