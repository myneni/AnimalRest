/**
 * 
 */
package com.walgreens.cdi.vo.customer;
import com.walgreens.cdi.util.CustomerMasterConstants;
import java.util.Calendar;
import java.util.Date;

import com.walgreens.cdi.vo.CustomerMasterPatientInsuranceInfo;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterDeceasedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterHouseholdLinkageRec;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterHubLinkageRec;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterGender;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLockedInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterOrigin;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPetInd;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterRefEIDLinkage;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterRefHubLinkageAct;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterRefHubLinkageRec;


/**
 * @author Picketta, lzhang
 *
 */
public class CustomerMaster {
	
	private String EID; 			//Number (1/1)	Enterprise ID for the requested customer.
	private Date compositeDateTime = Calendar.getInstance().getTime();		//Date/Time (1/1)	Date and time of Get results.
	private CustomerMasterAttr custAll =  new CustomerMasterAttr(false);
	private CustomerMasterAttr custLim = new CustomerMasterAttr(false);
	private CustomerMasterGender gender;// = new CustomerMasterGender();
	private CustomerMasterPetInd petInd;// = new CustomerMasterPetInd();
	private CustomerMasterDeceasedInd deceasedInd;// = new CustomerMasterDeceasedInd();
	private CustomerMasterLockedInd lockedInd;// = new CustomerMasterLockedInd();
	private CustomerMasterOrigin origin;// = new CustomerMasterOrigin();
	private CustomerMasterHubLinkageRec hubLinkageRec;// = new CustomerMasterHubLinkageRec();
	private String matchScore; 
	private String lastUpdateDate;
	private String secCode;
	private String sourceCode; //Added For LR Changes For Hub Search defect

	

	
	private CustomerMasterRefEIDLinkage linkageRefEID; // = new CustomerMasterRefEIDLinkage();
	
		
	/**
	 * @return the compositeDateTime
	 */
	public Date getCompositeDateTime() {
		return compositeDateTime;
	}
	/**
	 * @param compositeDateTime the compositeDateTime to set
	 */
	public void setCompositeDateTime(Date compositeDateTime) {
		this.compositeDateTime = compositeDateTime;
	}
	/**
	 * @return the custAll
	 */
	public CustomerMasterAttr getCustAll() {
		return custAll;
	}
	/**
	 * @param custAll the custAll to set
	 */
	public void setCustAll(CustomerMasterAttr custAll) {
		this.custAll = custAll;
	}
	/**
	 * @return the EID
	 */
	public String getEID() {
		return EID;
	}
	/**
	 * @param EID the EID to set
	 */
	public void setEID(String custEID) {
		this.EID = custEID;
	}
	
	/**
	 * @return the custLim
	 */
	public CustomerMasterAttr getCustLim() {
		return custLim;
	}
	/**
	 * @param custLim the custLim to set
	 */
	public void setCustLim(CustomerMasterAttr custLim) {
		this.custLim = custLim;
	}
	
	/**
	 * @return the deceasedInd
	 */
	public CustomerMasterDeceasedInd getDeceasedInd() {
		return deceasedInd;
	}
	/**
	 * @param deceasedInd the deceasedInd to set
	 */
	public void setDeceasedInd(CustomerMasterDeceasedInd deceasedInd) {
		this.deceasedInd = deceasedInd;
	}
	/**
	 * @return the gender
	 */
	public CustomerMasterGender getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(CustomerMasterGender gender) {
		this.gender = gender;
	}
	/**
	 * @return the origin
	 */
	public CustomerMasterOrigin getOrigin() {
		return origin;
	}
	/**
	 * @param origin the origin to set
	 */
	public void setOrigin(CustomerMasterOrigin origin) {
		this.origin = origin;
	}
	/**
	 * @return the petInd
	 */
	public CustomerMasterPetInd getPetInd() {
		return petInd;
	}
	/**
	 * @param petInd the petInd to set
	 */
	public void setPetInd(CustomerMasterPetInd petInd) {
		this.petInd = petInd;
	}
	
	/**
	 * @return the linkageRefEID
	 */
	public CustomerMasterRefEIDLinkage getLinkageRefEID() {
		return linkageRefEID;
	}
	/**
	 * @param linkageRefEID the linkageRefEID to set
	 */
	public void setLinkageRefEID(CustomerMasterRefEIDLinkage linkageRefEID) {
		this.linkageRefEID = linkageRefEID;
	}
	/**
	 * @return the lockedInd
	 */
	public CustomerMasterLockedInd getLockedInd() {
		return lockedInd;
	}
	/**
	 * @param lockedInd the lockedInd to set
	 */
	public void setLockedInd(CustomerMasterLockedInd lockedInd) {
		this.lockedInd = lockedInd;
	}
	
	/**
	 * @return the hubLinkageRec
	 */
	public CustomerMasterHubLinkageRec getHubLinkageRec() {
		return hubLinkageRec;
	}
	/**
	 * @param hubLinkageRec the hubLinkageRec to set
	 */
	public void setHubLinkageRec(CustomerMasterHubLinkageRec hubLinkageRec) {
		this.hubLinkageRec = hubLinkageRec;
	}
	
	/**
	 * @return the lastUpdateDate
	 */
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}
	/**
	 * @param lastUpdateDate the lastUpdateDate to set
	 */
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	/**
	 * @return the secCode
	 */
	public String getSecCode() {
		return secCode;
	}
	/**
	 * @param secCode the secCode to set
	 */
	public void setSecCode(String secCode) {
		this.secCode = secCode;
	}
	
	
	public String toString() {
		String str="";
		str = " EID : " +  EID + "\n" +
			  " compositeDateTime : " +  compositeDateTime   + "\n" +
			  " MatchScore : " + matchScore + "\n" ;
		
	    if (custAll.isLimited() && custLim.isLimited())
	    	str = str + custLim.toString() ;
	    else if(!custAll.isLimited() && !custLim.isLimited())
	    	str = str + custAll.toString() ;
	    else
	    {
	    	if (custAll != null)
	    		str = str + custAll.toString() ;
	    	if (custLim != null)
		    	str = str + custLim.toString() ;
	    }
	    if (gender != null)
	    	str = str +  gender.toString() ;
	    
	    if (petInd != null)
	    	str = str +  petInd.toString() ; 
	    
	    if (deceasedInd != null)
	    	str = str +  deceasedInd.toString() ; 	
		
	    if (lockedInd != null)
	    	str = str +  lockedInd.toString() ; 	
	    if (origin != null)
	    	str = str +  origin.toString() ; 	
	    if (hubLinkageRec != null)
	    	str = str +  hubLinkageRec.toString() ; 	
		
	    str =  str + " lastUpdateDate : " +  lastUpdateDate + "\n" +
	    			  " secCode : " +  secCode  + "\n" ;

	  return str;
	}
	
	public String toCompString() {
		String str="";
		str = CustomerMasterConstants.COMP_ATTR_NAME_EID + CustomerMasterConstants.DELIMITE_FIELD +
		     EID + CustomerMasterConstants.DELIMITE_FIELD +
		     matchScore + CustomerMasterConstants.DELIMITE_FIELD;
	
	    if (custAll != null)
	    	str = str + custAll.toCompString() ;
		//  if (custLim != null)
		//    	str = str + custLim.toString() ;
	    
	    if (gender != null)
	    	str = str +  gender.toCompString() ;
	    
	    if (petInd != null)
	    	str = str +  petInd.toCompString() ; 
	    
	    if (deceasedInd != null)
	    	str = str +  deceasedInd.toCompString() ; 	
		
	    if (lockedInd != null)
	    	str = str +  lockedInd.toCompString() ; 	
	    if (origin != null)
	    	str = str +  origin.toCompString() ; 	
	    if (hubLinkageRec != null)
	    	str = str +  hubLinkageRec.toCompString() ; 	
		
	  
	  return str;
	}
	public String getMatchScore() {
		return matchScore;
	}
	public void setMatchScore(String matchScore) {
		this.matchScore = matchScore;
	}
	public String getSourceCode() {
		return sourceCode;
	}
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	
	
	
}
