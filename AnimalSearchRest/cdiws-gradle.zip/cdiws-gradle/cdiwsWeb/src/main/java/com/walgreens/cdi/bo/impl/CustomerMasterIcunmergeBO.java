package com.walgreens.cdi.bo.impl;

import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterIcunmergeBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterIcunmergeRequest;
import com.walgreens.cdi.wsao.ICustomerMasterIcunmergeWSAO;

public class CustomerMasterIcunmergeBO extends BaseBO implements ICustomerMasterIcunmergeBO {
	
	private ICustomerMasterIcunmergeWSAO icunmergeWSAO;
	
	
	public boolean icunmergeCustomerMaster(CustomerMasterIcunmergeRequest customerMasterIcunmergeRequest) throws SystemException, BusinessRuleViolationException{
	
		try{
			//System.out.println("IN :: CustomerMasterIcunmergeBO");
			validateRequestObject(customerMasterIcunmergeRequest);
			//ICustomerMasterIcunmergeWSAO icunmergeWSAO = new CustomerMasterIcunmergeWSAO();
			return getcustomerMasterIcunmergeWSAO().icunmergeCustomerMaster(customerMasterIcunmergeRequest);
		}catch (JaxWsSoapFaultException e) {
			//e.printStackTrace();
			String exceptionCode = getExceptionCode(e);
			if(exceptionCode != null){
				if(exceptionCode.equals(CustomerMasterConstants.DO_NOT_THROW_EXCEPTION)){
					throw new SystemException(CustomerMasterConstants.ICUNMERGE_EC_MEMBER_EXIST, e.getMessage());
				}else{
					getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
					throw new SystemException(exceptionCode,e.getMessage());
				}
			}else{
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e.getMessage());
			}
		}catch(BusinessRuleViolationException e){
			//e.printStackTrace();
			throw e;
		}catch(Exception e){
			//e.printStackTrace();
			throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, e.getMessage());
		}
	}


	/**
	 * @return the searchWSAO
	 */
	public ICustomerMasterIcunmergeWSAO getcustomerMasterIcunmergeWSAO() {
		return icunmergeWSAO;
	}


	/**
	 * @param searchWSAO the searchWSAO to set
	 */
	public void setCustomerMasterIcunmergeWSAO(ICustomerMasterIcunmergeWSAO icunmergeWSAO) {
		this.icunmergeWSAO = icunmergeWSAO;
	}

	
	public void validateRequestObject(CustomerMasterIcunmergeRequest customerMasterIcunmergeRequest) throws BusinessRuleViolationException {
		ValidateCustomerMasterRequest.validateRequiredFields(customerMasterIcunmergeRequest);
		ValidateCustomerMasterRequest.validateInvalidFieldValues(customerMasterIcunmergeRequest);	
	}

	 /**
	    * This method sets the Error code  based on the type of
	    * Exception which Initiate gives
	    * @param exception
	    * @return
	    */
	   public  String  getExceptionCode(Exception exception){//already exists and INSERT_ONLY.
	       if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_CANDIDATES_FOUND.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_EXCEPTION_NO_CANDIDATES_FOUND;
	       }
	       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_MEMBER_RECORD_FOUND.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_EXCEPTION_NO_CANDIDATES_FOUND;
	       }
	       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NONE_REMAIN_AFTER_FILTER.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_EXCEPTION_NO_CANDIDATES_FOUND;
	       }
	       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_LOCK_IND_REQUIRED.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_EXCEPTION_LOCK_IND_REQUIRED;
	       }
	       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_PET_IND_REQUIRED.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_EXCEPTION_PET_IND_REQUIRED;
	       }
	       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_UPDATE_WILL_OCCUR.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_MEMBER_EXIST;
	       }
	       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_MEMBER_EXIST_INSERT_ONLY_1.trim())
	    		   && exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_MEMBER_EXIST_INSERT_ONLY_2.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_MEMBER_EXIST;
	       }
	       else if(exception.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_COULD_NOT_SEND_MSG.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_EXCEPTION_COULD_NOT_SEND_MSG;
	       }
	       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_UNABLE_INS_UPD_1.trim())
	    		   && exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_UNABLE_INS_UPD_2.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_EXCEPTION_UNABLE_INS_UPD;
	       }
	       else if(exception.getMessage().contains(CustomerMasterConstants.EXCEPTION_HUB_MAY_BE_DOWN.trim())){
	           return CustomerMasterConstants.ICUNMERGE_EC_EXCEPTION_HUB_MAY_BE_DOWN;
	       }
	       else{
	    	  return super.getExceptionCode(exception);
	       }
	   }
	
	

}
