package com.walgreens.cdi.vo;

import com.walgreens.cdi.vo.customer.CustomerMasterEntSearch;


/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author 
 * 
 */
public class CustomerMasterEntLookUpResponse {
	private CustomerMasterEntSearch entCustomer = new CustomerMasterEntSearch();
	
	public CustomerMasterEntSearch getEntCustomer() {
		return entCustomer;
	}

	public void setEntCustomer(CustomerMasterEntSearch entCustomer) {
		this.entCustomer = entCustomer;
	}

	

	
	

	
	
	
}
