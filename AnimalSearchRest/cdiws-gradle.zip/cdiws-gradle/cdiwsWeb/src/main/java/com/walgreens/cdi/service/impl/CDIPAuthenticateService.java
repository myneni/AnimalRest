/**
 * 
 */
package com.walgreens.cdi.service.impl;


import javax.jws.WebService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.initiate.bean.DictionaryGetRequest;

import com.walgreens.cdi.util.CustomerMasterUtility;

/**
 * @author Vijay Burri
 * 
 */
@WebService
public class CDIPAuthenticateService  {

	
	// Utility class
	CustomerMasterUtility cdiUtility = new CustomerMasterUtility();

	public boolean getAuthenticate(String a , String b) {
		boolean abc = false;
		System.out.println("getAuthenticate Method");
		
		String[] springFile = { "classpath*:bounce.xml" };
		ApplicationContext context = new ClassPathXmlApplicationContext(
				springFile);
		StringBuffer msg = new StringBuffer("<<< CONTEXT LOADED>>> [");
		for (int i = 0; i < springFile.length; i++) {
			if (i > 0) {
				msg.append(" ");
			}
			msg.append(springFile[i]);
		}
		msg.append("] IN class='");
		msg.append("'");

//		com.initiate.bean.IdentityHubPort identService = (com.initiate.bean.IdentityHubPort) context
//				.getBean("identityHubSpringBean");
		
		DictionaryGetRequest request = new DictionaryGetRequest();
		request.setSegCodeFilter("MEMHEAD,MEMATTRALL");
		request.setUserName(a);
		request.setUserPassword(b);
		try {
			// identService.getDictionary(request);
			 abc =true;
			 System.out.println("User is authenticated");
		} catch (Exception re) {
			System.out.println("User not authenticated"+ re);
			return false;
		}
		
		return abc;
	}

	
	
}
