package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterGetRequest;
import com.walgreens.cdi.vo.customer.ArrayOfCustomer;

public interface ICustomerMasterGetBO {
	
	public ArrayOfCustomer getCustomerMaster(CustomerMasterGetRequest customerMasterGetRequest) throws SystemException, BusinessRuleViolationException ;

	public void validateRequestObject(CustomerMasterGetRequest customerMasterGetRequest) throws BusinessRuleViolationException;
}
