package com.walgreens.cdi.vo;

import java.util.ArrayList;

public class CustomerMasterMemberIDResponse {

	private ArrayList<CustomerMasterEntMemberIdGenerateSequence> progCodeResponseArray = new ArrayList<CustomerMasterEntMemberIdGenerateSequence>();

	public ArrayList<CustomerMasterEntMemberIdGenerateSequence> getProgCodeResponseArray() {
		return progCodeResponseArray;
	}

	public void setProgCodeResponseArray(
			ArrayList<CustomerMasterEntMemberIdGenerateSequence> progCodeResponseArray) {
		this.progCodeResponseArray = progCodeResponseArray;
	}

	
	
}
