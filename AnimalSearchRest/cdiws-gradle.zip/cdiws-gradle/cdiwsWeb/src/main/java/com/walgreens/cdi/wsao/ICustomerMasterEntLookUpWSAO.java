package com.walgreens.cdi.wsao;

import madison.mpi.MemRowList;

import com.initiate.bean.ArrayOfMember;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpResponse;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpRequest;
import com.walgreens.cdi.vo.TrackingInfoVO;

public interface ICustomerMasterEntLookUpWSAO {
	
	public CustomerMasterEntLookUpResponse[] lookUpEntCustomerMasterCdi(CustomerMasterEntLookUpRequest customerMasterLookUpRequest, String srcCodeFilter, String getType,String initiateID, String initiatePWD,boolean printCorelationlogger, TrackingInfoVO localTrackingInfoVo) throws Exception;
	public CustomerMasterEntLookUpResponse[] lookUpEntCustomerMasterLoyalty(CustomerMasterEntLookUpRequest customerMasterLookUpRequest,String initiateID, String initiatePWD) throws Exception;
	public ArrayOfMember getCdiMemHead( CustomerMasterEntLookUpRequest customerMasterLookUpRequest,String srcCodeFilter, String getType,String initiateID, String initiatePWD,boolean printCorelationlogger, TrackingInfoVO localTrackingInfoVo)throws Exception;
	public ArrayOfMember getLoyaltyMemHead(CustomerMasterEntLookUpRequest customerMasterLookUpRequest,String initiateID, String initiatePWD)throws Exception;
	public MemRowList searchRefHub(CustomerMasterEntLookUpRequest customerMasterLookUpRequest,String segCodeFilter, String getType,boolean printCorelationlogger) throws Exception;
	public CustomerMasterEntLookUpResponse[] lookUpEntCustomerMasterRef(CustomerMasterEntLookUpRequest customerMasterLookUpRequest, String getType,boolean printCorelationlogger) throws Exception;
}
