package com.walgreens.cdi.exception;

/**
 * This exception is thrown whenever there is a data validation error in the VOs
 * @author amal.arindam
 */
public class BusinessRuleViolationException extends CDIException {

	 /**
     * This attribute is for uniquely identifying the Exception Class Version in
     * case it is serialized.
     */
    private static final long serialVersionUID = -3690440322021173179L;

   


    /**
     * Constructor accepting string arguments
     * @param exception
     */
    public BusinessRuleViolationException(String exception) {
        super(exception);
    }
    
    
    public BusinessRuleViolationException(String errorCode, String detailMessage) {
        super(errorCode, detailMessage);
        this.errorCode=errorCode;
    }
    
    public BusinessRuleViolationException(String errorCode, String detailMessage, String message) {
        super(errorCode, detailMessage , message);
        this.errorCode=errorCode;
    }




}
