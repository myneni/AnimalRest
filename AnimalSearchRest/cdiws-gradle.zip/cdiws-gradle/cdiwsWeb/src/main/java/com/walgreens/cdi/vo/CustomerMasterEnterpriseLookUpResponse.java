package com.walgreens.cdi.vo;

import javax.xml.bind.annotation.XmlType;

/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author
 * 
 */
//propOrder added for maintaing ordering in given order.
@XmlType(propOrder={"resultExceedInd","entCustomer"})
public class CustomerMasterEnterpriseLookUpResponse {
	private CustomerMasterEnterpriseSearch entCustomer = new CustomerMasterEnterpriseSearch();
	private String resultExceedInd;

	public String getResultExceedInd() {
		return resultExceedInd;
	}

	public void setResultExceedInd(String resultExceedInd) {
		this.resultExceedInd = resultExceedInd;
	}

	public CustomerMasterEnterpriseSearch getEntCustomer() {
		return entCustomer;
	}

	public void setEntCustomer(CustomerMasterEnterpriseSearch entCustomer) {
		this.entCustomer = entCustomer;
	}
}
