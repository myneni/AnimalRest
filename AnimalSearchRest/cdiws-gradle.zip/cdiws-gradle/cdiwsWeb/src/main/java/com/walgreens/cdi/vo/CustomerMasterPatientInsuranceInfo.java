package com.walgreens.cdi.vo;

public class CustomerMasterPatientInsuranceInfo {
	private String generalRecipientNbr;
	private String planId;
	public String getGeneralRecipientNbr() {
		return generalRecipientNbr;
	}
	public void setGeneralRecipientNbr(String generalRecipientNbr) {
		this.generalRecipientNbr = generalRecipientNbr;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
}
