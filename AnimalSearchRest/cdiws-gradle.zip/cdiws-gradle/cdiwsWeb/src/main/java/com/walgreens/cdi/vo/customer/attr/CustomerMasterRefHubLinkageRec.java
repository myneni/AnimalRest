/**
 * 
 */
package com.walgreens.cdi.vo.customer.attr;

import java.util.ArrayList;

/**
 * @author Picketta
 *
 */
public class CustomerMasterRefHubLinkageRec {
	//	 (Linkage of CustEID to Cust Source Records)		
	private ArrayList refHubLinkageArrayList;		//Array (1/n)	Linkage array, with occurrences for every active linkage
	/**
	 * For refHubLinkageArrayList
	 * 0 = sourceID
	 * 1 = sourceCode
	 * 2 = status ("Active" or "Inactive")
	 */
	private String refMemRecNo	;								//String (1/1)	Enterprise ID for the requested customer. 
	
	
	/**
	 * 
	 */
	public CustomerMasterRefHubLinkageRec() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@SuppressWarnings("unchecked")
	public void addHubLinkageRecord(String sourceID, String sourceCode, String status){
		this.refHubLinkageArrayList.add(new String[]{sourceID, sourceCode, status});
	}

	/**
	 * @return the refMemRecNo
	 */
	public String getRefMemRecNo() {
		return refMemRecNo;
	}

	/**
	 * @param refMemRecNo the refMemRecNo to set
	 */
	public void setRefMemRecNo(String custEID) {
		this.refMemRecNo = custEID;
	}

	/**
	 * @return the refHubLinkageArrayList
	 */
	public ArrayList getRefHubLinkageArrayList() {
		return refHubLinkageArrayList;
	}

	/**
	 * @param refHubLinkageArrayList the refHubLinkageArrayList to set
	 */
	public void setRefHubLinkageArrayList(ArrayList hubLinkageArrayList) {
		this.refHubLinkageArrayList = hubLinkageArrayList;
	}
	
	
}
