/*
 * This is an auto-generated class for the service object. Please do not modify this class.
 */
package com.walgreens.cdi.service.webservices;

import javax.jws.WebService;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.CDIExceptionFault;
import com.walgreens.cdi.exception.CDIException_Exception;
//As a part of WAS Migration Changes are in the new parameters addition for the @WebService tag, the new @SoapBinding tag, 
//and  replacing the @WebResult tag in the called methods with @WebMethod tags.

@WebService(targetNamespace = "http://webservices.service.cdi.walgreens.com/", 
serviceName = "CustomerMasterEntUpdateServiceWSServiceV2",
portName = "CustomerMasterEntUpdateServiceWSPortV2",
wsdlLocation = "WEB-INF/WSDL/CustomerMasterEntUpdateServiceWSServiceV2.wsdl")
@javax.jws.soap.SOAPBinding(style = javax.jws.soap.SOAPBinding.Style.DOCUMENT)
@javax.jws.HandlerChain(file = "/WSHandlerChain.xml")
public class CustomerMasterEntUpdateServiceWSV2 {
	private com.walgreens.cdi.service.impl.CustomerMasterEntUpdateServiceV2 _service = null;

	@javax.jws.WebMethod(exclude = true)
	private com.walgreens.cdi.service.impl.CustomerMasterEntUpdateServiceV2 getService() {
		_service = (com.walgreens.cdi.service.impl.CustomerMasterEntUpdateServiceV2) walgreens.utils.ioc.BeanFactoryUtil
				.getFactory().getBean("customerMasterEntUpdateServiceV2");
		return _service;
	}

	@javax.jws.WebResult(name = "updateCustomerMasterEnterpriseResponse", targetNamespace = "")
	public @javax.jws.WebMethod
	com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateResponse updateCustomerMasterEnterprise(
			com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateRequest arg0)
			throws com.walgreens.cdi.exception.CDIException_Exception {
		try {
			return getService().updateCustomerMasterEnterprise(arg0);
		} catch (CDIException e) {
			CDIExceptionFault fault = new CDIExceptionFault();
			fault.setErrorCode(e.getErrorCode());
			fault.setDetailMessage(e.getDetailMessage());
			fault.setMsg(e.getMsg());
			throw new CDIException_Exception(e.getMessage(), fault);
		}
	}
}
