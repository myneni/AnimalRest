package com.walgreens.cdi.exception;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(value=javax.xml.bind.annotation.XmlAccessType.FIELD)
@XmlType(name="CDIExceptionFault", propOrder={"errorCode","detailMessage", "msg"})
public class CDIExceptionFault {
	protected String detailMessage;
    protected String msg;
    
    protected String errorCode;
    public String getDetailMessage() {
		return detailMessage;
	}
    
	public void setDetailMessage(String detailMessage) {
		this.detailMessage = detailMessage;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	

}
