package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterDeleteRequest;

public interface ICustomerMasterDeleteBO {
	
	/**
	 * This bo is an interface for exposing EC Delete method at bo level.
	 *  
	 * @param customerMasterDeleteRequest
	 * @return boolean 
	 * @throws SystemException
	 * @throws BusinessRuleViolationException
	 */
	public boolean deleteCustomerMaster(CustomerMasterDeleteRequest customerMasterDeleteRequest) throws SystemException,BusinessRuleViolationException;

}
