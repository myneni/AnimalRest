package com.walgreens.cdi.util;

import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author lzhang
 */
public final class SecurityResource {

	private static SecurityResource securityResource;

	/**
	 * The initiateSecurityMap loaded
	 */
	private static HashMap initiateSecurityMap = null;

	private static HashMap appIDtoInitiateMap = null;

	/**
	 * Gets the only single instance of <code>SecurityResource</code>.
	 * 
	 * @return single instance of <code>SecurityResource</code>
	 */
	public static SecurityResource getInstance() {
		if (securityResource == null) {
			synchronized (SecurityResource.class) {
				securityResource = new SecurityResource();
			}
		}
		return securityResource;
	}

	/**
	 * Initialize the singleton object.
	 */
	private SecurityResource() {
		init();
	}

	/**
	 * Initializing method for HashMap.
	 */
	private void init() {

		initiateSecurityMap = new HashMap<String, String>();
		appIDtoInitiateMap = new HashMap<String, String>();

		try {
			DocumentBuilderFactory domFactory = DocumentBuilderFactory
					.newInstance();
			domFactory.setNamespaceAware(true);
			domFactory.setIgnoringElementContentWhitespace(true);

			DocumentBuilder builder = domFactory.newDocumentBuilder();
			// Load App ID mapping to Initiate
			Document appIDtoIniDoc = builder
					.parse(CustomerMasterConstants.class
							.getClassLoader()
							.getResourceAsStream(
									CustomerMasterConstants.XML_APPID_INITIATEID_MAP));

			// TreeDumper td = new TreeDumper();
			// td.dump(appIDtoIniDoc);
			NodeList apps = appIDtoIniDoc
					.getElementsByTagName(CustomerMasterConstants.XML_TAG_APPID);

			for (int i = 0; i < apps.getLength(); i++) {
				String appID = "";
				String initiateID = "";
				Element app = (Element) apps.item(i);

				NodeList appids = app
						.getElementsByTagName(CustomerMasterConstants.XML_TAG_ID);
				NodeList initids = app
						.getElementsByTagName(CustomerMasterConstants.XML_TAG_INITIATEID);
				Node appNode = appids.item(0);
				Node appValue = appNode.getFirstChild();
				if (appValue.getNodeType() == Node.TEXT_NODE) {
					if (appNode.getNodeName().equalsIgnoreCase(
							CustomerMasterConstants.XML_TAG_ID))
						appID = appValue.getNodeValue();
				}
				Node initiateNode = initids.item(0);
				Node initiateValue = initiateNode.getFirstChild();
				if (initiateValue.getNodeType() == Node.TEXT_NODE) {
					if (initiateNode.getNodeName().equalsIgnoreCase(
							CustomerMasterConstants.XML_TAG_INITIATEID))
						initiateID = initiateValue.getNodeValue();
				}

				if (!appID.equalsIgnoreCase("")) {
					appIDtoInitiateMap.put(appID, initiateID);
				}
				// System.out.println("app_initiate_map=" + appID + ", " +
				// appIDtoInitiateMap.get(appID));

			}

			// Load initiate Key Store
			Document initiateKeyStoreDoc = builder
					.parse(CustomerMasterConstants.class
							.getClassLoader()
							.getResourceAsStream(
									CustomerMasterConstants.XML_INITIATE_SECURITY_MAP));

			// TreeDumper td = new TreeDumper();
			// td.dump(doc);
			NodeList consumers = initiateKeyStoreDoc
					.getElementsByTagName(CustomerMasterConstants.XML_TAG_CUSTOMER);

			for (int i = 0; i < consumers.getLength(); i++) {
				String customerID = "";
				String customerPWD = "";
				Element consumer = (Element) consumers.item(i);

				NodeList ids = consumer
						.getElementsByTagName(CustomerMasterConstants.XML_TAG_ID);
				NodeList password = consumer
						.getElementsByTagName(CustomerMasterConstants.XML_TAG_PASSWORD);
				Node idNode = ids.item(0);
				Node idValue = idNode.getFirstChild();
				if (idValue.getNodeType() == Node.TEXT_NODE) {
					if (idNode.getNodeName().equalsIgnoreCase(
							CustomerMasterConstants.XML_TAG_ID))
						customerID = idValue.getNodeValue();
				}
				Node passwdNode = password.item(0);
				Node passwdValue = passwdNode.getFirstChild();
				if (passwdValue.getNodeType() == Node.TEXT_NODE) {
					if (passwdNode.getNodeName().equalsIgnoreCase(
							CustomerMasterConstants.XML_TAG_PASSWORD))
						customerPWD = passwdValue.getNodeValue();
				}
				if (!customerID.equalsIgnoreCase("")) {
					initiateSecurityMap.put(customerID, customerPWD);
				}
				// System.out.println("securitymap=" + customerID + ", " +
				// initiateSecurityMap.get(customerID));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String getInitiatePassword(String id) {

		if (initiateSecurityMap != null) {
			return (String) initiateSecurityMap.get(id);
		}
		return "";
	}

	public String getInitiateID(String id) {

		if (appIDtoInitiateMap != null) {
			return (String) appIDtoInitiateMap.get(id);
		}
		return "";
	}

	public static void main(String[] args) {
		SecurityResource sr = SecurityResource.getInstance();
		// System.out.println("system=" +sr.getInitiatePassword("system"));
		// System.out.println("cdi1=" +sr.getInitiateID("cdi1"));

	}

}