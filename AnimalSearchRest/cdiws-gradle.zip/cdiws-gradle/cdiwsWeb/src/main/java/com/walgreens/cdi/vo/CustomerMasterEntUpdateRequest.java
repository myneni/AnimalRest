package com.walgreens.cdi.vo;

import java.util.ArrayList;

public class CustomerMasterEntUpdateRequest extends CustomerMasterUpdateRequest {

	
	//private String secretCode;
	//private String enrollFormId;
	
	private ArrayList<CustomerMasterAttributesVO> custArrayOfAttributes=new ArrayList<CustomerMasterAttributesVO>();
	private ArrayList<CustomerMasterProgramVO> custProgIdArray = new ArrayList<CustomerMasterProgramVO>();
	private ArrayList<CustomerMasterProgramActionVO> custProgActionArray=new ArrayList<CustomerMasterProgramActionVO>();
	public ArrayList<CustomerMasterProgramVO> getCustProgIdArray() {
		return custProgIdArray;
	}

	public void setCustProgIdArray(
			ArrayList<CustomerMasterProgramVO> custProgIdArray) {
		this.custProgIdArray = custProgIdArray;
	}

	public ArrayList<CustomerMasterAttributesVO> getCustArrayOfAttributes() {
		return custArrayOfAttributes;
	}

	public void setCustArrayOfAttributes(
			ArrayList<CustomerMasterAttributesVO> custArrayOfAttributes) {
		this.custArrayOfAttributes = custArrayOfAttributes;
	}

	public ArrayList<CustomerMasterProgramActionVO> getCustProgActionArray() {
		return custProgActionArray;
	}

	public void setCustProgActionArray(
			ArrayList<CustomerMasterProgramActionVO> custProgActionArray) {
		this.custProgActionArray = custProgActionArray;
	}
		
	
}
