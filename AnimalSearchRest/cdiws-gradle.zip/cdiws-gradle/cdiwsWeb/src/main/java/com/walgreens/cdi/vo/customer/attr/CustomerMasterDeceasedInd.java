package com.walgreens.cdi.vo.customer.attr;
import com.walgreens.cdi.util.CustomerMasterConstants;

public class CustomerMasterDeceasedInd extends CustomerMasterAttributeStatus {
	//	 (Deceased Indicator attribute)		
	private String deceasedIndicator;					//Date (0/1)	Composite customer DeceasedIndicator.

	/**
	 * @return the deceasedIndicator
	 */
	public String getDeceasedIndicator() {
		return deceasedIndicator;
	}

	/**
	 * @param deceasedIndicator the deceasedIndicator to set
	 */
	public void setDeceasedIndicator(String custDeceasedIndicator) {
		this.deceasedIndicator = custDeceasedIndicator;
	}
	
	public String toString() {
		String str="";
		str = "\nDeceasedInd:\n____________________________________\n"+
		      " deceasedIndicator    =" + deceasedIndicator + "\n" +
		      " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
			  " securityClassCode   =" + getSecurityClassCode() + "\n" +
			  " sourceCode   =" + getSourceCode() + "\n" ;
		
					
         return str;
	}
	
	public String toCompString() {
		String str="";
		 str = CustomerMasterConstants.DELIMITE_ATTR +
		   CustomerMasterConstants.COMP_ATTR_NAME_DEATHIND+ CustomerMasterConstants.DELIMITE_FIELD +
	       deceasedIndicator + CustomerMasterConstants.DELIMITE_FIELD +
	       getLastUpdateDate() + CustomerMasterConstants.DELIMITE_FIELD +
		   getSecurityClassCode() + CustomerMasterConstants.DELIMITE_FIELD +
		   getSourceCode() + CustomerMasterConstants.DELIMITE_FIELD ;
		
					
         return str;
	}
	
	public boolean isNull(){
			
			if(isNull(deceasedIndicator))
					return true;
			else
				return false;
		}
		
		 private boolean isNull(String str){
				
				if(str==null||str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
					return true;
				else
					return false;
			}
		

}
