package com.walgreens.cdi.vo.customer;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpResponse;

/**
 * <p>Java class for ArrayOfCustomer complex type.
  * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfEntCustomer", propOrder = {
    "item",
    "totalResultCount"
})
public class ArrayOfEnterpriseCustomer {
	protected List<CustomerMasterEnterpriseLookUpResponse> item;
	private int totalResultCount;
    
	public void setItem(List<CustomerMasterEnterpriseLookUpResponse> item) {
		this.item = item;
	}
	public int getTotalResultCount() {
		return totalResultCount;
	}
	public void setTotalResultCount(int totalResultCount) {
		this.totalResultCount = totalResultCount;
	}
	/**
     * 
     * 
     * @return
     *     array of
     *     {@link Customer }
     *     
     */
    public CustomerMasterEnterpriseLookUpResponse[] getItem() {
        if (this.item == null) {
            return new CustomerMasterEnterpriseLookUpResponse[ 0 ] ;
        }
        return ((CustomerMasterEnterpriseLookUpResponse[]) this.item.toArray(new CustomerMasterEnterpriseLookUpResponse[this.item.size()] ));
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link Customer }
     *     
     */
    public CustomerMasterEnterpriseLookUpResponse getItem(int idx) {
        if (this.item == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.item.get(idx);
    }

    public int getItemLength() {
        if (this.item == null) {
            return  0;
        }
        return this.item.size();
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link CustomerMasterEntLookUpResponse }
     *     
     */
    public void setItem(CustomerMasterEnterpriseLookUpResponse[] values) {
        this._getItem().clear();
        int len = values.length;
        for (int i = 0; (i<len); i ++) {
            this.item.add(values[i]);
        }
    }

    protected List<CustomerMasterEnterpriseLookUpResponse> _getItem() {
        if (item == null) {
            item = new ArrayList<CustomerMasterEnterpriseLookUpResponse>();
        }
        return item;
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerMasterEntLookUpResponse }
     *     
     */
    public CustomerMasterEnterpriseLookUpResponse setItem(int idx, CustomerMasterEnterpriseLookUpResponse value) {
        return this.item.set(idx, value);
    }


}
