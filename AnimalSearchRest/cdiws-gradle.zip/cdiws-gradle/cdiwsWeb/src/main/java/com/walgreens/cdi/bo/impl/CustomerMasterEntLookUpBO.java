package com.walgreens.cdi.bo.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import madison.mpi.MemRow;
import madison.mpi.MemRowList;
import madison.mpi.RowIterator;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import walgreens.rap.webservices.security.server.ConsumerContext;
import walgreens.services.LoggingFacility;

import com.initiate.bean.ArrayOfMember;
import com.initiate.bean.Member;
import com.walgreens.cdi.bo.ICustomerMasterEntLookUpBO;
import com.walgreens.cdi.dao.ICustomerMasterEntLookUpDAO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CDILogger;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.CustomerMasterUtility;
import com.walgreens.cdi.util.SecurityResource;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpRequest;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpResponse;
import com.walgreens.cdi.vo.CustomerMasterEntSearchProgramVO;
import com.walgreens.cdi.vo.CustomerMasterLinkageVO;
import com.walgreens.cdi.vo.TrackingInfoVO;
import com.walgreens.cdi.vo.customer.ArrayOfEntCustomer;
import com.walgreens.cdi.vo.customer.CustomerMasterEntSearch;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddress;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterAddressAttr;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterHubLinkageRec;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterLinkageDetail;
import com.walgreens.cdi.vo.customer.attr.CustomerMasterPhoneAttr;
import com.walgreens.cdi.wsao.ICustomerMasterEntLookUpWSAO;

public class CustomerMasterEntLookUpBO extends BaseBO implements
		ICustomerMasterEntLookUpBO {

	private ICustomerMasterEntLookUpWSAO customerMasterEntLookUpWSAO;

	private ICustomerMasterEntLookUpDAO customerMasterEntLookUpDAO;

	public ArrayOfEntCustomer lookUpCustomerMasterEnt(
			CustomerMasterEntLookUpRequest customerMasterLookUpRequest)
			throws SystemException, BusinessRuleViolationException {
		try {
			validateRequestObject(customerMasterLookUpRequest);
			if (CustomerMasterUtility.isEmpty(customerMasterLookUpRequest.getEntReturnLinkages())) {
				customerMasterLookUpRequest
						.setEntReturnLinkages(CustomerMasterConstants.VALUE_FALSE);

			}

			CustomerMasterEntLookUpResponse[] searchResponse = null;
			//CustomerMasterEntLookUpResponse[] allSearchResp = null;
			CustomerMasterEntLookUpResponse[] finalSearchResponse = null;
			//String srcCodeFilter = null;
			//		
			//Code Change start for EIS Change
			boolean loyaltyPVtableSearchOff=false;
			String applicationID=getLoggingHandlerObj().getTrackingInfoProxyBean().getApplicationID();
			if(applicationID!=null && CustomerMasterConstants.LOYALTY_PV_SEARCH_OFF_CHANELS_LIST.contains(applicationID))
			{
				loyaltyPVtableSearchOff=true;
			}	
			System.out.println("****applicationID*******=="+applicationID);
			//Code Change END for EIS Change
			String consumerAppId = ConsumerContext
					.getCurrentConsumerApplicationId();
			String initiateID = "";
			String initiatePWD = "";
			SecurityResource securityResource = SecurityResource.getInstance();
			initiateID = securityResource.getInitiateID(consumerAppId);
			initiatePWD = securityResource.getInitiatePassword(initiateID);
			if (customerMasterLookUpRequest.getSearchCalibrateCd()
					.equalsIgnoreCase(
							CustomerMasterConstants.SEARCH_CALIBRATION_CD_A)) {
				
				searchResponse = searchEnterprise(customerMasterLookUpRequest,
								initiateID, initiatePWD,loyaltyPVtableSearchOff); //loyaltyPVtableSearchOff Flag is passed for EIS Change
				finalSearchResponse = searchResponse;                
			
			} else if (customerMasterLookUpRequest.getSearchCalibrateCd()
					.equalsIgnoreCase(
							CustomerMasterConstants.SEARCH_CALIBRATION_CD_B)) {
				if (!CustomerMasterConstants.CDI_HUB.equalsIgnoreCase(CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH)){
				ArrayOfMember arrMemberRes = null;
				try{
				if(!loyaltyPVtableSearchOff)//If condiotion Added  for EIS Change
				{	
					arrMemberRes = getCustomerMasterEntLookUpWSAO()
							.getLoyaltyMemHead(customerMasterLookUpRequest,
									initiateID, initiatePWD);
					if (CustomerMasterConstants.ENT_PV_TABLE_SEARCH) {
						searchResponse = getCVProgDeatilsFromPVtable(arrMemberRes);
					}
				}
				if (searchResponse == null) {
					getWalgreensLogger().log(LoggingFacility.INFO,
							"No records in PV table.Seraching in CDI hub");
					searchResponse = getCustomerMasterEntLookUpWSAO()
							.lookUpEntCustomerMasterLoyalty(
									customerMasterLookUpRequest, initiateID,
									initiatePWD);
				}
				finalSearchResponse = searchResponse;
				}catch(Exception e){
					getWalgreensLogger().log(LoggingFacility.INFO,
					"Exception occured while searching LR member");
					String exceptionCode = getExceptionCode(e);
					if (exceptionCode != null) {
						getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
						throw new SystemException(exceptionCode, e.getMessage());
					} else {
						getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
						throw new SystemException(
								CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e
										.getMessage());
					}
					
				}

			} else {
					getWalgreensLogger()
							.log(LoggingFacility.INFO,
									"CDI hub excluded from member search. LR member can not be searched");
					throw new SystemException(
							CustomerMasterConstants.EC_EXCEPTION_NO_CANDIDATES_FOUND,
							"LR member can not be searched as Customer Hub is excluded from search.");
				}
				
			}
			/* Checking for exclusion of detach card. While searching with detached progid no member will be returned. 
			** Inactive program can be searchable but inactive prog detl should not be shown in response
			*/
			if(null!=finalSearchResponse){
			CustomerMasterEntLookUpResponse[] filteredSearchResponse = new CustomerMasterEntLookUpResponse[finalSearchResponse.length];
			int k=0;			
			if (finalSearchResponse != null && finalSearchResponse.length > 0) {

				for (int j = 0; j < finalSearchResponse.length; j++) {

					CustomerMasterEntLookUpResponse memDetl = finalSearchResponse[j];
					ArrayList<CustomerMasterEntSearchProgramVO> programArray = memDetl
							.getEntCustomer().getProgramArray();
					String filterRec = CustomerMasterConstants.VAL_NO;
					String removeProgDetl = CustomerMasterConstants.VAL_NO;
					ArrayList<CustomerMasterEntSearchProgramVO> programArrayMod = new ArrayList<CustomerMasterEntSearchProgramVO>();
					programArrayMod.addAll(programArray);

					if (programArray != null && programArray.size() > 0) {
						for (int i = 0; i < programArray.size(); i++) {

							CustomerMasterEntSearchProgramVO progVo = programArray
									.get(i);
							if (!CustomerMasterUtility
									.isEmpty(customerMasterLookUpRequest
											.getProgramCode())
									&& !CustomerMasterUtility
											.isEmpty(customerMasterLookUpRequest
													.getProgramIdentifier())) {
								if (CustomerMasterConstants.ALLOW_PROG_SEARCH == true) {

									if (progVo.getProgramCode()
											.equalsIgnoreCase(
													customerMasterLookUpRequest
															.getProgramCode())
											&& progVo
													.getProgramId()
													.equalsIgnoreCase(
															customerMasterLookUpRequest
																	.getProgramIdentifier())
											&& progVo
													.getProgramStatus()
													.equalsIgnoreCase(
															CustomerMasterConstants.PROGRAM_STATUS_D)) {

										filterRec = CustomerMasterConstants.VAL_YES;
										break;
									}else if ((customerMasterLookUpRequest
											.getProgramCode().equalsIgnoreCase(CustomerMasterConstants.PROGRAM_EMPL)&&((progVo.getProgramCode()
											.equalsIgnoreCase(CustomerMasterConstants.PROGRAM_EEWAG))||(progVo.getProgramCode()
													.equalsIgnoreCase(CustomerMasterConstants.PROGRAM_EEDR))))
											&& progVo
													.getProgramId()
													.equalsIgnoreCase(
															customerMasterLookUpRequest
																	.getProgramIdentifier())
											&& progVo
													.getProgramStatus()
													.equalsIgnoreCase(
															CustomerMasterConstants.PROGRAM_STATUS_D)) {

										filterRec = CustomerMasterConstants.VAL_YES;
										break;
									}
									
									else if (progVo.getProgramCode()
											.equalsIgnoreCase(
													customerMasterLookUpRequest
															.getProgramCode())
											&& progVo
													.getProgramId()
													.equalsIgnoreCase(
															customerMasterLookUpRequest
																	.getProgramIdentifier())
											&& progVo
													.getProgramStatus()
													.equalsIgnoreCase(
															CustomerMasterConstants.PROGRAM_STATUS_A)) {

										filterRec = CustomerMasterConstants.VAL_NO;
									} else if (progVo
											.getProgramStatus()
											.equalsIgnoreCase(
													CustomerMasterConstants.PROGRAM_STATUS_I)
											|| progVo
													.getProgramStatus()
													.equalsIgnoreCase(
															CustomerMasterConstants.PROGRAM_STATUS_D)) {

										filterRec = CustomerMasterConstants.VAL_NO;
										removeProgDetl = CustomerMasterConstants.VAL_YES;
										programArrayMod.remove(progVo);

									}
								}
							} else {

								if (progVo
										.getProgramStatus()
										.equalsIgnoreCase(
												CustomerMasterConstants.PROGRAM_STATUS_I)
										|| progVo
												.getProgramStatus()
												.equalsIgnoreCase(
														CustomerMasterConstants.PROGRAM_STATUS_D)) {

									filterRec = CustomerMasterConstants.VAL_NO;
									removeProgDetl = CustomerMasterConstants.VAL_YES;
									programArrayMod.remove(progVo);

								}
							}

						}
					}

					if (filterRec
							.equalsIgnoreCase(CustomerMasterConstants.VAL_NO)
							&& removeProgDetl
									.equalsIgnoreCase(CustomerMasterConstants.VAL_NO)) {

						filteredSearchResponse[k] = memDetl;
						k++;
					} else if (filterRec
							.equalsIgnoreCase(CustomerMasterConstants.VAL_NO)
							&& removeProgDetl
									.equalsIgnoreCase(CustomerMasterConstants.VAL_YES)) {

						CustomerMasterEntSearch member = new CustomerMasterEntSearch();
						member = memDetl.getEntCustomer();
						member.setProgramArray(null);
						member.addProgramArray(programArrayMod);

						memDetl.setEntCustomer(member);
						filteredSearchResponse[k] = memDetl;
						k++;

					}

				}

			}
			
			
			finalSearchResponse = (CustomerMasterEntLookUpResponse[]) ArrayUtils.subarray(filteredSearchResponse, 0, k);
		}
			if(null==finalSearchResponse||finalSearchResponse.length==0){
				
				throw new SystemException(
						CustomerMasterConstants.EC_EXCEPTION_NO_CANDIDATES_FOUND,"");
			}
						


			// Invoke Calibration process
			int maxMemberCnt=0;
			if (CustomerMasterUtility.isEmpty(customerMasterLookUpRequest.getMemSearchMaxResp())
					||(!CustomerMasterUtility.isEmpty(customerMasterLookUpRequest.getMemSearchMaxResp()) && (Integer.parseInt(customerMasterLookUpRequest.getMemSearchMaxResp()) > CustomerMasterConstants.MAX_ROWS))) {

				maxMemberCnt = CustomerMasterConstants.MAX_ROWS;
			} else {
				maxMemberCnt = Integer.parseInt(customerMasterLookUpRequest.getMemSearchMaxResp());
			}
			finalSearchResponse= calibrateResponseArray(finalSearchResponse,maxMemberCnt);
			
           // Code change Start For EntLookUpResponseCustomization	
			if(null!=finalSearchResponse){
			for(CustomerMasterEntLookUpResponse entLookUpResponseObj:finalSearchResponse)
			{	
				if(!(entLookUpResponseObj.getEntCustomer().getSrcCode().equalsIgnoreCase(CustomerMasterConstants.LR_SRC))&&(entLookUpResponseObj.getEntCustomer().getCustAll().getBirthDate()!=null || entLookUpResponseObj.getEntCustomer().getCustAll().getPhone()!=null))
				{
					validateResponse(entLookUpResponseObj);
				}	
			}
		}
		//Code change End For EntLookUpResponseCustomization

			ArrayOfEntCustomer arr = new ArrayOfEntCustomer();
			arr.setItem(finalSearchResponse);
			arr.setTotalResultCount(finalSearchResponse.length);
			return arr;

		} catch (JaxWsSoapFaultException e) {
			String exceptionCode = getExceptionCode(e);
			if (exceptionCode != null) {
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(exceptionCode, e.getMessage());
			} else {
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(
						CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e
								.getMessage());
			}
		} catch (BusinessRuleViolationException e) {
			throw e;
		}

	}

	public void validateRequestObject(
			CustomerMasterEntLookUpRequest customerMasterLookUpRequest)
			throws BusinessRuleViolationException {
		ValidateCustomerMasterRequest
				.validateRequiredFields(customerMasterLookUpRequest);
		ValidateCustomerMasterRequest
				.validateInvalidFieldValues(customerMasterLookUpRequest);
	}

	private CustomerMasterHubLinkageRec getLinkageDetails(String eid,
			List<CustomerMasterLinkageVO> linkageList) {
		CustomerMasterHubLinkageRec hubLinkage = new CustomerMasterHubLinkageRec();
		hubLinkage.setEid(eid);
		List<CustomerMasterLinkageDetail> linkageDetail = new ArrayList<CustomerMasterLinkageDetail>();

		for (int i = 0; i < linkageList.size(); i++) {
			if (eid.equals(linkageList.get(i).getEntityId())) {
				CustomerMasterLinkageDetail obj = new CustomerMasterLinkageDetail();
				obj.setRefCode(linkageList.get(i).getRefCode());
				obj.setRefID(linkageList.get(i).getRefID());
				obj.setSourceCode(linkageList.get(i).getSourceCode());
				obj.setSourceID(linkageList.get(i).getSourceID());
				obj.setStatus(linkageList.get(i).getStatus());
				linkageDetail.add(obj);
			}
		}
		CustomerMasterLinkageDetail[] linkageArr = new CustomerMasterLinkageDetail[linkageDetail
				.size()];
		hubLinkage.setLinkageDetail(linkageDetail.toArray(linkageArr));
		return hubLinkage;
	}

	public CustomerMasterEntLookUpResponse[] getCVLinkageFromPVtable(
			ArrayOfMember arrMemberRes, String showLinkage) {
		CustomerMasterEntLookUpResponse[] searchResponse = null;
		List<CustomerMasterLinkageVO> linkageList = null;

		try {
			List<Member> memberList=arrMemberRes.getItem();
			Member[] memberRes = memberList.toArray(new Member[memberList.size()]);
			long entRecno = 0;
			List<CustomerMasterEntSearch> list = null;
			int memCount = memberRes.length;
			Map<String, Member> memberMap = new HashMap<String, Member>();
			Set<Long> eidSet = new LinkedHashSet<Long>();
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"Member count from memhead " + memCount);
			for (int i = 0; i < memCount; i++) {
				entRecno = memberRes[i].getMemHead().getEntRecno();
				Short currMatchScore = memberRes[i].getMemHead()
						.getMatchScore();


				// If entRecno is not present add it
				if (memberMap.get("" + entRecno) == null) {
					memberMap.put("" + entRecno, memberRes[i]);
				}
				// check if entRecno already present in the map then compare
				// the match score overwrite with higher matchscore
				else if (memberMap.get("" + entRecno) != null
						&& currMatchScore > Short.valueOf(memberMap.get(
								"" + entRecno).getMemHead().getMatchScore())) {
					memberMap.put("" + entRecno, memberRes[i]);
				}

				eidSet.add(entRecno);
			}
			int uniqueEidCount = eidSet.size();
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"Eid List for PV look up " + eidSet);
			long st = System.currentTimeMillis();

			list = getCustomerMasterEntLookUpDAO().getCdiCompViewAllSrc(eidSet);

			long et = System.currentTimeMillis();
			long t = et - st;
			getWalgreensLogger().log(
					LoggingFacility.DEBUG,
					"Total time taken in getting Composite view details from PV Table "
							+ t);
			if (list != null) {
				if (uniqueEidCount != list.size()) {

					getWalgreensLogger()
							.log(
									LoggingFacility.INFO,
									"Composite view PV table does not have all the EID details associated with this search");
					getWalgreensLogger().log(LoggingFacility.INFO,
							"Turned on search from Hub");
					searchResponse = null;
					return searchResponse; //
				} else {
					st = System.currentTimeMillis();

					if (showLinkage
							.equalsIgnoreCase(CustomerMasterConstants.VALUE_TRUE)) {

						linkageList = getCustomerMasterEntLookUpDAO()
								.getCdiLinkageAllSrc(eidSet);

					}

					et = System.currentTimeMillis();
					t = et - st;
					getWalgreensLogger().log(
							LoggingFacility.DEBUG,
							"Total time taken in getting Linkage details from PV Table "
									+ t);

					Map<String, CustomerMasterEntSearch> custLookUpMap = new HashMap<String, CustomerMasterEntSearch>();
					for (int i = 0; i < list.size(); i++) {
						CustomerMasterEntSearch custLookUpVO = list.get(i);
						custLookUpMap.put(custLookUpVO.getEID(), custLookUpVO);

					}
					searchResponse = new CustomerMasterEntLookUpResponse[custLookUpMap.size()];
					int i = 0;
					Iterator itr = eidSet.iterator();
					while (itr.hasNext()) {

						CustomerMasterEntSearch custMst = custLookUpMap.get(""
								+ itr.next());
						entRecno = Long.parseLong(custMst.getEID());
						Member mem = memberMap.get(custMst.getEID());
						custMst.setMatchScore(Short.toString(mem.getMemHead()
								.getMatchScore()));
						custMst.setSrcCode(mem.getMemHead().getSrcCode());
						custMst.setMemberId(mem.getMemHead().getMemIdnum());
						custMst.setMemberStatus(mem.getMemHead().getMemStat());
						

						if (showLinkage
								.equalsIgnoreCase(CustomerMasterConstants.VALUE_TRUE)) {
							CustomerMasterHubLinkageRec hubLinkageRec = getLinkageDetails(
									Long.toString(entRecno), linkageList);
							if (hubLinkageRec != null) {
								custMst.setHubLinkageRec(hubLinkageRec);
								getWalgreensLogger().log(
										LoggingFacility.DEBUG,
										"Linkage found in table CDI_LINKAGE_CV_ID for EID "
												+ entRecno);
							} else {
								// If linkage not found for any eid set PVSearch
								// will return nothing
								getWalgreensLogger()
										.log(
												LoggingFacility.INFO,
												"Linkage Not found in table for EID "
														+ entRecno
														+ " Turned off PV search for this search request");
								// break;
								searchResponse = null;
								return searchResponse;
							}
						}
						searchResponse[i] = new CustomerMasterEntLookUpResponse();
						searchResponse[i].setEntCustomer(custMst);
						getWalgreensLogger().log(LoggingFacility.DEBUG,
								"EID Iteration " + i);
						i++;
					}

				}
			} else {
				getWalgreensLogger()
						.log(
								LoggingFacility.INFO,
								" CV and Linkage Not found in PV table for EID "
										+ entRecno
										+ " Turned off PV search for this search request");

				searchResponse = null;
				return searchResponse;
			}
		} catch (Exception e) {
			getWalgreensLogger()
					.log(LoggingFacility.ERROR,
							"There is an Error in PV Search..Turning off PV search for this search request");
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
			e.printStackTrace();
		}

		return searchResponse;

	}

	public CustomerMasterEntLookUpResponse[] getCVLinkageFromRefHubPVtable(
			MemRowList MemberList) {

		CustomerMasterEntLookUpResponse[] searchResponse = null;

		try {

			RowIterator iter = MemberList.rows();
			List<CustomerMasterEntSearch> list = null;
			CustomerMasterEntSearch custMst;
			int i = 0;
			searchResponse = new CustomerMasterEntLookUpResponse[MemberList
					.size()];
			while (iter.hasMoreRows()) {
				MemRow memRow = (MemRow) iter.nextRow();
				list = getCustomerMasterEntLookUpDAO().getRefCompViewAllSrc(
						memRow.getMemHead().getSrcCode(),
						memRow.getMemHead().getMemIdnum());
				if (list.size() == 0) {
					getWalgreensLogger()
							.log(LoggingFacility.INFO,
									"CV details not found in PV Search..Going to search in hub");
					searchResponse = null;
					return searchResponse;

				} else {
					custMst = list.get(0);
					custMst.setEID(Long.toString(memRow.getMemHead()
							.getEntRecno()));
					custMst.setMatchScore(Short.toString(memRow.getMemHead()
							.getMatchScore()));
					custMst.setSrcCode(memRow.getMemHead().getSrcCode());
					custMst.setMemberId(memRow.getMemHead().getMemIdnum());
					custMst.setMemberStatus(memRow.getMemHead().getMemStat());
					searchResponse[i] = new CustomerMasterEntLookUpResponse();
					searchResponse[i].setEntCustomer(custMst);
				}
				i++;
			}

		} catch (Exception e) {
			getWalgreensLogger()
					.log(LoggingFacility.ERROR,
							"There is an Error in PV Search..Turning off PV search for this search request");
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
			e.printStackTrace();
		}

		return searchResponse;

	}

	public CustomerMasterEntLookUpResponse[] getCVProgDeatilsFromPVtable(
			ArrayOfMember arrMemberRes) {

		CustomerMasterEntLookUpResponse[] searchResponse = null;

		try {
			List<Member> memberList=arrMemberRes.getItem();
			Member[] memberRes = memberList.toArray(new Member[memberList.size()]);
			List<CustomerMasterEntSearch> list = null;
			CustomerMasterEntSearch custMst;

			searchResponse = new CustomerMasterEntLookUpResponse[memberRes.length];
			for (int i = 0; i < memberRes.length; i++) {

				Member mem = memberRes[i];
				String memStat = memberRes[i].getMemHead().getMemStat();
				list = getCustomerMasterEntLookUpDAO().getLoyaltyMemCompView(
						mem.getMemHead().getSrcCode(),
						mem.getMemHead().getMemIdnum());
				if (list.size() == 0) {
					getWalgreensLogger()
							.log(LoggingFacility.INFO,
									"CV details not found in PV Search..Going to search in hub");
					searchResponse = null;
					return searchResponse;

				} else {
					custMst = list.get(0);
					ArrayList<CustomerMasterEntSearchProgramVO> progList = new ArrayList<CustomerMasterEntSearchProgramVO>();

					List<Map<String, Object>> result = getCustomerMasterEntLookUpDAO()
							.getAllProgramsAndAttr(
									mem.getMemHead().getSrcCode(),
									mem.getMemHead().getMemIdnum());
					if (result.size() == 0) {
						getWalgreensLogger()
								.log(LoggingFacility.INFO,
										"Program details not found in PV Search..Going to search in hub");
						searchResponse = null;
						return searchResponse;

					} else {
						
						for (int j = 0; j < result.size(); j++) {
							Map<String, Object> obj = result.get(j);
							CustomerMasterEntSearchProgramVO progVO = new CustomerMasterEntSearchProgramVO();
							progVO.setProgramCode((String) obj
									.get(CustomerMasterConstants.PROGRAM_CODE));
							progVO
									.setProgramId((String) obj
											.get(CustomerMasterConstants.PROGRAM_IDENT));
							progVO
									.setProgramStatus((String) obj
											.get(CustomerMasterConstants.PROGRAM_STATUS));
							progVO
									.setProgStartDt((String) obj
											.get(CustomerMasterConstants.PROGRAM_STARTDT));
							progVO
									.setProgEndDt((String) obj
											.get(CustomerMasterConstants.PROGRAM_ENDDT));
							progVO
									.setProgLstUpDt((String) obj
											.get(CustomerMasterConstants.PROGRAM_LAST_UPDATE_DATE_PV));
							progList.add(progVO);
							if(CustomerMasterConstants.STATUS_PENDING.equalsIgnoreCase((String) obj
											.get(CustomerMasterConstants.PROGRAM_STATUS))){
								memStat = CustomerMasterConstants.STATUS_PENDING;
							}

						}
					}

					custMst.setProgramArray(progList);
					custMst.setEID(Long
							.toString(mem.getMemHead().getEntRecno()));
					custMst.setMatchScore(Short.toString(mem.getMemHead()
							.getMatchScore()));
					custMst.setSrcCode(memberRes[i].getMemHead().getSrcCode());
					custMst.setMemberId(memberRes[i].getMemHead().getMemIdnum());
					custMst.setMemberStatus(memStat);
					searchResponse[i] = new CustomerMasterEntLookUpResponse();
					searchResponse[i].setEntCustomer(custMst);

				}
			}
		} catch (Exception e) {
			getWalgreensLogger()
					.log(LoggingFacility.ERROR,
							"There is an Error in PV Search..Turning off PV search for this search request");
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
			e.printStackTrace();
			searchResponse = null;
			return searchResponse;
		}

		return searchResponse;

	}

	/**
	 * this method removes all entry which are present more than one time e.g
	 * "IC,SM,IC,EC" will be returned as "IC,SM,EC"
	 * 
	 */
	public String removeDuplicateEntry(String str) {

		StringBuffer strBuff = new StringBuffer();

		try {
			String[] temp = str.split(CustomerMasterConstants.COMA_DELIMITER);
			for (int i = 0; i < temp.length; i++) {
				if (!strBuff.toString().contains(temp[i]))
					strBuff.append(temp[i]).append(
							CustomerMasterConstants.COMA_DELIMITER);
			}

		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.INFO,"Error Msg:" + e.getMessage());
		}
		return strBuff.substring(0, (strBuff.length() - 1)).toString();
	}

	public CustomerMasterEntLookUpResponse[] calibrateResponseArray(
			CustomerMasterEntLookUpResponse[] searchResponse, int maxRecCount) {
		if(searchResponse !=null){		
		if (searchResponse.length > 1) {
			CustomerMasterEntLookUpResponse temp;
			int j;
			boolean flag = true;

			while (flag) {
				flag = false;
				for (j = 0; j < searchResponse.length - 1; j++) {
					
						if ((Integer.valueOf(searchResponse[j].getEntCustomer()
							.getMatchScore())) < (Integer
							.valueOf(searchResponse[j+1].getEntCustomer()
									.getMatchScore()))) {
						temp = searchResponse[j];
						searchResponse[j] = searchResponse[j + 1];
						searchResponse[j + 1] = temp;
						flag = true;
					}
					
				}
			}
		}
		// Select top 20 records at max
		if(searchResponse.length>maxRecCount){
			searchResponse = (CustomerMasterEntLookUpResponse[]) ArrayUtils.subarray(searchResponse, 0, maxRecCount);
			
		}
	}
		return searchResponse;

	}

	public CustomerMasterEntLookUpResponse[] searchEnterprise(
			CustomerMasterEntLookUpRequest customerMasterLookUpRequest,
			String initiateID, String initiatePWD,boolean loyaltyPVtableSearchOff) throws SystemException {

		CustomerMasterEntLookUpResponse[] searchResponse = null;
		CustomerMasterEntLookUpResponse[] refSearchResp = null;
		CustomerMasterEntLookUpResponse[] finalSearchResponse = null;
		ArrayOfMember arrMemberRes = null;
		boolean parallelSearchFlag=true;
		try {
			String srcCodeFilter = CustomerMasterConstants.ENT_SEARCH_SRC_CALCODE_A;
			if (!CustomerMasterConstants.CDI_HUB.equalsIgnoreCase(CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH)){
			try {
				if(!loyaltyPVtableSearchOff) //IF condition added For PV table search Off
				{	
					arrMemberRes = getCustomerMasterEntLookUpWSAO()
							.getLoyaltyMemHead(customerMasterLookUpRequest,
									initiateID, initiatePWD);
	
					if (CustomerMasterConstants.ENT_PV_TABLE_SEARCH) {
						searchResponse = getCVProgDeatilsFromPVtable(arrMemberRes);
					} else {
						getWalgreensLogger().log(LoggingFacility.INFO,
								"PV search disabled.Seraching in hub");
					}
				}
				if (searchResponse == null) {
					getWalgreensLogger().log(LoggingFacility.INFO,
							"No records in PV table.Seraching in CDI hub");
					searchResponse = getCustomerMasterEntLookUpWSAO()
							.lookUpEntCustomerMasterLoyalty(
									customerMasterLookUpRequest, initiateID,
									initiatePWD);
				}
			} catch (Exception ex) {
								
				if(ex.getMessage()!=null && ex.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_CANDIDATES_FOUND))
					
				{					
					getWalgreensLogger().log(LoggingFacility.INFO,
					"LR member not found.Seraching in CDI and REF hub in parallel");				
					
				}
				else
					
				{
					getWalgreensLogger().log(LoggingFacility.INFO,
					"Exception occured while searching LR member");
					parallelSearchFlag=false;
					throw ex;
				}
			}
			} else{
				getWalgreensLogger().log(LoggingFacility.INFO,
				"CDI hub excluded from search. Going to search in REF hub");
				parallelSearchFlag=true;
			}

			if (searchResponse == null) {
				if(parallelSearchFlag==true){
				CustomerMasterREFSearchThread thread1 = null;
				CustomerMasterCDISearchThread thread2 = null;				
				
				if (null == CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH|| CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH
								.equalsIgnoreCase("")) {
					// call REF hub
					
					
					TrackingInfoVO localTrackingInfoVo = new TrackingInfoVO();
					localTrackingInfoVo.setApplicationID(getLoggingHandlerObj().getTrackingInfoProxyBean().getApplicationID());
					localTrackingInfoVo.setMessageID(getLoggingHandlerObj().getTrackingInfoProxyBean().getMessageID());
					localTrackingInfoVo.setCorrelationID(getLoggingHandlerObj().getTrackingInfoProxyBean().getCorrelationID());
					CDILogger localCdiLogger = new CDILogger();
					localCdiLogger.setTrackingInfoProxyBean(localTrackingInfoVo);
					localCdiLogger.setWalgreensLogger(getLoggingHandlerObj().getCdiLogger().getWalgreensLogger());
					
					
					
					thread1 = new CustomerMasterREFSearchThread(
							customerMasterLookUpRequest, this,
							getCustomerMasterEntLookUpWSAO(),
							CustomerMasterConstants.AS_MEMBER,localCdiLogger);
					thread1.start();
					thread1.join();
					searchResponse = thread1.searchResponse;
					

					// call CDI hub
					thread2 = new CustomerMasterCDISearchThread(
							customerMasterLookUpRequest, srcCodeFilter, this,
							getCustomerMasterEntLookUpWSAO(),
							CustomerMasterConstants.AS_ENTITY, initiateID,
							initiatePWD,localCdiLogger,localTrackingInfoVo);
					thread2.start();
					thread2.join();
					refSearchResp = thread2.searchResponse;
					localCdiLogger = null;
					localTrackingInfoVo = null;
					
				}
				else if (CustomerMasterConstants.REF_HUB.equalsIgnoreCase(CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH)){
					getWalgreensLogger().log(LoggingFacility.INFO,"REF hub excluded from Search");
					// Search in CDI hub only
					try{
					ArrayOfMember arrMemberResponse = null;

					arrMemberResponse = getCustomerMasterEntLookUpWSAO().getCdiMemHead(customerMasterLookUpRequest,
							srcCodeFilter,CustomerMasterConstants.AS_ENTITY, initiateID,
							initiatePWD,true,getLoggingHandlerObj().getTrackingInfoProxyBean());
					if(CustomerMasterConstants.ENT_PV_TABLE_SEARCH){
					searchResponse = getCVLinkageFromPVtable(arrMemberResponse,						
							customerMasterLookUpRequest.getEntReturnLinkages());
					}
					else{
						getWalgreensLogger().log(LoggingFacility.INFO,"PV search disabled.Seraching in CDI hub");
					}
					if (searchResponse == null) {
						searchResponse = getCustomerMasterEntLookUpWSAO().lookUpEntCustomerMasterCdi(
								customerMasterLookUpRequest, srcCodeFilter, CustomerMasterConstants.AS_ENTITY, initiateID,
								initiatePWD,true,getLoggingHandlerObj().getTrackingInfoProxyBean());

					}
					} catch (Exception ex) {
						
							getWalgreensLogger().log(LoggingFacility.INFO,
							"Exception occured while searching in CDI hub");
							
							throw ex;
						
					}

					
				}
				else if (CustomerMasterConstants.CDI_HUB.equalsIgnoreCase(CustomerMasterConstants.EXCLUDE_HUB_ONSEARCH)){
					getWalgreensLogger().log(LoggingFacility.INFO,"CDI hub excluded from Search");
					// Search in REF hub only
					try{
					MemRowList MemberList = null;

					MemberList = getCustomerMasterEntLookUpWSAO().searchRefHub(customerMasterLookUpRequest,
							CustomerMasterConstants.SEG_CODE_MEMHEAD, CustomerMasterConstants.AS_MEMBER,true);
					if (CustomerMasterConstants.ENT_PV_TABLE_SEARCH) {
						refSearchResp = getCVLinkageFromRefHubPVtable(MemberList);
					}
					else{
						getWalgreensLogger().log(LoggingFacility.INFO,"PV search disabled.Seraching in Ref hub");
					}
					if (refSearchResp == null) {						
						searchResponse = getCustomerMasterEntLookUpWSAO().lookUpEntCustomerMasterRef(
								customerMasterLookUpRequest, CustomerMasterConstants.AS_MEMBER,true);

					}
					} catch (Exception ex) {
						
						getWalgreensLogger().log(LoggingFacility.INFO,
						"Exception occured while searching in Ref hub");
						
						throw ex;
					
				}
					
				}

				if ((searchResponse == null || searchResponse.length < 1)
						&& (refSearchResp == null || refSearchResp.length < 1)) {
					throw new SystemException(
							CustomerMasterConstants.EC_EXCEPTION_NO_CANDIDATES_FOUND,CustomerMasterConstants.EXCEPTION_NO_CANDIDATES_FOUND,CustomerMasterConstants.EXCEPTION_NO_CANDIDATES_FOUND);

				}

				if (searchResponse != null && refSearchResp != null) {
					finalSearchResponse = (CustomerMasterEntLookUpResponse[]) ArrayUtils
							.addAll(searchResponse, refSearchResp);
				} else if (searchResponse == null ) {
					if (refSearchResp != null)
					{
						finalSearchResponse = refSearchResp;
					}
				} else if (searchResponse != null ) {
					if (refSearchResp == null)
					{
					finalSearchResponse = searchResponse;
					}

				}

			}} else {
				finalSearchResponse = searchResponse;
			}
			
			return finalSearchResponse;
			
		} catch (JaxWsSoapFaultException e) {
			String exceptionCode = getExceptionCode(e);
			if (exceptionCode != null) {
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(exceptionCode, e.getMessage());
			} else {
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(
						CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e
								.getMessage());
			}
		} catch (Exception e) {			
			if(e.getMessage()!=null && (e.getMessage().equalsIgnoreCase(CustomerMasterConstants.EXCEPTION_NO_CANDIDATES_FOUND) ||
					e.getMessage().equalsIgnoreCase(CustomerMasterConstants.EC_EXCEPTION_NO_CANDIDATES_FOUND)))
				
			{
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
			
			    throw new SystemException(
					CustomerMasterConstants.EC_EXCEPTION_NO_CANDIDATES_FOUND, CustomerMasterConstants.EXCEPTION_NO_CANDIDATES_FOUND);
			}
			
			else{
				String exceptionCode = getExceptionCode(e);
				if (exceptionCode != null) {
					getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
					throw new SystemException(exceptionCode, e.getMessage());
				} else {
					getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
					throw new SystemException(
							CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e
									.getMessage());
			}
			}

		}

	}

	public ICustomerMasterEntLookUpWSAO getCustomerMasterEntLookUpWSAO() {
		return customerMasterEntLookUpWSAO;
	}

	public void setCustomerMasterEntLookUpWSAO(
			ICustomerMasterEntLookUpWSAO customerMasterEntLookUpWSAO) {
		this.customerMasterEntLookUpWSAO = customerMasterEntLookUpWSAO;
	}

	public ICustomerMasterEntLookUpDAO getCustomerMasterEntLookUpDAO() {
		return customerMasterEntLookUpDAO;
	}

	public void setCustomerMasterEntLookUpDAO(
			ICustomerMasterEntLookUpDAO customerMasterEntLookUpDAO) {
		this.customerMasterEntLookUpDAO = customerMasterEntLookUpDAO;
	}
	
	/**
	 * This Function will Validate Response of ENTLookupService.
	 * 
	 * 
	 * @param CustomerMasterEntLookUpResponse
	 * @return
	 */
	private void validateResponse(CustomerMasterEntLookUpResponse objEntLookUpResponse)
	{
		CustomerMasterPhoneAttr homePhone=null; 
		CustomerMasterPhoneAttr cellPhone=null;
		CustomerMasterPhoneAttr workPhone=null;
		String date=null;
		if(objEntLookUpResponse.getEntCustomer().getCustAll().getBirthDate()!=null)
		{
				
			if(objEntLookUpResponse.getEntCustomer().getCustAll().getBirthDate().getBirthdate().length()>10)
			{
				date=objEntLookUpResponse.getEntCustomer().getCustAll().getBirthDate().getBirthdate().trim().substring(0, 10);
			}	
			else
			{
				 date=objEntLookUpResponse.getEntCustomer().getCustAll().getBirthDate().getBirthdate();	
			}
			if(StringUtils.isNotBlank(date)){
				if(!validBirthDate(date))
				{
					
					//Supress Birth Date.
					objEntLookUpResponse.getEntCustomer().getCustAll().setBirthDate(null);
					
				}
				
			}
			else
				objEntLookUpResponse.getEntCustomer().getCustAll().setBirthDate(null);
			
			
		}
		if(objEntLookUpResponse.getEntCustomer().getCustAll().getPhone()!=null)
		{
			
			boolean supressPhoneNumberandareaCode=false;
			if(objEntLookUpResponse.getEntCustomer().getCustAll().getPhone().getHomePhone()!=null)
			{	
				homePhone=objEntLookUpResponse.getEntCustomer().getCustAll().getPhone().getHomePhone();
				if(StringUtils.isBlank(homePhone.getAreaCode())||StringUtils.isBlank(homePhone.getPhoneNumber()))
					supressPhoneNumberandareaCode=true;
				else
				{
					if(!validAreaCode(homePhone.getAreaCode()))
					{
		
						supressPhoneNumberandareaCode=true;
					}
					else if(!validPhoneNumber(homePhone.getPhoneNumber()))
					{
						supressPhoneNumberandareaCode=true;
					}
				}
				if(supressPhoneNumberandareaCode)
					objEntLookUpResponse.getEntCustomer().getCustAll().getPhone().setHomePhone(null);
			}
			
			 supressPhoneNumberandareaCode=false;
			if(objEntLookUpResponse.getEntCustomer().getCustAll().getPhone().getCellPhone()!=null)
			{	
				cellPhone=objEntLookUpResponse.getEntCustomer().getCustAll().getPhone().getCellPhone();
				if(StringUtils.isBlank(cellPhone.getAreaCode())||StringUtils.isBlank(cellPhone.getPhoneNumber()))
					supressPhoneNumberandareaCode=true;
				else
				{
					if(!validAreaCode(cellPhone.getAreaCode()))
					{
		
						supressPhoneNumberandareaCode=true;
					}
					else if(!validPhoneNumber(cellPhone.getPhoneNumber()))
					{
						supressPhoneNumberandareaCode=true;
					}
				}
				if(supressPhoneNumberandareaCode)
					objEntLookUpResponse.getEntCustomer().getCustAll().getPhone().setCellPhone(null);
			}
			
			supressPhoneNumberandareaCode=false;
			if(objEntLookUpResponse.getEntCustomer().getCustAll().getPhone().getWorkPhone()!=null)
			{	
				workPhone=objEntLookUpResponse.getEntCustomer().getCustAll().getPhone().getWorkPhone();
				if(StringUtils.isBlank(workPhone.getAreaCode())||StringUtils.isBlank(workPhone.getPhoneNumber()))
					supressPhoneNumberandareaCode=true;
				else
				{
					if(!validAreaCode(workPhone.getAreaCode()))
					{
		
						supressPhoneNumberandareaCode=true;
					}
					else if(!validPhoneNumber(workPhone.getPhoneNumber()))
					{
						supressPhoneNumberandareaCode=true;
					}
				}
				if(supressPhoneNumberandareaCode)
					objEntLookUpResponse.getEntCustomer().getCustAll().getPhone().setWorkPhone(null);
			}
		}
		
		//start for Address Validation
		if (null != objEntLookUpResponse.getEntCustomer().getCustAll()
				.getAddress()) {
			CustomerMasterAddress customerAddress = objEntLookUpResponse
					.getEntCustomer().getCustAll().getAddress();
			if (null != customerAddress.getHome2Address()) {
				validateAddress(customerAddress.getHome2Address());
				}
			if (null != customerAddress.getPermAddress()) {
				validateAddress(customerAddress.getPermAddress());
				}
			
			if (null != customerAddress.getWorkAddress()) {
				validateAddress(customerAddress.getWorkAddress());
				}
		}
		
		//end for Address Validation

	}
	/**
	 * This Function will Validate Date .
	 * 
	 * 
	 * @param date
	 * @return
	 */
	private boolean validBirthDate(String date)
	{
		SimpleDateFormat sdf=new SimpleDateFormat(CustomerMasterConstants.BDATE_FORMAT);
		Date testDate=null;
		try{
			testDate=sdf.parse(date);
			if(!sdf.format(testDate).equals(date))
				return false;
		}
		catch(ParseException ex){
			return false;
		}
		catch(IllegalArgumentException ex1){
			return false;
		}
		return true;

	}
	/**
	 * This Function will Validate Area Code .It will validate that
	 * Area code Must be 3 digits in length.
	 * Area code Must be numeric.
	 * Area code Cannot start with a zero or a one.
	 * @param areaCode
	 * @return
	 */
	private boolean validAreaCode(String areaCode)
	{
	    if(areaCode.length()!=CustomerMasterConstants.AREA_CODE_LENGTH)
	    	return false;
	    else if(!StringUtils.isNumeric(areaCode))
	    	return false;
	    else if(areaCode.startsWith("0") || areaCode.startsWith("1"))
	    	return false;
		return true;	
	}
	/**
	 * This Function will Validate phone Number .It will validate that
	 * phone Number Must be 7 digits in length.
	 * phone Number Must be numeric.
	 * phone Number Cannot start with one.
	 * @param areaCode
	 * @return
	 */	
	private boolean validPhoneNumber(String phoneNumber)
	{
		if(phoneNumber.length()!=CustomerMasterConstants.PHONE_NUMBER_LENGTH)
	    	return false;
	    else if(!StringUtils.isNumeric(phoneNumber))
	    	return false;
	    else if(phoneNumber.startsWith("1"))
	    	return false;
		return true;
	}	
	//start for Address Validation
	/**
	 * This Function will Validate Address .
	 * It will remove certain characters or strings from 
	 * address line1 and line2.
	 * @param customerMasterAddAttr
	 * @return void
	 */	
	private void validateAddress(CustomerMasterAddressAttr customerMasterAddAttr) {

		if (null != customerMasterAddAttr.getStreetLine1()) {
			customerMasterAddAttr.setStreetLine1(customerMasterAddAttr.getStreetLine1().replaceAll(
					CustomerMasterConstants.ADDRESS_REMOVABLE_STRING,
					CustomerMasterConstants.BLANK_STRING));
		}
		if (null != customerMasterAddAttr.getStreetLine2()) {
			customerMasterAddAttr.setStreetLine2(customerMasterAddAttr.getStreetLine2().replaceAll(
					CustomerMasterConstants.ADDRESS_REMOVABLE_STRING,
					CustomerMasterConstants.BLANK_STRING));
		}

	}
	//end for Address Validation

}
