package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateRequest;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseUpdateResponse;

public interface ICustomerMasterEntUpdateServiceV2 {
/**
 * This service is an interface for exposing  updateCustomerMasterEnterprise method at service level.
 * @param enterpriseUpdateRequest
 * @return
 * @throws CDIException
 */
	public CustomerMasterEnterpriseUpdateResponse updateCustomerMasterEnterprise(
			CustomerMasterEnterpriseUpdateRequest enterpriseUpdateRequest)
			throws CDIException;

}
