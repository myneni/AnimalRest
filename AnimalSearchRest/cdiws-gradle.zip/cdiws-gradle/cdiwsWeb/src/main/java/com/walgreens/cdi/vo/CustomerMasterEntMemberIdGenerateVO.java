package com.walgreens.cdi.vo;

public class CustomerMasterEntMemberIdGenerateVO {

	private String progCode;

	public String getProgCode() {
		return progCode;
	}

	public void setProgCode(String progCode) {
		this.progCode = progCode;
	}

}
