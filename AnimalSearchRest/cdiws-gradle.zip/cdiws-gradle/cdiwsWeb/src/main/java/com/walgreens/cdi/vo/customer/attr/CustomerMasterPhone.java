package com.walgreens.cdi.vo.customer.attr;

import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.*;

public class CustomerMasterPhone {
	private CustomerMasterPhoneAttr homePhone; // = new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_H);
	private CustomerMasterPhoneAttr cellPhone;// = new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_C);
	private CustomerMasterPhoneAttr workPhone; //= new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_W);
	private CustomerMasterPhoneAttr secPhone; //= new CustomerMasterPhoneAttr(CustomerMasterConstants.CM_PHONE_TYPE_S);
	
	/**
	 * @return the cellPhone
	 */
	public CustomerMasterPhoneAttr getCellPhone() {
		return cellPhone;
	}
	/**
	 * @param cellPhone the cellPhone to set
	 */
	public void setCellPhone(CustomerMasterPhoneAttr cellPhone) {
		this.cellPhone = cellPhone;
	}
	/**
	 * @return the homePhone
	 */
	public CustomerMasterPhoneAttr getHomePhone() {
		return homePhone;
	}
	/**
	 * @param homePhone the homePhone to set
	 */
	public void setHomePhone(CustomerMasterPhoneAttr homePhone) {
		this.homePhone = homePhone;
	}
	/**
	 * @return the workPhone
	 */
	public CustomerMasterPhoneAttr getWorkPhone() {
		return workPhone;
	}
	/**
	 * @param workPhone the workPhone to set
	 */
	public void setWorkPhone(CustomerMasterPhoneAttr workPhone) {
		this.workPhone = workPhone;
	}
	
	/**
	 * @return the secPhone
	 */
	public CustomerMasterPhoneAttr getSecPhone() {
		return secPhone;
	}
	/**
	 * @param secPhone the secPhone to set
	 */
	public void setSecPhone(CustomerMasterPhoneAttr secPhone) {
		this.secPhone = secPhone;
	}
	
	public String toString() {
		String str = "";
		String strTemp = "";
		if (homePhone != null)
		{
			strTemp = "\n HomePhone\n_________________________________\n" +
			homePhone.toString() ;
			str = str + strTemp;
		}
		if (cellPhone != null)
		{
			strTemp = "\n CellPhone\n_________________________________\n" +
			cellPhone.toString() ;
			str = str + strTemp;
		}
		if (workPhone != null)
		{
			strTemp = "\n WorkPhone\n_________________________________\n" +
			workPhone.toString() ;
			str = str + strTemp;
		}
	
		return str;
	}
	
	public String toCompString() {
		String str="";
		
		String strTemp = CustomerMasterConstants.DELIMITE_ATTR
		   + CustomerMasterConstants.COMP_ATTR_NAME_PHONE;
		if (homePhone != null)
		{
			strTemp = 	homePhone.toCompString() ;
			str = str + strTemp;
		}
		if (cellPhone != null)
		{
			strTemp = cellPhone.toCompString() ;
			str = str + strTemp;
		}
		if (workPhone != null)
		{
			strTemp = workPhone.toCompString() ;
			str = str + strTemp;
		}
	
		return str;
	
		
	}
	
}
