/**
 * 
 */
package com.walgreens.cdi.vo.customer.attr;

import java.util.ArrayList;

/**
 * @author Picketta
 *
 */
public class CustomerMasterRefEIDLinkage {
	//	 (Linkage of CustRefEID to Cust Source Records)		
	private ArrayList linkageCustRefEIDCustSource;		//Array (1/n)	Linkage array, with occurrences for every active linkage
	private String custRefEID	;								//String (1/1)	Enterprise ID for the requested customer. 
	private String custRefSourceCode;							
	private String custRefSourceID;							//String (1/1)	Source Identifier for a record which is linked to the requested customer, e.g. Patient ID.
	public String getCustRefEID() {
		return custRefEID;
	}
	public void setCustRefEID(String custRefEID) {
		this.custRefEID = custRefEID;
	}
	public String getCustRefSourceCode() {
		return custRefSourceCode;
	}
	public void setCustRefSourceCode(String custRefSourceCode) {
		this.custRefSourceCode = custRefSourceCode;
	}
	public String getCustRefSourceID() {
		return custRefSourceID;
	}
	public void setCustRefSourceID(String custRefSourceID) {
		this.custRefSourceID = custRefSourceID;
	}
	public ArrayList getLinkageCustRefEIDCustSource() {
		return linkageCustRefEIDCustSource;
	}
	public void setLinkageCustRefEIDCustSource(ArrayList linkageCustRefEIDCustSource) {
		this.linkageCustRefEIDCustSource = linkageCustRefEIDCustSource;
	}
	

	
}
