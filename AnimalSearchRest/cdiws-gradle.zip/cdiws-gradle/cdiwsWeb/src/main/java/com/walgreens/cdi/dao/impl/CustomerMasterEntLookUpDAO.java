package com.walgreens.cdi.dao.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.sql.DataSource;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import walgreens.services.LoggingFacility;
import walgreens.utils.logging.WalgreensLog4JImpl;
import com.walgreens.cdi.dao.ICustomerMasterEntLookUpDAO;
import com.walgreens.cdi.vo.CustomerMasterLinkageVO;
import com.walgreens.cdi.vo.customer.CustomerMasterEntSearch;

public class CustomerMasterEntLookUpDAO implements ICustomerMasterEntLookUpDAO {

	private JdbcTemplate jdbcTemplate;

	private JdbcTemplate jdbcTemplateRef;

	public void setDataSource(DataSource datasource) {
		jdbcTemplate = new JdbcTemplate(datasource);
		jdbcTemplate.setFetchSize(50);
	}

	public void setDataSourceRef(DataSource datasource) {
		jdbcTemplateRef = new JdbcTemplate(datasource);
		jdbcTemplateRef.setFetchSize(50);
	}

	public List<CustomerMasterEntSearch> getCdiCompViewAllSrc(Set eidSet) {

		List<CustomerMasterEntSearch> list = null;
		String entRecNo = "";
		Iterator itr = eidSet.iterator();
		int i = 0;
		while (itr.hasNext()) {
			if (i == 0) {
				entRecNo = entRecNo + itr.next();
			} else {
				entRecNo = entRecNo + "," + itr.next();
			}

			i++;
		}
		try {

			String sql = "select * from CDI_EMCA_CV_ALL_SRC where ENTITYID in ("
					+ entRecNo + ")";

			long st = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);

			list = this.jdbcTemplate.query(sql,
					new CustomerMasterEntLookUpRowsMapper(sql, st));

			long et = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"Time taken:" + (et - st) + ":" + sql);

		} catch (DataAccessException we) {
			String msg = "Error while getting value from CDI_EMCA_CV_ALL_SRC table with ENTITYID:"
					+ entRecNo;
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());

		}

		return list;

	}

	public List<CustomerMasterLinkageVO> getCdiLinkageAllSrc(Set eidSet) {

		List<CustomerMasterLinkageVO> linkageMap = null;
		String entRecNo = "";
		Iterator itr = eidSet.iterator();
		int i = 0;
		while (itr.hasNext()) {
			if (i == 0) {
				entRecNo = entRecNo + itr.next();
			} else {
				entRecNo = entRecNo + "," + itr.next();
			}

			i++;
		}
		try {
			String sql = "select * from CDI_LINKAGE_CV_ALL_SRC where ENTITYID in ("
					+ entRecNo + ")";
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);
			linkageMap = this.jdbcTemplate.query(sql,
					new CustomerMasterLinkageRowsMapper());

		} catch (DataAccessException we) {
			String msg = "Error while getting value from cdi_linkage_cv_id table with MEMRECNO:"
					+ entRecNo;
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());
			//e.printStackTrace();
		}
		return linkageMap;

	}

	public List<CustomerMasterEntSearch> getLoyaltyMemCompView(String srcCode,
			String srcId) {

		List<CustomerMasterEntSearch> loyaltymMemCv = null;

		try {

			String sql = "select * from CDI_MMCA_CV_MEMBER where SRCCODE='"
					+ srcCode + "' and SRCID='" + srcId + "'";

			long st = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);

			loyaltymMemCv = this.jdbcTemplate.query(sql,
					new CustomerMasterLoyaltyMemRowsMapper(sql, st));

			long et = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"Time taken:" + (et - st) + ":" + sql);

		} catch (DataAccessException we) {
			String msg = "Error while getting value from CDI_MMCA_CV_MEMBER table ";

			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());

		}

		return loyaltymMemCv;

	}

	public List<Map<String, Object>> getAllProgramsAndAttr(String srcCode,
			String srcId) {

		List<Map<String, Object>> resultSet = null;

		try {

			String sql = "select * from CDI_PRGM_CV_MEMBER where SRCCODE='"
					+ srcCode + "' and SRCID='" + srcId + "'";
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);
			resultSet = this.jdbcTemplate.queryForList(sql);

		} catch (DataAccessException we) {
			String msg = "Error while getting value from CDI_PRGM_CV_LOYALTY table:   ";
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());
			//e.printStackTrace();
		}
		return resultSet;

	}

	public List<CustomerMasterEntSearch> getRefCompViewAllSrc(String srcCode, String srcId) {

		List<CustomerMasterEntSearch> list = null;
		
		try {

			String sql = "select * from REF_MEM_DEMO_ID where SRCCODE='"
					+ srcCode + "' and PRSNSEQNO='" + srcId + "'";
			
			long st = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);

			list = this.jdbcTemplateRef.query(sql,
					new CustomerMasterEntRefMemRowsMapper(sql, st));

			long et = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"Time taken:" + (et - st) + ":" + sql);

		} catch (DataAccessException we) {
			String msg = "Error while getting value from REF_MEM_DEMO_ID table :";
					
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());

		}

		return list;

	}



	/**
	 * Referring to the WalgreensLog4JImpl
	 */
	private WalgreensLog4JImpl walgreensLogger;

	/**
	 * @return the walgreensLogger
	 */
	public WalgreensLog4JImpl getWalgreensLogger() {
		return walgreensLogger;
	}

	/**
	 * @param walgreensLogger
	 *            the walgreensLogger to set
	 */
	public void setWalgreensLogger(WalgreensLog4JImpl walgreensLogger) {
		this.walgreensLogger = walgreensLogger;
	}

}
