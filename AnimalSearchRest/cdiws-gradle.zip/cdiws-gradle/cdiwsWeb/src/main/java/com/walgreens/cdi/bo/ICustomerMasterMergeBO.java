package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterMergeRequest;

public interface ICustomerMasterMergeBO {
	
	public boolean mergeCustomerMaster(CustomerMasterMergeRequest customerMasterMergeRequest) throws SystemException, BusinessRuleViolationException;

	public void validateRequestObject(CustomerMasterMergeRequest customerMasterMergeRequest) throws BusinessRuleViolationException;

}
