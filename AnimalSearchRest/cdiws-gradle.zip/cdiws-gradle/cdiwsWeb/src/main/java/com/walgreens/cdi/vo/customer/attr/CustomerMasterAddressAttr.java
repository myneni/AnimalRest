package com.walgreens.cdi.vo.customer.attr;

import com.walgreens.cdi.util.CustomerMasterConstants;

public class CustomerMasterAddressAttr extends CustomerMasterAddressAttrBase {

	/**
	 * 
	 */
	public CustomerMasterAddressAttr() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerMasterAddressAttr(String addressUsageType) {
		super(addressUsageType);
	}
	
	private String country;						//String (0/1)	AllSource Home2 Country.
	private String USPSAddressType;				//String (0/1)	AllSource Home2 USPS Address Type.
	private String DPVFootnote;					//String (0/1)	AllSource Home2 DPV Footnote.
	private String DPVIndicator;				//String (0/1)	AllSource Home2 DPV Indicator.
	private String CASSFootnote;				//String (0/1)	AllSource Home2 CASS Footnote.
	private String Latitude;					//String (0/1)	AllSource Home2 Latitude,
	private String Longitude;					//String (0/1)	AllSource Home2 Longitude.
	private String standardizationProcessDate;	//String (0/1)	AllSource Home2 Address Standardization Process Date.
	private String urbanizationCode;			//String (0/1)	AllSource Home2 Urbanization Code.
	private String LACSAddressFlag;				//String (0/1)	AllSource Home2 LACS Address Flag.
	private String LACSFootnote;				//String (0/1)	AllSource Home2 LACS Footnote.
	private String LACSReturnCode;				//String (0/1)	AllSource Home2 LACS Return Code,
	/**
	 * @return the cASSFootnote
	 */
	public String getCASSFootnote() {
		return CASSFootnote;
	}
	/**
	 * @param footnote the cASSFootnote to set
	 */
	public void setCASSFootnote(String footnote) {
		CASSFootnote = footnote;
	}
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return the dPVFootnote
	 */
	public String getDPVFootnote() {
		return DPVFootnote;
	}
	/**
	 * @param footnote the dPVFootnote to set
	 */
	public void setDPVFootnote(String footnote) {
		DPVFootnote = footnote;
	}
	/**
	 * @return the dPVIndicator
	 */
	public String getDPVIndicator() {
		return DPVIndicator;
	}
	/**
	 * @param indicator the dPVIndicator to set
	 */
	public void setDPVIndicator(String indicator) {
		DPVIndicator = indicator;
	}
	/**
	 * @return the lACSAddressFlag
	 */
	public String getLACSAddressFlag() {
		return LACSAddressFlag;
	}
	/**
	 * @param addressFlag the lACSAddressFlag to set
	 */
	public void setLACSAddressFlag(String addressFlag) {
		LACSAddressFlag = addressFlag;
	}
	/**
	 * @return the lACSFootnote
	 */
	public String getLACSFootnote() {
		return LACSFootnote;
	}
	/**
	 * @param footnote the lACSFootnote to set
	 */
	public void setLACSFootnote(String footnote) {
		LACSFootnote = footnote;
	}
	/**
	 * @return the lACSReturnCode
	 */
	public String getLACSReturnCode() {
		return LACSReturnCode;
	}
	/**
	 * @param returnCode the lACSReturnCode to set
	 */
	public void setLACSReturnCode(String returnCode) {
		LACSReturnCode = returnCode;
	}
	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return Latitude;
	}
	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(String latitude) {
		Latitude = latitude;
	}
	/**
	 * @return the longitude
	 */
	public String getLongitude() {
		return Longitude;
	}
	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(String longitude) {
		Longitude = longitude;
	}
	/**
	 * @return the standardizationProcessDate
	 */
	public String getStandardizationProcessDate() {
		return standardizationProcessDate;
	}
	/**
	 * @param standardizationProcessDate the standardizationProcessDate to set
	 */
	public void setStandardizationProcessDate(String standardizationProcessDate) {
		this.standardizationProcessDate = standardizationProcessDate;
	}
	/**
	 * @return the urbanizationCode
	 */
	public String getUrbanizationCode() {
		return urbanizationCode;
	}
	/**
	 * @param urbanizationCode the urbanizationCode to set
	 */
	public void setUrbanizationCode(String urbanizationCode) {
		this.urbanizationCode = urbanizationCode;
	}
	/**
	 * @return the uSPSAddressType
	 */
	public String getUSPSAddressType() {
		return USPSAddressType;
	}
	/**
	 * @param addressType the uSPSAddressType to set
	 */
	public void setUSPSAddressType(String addressType) {
		USPSAddressType = addressType;
	}
	
	public String toString() {
	String str = "";
		
	str = " AddressUsageType    =" + 	getAddressUsageType()  	+"\n" +	
		  " strLine1            =" +	getStreetLine1() 		+"\n" +	
	      " strLine2            =" +	getStreetLine2()		+"\n" +	
	      " City                =" +	getCity() 				+"\n" +	
	      " State               =" +	getState() 				+"\n" +	
	      " Zip                 =" +	getZipCode() 				+"\n" +	
	      " Country             =" +	getCountry() 			+"\n" +	
		  " CASSFootnote       	=" + 	getCASSFootnote() 		+"\n" +
	      " country             =" + 	getCountry() 			+"\n" +
	      " USPSAddressType    	=" +    getUSPSAddressType()	+"\n" +
	      " DPVFootnote         =" + 	getDPVFootnote() 		+"\n" +	
	      " DPVIndicator        =" + 	getDPVIndicator() 		+"\n" +	
		  " Latitude            =" +	getLatitude() 			+"\n" +	
		  " Longitude           =" + 	getLongitude() 			+"\n" +	
		  " standardizationProcessDate= " + getStandardizationProcessDate() +"\n" +	
		  " urbanizationCode    =" + 	getUrbanizationCode() 	+"\n" +	
		  " LACSAddressFlag    	=" + 	getLACSAddressFlag() 	+"\n" +	
		  " LACSFootnote        =" + 	getLACSFootnote() 		+"\n" +	
		  " LACSReturnCode      =" + 	getLACSReturnCode()		+"\n" +	
		  " DPVIndicator        = "+ 	getDPVIndicator() 		+"\n"  +
		  " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
		  " securityClassCode   =" + getSecurityClassCode() + "\n" +
		  " sourceCode   =" + getSourceCode() + "\n" ;;
	
		
		return str;
	}
	
	public String toCompString() {
		String str="";
		 str = CustomerMasterConstants.DELIMITE_FIELD +
		       	getAddressUsageType()  	+CustomerMasterConstants.DELIMITE_FIELD +	
		        getStreetLine1() 		+CustomerMasterConstants.DELIMITE_FIELD +	
	         	getStreetLine2()		+CustomerMasterConstants.DELIMITE_FIELD +	
	         							CustomerMasterConstants.DELIMITE_FIELD +	
	         						    CustomerMasterConstants.DELIMITE_FIELD +	
	          	getCity() 				+CustomerMasterConstants.DELIMITE_FIELD +	
	         	getZipCode()			+CustomerMasterConstants.DELIMITE_FIELD +	
	         	getState() 				+CustomerMasterConstants.DELIMITE_FIELD +	
	        	getCountry() 			+CustomerMasterConstants.DELIMITE_FIELD +	
		     	getCASSFootnote() 		+CustomerMasterConstants.DELIMITE_FIELD +
	          	getCountry() 			+CustomerMasterConstants.DELIMITE_FIELD +
	         	getUSPSAddressType()	+CustomerMasterConstants.DELIMITE_FIELD +
	            getDPVFootnote() 		+CustomerMasterConstants.DELIMITE_FIELD +	
	        	getDPVIndicator() 		+CustomerMasterConstants.DELIMITE_FIELD +	
		        getStandardizationProcessDate() +CustomerMasterConstants.DELIMITE_FIELD +	
		    	getUrbanizationCode() 	+CustomerMasterConstants.DELIMITE_FIELD +	
		     	getLongitude() 			+CustomerMasterConstants.DELIMITE_FIELD +	
			   	getLatitude() 			+CustomerMasterConstants.DELIMITE_FIELD +	
		       	getLACSAddressFlag() 	+CustomerMasterConstants.DELIMITE_FIELD +	
		    	getLACSFootnote() 		+CustomerMasterConstants.DELIMITE_FIELD +	
		    	getLACSReturnCode()		+CustomerMasterConstants.DELIMITE_FIELD +	
		    	getDPVIndicator() 		+CustomerMasterConstants.DELIMITE_FIELD +
		    	  							CustomerMasterConstants.DELIMITE_FIELD +	
		    	  							CustomerMasterConstants.DELIMITE_FIELD +	
		    	  							CustomerMasterConstants.DELIMITE_FIELD +	
		    	  							CustomerMasterConstants.DELIMITE_FIELD +	
		    	  							CustomerMasterConstants.DELIMITE_FIELD +	
		    	  							CustomerMasterConstants.DELIMITE_FIELD +
		    	  							CustomerMasterConstants.DELIMITE_FIELD +	
			    getSourceCode() + CustomerMasterConstants.DELIMITE_FIELD +
			    getSecurityClassCode() + CustomerMasterConstants.DELIMITE_FIELD +
			    getLastUpdateDate() + CustomerMasterConstants.DELIMITE_FIELD;
	     
	
         return str;
	}
	
	public boolean isNull(){
		
		if(isNull(getStreetLine1())&&		
				isNull(getStreetLine2())&&		
				isNull(getCity())&&	 			
				isNull(getState())&&	
				isNull(getZipCode())&&			
				isNull(getCountry() )&&			
				isNull(getCASSFootnote())&&			
				isNull(getCountry())&&			
		        isNull(getUSPSAddressType())&&	
		        isNull(getDPVFootnote())&&			
		        isNull(getDPVIndicator())&&		
		        isNull(getLatitude())&&				
		        isNull(getLongitude())&&				
		        isNull(getStandardizationProcessDate())&&	
		        isNull(getUrbanizationCode())&&	
		        isNull(getLACSAddressFlag())&&		
		        isNull(getLACSFootnote())&&	
		        isNull(getLACSReturnCode())&&	
		        isNull(getDPVIndicator()))
					     
				return true;
		else
			return false;
	}
	
	// Added for lookup enterprise service.
	public boolean isNullEnterpriseLookup(){
		
		if(isNull(getStreetLine1() )&&		
				isNull(getStreetLine2())&&		
					isNull(getCity())&&	 			
					isNull(getState())&&				
					isNull(getZipCode())			
					)	   
		{					     
				return true;
		}
		else
			return false;
	}
		
		 private boolean isNull(String str){
			   if(str==null)
				   return true;
				if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
					return true;
				else
					return false;
			}

}
