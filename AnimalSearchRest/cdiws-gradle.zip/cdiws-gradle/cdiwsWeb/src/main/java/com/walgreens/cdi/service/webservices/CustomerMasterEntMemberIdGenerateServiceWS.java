/*
 * This is an auto-generated class for the service object. Please do not modify this class.
*/
package com.walgreens.cdi.service.webservices;

import javax.jws.WebResult;
import javax.jws.WebService;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.CDIExceptionFault;
import com.walgreens.cdi.exception.CDIException_Exception;
//As a part of WAS Migration Changes are in the new parameters addition for the @WebService tag, the new @SoapBinding tag, 
//and  replacing the @WebResult tag in the called methods with @WebMethod tags.
@WebService (targetNamespace="http://webservices.service.cdi.walgreens.com/", 
serviceName="CustomerMasterEntMemberIdGenerateServiceWSService", 
portName="CustomerMasterEntMemberIdGenerateServiceWSPort", 
wsdlLocation="WEB-INF/WSDL/CustomerMasterEntMemberIdGenerateServiceWSService.wsdl")
@javax.jws.soap.SOAPBinding(style = javax.jws.soap.SOAPBinding.Style.DOCUMENT)
@javax.jws.HandlerChain(file="/WSHandlerChain.xml")
public class CustomerMasterEntMemberIdGenerateServiceWS{
    private com.walgreens.cdi.service.impl.CustomerMasterEntMemberIdGenerateService _service = null;

    @javax.jws.WebMethod(exclude=true)
    private com.walgreens.cdi.service.impl.CustomerMasterEntMemberIdGenerateService getService() {
             _service = (com.walgreens.cdi.service.impl.CustomerMasterEntMemberIdGenerateService)walgreens.utils.ioc.BeanFactoryUtil.getFactory().getBean("customerMasterEntMemberIdGenerateService");
        return _service;
    }

    @WebResult(name = "generateCustomerEntMemberIdResponse", targetNamespace = "")	
    public @javax.jws.WebMethod com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateResponse generateCustomerEntMemberId(com.walgreens.cdi.vo.CustomerMasterEntMemberIdGenerateRequest arg0) throws com.walgreens.cdi.exception.CDIException_Exception{
        try{
    	return getService().generateCustomerEntMemberId( arg0);
        }catch (CDIException e) {
    		CDIExceptionFault fault = new CDIExceptionFault();
			fault.setErrorCode(e.getErrorCode());
			fault.setDetailMessage(e.getDetailMessage());
			
			fault.setMsg(e.getMsg());
			throw new CDIException_Exception(e.getMessage(), fault);
    	}
    }
}
