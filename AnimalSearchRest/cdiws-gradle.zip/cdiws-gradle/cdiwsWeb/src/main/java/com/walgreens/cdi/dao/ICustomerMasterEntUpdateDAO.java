package com.walgreens.cdi.dao;

public interface ICustomerMasterEntUpdateDAO {
	
	//public String generateDynamicVirtualCardNumber();
	
	public String getLoyaltySequencNumber();

}
