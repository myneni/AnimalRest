package com.walgreens.cdi.vo;

import java.util.ArrayList;

/**
 * This class would contain all the attributes required to update member and get
 * the response back
 * 
 * @author psrivakf
 * 
 */
public class CustomerMasterEnterpriseUpdateRequest {

	private String srcCode;
	private String srcIdNum;
	private String nameFirst;
	private String nameLast;
	private String nameMiddle;
	private String namePrefix;
	private String nameSuffix;
	private String gender;
	private String petInd;
	private String deceasedInd;
	private String secCode;
	private String email;
	private String ecicMemId;
	private String pcecMemId;
	private String lockInd;
	private String bDate;
	private String origin;
	private String originStoreInd;
	private String hohId;
	private String hohRelateCode;
	private String addrStLine1;
	private String addrStLine2;
	private String addrCity;
	private String addrState;
	private String addrZip;
	private String addrCountry;
	private String addrType;
	private String addrDpvFtNote;
	private String addrDpvInd;
	private String addrCassFtNote;
	private String addrLatitude;
	private String addrLongitude;
	private String addrStndrdPrDate;
	private String addrUrbCode;
	private String addrLacsFlag;
	private String addrLacsFtnote;
	private String addrLacsRtrnCode;
	private String addrNcoaStLine1;
	private String addrNcoaStLine2;
	private String addrNcoaCity;
	private String addrNcoaState;
	private String addrNcoaZip;
	private String addrNcoaType;
	private String addrNcoaActCode;
	private String addrNcoaAnkCode;
	private String addrNcoaMvDate;
	private String addrNcoaMvType;
	private String addrNcoaNewFlag;
	private String addrNcoaNixFtNote;
	private String addrNcoaRtrnCode;
	private String addrNcoaPrDate;
	private String addrNcoaUrbCode;

	private String addr2StLine1;
	private String addr2StLine2;
	private String addr2City;
	private String addr2State;
	private String addr2Zip;
	private String addr2Country;
	private String addr2Type;
	private String addr2DpvFtNote;
	private String addr2DpvInd;
	private String addr2CassFtNote;
	private String addr2Latitude;
	private String addr2Longitude;
	private String addr2StndrdPrDate;
	private String addr2UrbCode;
	private String addr2LacsFlag;
	private String addr2LacsFtnote;
	private String addr2LacsRtrnCode;

	private String addrWkStLine1;
	private String addrWkStLineWk;
	private String addrWkCity;
	private String addrWkState;
	private String addrWkZip;
	private String addrWkCountry;
	private String addrWkType;
	private String addrWkDpvFtNote;
	private String addrWkDpvInd;
	private String addrWkCassFtNote;
	private String addrWkLatitude;
	private String addrWkLongitude;
	private String addrWkStndrdPrDate;
	private String addrWkUrbCode;
	private String addrWkLacsFlag;
	private String addrWkLacsFtnote;
	private String addrWkLacsRtrnCode;

	private String phoneArea;
	private String phoneNumber;
	private String phonePriority;

	private String phone2Area;
	private String phone2Number;
	private String phone2Priority;

	private String phoneWkArea;
	private String phoneWkNumber;
	private String phoneWkPriority;

	private String lastUpdateDate;

	private ArrayList<CustomerMasterEnterpriseAttributesVO> custArrayOfAttributes = new ArrayList<CustomerMasterEnterpriseAttributesVO>();
	private ArrayList<CustomerMasterEnterpriseProgramVO> custProgIdArray = new ArrayList<CustomerMasterEnterpriseProgramVO>();
	private ArrayList<CustomerMasterEnterpriseProgramActionVO> custProgActionArray = new ArrayList<CustomerMasterEnterpriseProgramActionVO>();

	private String cvControl;

	public String getCvControl() {
		return cvControl;
	}

	public void setCvControl(String cvControl) {
		this.cvControl = cvControl;
	}

	// Code change ENd start for ECOMM Validation changes

	/**
	 * @return the addr2City
	 */
	public String getAddr2City() {
		return addr2City;
	}

	/**
	 * @param addr2City
	 *            the addr2City to set
	 */
	public void setAddr2City(String addr2City) {
		this.addr2City = addr2City;
	}

	/**
	 * @return the addr2Country
	 */
	public String getAddr2Country() {
		return addr2Country;
	}

	/**
	 * @param addr2Country
	 *            the addr2Country to set
	 */
	public void setAddr2Country(String addr2Country) {
		this.addr2Country = addr2Country;
	}

	/**
	 * @return the addr2DpvFtNote
	 */
	public String getAddr2DpvFtNote() {
		return addr2DpvFtNote;
	}

	/**
	 * @param addr2DpvFtNote
	 *            the addr2DpvFtNote to set
	 */
	public void setAddr2DpvFtNote(String addr2DpvFtNote) {
		this.addr2DpvFtNote = addr2DpvFtNote;
	}

	/**
	 * @return the addr2DpvInd
	 */
	public String getAddr2DpvInd() {
		return addr2DpvInd;
	}

	/**
	 * @param addr2DpvInd
	 *            the addr2DpvInd to set
	 */
	public void setAddr2DpvInd(String addr2DpvInd) {
		this.addr2DpvInd = addr2DpvInd;
	}

	/**
	 * @return the addr2CassFtNote
	 */
	public String getAddr2CassFtNote() {
		return addr2CassFtNote;
	}

	/**
	 * @param addr2CassFtNote
	 *            the addr2CassFtNote to set
	 */
	public void setAddr2CassFtNote(String addr2FtNote) {
		this.addr2CassFtNote = addr2FtNote;
	}

	/**
	 * @return the addr2LacsFlag
	 */
	public String getAddr2LacsFlag() {
		return addr2LacsFlag;
	}

	/**
	 * @param addr2LacsFlag
	 *            the addr2LacsFlag to set
	 */
	public void setAddr2LacsFlag(String addr2LacsFlag) {
		this.addr2LacsFlag = addr2LacsFlag;
	}

	/**
	 * @return the addr2LacsFtnote
	 */
	public String getAddr2LacsFtnote() {
		return addr2LacsFtnote;
	}

	/**
	 * @param addr2LacsFtnote
	 *            the addr2LacsFtnote to set
	 */
	public void setAddr2LacsFtnote(String addr2LacsFtnote) {
		this.addr2LacsFtnote = addr2LacsFtnote;
	}

	/**
	 * @return the addr2LacsRtrnCode
	 */
	public String getAddr2LacsRtrnCode() {
		return addr2LacsRtrnCode;
	}

	/**
	 * @param addr2LacsRtrnCode
	 *            the addr2LacsRtrnCode to set
	 */
	public void setAddr2LacsRtrnCode(String addr2LacsRtrnCode) {
		this.addr2LacsRtrnCode = addr2LacsRtrnCode;
	}

	/**
	 * @return the addr2Latitude
	 */
	public String getAddr2Latitude() {
		return addr2Latitude;
	}

	/**
	 * @param addr2Latitude
	 *            the addr2Latitude to set
	 */
	public void setAddr2Latitude(String addr2Latitude) {
		this.addr2Latitude = addr2Latitude;
	}

	/**
	 * @return the addr2Longitude
	 */
	public String getAddr2Longitude() {
		return addr2Longitude;
	}

	/**
	 * @param addr2Longitude
	 *            the addr2Longitude to set
	 */
	public void setAddr2Longitude(String addr2Longitude) {
		this.addr2Longitude = addr2Longitude;
	}

	/**
	 * @return the addr2StndrdPrDate
	 */
	public String getAddr2StndrdPrDate() {
		return addr2StndrdPrDate;
	}

	/**
	 * @param addr2StndrdPrDate
	 *            the addr2StndrdPrDate to set
	 */
	public void setAddr2StndrdPrDate(String addr2PrDate) {
		this.addr2StndrdPrDate = addr2PrDate;
	}

	/**
	 * @return the addr2State
	 */
	public String getAddr2State() {
		return addr2State;
	}

	/**
	 * @param addr2State
	 *            the addr2State to set
	 */
	public void setAddr2State(String addr2State) {
		this.addr2State = addr2State;
	}

	/**
	 * @return the addr2StLine1
	 */
	public String getAddr2StLine1() {
		return addr2StLine1;
	}

	/**
	 * @param addr2StLine1
	 *            the addr2StLine1 to set
	 */
	public void setAddr2StLine1(String addr2StLine1) {
		this.addr2StLine1 = addr2StLine1;
	}

	/**
	 * @return the addr2StLine2
	 */
	public String getAddr2StLine2() {
		return addr2StLine2;
	}

	/**
	 * @param addr2StLine2
	 *            the addr2StLine2 to set
	 */
	public void setAddr2StLine2(String addr2StLine2) {
		this.addr2StLine2 = addr2StLine2;
	}

	/**
	 * @return the addr2Type
	 */
	public String getAddr2Type() {
		return addr2Type;
	}

	/**
	 * @param addr2Type
	 *            the addr2Type to set
	 */
	public void setAddr2Type(String addr2Type) {
		this.addr2Type = addr2Type;
	}

	/**
	 * @return the addr2UrbCode
	 */
	public String getAddr2UrbCode() {
		return addr2UrbCode;
	}

	/**
	 * @param addr2UrbCode
	 *            the addr2UrbCode to set
	 */
	public void setAddr2UrbCode(String addr2UrbCode) {
		this.addr2UrbCode = addr2UrbCode;
	}

	/**
	 * @return the addr2Zip
	 */
	public String getAddr2Zip() {
		return addr2Zip;
	}

	/**
	 * @param addr2Zip
	 *            the addr2Zip to set
	 */
	public void setAddr2Zip(String addr2Zip) {
		this.addr2Zip = addr2Zip;
	}

	/**
	 * @return the addrCity
	 */
	public String getAddrCity() {
		return addrCity;
	}

	/**
	 * @param addrCity
	 *            the addrCity to set
	 */
	public void setAddrCity(String addrCity) {
		this.addrCity = addrCity;
	}

	/**
	 * @return the addrCountry
	 */
	public String getAddrCountry() {
		return addrCountry;
	}

	/**
	 * @param addrCountry
	 *            the addrCountry to set
	 */
	public void setAddrCountry(String addrCountry) {
		this.addrCountry = addrCountry;
	}

	/**
	 * @return the addrDpvFtNote
	 */
	public String getAddrDpvFtNote() {
		return addrDpvFtNote;
	}

	/**
	 * @param addrDpvFtNote
	 *            the addrDpvFtNote to set
	 */
	public void setAddrDpvFtNote(String addrDpvFtNote) {
		this.addrDpvFtNote = addrDpvFtNote;
	}

	/**
	 * @return the addrDpvInd
	 */
	public String getAddrDpvInd() {
		return addrDpvInd;
	}

	/**
	 * @param addrDpvInd
	 *            the addrDpvInd to set
	 */
	public void setAddrDpvInd(String addrDpvInd) {
		this.addrDpvInd = addrDpvInd;
	}

	/**
	 * @return the addrCassFtNote
	 */
	public String getAddrCassFtNote() {
		return addrCassFtNote;
	}

	/**
	 * @param addrCassFtNote
	 *            the addrCassFtNote to set
	 */
	public void setAddrCassFtNote(String addrFtNote) {
		this.addrCassFtNote = addrFtNote;
	}

	/**
	 * @return the addrLacsFlag
	 */
	public String getAddrLacsFlag() {
		return addrLacsFlag;
	}

	/**
	 * @param addrLacsFlag
	 *            the addrLacsFlag to set
	 */
	public void setAddrLacsFlag(String addrLacsFlag) {
		this.addrLacsFlag = addrLacsFlag;
	}

	/**
	 * @return the addrLacsFtnote
	 */
	public String getAddrLacsFtnote() {
		return addrLacsFtnote;
	}

	/**
	 * @param addrLacsFtnote
	 *            the addrLacsFtnote to set
	 */
	public void setAddrLacsFtnote(String addrLacsFtnote) {
		this.addrLacsFtnote = addrLacsFtnote;
	}

	/**
	 * @return the addrLacsRtrnCode
	 */
	public String getAddrLacsRtrnCode() {
		return addrLacsRtrnCode;
	}

	/**
	 * @param addrLacsRtrnCode
	 *            the addrLacsRtrnCode to set
	 */
	public void setAddrLacsRtrnCode(String addrLacsRtrnCode) {
		this.addrLacsRtrnCode = addrLacsRtrnCode;
	}

	/**
	 * @return the addrLatitude
	 */
	public String getAddrLatitude() {
		return addrLatitude;
	}

	/**
	 * @param addrLatitude
	 *            the addrLatitude to set
	 */
	public void setAddrLatitude(String addrLatitude) {
		this.addrLatitude = addrLatitude;
	}

	/**
	 * @return the addrLongitude
	 */
	public String getAddrLongitude() {
		return addrLongitude;
	}

	/**
	 * @param addrLongitude
	 *            the addrLongitude to set
	 */
	public void setAddrLongitude(String addrLongitude) {
		this.addrLongitude = addrLongitude;
	}

	/**
	 * @return the addrNcoaActCode
	 */
	public String getAddrNcoaActCode() {
		return addrNcoaActCode;
	}

	/**
	 * @param addrNcoaActCode
	 *            the addrNcoaActCode to set
	 */
	public void setAddrNcoaActCode(String addrNcoaActCode) {
		this.addrNcoaActCode = addrNcoaActCode;
	}

	/**
	 * @return the addrNcoaAnkCode
	 */
	public String getAddrNcoaAnkCode() {
		return addrNcoaAnkCode;
	}

	/**
	 * @param addrNcoaAnkCode
	 *            the addrNcoaAnkCode to set
	 */
	public void setAddrNcoaAnkCode(String addrNcoaAnkCode) {
		this.addrNcoaAnkCode = addrNcoaAnkCode;
	}

	/**
	 * @return the addrNcoaCity
	 */
	public String getAddrNcoaCity() {
		return addrNcoaCity;
	}

	/**
	 * @param addrNcoaCity
	 *            the addrNcoaCity to set
	 */
	public void setAddrNcoaCity(String addrNcoaCity) {
		this.addrNcoaCity = addrNcoaCity;
	}

	/**
	 * @return the addrNcoaMvDate
	 */
	public String getAddrNcoaMvDate() {
		return addrNcoaMvDate;
	}

	/**
	 * @param addrNcoaMvDate
	 *            the addrNcoaMvDate to set
	 */
	public void setAddrNcoaMvDate(String addrNcoaMvDate) {
		this.addrNcoaMvDate = addrNcoaMvDate;
	}

	/**
	 * @return the addrNcoaMvType
	 */
	public String getAddrNcoaMvType() {
		return addrNcoaMvType;
	}

	/**
	 * @param addrNcoaMvType
	 *            the addrNcoaMvType to set
	 */
	public void setAddrNcoaMvType(String addrNcoaMvType) {
		this.addrNcoaMvType = addrNcoaMvType;
	}

	/**
	 * @return the addrNcoaNewFlag
	 */
	public String getAddrNcoaNewFlag() {
		return addrNcoaNewFlag;
	}

	/**
	 * @param addrNcoaNewFlag
	 *            the addrNcoaNewFlag to set
	 */
	public void setAddrNcoaNewFlag(String addrNcoaNewFlag) {
		this.addrNcoaNewFlag = addrNcoaNewFlag;
	}

	/**
	 * @return the addrNcoaNixFtNote
	 */
	public String getAddrNcoaNixFtNote() {
		return addrNcoaNixFtNote;
	}

	/**
	 * @param addrNcoaNixFtNote
	 *            the addrNcoaNixFtNote to set
	 */
	public void setAddrNcoaNixFtNote(String addrNcoaNixFtNote) {
		this.addrNcoaNixFtNote = addrNcoaNixFtNote;
	}

	/**
	 * @return the addrNcoaPrDate
	 */
	public String getAddrNcoaPrDate() {
		return addrNcoaPrDate;
	}

	/**
	 * @param addrNcoaPrDate
	 *            the addrNcoaPrDate to set
	 */
	public void setAddrNcoaPrDate(String addrNcoaPrDate) {
		this.addrNcoaPrDate = addrNcoaPrDate;
	}

	/**
	 * @return the addrNcoaRtrnCode
	 */
	public String getAddrNcoaRtrnCode() {
		return addrNcoaRtrnCode;
	}

	/**
	 * @param addrNcoaRtrnCode
	 *            the addrNcoaRtrnCode to set
	 */
	public void setAddrNcoaRtrnCode(String addrNcoaRtrnCode) {
		this.addrNcoaRtrnCode = addrNcoaRtrnCode;
	}

	/**
	 * @return the addrNcoaState
	 */
	public String getAddrNcoaState() {
		return addrNcoaState;
	}

	/**
	 * @param addrNcoaState
	 *            the addrNcoaState to set
	 */
	public void setAddrNcoaState(String addrNcoaState) {
		this.addrNcoaState = addrNcoaState;
	}

	/**
	 * @return the addrNcoaStLine1
	 */
	public String getAddrNcoaStLine1() {
		return addrNcoaStLine1;
	}

	/**
	 * @param addrNcoaStLine1
	 *            the addrNcoaStLine1 to set
	 */
	public void setAddrNcoaStLine1(String addrNcoaStLine1) {
		this.addrNcoaStLine1 = addrNcoaStLine1;
	}

	/**
	 * @return the addrNcoaStLine2
	 */
	public String getAddrNcoaStLine2() {
		return addrNcoaStLine2;
	}

	/**
	 * @param addrNcoaStLine2
	 *            the addrNcoaStLine2 to set
	 */
	public void setAddrNcoaStLine2(String addrNcoaStLine2) {
		this.addrNcoaStLine2 = addrNcoaStLine2;
	}

	/**
	 * @return the addrNcoaType
	 */
	public String getAddrNcoaType() {
		return addrNcoaType;
	}

	/**
	 * @param addrNcoaType
	 *            the addrNcoaType to set
	 */
	public void setAddrNcoaType(String addrNcoaType) {
		this.addrNcoaType = addrNcoaType;
	}

	/**
	 * @return the addrNcoaUrbCode
	 */
	public String getAddrNcoaUrbCode() {
		return addrNcoaUrbCode;
	}

	/**
	 * @param addrNcoaUrbCode
	 *            the addrNcoaUrbCode to set
	 */
	public void setAddrNcoaUrbCode(String addrNcoaUrbCode) {
		this.addrNcoaUrbCode = addrNcoaUrbCode;
	}

	/**
	 * @return the addrNcoaZip
	 */
	public String getAddrNcoaZip() {
		return addrNcoaZip;
	}

	/**
	 * @param addrNcoaZip
	 *            the addrNcoaZip to set
	 */
	public void setAddrNcoaZip(String addrNcoaZip) {
		this.addrNcoaZip = addrNcoaZip;
	}

	/**
	 * @return the addrStndrdPrDate
	 */
	public String getAddrStndrdPrDate() {
		return addrStndrdPrDate;
	}

	/**
	 * @param addrStndrdPrDate
	 *            the addrStndrdPrDate to set
	 */
	public void setAddrStndrdPrDate(String addrPrDate) {
		this.addrStndrdPrDate = addrPrDate;
	}

	/**
	 * @return the addrState
	 */
	public String getAddrState() {
		return addrState;
	}

	/**
	 * @param addrState
	 *            the addrState to set
	 */
	public void setAddrState(String addrState) {
		this.addrState = addrState;
	}

	/**
	 * @return the addrStLine1
	 */
	public String getAddrStLine1() {
		return addrStLine1;
	}

	/**
	 * @param addrStLine1
	 *            the addrStLine1 to set
	 */
	public void setAddrStLine1(String addrStLine1) {
		this.addrStLine1 = addrStLine1;
	}

	/**
	 * @return the addrStLine2
	 */
	public String getAddrStLine2() {
		return addrStLine2;
	}

	/**
	 * @param addrStLine2
	 *            the addrStLine2 to set
	 */
	public void setAddrStLine2(String addrStLine2) {
		this.addrStLine2 = addrStLine2;
	}

	/**
	 * @return the addrType
	 */
	public String getAddrType() {
		return addrType;
	}

	/**
	 * @param addrType
	 *            the addrType to set
	 */
	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}

	/**
	 * @return the addrUrbCode
	 */
	public String getAddrUrbCode() {
		return addrUrbCode;
	}

	/**
	 * @param addrUrbCode
	 *            the addrUrbCode to set
	 */
	public void setAddrUrbCode(String addrUrbCode) {
		this.addrUrbCode = addrUrbCode;
	}

	/**
	 * @return the addrWkCity
	 */
	public String getAddrWkCity() {
		return addrWkCity;
	}

	/**
	 * @param addrWkCity
	 *            the addrWkCity to set
	 */
	public void setAddrWkCity(String addrWkCity) {
		this.addrWkCity = addrWkCity;
	}

	/**
	 * @return the addrWkCountry
	 */
	public String getAddrWkCountry() {
		return addrWkCountry;
	}

	/**
	 * @param addrWkCountry
	 *            the addrWkCountry to set
	 */
	public void setAddrWkCountry(String addrWkCountry) {
		this.addrWkCountry = addrWkCountry;
	}

	/**
	 * @return the addrWkDpvFtNote
	 */
	public String getAddrWkDpvFtNote() {
		return addrWkDpvFtNote;
	}

	/**
	 * @param addrWkDpvFtNote
	 *            the addrWkDpvFtNote to set
	 */
	public void setAddrWkDpvFtNote(String addrWkDpvFtNote) {
		this.addrWkDpvFtNote = addrWkDpvFtNote;
	}

	/**
	 * @return the addrWkDpvInd
	 */
	public String getAddrWkDpvInd() {
		return addrWkDpvInd;
	}

	/**
	 * @param addrWkDpvInd
	 *            the addrWkDpvInd to set
	 */
	public void setAddrWkDpvInd(String addrWkDpvInd) {
		this.addrWkDpvInd = addrWkDpvInd;
	}

	/**
	 * @return the addrWkCassFtNote
	 */
	public String getAddrWkCassFtNote() {
		return addrWkCassFtNote;
	}

	/**
	 * @param addrWkCassFtNote
	 *            the addrWkCassFtNote to set
	 */
	public void setAddrWkCassFtNote(String addrWkFtNote) {
		this.addrWkCassFtNote = addrWkFtNote;
	}

	/**
	 * @return the addrWkLacsFlag
	 */
	public String getAddrWkLacsFlag() {
		return addrWkLacsFlag;
	}

	/**
	 * @param addrWkLacsFlag
	 *            the addrWkLacsFlag to set
	 */
	public void setAddrWkLacsFlag(String addrWkLacsFlag) {
		this.addrWkLacsFlag = addrWkLacsFlag;
	}

	/**
	 * @return the addrWkLacsFtnote
	 */
	public String getAddrWkLacsFtnote() {
		return addrWkLacsFtnote;
	}

	/**
	 * @param addrWkLacsFtnote
	 *            the addrWkLacsFtnote to set
	 */
	public void setAddrWkLacsFtnote(String addrWkLacsFtnote) {
		this.addrWkLacsFtnote = addrWkLacsFtnote;
	}

	/**
	 * @return the addrWkLacsRtrnCode
	 */
	public String getAddrWkLacsRtrnCode() {
		return addrWkLacsRtrnCode;
	}

	/**
	 * @param addrWkLacsRtrnCode
	 *            the addrWkLacsRtrnCode to set
	 */
	public void setAddrWkLacsRtrnCode(String addrWkLacsRtrnCode) {
		this.addrWkLacsRtrnCode = addrWkLacsRtrnCode;
	}

	/**
	 * @return the addrWkLatitude
	 */
	public String getAddrWkLatitude() {
		return addrWkLatitude;
	}

	/**
	 * @param addrWkLatitude
	 *            the addrWkLatitude to set
	 */
	public void setAddrWkLatitude(String addrWkLatitude) {
		this.addrWkLatitude = addrWkLatitude;
	}

	/**
	 * @return the addrWkLongitude
	 */
	public String getAddrWkLongitude() {
		return addrWkLongitude;
	}

	/**
	 * @param addrWkLongitude
	 *            the addrWkLongitude to set
	 */
	public void setAddrWkLongitude(String addrWkLongitude) {
		this.addrWkLongitude = addrWkLongitude;
	}

	/**
	 * @return the addrWkStndrdPrDate
	 */
	public String getAddrWkStndrdPrDate() {
		return addrWkStndrdPrDate;
	}

	/**
	 * @param addrWkStndrdPrDate
	 *            the addrWkStndrdPrDate to set
	 */
	public void setAddrWkStndrdPrDate(String addrWkPrDate) {
		this.addrWkStndrdPrDate = addrWkPrDate;
	}

	/**
	 * @return the addrWkState
	 */
	public String getAddrWkState() {
		return addrWkState;
	}

	/**
	 * @param addrWkState
	 *            the addrWkState to set
	 */
	public void setAddrWkState(String addrWkState) {
		this.addrWkState = addrWkState;
	}

	/**
	 * @return the addrWkStLine1
	 */
	public String getAddrWkStLine1() {
		return addrWkStLine1;
	}

	/**
	 * @param addrWkStLine1
	 *            the addrWkStLine1 to set
	 */
	public void setAddrWkStLine1(String addrWkStLine1) {
		this.addrWkStLine1 = addrWkStLine1;
	}

	/**
	 * @return the addrWkStLineWk
	 */
	public String getAddrWkStLineWk() {
		return addrWkStLineWk;
	}

	/**
	 * @param addrWkStLineWk
	 *            the addrWkStLineWk to set
	 */
	public void setAddrWkStLineWk(String addrWkStLineWk) {
		this.addrWkStLineWk = addrWkStLineWk;
	}

	/**
	 * @return the addrWkType
	 */
	public String getAddrWkType() {
		return addrWkType;
	}

	/**
	 * @param addrWkType
	 *            the addrWkType to set
	 */
	public void setAddrWkType(String addrWkType) {
		this.addrWkType = addrWkType;
	}

	/**
	 * @return the addrWkUrbCode
	 */
	public String getAddrWkUrbCode() {
		return addrWkUrbCode;
	}

	/**
	 * @param addrWkUrbCode
	 *            the addrWkUrbCode to set
	 */
	public void setAddrWkUrbCode(String addrWkUrbCode) {
		this.addrWkUrbCode = addrWkUrbCode;
	}

	/**
	 * @return the addrWkZip
	 */
	public String getAddrWkZip() {
		return addrWkZip;
	}

	/**
	 * @param addrWkZip
	 *            the addrWkZip to set
	 */
	public void setAddrWkZip(String addrWkZip) {
		this.addrWkZip = addrWkZip;
	}

	/**
	 * @return the addrZip
	 */
	public String getAddrZip() {
		return addrZip;
	}

	/**
	 * @param addrZip
	 *            the addrZip to set
	 */
	public void setAddrZip(String addrZip) {
		this.addrZip = addrZip;
	}

	/**
	 * @return the bDate
	 */
	public String getBDate() {
		return bDate;
	}

	/**
	 * @param date
	 *            the bDate to set
	 */
	public void setBDate(String date) {
		bDate = date;
	}

	/**
	 * @return the deceasedInd
	 */
	public String getDeceasedInd() {
		return deceasedInd;
	}

	/**
	 * @param deceasedInd
	 *            the deceasedInd to set
	 */
	public void setDeceasedInd(String deathInd) {
		this.deceasedInd = deathInd;
	}

	/**
	 * @return the ecicMemId
	 */
	public String getEcicMemId() {
		return ecicMemId;
	}

	/**
	 * @param ecicMemId
	 *            the ecicMemId to set
	 */
	public void setEcicMemId(String ecicMemId) {
		this.ecicMemId = ecicMemId;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the hohId
	 */
	public String getHohId() {
		return hohId;
	}

	/**
	 * @param hohId
	 *            the hohId to set
	 */
	public void setHohId(String hohId) {
		this.hohId = hohId;
	}

	/**
	 * @return the hohRelateCode
	 */
	public String getHohRelateCode() {
		return hohRelateCode;
	}

	/**
	 * @param hohRelateCode
	 *            the hohRelateCode to set
	 */
	public void setHohRelateCode(String hohRelateCode) {
		this.hohRelateCode = hohRelateCode;
	}

	/**
	 * @return the lastUpdateDate
	 */
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	/**
	 * @param lastUpdateDate
	 *            the lastUpdateDate to set
	 */
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	/**
	 * @return the lockInd
	 */
	public String getLockInd() {
		return lockInd;
	}

	/**
	 * @param lockInd
	 *            the lockInd to set
	 */
	public void setLockInd(String lockInd) {
		this.lockInd = lockInd;
	}

	/**
	 * @return the srcIdNum
	 */
	public String getSrcIdNum() {
		return srcIdNum;
	}

	/**
	 * @param srcIdNum
	 *            the srcIdNum to set
	 */
	public void setSrcIdNum(String memIdNum) {
		this.srcIdNum = memIdNum;
	}

	/**
	 * @return the nameFirst
	 */
	public String getNameFirst() {
		return nameFirst;
	}

	/**
	 * @param nameFirst
	 *            the nameFirst to set
	 */
	public void setNameFirst(String nameFirst) {
		this.nameFirst = nameFirst;
	}

	/**
	 * @return the nameLast
	 */
	public String getNameLast() {
		return nameLast;
	}

	/**
	 * @param nameLast
	 *            the nameLast to set
	 */
	public void setNameLast(String nameLast) {
		this.nameLast = nameLast;
	}

	/**
	 * @return the nameMiddle
	 */
	public String getNameMiddle() {
		return nameMiddle;
	}

	/**
	 * @param nameMiddle
	 *            the nameMiddle to set
	 */
	public void setNameMiddle(String nameMiddle) {
		this.nameMiddle = nameMiddle;
	}

	/**
	 * @return the namePrefix
	 */
	public String getNamePrefix() {
		return namePrefix;
	}

	/**
	 * @param namePrefix
	 *            the namePrefix to set
	 */
	public void setNamePrefix(String namePrefix) {
		this.namePrefix = namePrefix;
	}

	/**
	 * @return the nameSuffix
	 */
	public String getNameSuffix() {
		return nameSuffix;
	}

	/**
	 * @param nameSuffix
	 *            the nameSuffix to set
	 */
	public void setNameSuffix(String nameSuffix) {
		this.nameSuffix = nameSuffix;
	}

	/**
	 * @return the origin
	 */
	public String getOrigin() {
		return origin;
	}

	/**
	 * @param origin
	 *            the origin to set
	 */
	public void setOrigin(String origin) {
		this.origin = origin;
	}

	/**
	 * @return the originStoreInd
	 */
	public String getOriginStoreInd() {
		return originStoreInd;
	}

	/**
	 * @param originStoreInd
	 *            the originStoreInd to set
	 */
	public void setOriginStoreInd(String originStoreInd) {
		this.originStoreInd = originStoreInd;
	}

	/**
	 * @return the pcecMemId
	 */
	public String getPcecMemId() {
		return pcecMemId;
	}

	/**
	 * @param pcecMemId
	 *            the pcecMemId to set
	 */
	public void setPcecMemId(String pcecMemId) {
		this.pcecMemId = pcecMemId;
	}

	/**
	 * @return the petInd
	 */
	public String getPetInd() {
		return petInd;
	}

	/**
	 * @param petInd
	 *            the petInd to set
	 */
	public void setPetInd(String petInd) {
		this.petInd = petInd;
	}

	/**
	 * @return the phoneArea
	 */
	public String getPhoneArea() {
		return phoneArea;
	}

	/**
	 * @param phoneArea
	 *            the phoneArea to set
	 */
	public void setPhoneArea(String phoneArea) {
		this.phoneArea = phoneArea;
	}

	/**
	 * @return the phone2Area
	 */
	public String getPhone2Area() {
		return phone2Area;
	}

	/**
	 * @param phone2Area
	 *            the phone2Area to set
	 */
	public void setPhone2Area(String phoneCellArea) {
		this.phone2Area = phoneCellArea;
	}

	/**
	 * @return the phone2Number
	 */
	public String getPhone2Number() {
		return phone2Number;
	}

	/**
	 * @param phone2Number
	 *            the phone2Number to set
	 */
	public void setPhone2Number(String phoneCellNumber) {
		this.phone2Number = phoneCellNumber;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber
	 *            the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the phoneWkArea
	 */
	public String getPhoneWkArea() {
		return phoneWkArea;
	}

	/**
	 * @param phoneWkArea
	 *            the phoneWkArea to set
	 */
	public void setPhoneWkArea(String phoneWkArea) {
		this.phoneWkArea = phoneWkArea;
	}

	/**
	 * @return the phoneWkNumber
	 */
	public String getPhoneWkNumber() {
		return phoneWkNumber;
	}

	/**
	 * @param phoneWkNumber
	 *            the phoneWkNumber to set
	 */
	public void setPhoneWkNumber(String phoneWkNumber) {
		this.phoneWkNumber = phoneWkNumber;
	}

	/**
	 * @return the secCode
	 */
	public String getSecCode() {
		return secCode;
	}

	/**
	 * @param secCode
	 *            the secCode to set
	 */
	public void setSecCode(String secCode) {
		this.secCode = secCode;
	}

	/**
	 * @return the srcCode
	 */
	public String getSrcCode() {
		return srcCode;
	}

	/**
	 * @param srcCode
	 *            the srcCode to set
	 */
	public void setSrcCode(String srcCode) {
		this.srcCode = srcCode;
	}

	// Phone Alignement Code changes start
	/**
	 * @return the phone2Priority
	 */
	public String getPhone2Priority() {
		return phone2Priority;
	}

	/**
	 * @param phone2Priority
	 *            the phone2Priority to set
	 */
	public void setPhone2Priority(String phone2Priority) {
		this.phone2Priority = phone2Priority;
	}

	/**
	 * @return the phonePriority
	 */
	public String getPhonePriority() {
		return phonePriority;
	}

	/**
	 * @param phonePriority
	 *            the phonePriority to set
	 */
	public void setPhonePriority(String phonePriority) {
		this.phonePriority = phonePriority;
	}

	/**
	 * @return the phoneWkPriority
	 */
	public String getPhoneWkPriority() {
		return phoneWkPriority;
	}

	/**
	 * @param phoneWkPriority
	 *            the phoneWkPriority to set
	 */
	public void setPhoneWkPriority(String phoneWkPriority) {
		this.phoneWkPriority = phoneWkPriority;
	}

	// Phone Alignement Code changes End

	public ArrayList<CustomerMasterEnterpriseAttributesVO> getCustArrayOfAttributes() {
		return custArrayOfAttributes;
	}

	public void setCustArrayOfAttributes(
			ArrayList<CustomerMasterEnterpriseAttributesVO> custArrayOfAttributes) {
		this.custArrayOfAttributes = custArrayOfAttributes;
	}

	public ArrayList<CustomerMasterEnterpriseProgramVO> getCustProgIdArray() {
		return custProgIdArray;
	}

	public void setCustProgIdArray(
			ArrayList<CustomerMasterEnterpriseProgramVO> custProgIdArray) {
		this.custProgIdArray = custProgIdArray;
	}

	public ArrayList<CustomerMasterEnterpriseProgramActionVO> getCustProgActionArray() {
		return custProgActionArray;
	}

	public void setCustProgActionArray(
			ArrayList<CustomerMasterEnterpriseProgramActionVO> custProgActionArray) {
		this.custProgActionArray = custProgActionArray;
	}

}
