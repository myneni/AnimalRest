package com.walgreens.cdi.exception;

import javax.xml.ws.WebFault;
@WebFault(name="CDIException")

public class CDIException_Exception extends Exception{
	private CDIExceptionFault faultInfo;
	private String detailMessage = null;
	protected String msg;
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getDetailMessage() {
		return detailMessage;
	}

	public void setDetailMessage(String detailMessage) {
		this.detailMessage = detailMessage;
	}

	protected String errorCode;
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public CDIException_Exception(String message, CDIExceptionFault faultInfo) {
        super(message);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @param faultInfo
     * @param message
     * @param cause
     */
    public CDIException_Exception(String message, CDIExceptionFault faultInfo, Throwable cause) {
        super(message, cause);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @return
     *     returns fault bean: com.walgreens.opv.ods.customer.service.webservices.OPVException
     */
    public CDIExceptionFault getFaultInfo() {
        return faultInfo;
    }

}
