package com.walgreens.cdi.dao.impl;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import walgreens.utils.logging.WalgreensLog4JImpl;

import com.walgreens.cdi.dao.ICustomerMasterEntMemberIdGenerateDAO;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.CustomerMasterUtility;

public class CustomerMasterEntMemberIdGenerateDAO implements ICustomerMasterEntMemberIdGenerateDAO {

	private WalgreensLog4JImpl walgreensLogger;

	private JdbcTemplate jdbcTemplate;

	public void setDataSource(DataSource datasource) {
		jdbcTemplate = new JdbcTemplate(datasource);
		jdbcTemplate.setFetchSize(50);
	}

	public String getMemberIDNumber(String programCode) {

		long sequence;
		String currentSequence = "";

		if (programCode.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_MEMID)) {
			try {
				String sql_MEMID = "SELECT loyalty_mem_id_no_seq.nextval from DUAL";
				

				sequence = this.jdbcTemplate.queryForLong(sql_MEMID);
				//System.out.println("CurrentSequence value in DAO sequence" + sequence);
				currentSequence = String.valueOf(sequence);
				//System.out.println("CurrentSequence value in DAO currentSequence" + currentSequence);
				getWalgreensLogger().log(1, "Member ID value::"+ currentSequence);

			} catch (DataAccessException we) {
				String msg = "Error while getting value from Sequencer for Member ID:";
				msg = msg + we.getMessage();
				System.out.println (" DataAccessException Error while getting value from Sequencer for MEMID:" + we.getMessage());
				throw we;
			} catch (Exception e) {
				System.out.println (" Exception Error while getting value from Sequencer for MEMID:" + e.getMessage());
				e.printStackTrace();
				
			}
		}
		else if (programCode.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_LYCD)) {
			try {
				String sql_LYCD = "SELECT loyalty_mem_id_no_seq.nextval from DUAL";
				

				sequence = this.jdbcTemplate.queryForLong(sql_LYCD);
				currentSequence = String.valueOf(sequence);

			} catch (DataAccessException we) {
				String msg = "Error while getting value from Sequencer for LYCD:";
				msg = msg + we.getMessage();
				System.out.println (" DataAccessException Error while getting value from Sequencer for LYCD:" + we.getMessage());
				throw we;
			} catch (Exception e) {
				System.out.println (" Exception Error while getting value from Sequencer for LYCD:" + e.getMessage());
				
				e.printStackTrace();

			}
		} else if (programCode.equalsIgnoreCase(CustomerMasterConstants.PROGRAMCODE_VCD)) {

			try {
				String sql_VCD = "SELECT loyalty_vcd_id_no_seq.nextval from DUAL";
				

				sequence = this.jdbcTemplate.queryForLong(sql_VCD);
				String tempCurrentSequence = String.valueOf(sequence);
				currentSequence = CustomerMasterUtility.generateDynamicVirtualCardNumber(tempCurrentSequence);

			} catch (DataAccessException we) {
				String msg = "Error while getting value from Sequencer for VCD:";
				msg = msg + we.getMessage();
				System.out.println (" DataAccessException Error while getting value from Sequencer for VCD:" + we.getMessage());
				throw we;
			} catch (Exception e) {
				System.out.println (" Exception Error while getting value from Sequencer for VCD:" + e.getMessage());
				e.printStackTrace();

			}
		}
		
		return currentSequence;
	}

	public WalgreensLog4JImpl getWalgreensLogger() {
		return walgreensLogger;
	}

	public void setWalgreensLogger(WalgreensLog4JImpl walgreensLogger) {
		this.walgreensLogger = walgreensLogger;
	}

}
