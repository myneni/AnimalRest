package com.walgreens.cdi.dao.impl;


import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.StopWatch;

import walgreens.services.LoggingFacility;
import walgreens.utils.logging.WalgreensLog4JImpl;

import com.walgreens.cdi.dao.ICustomerMasterLookUpDAO;
import com.walgreens.cdi.vo.CustomerMasterLinkageVO;
import com.walgreens.cdi.vo.CustomerMasterLookUpVO;


public class CustomerMasterLookUpDAO implements ICustomerMasterLookUpDAO{
	
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource datasource){
		jdbcTemplate = new JdbcTemplate(datasource);
		jdbcTemplate.setFetchSize(50);		
	}
	
	public List<CustomerMasterLookUpVO> getCompView(Set eidSet)
	{
		List<CustomerMasterLookUpVO> list = null;
		String entRecNo="";
		Iterator itr = eidSet.iterator();
		int i=0;
		while(itr.hasNext())
		{
			if(i==0){
				entRecNo = entRecNo + itr.next();
			}
			else{
				entRecNo = entRecNo + ","+itr.next();
			}
			
			i++;
		}
		try {		
		String sql = "select * from cdi_emca_cv_id where ENTITYID in ("+entRecNo+")";
		long st = System.currentTimeMillis();
		getWalgreensLogger().log(LoggingFacility.DEBUG,sql);
		list = this.jdbcTemplate.query(sql, new CustomerMasterLookUpRowsMapper(sql, st));
		long et = System.currentTimeMillis();
		getWalgreensLogger().log(LoggingFacility.DEBUG,"Time taken:"+(et-st)+":"+sql);
		} catch (DataAccessException we) {
			String msg = "Error while getting value from cdi_emca_cv_id table with ENTITYID:"
					+ entRecNo;
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR,msg);
			throw we;
		}
		catch (Exception e)
		{
			getWalgreensLogger().log(LoggingFacility.ERROR,"Error in fetching the data from DB :"+e.getMessage());
		}
		return list;
	}
	public List<CustomerMasterLinkageVO> getLinkage(Set eidSet)
	{
		List<CustomerMasterLinkageVO> linkageMap = null;
		String entRecNo="";
		Iterator itr = eidSet.iterator();
		int i=0;
		while(itr.hasNext())
		{
			if(i==0){
				entRecNo = entRecNo + itr.next();
			}
			else{
				entRecNo = entRecNo + ","+itr.next();
			}
			
			i++;
		}
		try {
			String sql = "select * from cdi_linkage_cv_id where ENTITYID in ("+entRecNo+")";
			getWalgreensLogger().log(LoggingFacility.DEBUG,sql);
			linkageMap =  this.jdbcTemplate.query(sql, new CustomerMasterLinkageRowsMapper());
		
		} catch (DataAccessException we) {
				String msg = "Error while getting value from cdi_linkage_cv_id table with MEMRECNO:"
						+ entRecNo;
				msg = msg + we.getMessage();
				getWalgreensLogger().log(LoggingFacility.ERROR,msg);
				throw we;
			}
			catch (Exception e)
			{
				getWalgreensLogger().log(LoggingFacility.ERROR,"Error in fetching the data from DB :"+e.getMessage());
			}
		return linkageMap;
	}
	
	 /**
     * Referring to the WalgreensLog4JImpl
     */
    private WalgreensLog4JImpl walgreensLogger;

    /**
     * @return the walgreensLogger
     */
    public WalgreensLog4JImpl getWalgreensLogger() {
        return walgreensLogger;
    }


    /**
     * @param walgreensLogger
     *            the walgreensLogger to set
     */
    public void setWalgreensLogger(WalgreensLog4JImpl walgreensLogger) {
        this.walgreensLogger = walgreensLogger;
    }
	
}
