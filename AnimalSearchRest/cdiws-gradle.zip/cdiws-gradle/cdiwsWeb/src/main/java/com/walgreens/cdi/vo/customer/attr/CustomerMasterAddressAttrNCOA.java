package com.walgreens.cdi.vo.customer.attr;
import com.walgreens.cdi.util.CustomerMasterConstants;


public class CustomerMasterAddressAttrNCOA extends CustomerMasterAddressAttr {		
	
	//private String NCOAStreetLine1;
	//private String NCOAStreetLine2;
	//private String NCOACity;
	//private String NCOAState;
	//private String NCOAZip;
	//private String NCOAUSPSAddressType;	//String (0/1)	AllSource Perm NCOA USPS Address Type.
	//private String NCOAUrbanizationCode;
	
	private String NCOAActionCode;		//String (0/1)	AllSource Perm NCOA Action Code.
	private String NCOAANKCode;			//String (0/1)	AllSource Perm NCOA ANK Code.
	private String NCOAMoveDate;			//String (0/1)	AllSource Perm NCOA Move Date.
	private String NCOAMoveType;			//String (0/1)	AllSource Perm NCOA Move Type.
	private String NCOANewAddressFlag;	//String (0/1)	AllSource Perm NCOA New Address Flag,
	private String NCOANIXIEFootnote;	//String (0/1)	AllSource Perm NCOA NIXIE Footnote.
	private String NCOAProcessDate;		//String (0/1)	AllSource Perm NCOA Process Date.
	private String NCOAReturnCode;		//String (0/1)	AllSource Perm NCOA Return Code.
	
	/**
	 * 
	 */
	public CustomerMasterAddressAttrNCOA() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * 
	 */
	public CustomerMasterAddressAttrNCOA(String addresUsageType) {
		super(addresUsageType);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the nCOAActionCode
	 */
	public String getNCOAActionCode() {
		return NCOAActionCode;
	}
	/**
	 * @param actionCode the nCOAActionCode to set
	 */
	public void setNCOAActionCode(String actionCode) {
		NCOAActionCode = actionCode;
	}
	/**
	 * @return the nCOAANKCode
	 */
	public String getNCOAANKCode() {
		return NCOAANKCode;
	}
	/**
	 * @param code the nCOAANKCode to set
	 */
	public void setNCOAANKCode(String code) {
		NCOAANKCode = code;
	}
	/**
	 * @return the nCOAMoveDate
	 */
	public String getNCOAMoveDate() {
		return NCOAMoveDate;
	}
	/**
	 * @param moveDate the nCOAMoveDate to set
	 */
	public void setNCOAMoveDate(String moveDate) {
		NCOAMoveDate = moveDate;
	}
	/**
	 * @return the nCOAMoveType
	 */
	public String getNCOAMoveType() {
		return NCOAMoveType;
	}
	/**
	 * @param moveType the nCOAMoveType to set
	 */
	public void setNCOAMoveType(String moveType) {
		NCOAMoveType = moveType;
	}
	/**
	 * @return the nCOANewAddressFlag
	 */
	public String getNCOANewAddressFlag() {
		return NCOANewAddressFlag;
	}
	/**
	 * @param newAddressFlag the nCOANewAddressFlag to set
	 */
	public void setNCOANewAddressFlag(String newAddressFlag) {
		NCOANewAddressFlag = newAddressFlag;
	}
	/**
	 * @return the nCOANIXIEFootnote
	 */
	public String getNCOANIXIEFootnote() {
		return NCOANIXIEFootnote;
	}
	/**
	 * @param footnote the nCOANIXIEFootnote to set
	 */
	public void setNCOANIXIEFootnote(String footnote) {
		NCOANIXIEFootnote = footnote;
	}
	/**
	 * @return the nCOAProcessDate
	 */
	public String getNCOAProcessDate() {
		return NCOAProcessDate;
	}
	/**
	 * @param processDate the nCOAProcessDate to set
	 */
	public void setNCOAProcessDate(String processDate) {
		NCOAProcessDate = processDate;
	}
	/**
	 * @return the nCOAReturnCode
	 */
	public String getNCOAReturnCode() {
		return NCOAReturnCode;
	}
	/**
	 * @param returnCode the nCOAReturnCode to set
	 */
	public void setNCOAReturnCode(String returnCode) {
		NCOAReturnCode = returnCode;
	}
	
	
	
	
	public String toString() {
		String str = "";
		      
		str = " AddressUsageType    =" + 	getAddressUsageType()  	+"\n" +	
		      " strLine1            =" +	getStreetLine1() 		+"\n" +	
	          " strLine2            =" +	getStreetLine2()		+"\n" +	
	          " City                =" +	getCity() 				+"\n" +	
	          " State               =" +	getState() 				+"\n" +	
	          " Country             =" +	getCountry() 			+"\n" +	
		      " CASSFootnote       	=" + 	getCASSFootnote() 		+"\n" +
	          " country             =" + 	getCountry() 			+"\n" +
	          " USPSAddressType     =" + 	getUSPSAddressType()	+"\n" +
	          " DPVFootnote         =" +    getDPVFootnote() 		+"\n" +	
	          " DPVIndicator        =" + 	getDPVIndicator() 		+"\n" +	
		      " Latitude            =" +	getLatitude() 			+"\n" +	
		      " Longitude           =" + 	getLongitude() 			+"\n" +	
		      " standardizationProcessDate= " + getStandardizationProcessDate() +"\n" +	
		      " urbanizationCode    =" + 	getUrbanizationCode() 	+"\n" +	
		      " LACSAddressFlag    	=" + 	getLACSAddressFlag() 	+"\n" +	
		      " LACSFootnote        =" + 	getLACSFootnote() 		+"\n" +	
		      " LACSReturnCode      =" + 	getLACSReturnCode()		+"\n" +	
		      " DPVIndicator        = "+ 	getDPVIndicator() 		+"\n" +
			  " NCOAActionCode      =" +    getNCOAActionCode()     +"\n" +	
			  " NCOAANKCode         =" +    getNCOAANKCode()		+"\n" +	
			  " NCOAMoveDate        =" +    getNCOAMoveDate()		+"\n" +	
			  " NCOAMoveType        =" + 	getNCOAMoveType()		+"\n" +	
			  " NCOANewAddressFlag  =" +    getNCOANewAddressFlag() +"\n" +	
			  " NCOANIXIEFootnote   =" +    getNCOANIXIEFootnote()  +"\n" +	
			  " NCOAProcessDate     =" +    getNCOAProcessDate()    +"\n" +	
			  " NCOAReturnCode      =" +    getNCOAReturnCode()     +"\n" +
			  " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
			  " securityClassCode   =" + getSecurityClassCode() + "\n" +
			  " sourceCode   =" + getSourceCode() + "\n" ;;
		
	     
		
		return str;
	}
	
	
	public String toCompString() {
		String str="";
		 str = CustomerMasterConstants.DELIMITE_FIELD +
		       	getAddressUsageType()  	+CustomerMasterConstants.DELIMITE_FIELD +	
		        getStreetLine1() 		+CustomerMasterConstants.DELIMITE_FIELD +	
	         	getStreetLine2()		+CustomerMasterConstants.DELIMITE_FIELD +	
	         							CustomerMasterConstants.DELIMITE_FIELD +	
	         						    CustomerMasterConstants.DELIMITE_FIELD +	
	          	getCity() 				+CustomerMasterConstants.DELIMITE_FIELD +	
	         	getState() 				+CustomerMasterConstants.DELIMITE_FIELD +	
	        	getCountry() 			+CustomerMasterConstants.DELIMITE_FIELD +	
		     	getCASSFootnote() 		+CustomerMasterConstants.DELIMITE_FIELD +
	          	getCountry() 			+CustomerMasterConstants.DELIMITE_FIELD +
	         	getUSPSAddressType()	+CustomerMasterConstants.DELIMITE_FIELD +
	            getDPVFootnote() 		+CustomerMasterConstants.DELIMITE_FIELD +	
	        	getDPVIndicator() 		+CustomerMasterConstants.DELIMITE_FIELD +	
		        getStandardizationProcessDate() +CustomerMasterConstants.DELIMITE_FIELD +	
		    	getUrbanizationCode() 	+CustomerMasterConstants.DELIMITE_FIELD +	
		     	getLongitude() 			+CustomerMasterConstants.DELIMITE_FIELD +	
			   	getLatitude() 			+CustomerMasterConstants.DELIMITE_FIELD +	
		       	getLACSAddressFlag() 	+CustomerMasterConstants.DELIMITE_FIELD +	
		    	getLACSFootnote() 		+CustomerMasterConstants.DELIMITE_FIELD +	
		    	getLACSReturnCode()		+CustomerMasterConstants.DELIMITE_FIELD +	
		    	getDPVIndicator() 		+CustomerMasterConstants.DELIMITE_FIELD +
		    	getNCOAActionCode()     +CustomerMasterConstants.DELIMITE_FIELD +	
			    getNCOAANKCode()		+CustomerMasterConstants.DELIMITE_FIELD +	
			    getNCOAMoveDate()		+CustomerMasterConstants.DELIMITE_FIELD +	
			    getNCOAMoveType()		+CustomerMasterConstants.DELIMITE_FIELD +	
			    getNCOANIXIEFootnote()  +CustomerMasterConstants.DELIMITE_FIELD +	
			    getNCOANewAddressFlag() +CustomerMasterConstants.DELIMITE_FIELD +	
			    getNCOAReturnCode()     +CustomerMasterConstants.DELIMITE_FIELD +
			    getNCOAProcessDate()    +CustomerMasterConstants.DELIMITE_FIELD +	
			    getSourceCode() + CustomerMasterConstants.DELIMITE_FIELD +
			    getSecurityClassCode() + CustomerMasterConstants.DELIMITE_FIELD +
			    getLastUpdateDate() + CustomerMasterConstants.DELIMITE_FIELD;
	     
	
         return str;
	}
	
	
public boolean isNull(){
		
		if(isNull(getStreetLine1() )&&		
				isNull(getStreetLine2())&&		
					isNull(getCity())&&	 			
					isNull(getState())&&				
					isNull(getCountry())&&			
					isNull(getCASSFootnote())&&			
					isNull(getCountry())&&			
		         	isNull(getUSPSAddressType())&&	
		          isNull(getDPVFootnote())&&			
		          isNull(getDPVIndicator())&&		
		          isNull(getLatitude())&&				
		          isNull(getLongitude())&&				
		          isNull(getStandardizationProcessDate())&&	
		          isNull(getUrbanizationCode())&&	
		          isNull(getLACSAddressFlag())&&		
		          isNull(getLACSFootnote())&&	
		          isNull(getLACSReturnCode())&&	
		          isNull(getDPVIndicator())&&		
		          isNull(getNCOAActionCode() )&&	  
		          isNull(getNCOAANKCode())&&		
		          isNull(getNCOAMoveDate())&&	
		          isNull(getNCOAMoveType())&&		
		          isNull(getNCOANewAddressFlag() )&&	
		          isNull(getNCOANIXIEFootnote())&&	 
		          isNull(getNCOAProcessDate())&&
		          isNull(getNCOAReturnCode()))	   
		        
					     
				return true;
		else
			return false;
	}
	// Added for lookup enterprise service.
public boolean isNullEnterpriseLookup(){
	//System.out.println("Inside isNullEnterpriseLookup");
	if(isNull(getStreetLine1() )&&		
			isNull(getStreetLine2())&&		
				isNull(getCity())&&	 			
				isNull(getState())&&				
				isNull(getZipCode())			
				)	
	{
	        
		//System.out.println("Inside PR Address Zip Code IF condition"+ getZipCode());			     
			return true;
	}
	else
	{
		//System.out.println("Inside PR Address Zip Code Else condition"+ getZipCode());	
		return false;
	}
}
	
	 private boolean isNull(String str){
			if(str==null)
				return true;
			if(str.equalsIgnoreCase("null")||str.trim().equalsIgnoreCase(""))
				return true;
			else
				return false;
		}

	
}
