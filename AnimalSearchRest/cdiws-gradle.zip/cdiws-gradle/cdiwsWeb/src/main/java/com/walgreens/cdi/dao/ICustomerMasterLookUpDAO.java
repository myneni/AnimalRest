package com.walgreens.cdi.dao;

import java.util.List;
import java.util.Set;

import com.walgreens.cdi.vo.CustomerMasterLinkageVO;
import com.walgreens.cdi.vo.CustomerMasterLookUpVO;

public interface ICustomerMasterLookUpDAO {
public List<CustomerMasterLookUpVO> getCompView(Set eidSet);
public List<CustomerMasterLinkageVO> getLinkage(Set eidSet);
}
