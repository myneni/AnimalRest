package com.walgreens.cdi.service.impl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterResponse;
import com.walgreens.cdi.bo.ICustomerMasterGetBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.service.ICustomerMasterGetService;
import com.walgreens.cdi.vo.CustomerMasterGetRequest;

import com.walgreens.cdi.vo.customer.ArrayOfCustomer;

public class CustomerMasterGetService extends BaseService implements ICustomerMasterGetService{
	
	public ICustomerMasterGetBO customerMasterGetBO;
	
	

	public ArrayOfCustomer getCustomerMaster(CustomerMasterGetRequest customerMasterGetRequest) throws CDIException {
		
		//System.out.println("Start calling CustomerMasterGetService::getCustomerMaster() method");
		try{
			return getcustomerMasterGetBO().getCustomerMaster(customerMasterGetRequest);
		} catch (CDIException e) {
            //e.printStackTrace();
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return null;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
        }
	}

	/**
	 * @return the customerMasterGetBO
	 */
	public ICustomerMasterGetBO getcustomerMasterGetBO() {
		return customerMasterGetBO;
	}


	/**
	 * @param customerMasterGetBO 
	 */
	public void setCustomerMasterGetBO(ICustomerMasterGetBO customerMasterGetBO) {
		this.customerMasterGetBO = customerMasterGetBO;
	}
	


	public static void main(String[] args) {
	
		String[] springFile = { "classpath*:bounce.xml" };
		ApplicationContext context = new ClassPathXmlApplicationContext(
				springFile);
			
		CustomerMasterGetService retrieveService = (CustomerMasterGetService) context
		.getBean("customerMasterGetService");
		
		CustomerMasterGetRequest sendBuffer = new CustomerMasterGetRequest();
		//sendBuffer.setCustSourceCode("IC");
		//sendBuffer.setCustSourceID("1");
		sendBuffer.setCustEID("7483609");
		sendBuffer.setCvWName("ALLL");
		//sendBuffer.setCustSourceCode("EC");
		//sendBuffer.setCustSourceID("00987654398");
		try{
			
			ArrayOfCustomer tt= retrieveService.getCustomerMaster(sendBuffer);
			CustomerMasterResponse[] abcd = tt.getItem();
			//System.out.println("Got the GETCustomer result ..."+abcd.toString()+ " : " + abcd.length);
		
			//System.out.println("\n***************************CustomerGetService Result***********************\n");
			   for (int i=0; i<abcd.length; i++)
			   {
				   String aa= abcd[i].getCdiCustomer().toString();
				  // System.out.println("\n##########################Customer : "  + i + " ########################\n " +aa);
				   //System.out.println("CELL PHONE :: " + abcd[i].getCdiCustomer().getCustAll().getPhone().getCellPhone());
				/*   System.out.println("Prefix :: " + abcd[i].getCdiCustomer().getCustAll().getName().getPrefixName());
				   System.out.println("First Name :: " + abcd[i].getCdiCustomer().getCustAll().getName().getFirstName());
				   System.out.println("Middle Name :: " + abcd[i].getCdiCustomer().getCustAll().getName().getMiddleName());
				   System.out.println("Last Name :: " + abcd[i].getCdiCustomer().getCustAll().getName().getLastName());
				   System.out.println("Suffix :: " + abcd[i].getCdiCustomer().getCustAll().getName().getSuffixName());
				   System.out.println("Last Updated :: " + abcd[i].getCdiCustomer().getCustAll().getName().getLastUpdateDate());
//				   SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
*/
				   //				   Date systemDate = sdf.parse(abcd[i].getCdiCustomer().getCustAll().getName().getLastUpdateDate());
//				   SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//				   sdf2.setTimeZone(TimeZone.getTimeZone("GMT"));
//				   
//				   System.out.println("Converted Last Updated :: " + sdf2.format(systemDate));
				   
			   }
			
		}catch (CDIException e) {
			if (e instanceof SystemException) {
				CDIException brv = (SystemException)e;
				System.err.println("\n\nError Code :: " +brv.getMessage());
				System.err.println("\t:: " +brv.getMsg());
				System.err.println("\t:: " +brv.getDetailMessage());
			}else if (e instanceof BusinessRuleViolationException) {
				CDIException brv = (BusinessRuleViolationException)e;
				System.err.println("\n\nError Code :: " +brv.getMessage());
				System.err.println("\t:: " +brv.getMsg());
				System.err.println("\t:: " +brv.getDetailMessage());
			}else {
				e.printStackTrace();
			}
			//e.printStackTrace();
			// TODO: handle exception
		}
	
	}

}
