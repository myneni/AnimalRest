package com.walgreens.cdi.vo;

/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author 
 * 
 */
public class CustomerMasterUpdateVO {

//	 Create date time
	private String createDttm;
	// Birth date 
	private String custBirthDttm;
	// Decesed Indicator
	private String custDeceasedInd;
	// Name Prefix
	private String custNamePrefix;
	// First Name
	private String custFirstName;
	// Head of Household Id
	private String custHohId;
	// Relation code of customer with Head of Household
	private String custHohRelationCd;
	// Customer Id
	private String sourceId;
	// Lsat Name
	private String custLastName;
	// Middle Initial
	private String custMidInit;
	// Pet Indicator
	private String custPetInd;
	// Prime area code 
	private String custPrimAreaCd;
	// Prime phone number
	private String custPrimPhone;
	// Secondary area code
	private String custSecAreaCd;
	// Secondary phone number
	private String custSecPhone;
	// Sex code
	private String custSexCd;
	// Surname Suffix
	private String custSurnameSuffix;
	// Customer origin code
	private String customerOrigin;
	// Store Indicator of customer
	private String custStoreIndicator;
	// Source code
	private String sourceCode;
	// Email Address
	private String emailAddress;
	// Street address
	private String streetAddr;
	// City 
	private String city;
	// State
	private String state;
	// Zip
	private String zip;
	// User Name
	private String userNm;
	// User Password
	private String userPassword;
	
	
//	 Patient Insurance Info
	private CustomerMasterPatientInsuranceInfo[] customerMasterPatientInsuranceInfo;
	
	/**
	 * 
	 * @return customerMasterPatientInsuranceInfo[]
	 */
	public CustomerMasterPatientInsuranceInfo[] getPatientInsuranceInfo() {
		return customerMasterPatientInsuranceInfo;
	}
	/**
	 * This method is used to set the information about patient insurance
	 * @param customerMasterPatientInsuranceInfo
	 */
	public void setPatientInsuranceInfo(CustomerMasterPatientInsuranceInfo[] patientInsuranceInfo) {
		this.customerMasterPatientInsuranceInfo = patientInsuranceInfo;
	}
	
	/**
	 * 
	 * @return userNm
	 */
	public String getUserNm() {
		return userNm;
	}
	/**
	 * This method is used to set the user name
	 * @param userNm
	 */
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	/**
	 * 
	 * @return userPassword
	 */
	public String getUserPassword() {
		return userPassword;
	}
	/**
	 * This method is used to set the user password
	 * @param userPassword
	 */
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	/**
	 * 
	 * @return createDttm
	 */
	public String getCreateDttm() {
		return createDttm;
	}
	/**
	 * 
	 * @param createDttm
	 */
	public void setCreateDttm(String createDttm) {
		this.createDttm = createDttm;
	}
	/**
	 * 
	 * @return custBirthDttm
	 */
	public String getCustBirthDttm() {
		return custBirthDttm;
	}
	/**
	 * 
	 * @param custBirthDttm
	 */
	public void setCustBirthDttm(String custBirthDttm) {
		this.custBirthDttm = custBirthDttm;
	}
	/**
	 * 
	 * @return custDeceasedInd
	 */
	public String getCustDeceasedInd() {
		return custDeceasedInd;
	}
	/**
	 * This method is used to set the Customer deceased indicator
	 * @param custDeceasedInd
	 */
	public void setCustDeceasedInd(String custDeceasedInd) {
		this.custDeceasedInd = custDeceasedInd;
	}
	/**
	 * 
	 * @return custFirstName
	 */
	public String getCustFirstName() {
		return custFirstName;
	}
	/**
	 * This method is used to set the first name of customer
	 * @param custFirstName
	 */
	public void setCustFirstName(String custFirstName) {
		this.custFirstName = custFirstName;
	}
	/**
	 * 
	 * @return custHohId
	 */
	public String getCustHohId() {
		return custHohId;
	}
	/**
	 * This method is used to set the Head of Household Id of the Customer
	 * @param custHohId
	 */
	public void setCustHohId(String custHohId) {
		this.custHohId = custHohId;
	}
	/**
	 * 
	 * @return custId
	 */
	public String getSourceId() {
		return sourceId;
	}
	/**
	 * This method is used to set the Customer Id
	 * @param custId
	 */
	public void setSourceId(String custId) {
		this.sourceId = custId;
	}
	/**
	 * 
	 * @return custLastName
	 */
	public String getCustLastName() {
		return custLastName;
	}
	/**
	 *  This method is used to set the last name of customer
	 * @param custLastName
	 */
	public void setCustLastName(String custLastName) {
		this.custLastName = custLastName;
	}
	/**
	 * 
	 * @return custMidInit
	 */
	public String getCustMidInit() {
		return custMidInit;
	}
	/**
	 * This method is used to set the middle initial of customer's name
	 * @param custMidInit
	 */
	public void setCustMidInit(String custMidInit) {
		this.custMidInit = custMidInit;
	}
	/**
	 * 
	 * @return custNamePrefix
	 */
	public String getCustNamePrefix() {
		return custNamePrefix;
	}
	/**
	 * This method is used to set the customer name prefix.
	 * @param custNamePrefix
	 */
	public void setCustNamePrefix(String custNamePrefix) {
		this.custNamePrefix = custNamePrefix;
	}
	/**
	 * 
	 * @return customerOrigin
	 */
	public String getCustomerOrigin() {
		return customerOrigin;
	}
	/**
	 * This method is used to set the customer origin code
	 * @param customerOrigin
	 */
	public void setCustomerOrigin(String customerOrigin) {
		this.customerOrigin = customerOrigin;
	}
	/**
	 * 
	 * @return custPetInd
	 */
	public String getCustPetInd() {
		return custPetInd;
	}
	/**
	 * This method is used to set the pet indicator
	 * @param custPetInd
	 */
	public void setCustPetInd(String custPetInd) {
		this.custPetInd = custPetInd;
	}
	/**
	 * 
	 * @return custPrimAreaCd
	 */
	public String getCustPrimAreaCd() {
		return custPrimAreaCd;
	}
	/**
	 * This method is used to set the Prime area code of customer
	 * @param custPrimAreaCd
	 */
	public void setCustPrimAreaCd(String custPrimAreaCd) {
		this.custPrimAreaCd = custPrimAreaCd;
	}
	/**
	 * 
	 * @return custPrimPhone
	 */
	public String getCustPrimPhone() {
		return custPrimPhone;
	}
	/**
	 * This method is used to set the prime phone number of customer
	 * @param custPrimPhone
	 */
	public void setCustPrimPhone(String custPrimPhone) {
		this.custPrimPhone = custPrimPhone;
	}
	/**
	 * 
	 * @return custSecAreaCd
	 */
	public String getCustSecAreaCd() {
		return custSecAreaCd;
	}
	/**
	 * This method is used to set the secondary area code of customer
	 * @param custSecAreaCd
	 */
	public void setCustSecAreaCd(String custSecAreaCd) {
		this.custSecAreaCd = custSecAreaCd;
	}
	/**
	 * 
	 * @return custSecPhone
	 */
	public String getCustSecPhone() {
		return custSecPhone;
	}
	/**
	 * This method is used to set the secondary phone number of customer
	 * @param custSecPhone
	 */
	public void setCustSecPhone(String custSecPhone) {
		this.custSecPhone = custSecPhone;
	}
	/**
	 * 
	 * @return custSexCd
	 */
	public String getCustSexCd() {
		return custSexCd;
	}
	/**
	 * This method is used to set the gender
	 * @param custSexCd
	 */
	public void setCustSexCd(String custSexCd) {
		this.custSexCd = custSexCd;
	}
	/**
	 * 
	 * @return custStoreIndicator
	 */
	public String getCustStoreIndicator() {
		return custStoreIndicator;
	}
	/**
	 * This method is used to set the store indicator of customer
	 * @param custStoreIndicator
	 */
	public void setCustStoreIndicator(String custStoreIndicator) {
		this.custStoreIndicator = custStoreIndicator;
	}
	/**
	 * 
	 * @return custSurnameSuffix
	 */
	public String getCustSurnameSuffix() {
		return custSurnameSuffix;
	}
	/**
	 * This method is used to set the surname suffix of customer
	 * @param custSurnameSuffix
	 */
	public void setCustSurnameSuffix(String custSurnameSuffix) {
		this.custSurnameSuffix = custSurnameSuffix;
	}
	/**
	 * 
	 * @return emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * This method is used to set the email address of customer
	 * @param emailAddress
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * 
	 * @return sourceCode
	 */
	public String getSourceCode() {
		return sourceCode;
	}
	/**
	 * This method is used to set the source code
	 * @param sourceCode
	 */
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	
	public String getCustHohRelationCd() {
		return custHohRelationCd;
	}
	/**
	 * 
	 * @param custHohRelationCd
	 */
	public void setCustHohRelationCd(String custHohRelationCd) {
		this.custHohRelationCd = custHohRelationCd;
	}

	/**
	 * 
	 * @return city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * This method is used to set the City
	 * @param city
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * 
	 * @return state
	 */
	public String getState() {
		return state;
	}
	/**
	 * This method is used to set the State
	 * @param state
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * 
	 * @return streetAddr
	 */
	public String getStreetAddr() {
		return streetAddr;
	}
	/**
	 * This method is used to set the street address
	 * @param streetAddr
	 */
	public void setStreetAddr(String streetAddr) {
		this.streetAddr = streetAddr;
	}
	/**
	 * 
	 * @return zip
	 */
	public String getZip() {
		return zip;
	}
	/**
	 * This method is used to set the Zip code
	 * @param zip
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}

}
