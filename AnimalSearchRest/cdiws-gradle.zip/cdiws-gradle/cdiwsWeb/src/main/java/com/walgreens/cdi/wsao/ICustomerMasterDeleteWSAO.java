package com.walgreens.cdi.wsao;

import com.walgreens.cdi.vo.CustomerMasterDeleteRequest;

/**
 * This is an interface for exposing EC Delete method at wsao layer.
 *
 * @author TCS
 *
 */
public interface ICustomerMasterDeleteWSAO {


	public boolean deleteCustomerMaster(CustomerMasterDeleteRequest customerMasterDeleteRequest);

}
