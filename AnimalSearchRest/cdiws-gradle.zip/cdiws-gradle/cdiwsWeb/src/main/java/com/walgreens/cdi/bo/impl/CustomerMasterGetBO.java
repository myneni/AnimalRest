package com.walgreens.cdi.bo.impl;

import org.springframework.remoting.jaxws.JaxWsSoapFaultException;

import com.walgreens.cdi.bo.ICustomerMasterGetBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.util.ValidateCustomerMasterRequest;
import com.walgreens.cdi.vo.CustomerMasterGetRequest;
import com.walgreens.cdi.vo.CustomerMasterResponse;
import com.walgreens.cdi.vo.customer.ArrayOfCustomer;
import com.walgreens.cdi.wsao.ICustomerMasterGetWSAO;

import walgreens.services.LoggingFacility;

/**
 * @author picketta
 *
 */
public class CustomerMasterGetBO extends BaseBO implements ICustomerMasterGetBO {
	
	private ICustomerMasterGetWSAO customerMasterGetWSAO;
	
	
	public ArrayOfCustomer getCustomerMaster(CustomerMasterGetRequest customerMasterGetRequest) throws SystemException, BusinessRuleViolationException {
			
		try{
			validateRequestObject(customerMasterGetRequest);
			CustomerMasterResponse[] 	customerMasterResponse = getcustomerMasterGetWSAO().getCustomerMaster(customerMasterGetRequest);
			ArrayOfCustomer arr = new ArrayOfCustomer();
			arr.setItem(customerMasterResponse);
			return arr;
		}catch (JaxWsSoapFaultException e) {
			String exceptionCode = getExceptionCode(e);
			if(exceptionCode != null){
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(exceptionCode,e.getMessage());
			}else{
				getWalgreensLogger().log(LoggingFacility.ERROR, e.getMessage());
				throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION, e.getMessage());
			}
		}catch(BusinessRuleViolationException e){
			throw e;
		}catch(Exception e){
			throw new SystemException(CustomerMasterConstants.EC_UNKNOWN_EXCEPTION_2, e.getMessage());
		}
		//return  getcdiRetrieveWSAO().retrieveCustomer(cdiRetrieveRequest);
	}

	/**
	 * @return the RetrieveWSAO
	 */
	public ICustomerMasterGetWSAO getcustomerMasterGetWSAO() {
		return customerMasterGetWSAO;
	}


	/**
	 * @param RetrieveWSAO the RetrieveWSAO to set
	 */
	public void setCustomerMasterGetWSAO(ICustomerMasterGetWSAO customerMasterGetWSAO) {
		this.customerMasterGetWSAO = customerMasterGetWSAO;
	}


	/**
	 * Method runs validations for request object
	 */
	public void validateRequestObject(CustomerMasterGetRequest customerMasterGetRequest) throws BusinessRuleViolationException {
		ValidateCustomerMasterRequest.validateRequiredFields(customerMasterGetRequest);
		ValidateCustomerMasterRequest.validateInvalidFieldValues(customerMasterGetRequest);	
	}

	
	

}
