package com.walgreens.cdi.dao.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import walgreens.services.LoggingFacility;
import walgreens.utils.logging.WalgreensLog4JImpl;

import com.walgreens.cdi.dao.ICustomerMasterEnterpriseLookUpDAO;
import com.walgreens.cdi.util.CustomerMasterConstants;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseSearch;
import com.walgreens.cdi.vo.CustomerMasterLinkageVO;

/**
 * This class is used to fetch data from the database
 * 
 * @author
 * 
 */
public class CustomerMasterEnterpriseLookUpDAO implements
		ICustomerMasterEnterpriseLookUpDAO {

	private JdbcTemplate jdbcTemplate;

	private JdbcTemplate jdbcTemplateRef;

	/**
	 * This method is used to set the data source.
	 * 
	 * @param datasource
	 */
	public void setDataSource(DataSource datasource) {
		jdbcTemplate = new JdbcTemplate(datasource);
		jdbcTemplate.setFetchSize(50);
	}

	/**
	 * This method is used to set the data source for reference database.
	 * 
	 * @param datasource
	 */
	public void setDataSourceRef(DataSource datasource) {
		jdbcTemplateRef = new JdbcTemplate(datasource);
		jdbcTemplateRef.setFetchSize(50);
	}

	/**
	 * This method is used to get the composite view from all source table
	 * 
	 * @param eidSet
	 * @return
	 */
	public List<CustomerMasterEnterpriseSearch> getCdiCompViewAllSrc(Set eidSet) {

		List<CustomerMasterEnterpriseSearch> list = null;
		String entRecNo = "";
		Iterator itr = eidSet.iterator();
		int i = 0;
		while (itr.hasNext()) {
			if (i == 0) {
				entRecNo = entRecNo + itr.next();
			} else {
				entRecNo = entRecNo + "," + itr.next();
			}

			i++;
		}
		try {

			String sql = "select ENTITYID,CVWTYPE,LASTNAME,FIRSTNAME,MIDDLENAME,PREFIXNAME,SUFFIXNAME,NAMEUPDATE,NAMSECCODE,NAMSRCCODE,BIRTHDATE,BIRTHUPDATE,BIRTHSECCODE,BIRTHSRCCODE,EMAILTYPE,EMAIL,EMAILUPDATE,EMAILSECCODE,EMAILSRCCODE,ADDRTYPE,PCUSTSTLINE1,PCUSTSTLINE2,PCUSTCITY,PCUSTSTATE,PCUSTZIPCODE,PCUSTCOUNTRY,PADDRTYPE,PDPVFTNOTE,PDPVIND,PFTNOTE,PLATITUDE,PLONGITUDE,PPRDATE,PURBCODE,PLACSADDRFLAG,PLACSFTNOTE,PLACSRTRNCODE,PNCOAACTCODE,PNCOAANKCODE,PNCOAMVDATE,PNCOAMVTYPE,PNCOANEWADDRFLG,PNCOANIXFTNOTE,PNCOAPRDATE,PNCOARTRNCODE,PADDRUPDATE,PADDRSECCODE,PADDRSRCCODE,ADDRTYPE2,HCUSTSTLINE1,HCUSTSTLINE2,HCUSTCITY,HCUSTSTATE,HCUSTZIPCODE,HCUSTCOUNTRY,HADDRTYPE,HDPVFTNOTE,HDPVIND,HFTNOTE,HLATITUDE,HLONGITUDE,HPRDATE,HURBCODE,HLACSADDRFLAG,HLACSFTNOTE,HLACSRTRNCODE,HADDRUPDATE,HADDRSECCODE,HADDRSRCCODE,ADDRTYPE3,WCUSTSTLINE1,WCUSTSTLINE2,WCUSTCITY,WCUSTSTATE,WCUSTZIPCODE,WCUSTCOUNTRY,WADDRTYPE,WDPVFTNOTE,WDPVIND,WFTNOTE,WLATITUDE,WLONGITUDE,WPRDATE,WURBCODE,WLACSADDRFLAG,WLACSFTNOTE,WLACSRTRNCODE,WADDRUPDATE,WADDRSECCODE,WADDRSRCCODE,HPHTYPE,HPHAREA,HPHNUMBER,HPHUPDATE,HPHSECCODE,HPHSRCCODE,CPHTYPE,CPHAREA,CPHNUMBER,CPHUPDATE,CPHSECCODE,CPHSRCCODE,WPHTYPE,WPHAREA,WPHNUMBER,WPHUPDATE,WPHSECCODE,WPHSRCCODE,GENDER,GENDERUPDATE,GENDERSECCODE,GENDERSRCCODE,PETIND,PETUPDATE,PETSECCODE,PETSRCCODE,DEATHIND,DEATHUPDATE,DEATHSECCODE,DEATHSRCCODE,LOCKIND,LOCKUPDATE,LOCKSECCODE,LOCKSRCCODE,STOREORIG,STOREIND,STOREUPDATE,STORESECCODE,STORESRCCODE,LASTUPDATE from CDI_EMCA_CV_ALL_SRC where ENTITYID in ("
					+ entRecNo + ")";

			long st = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);

			list = this.jdbcTemplate.query(sql,
					new CustomerMasterEnterpriseLookUpRowsMapper(sql, st));

			long et = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"Time taken:" + (et - st) + ":" + sql);

		} catch (DataAccessException we) {
			String msg = "Error while getting value from CDI_EMCA_CV_ALL_SRC table with ENTITYID:"
					+ entRecNo;
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());

		}

		return list;

	}

	/**
	 * This method is used to get the linkage details from all source table
	 * 
	 * @param eidSet
	 * @return
	 */
	public List<CustomerMasterLinkageVO> getCdiLinkageAllSrc(Set eidSet,String applicationId) {

		List<CustomerMasterLinkageVO> linkageMap = null;
		String entRecNo = "";
		String sql=null;
		Iterator itr = eidSet.iterator();
		int i = 0;
		while (itr.hasNext()) {
			if (i == 0) {
				entRecNo = entRecNo + itr.next();
			} else {
				entRecNo = entRecNo + "," + itr.next();
			}

			i++;
		}
		try {
			//code changes for PCC CR starts
				if(applicationId!=null && CustomerMasterConstants.NON_AUTHORIZE_APPLICATION_ID_HIPAA.contains(applicationId))
			{
			 sql = "select ENTITYID,SRCCODE,SRCID,MEMSTAT,TRANDATE,REFCODE,REFID from CDI_LINKAGE_CV_ALL_SRC where ENTITYID in ("
					+ entRecNo + ") and srccode in (" +CustomerMasterConstants.NON_TRUSTED_SOURCES + ")";
			}
			else
			{
			 sql = "select ENTITYID,SRCCODE,SRCID,MEMSTAT,TRANDATE,REFCODE,REFID from CDI_LINKAGE_CV_ALL_SRC where ENTITYID in ("
						+ entRecNo + ")";
			}
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);
			linkageMap = this.jdbcTemplate.query(sql,
					new CustomerMasterLinkageRowsMapper());

		} 
		//code changes for PCC CR ends
		catch (DataAccessException we) {
			String msg = "Error while getting value from cdi_linkage_cv_all_src table with ENTITYID:"
					+ entRecNo;
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());
			// e.printStackTrace();
		}
		return linkageMap;

	}

	/**
	 * This method is used to get the member view.
	 * 
	 * @param srcCode
	 * @param srcId
	 * @return
	 */
	public List<CustomerMasterEnterpriseSearch> getLoyaltyMemCompView(
			String srcCode, String srcId) {

		List<CustomerMasterEnterpriseSearch> loyaltymMemCv = null;

		try {

			String sql = "select SRCCODE,SRCID,CVWTYPE,LASTNAME,FIRSTNAME,MIDDLENAME,PREFIXNAME,SUFFIXNAME,NAMEUPDATE,NAMSECCODE,NAMSRCCODE,BIRTHDATE,BIRTHUPDATE,BIRTHSECCODE,BIRTHSRCCODE,EMAILTYPE,EMAIL,EMAILUPDATE,EMAILSECCODE,EMAILSRCCODE,ADDRTYPE,PCUSTSTLINE1,PCUSTSTLINE2,PCUSTCITY,PCUSTSTATE,PCUSTZIPCODE,PCUSTCOUNTRY,PADDRTYPE,PDPVFTNOTE,PDPVIND,PFTNOTE,PLATITUDE,PLONGITUDE,PPRDATE,PURBCODE,PLACSADDRFLAG,PLACSFTNOTE,PLACSRTRNCODE,PNCOAACTCODE,PNCOAANKCODE,PNCOAMVDATE,PNCOAMVTYPE,PNCOANEWADDRFLG,PNCOANIXFTNOTE,PNCOAPRDATE,PNCOARTRNCODE,PADDRUPDATE,PADDRSECCODE,PADDRSRCCODE,ADDRTYPE2,HCUSTSTLINE1,HCUSTSTLINE2,HCUSTCITY,HCUSTSTATE,HCUSTZIPCODE,HCUSTCOUNTRY,HADDRTYPE,HDPVFTNOTE,HDPVIND,HFTNOTE,HLATITUDE,HLONGITUDE,HPRDATE,HURBCODE,HLACSADDRFLAG,HLACSFTNOTE,HLACSRTRNCODE,HADDRUPDATE,HADDRSECCODE,HADDRSRCCODE,ADDRTYPE3,WCUSTSTLINE1,WCUSTSTLINE2,WCUSTCITY,WCUSTSTATE,WCUSTZIPCODE,WCUSTCOUNTRY,WADDRTYPE,WDPVFTNOTE,WDPVIND,WFTNOTE,WLATITUDE,WLONGITUDE,WPRDATE,WURBCODE,WLACSADDRFLAG,WLACSFTNOTE,WLACSRTRNCODE,WADDRUPDATE,WADDRSECCODE,WADDRSRCCODE,HPHTYPE,HPHAREA,HPHNUMBER,HPHUPDATE,HPHSECCODE,HPHSRCCODE,CPHTYPE,CPHAREA,CPHNUMBER,CPHUPDATE,CPHSECCODE,CPHSRCCODE,WPHTYPE,WPHAREA,WPHNUMBER,WPHUPDATE,WPHSECCODE,WPHSRCCODE,GENDER,GENDERUPDATE,GENDERSECCODE,GENDERSRCCODE,PETIND,PETUPDATE,PETSECCODE,PETSRCCODE,DEATHIND,DEATHUPDATE,DEATHSECCODE,DEATHSRCCODE,LOCKIND,LOCKUPDATE,LOCKSECCODE,LOCKSRCCODE,STOREORIG,STOREIND,STOREUPDATE,STORESECCODE,STORESRCCODE,EESECRETCODE,EESECRETCODEUPDATE,EESECRETCODESECCODE,EESECRETCODESRCCODE,ENRLFORMID,ENRLFORMIDUPDATE,ENRLFORMIDSECCODE,ENRLFORMIDSRCCODE,EECARDNO,EECARDNOUPDATE,EECARDNOSECCODE,EECARDNOSRCCODE,PSCLROPTIN,PSCLROPTINUPDATE,PSCLROPTINSECCODE,PSCLROPTINSRCCCODE,LASTUPDATE from CDI_MMCA_CV_MEMBER where SRCCODE='"
					+ srcCode + "' and SRCID='" + srcId + "'";

			long st = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);

			loyaltymMemCv = this.jdbcTemplate.query(sql,
					new EnterpriseLoyaltyMemRowsMapper(sql, st));

			long et = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"Time taken:" + (et - st) + ":" + sql);

		} catch (DataAccessException we) {
			String msg = "Error while getting value from CDI_MMCA_CV_MEMBER table ";

			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());

		}

		return loyaltymMemCv;

	}

	/**
	 * This method is used to get the program details.
	 * 
	 * @param srcCode
	 * @param srcId
	 * @return
	 */
	public List<Map<String, Object>> getAllProgramsAndAttr(String srcCode,
			String srcId) {

		List<Map<String, Object>> resultSet = null;

		try {

			String sql = "select SRCCODE,SRCID,PROGRAMSTATUS,PROGRAMCODE,PROGRAMIDENT,PROGRAMSTARTDT,PROGRAMENDDT,PROGRAMLASTUPDATE,TRANDATE from CDI_PRGM_CV_MEMBER where SRCCODE='"
					+ srcCode + "' and SRCID='" + srcId + "'";
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);
			resultSet = this.jdbcTemplate.queryForList(sql);

		} catch (DataAccessException we) {
			String msg = "Error while getting value from CDI_PRGM_CV_LOYALTY table:   ";
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());
			// e.printStackTrace();
		}
		return resultSet;

	}

	/**
	 * This method is used to get the reference composite view from all source
	 * table
	 * 
	 * @param srcCode
	 * @param srcId
	 * @return
	 */
	public List<CustomerMasterEnterpriseSearch> getRefCompViewAllSrc(
			String srcCode, String srcId) {

		List<CustomerMasterEnterpriseSearch> list = null;

		try {

			String sql = "select PRSNSEQNO,SRCCODE,LASTNAME,FIRSTNAME,MIDDLENAME,SUFFIXNAME,GENDER,BIRTHDATE,PCUSTSTLINE1,PCUSTSTLINE2,PCUSTCITY,PCUSTSTATE,PCUSTZIPCODE,HPHAREA,HPHNUMBER,EMAIL1,EMAIL2,LASTUPDATE from REF_MEM_DEMO_ID where SRCCODE='"
					+ srcCode + "' and PRSNSEQNO='" + srcId + "'";

			long st = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);

			list = this.jdbcTemplateRef.query(sql,
					new EnterpriseRefMemRowsMapper(sql, st));

			long et = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"Time taken:" + (et - st) + ":" + sql);

		} catch (DataAccessException we) {
			String msg = "Error while getting value from REF_MEM_DEMO_ID table :";

			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());

		}

		return list;

	}

	/**
	 * This method is used to get the composite view.
	 * 
	 * @param eidSet
	 * @return
	 */
	public List<CustomerMasterEnterpriseSearch> getCompView(Set eidSet) {
		List<CustomerMasterEnterpriseSearch> list = null;
		String entRecNo = "";
		Iterator itr = eidSet.iterator();
		int i = 0;
		while (itr.hasNext()) {
			if (i == 0) {
				entRecNo = entRecNo + itr.next();
			} else {
				entRecNo = entRecNo + "," + itr.next();
			}

			i++;
		}
		try {
			String sql = "select ENTITYID,CVWTYPE,LASTNAME,FIRSTNAME,MIDDLENAME,PREFIXNAME,SUFFIXNAME,NAMEUPDATE,NAMSECCODE,NAMSRCCODE,BIRTHDATE,BIRTHUPDATE,BIRTHSECCODE,BIRTHSRCCODE,EMAILTYPE,EMAIL,EMAILUPDATE,EMAILSECCODE,EMAILSRCCODE,ADDRTYPE,PCUSTSTLINE1,PCUSTSTLINE2,PCUSTCITY,PCUSTSTATE,PCUSTZIPCODE,PCUSTCOUNTRY,PADDRTYPE,PDPVFTNOTE,PDPVIND,PFTNOTE,PLATITUDE,PLONGITUDE,PPRDATE,PURBCODE,PLACSADDRFLAG,PLACSFTNOTE,PLACSRTRNCODE,PNCOAACTCODE,PNCOAANKCODE,PNCOAMVDATE,PNCOAMVTYPE,PNCOANEWADDRFLG,PNCOANIXFTNOTE,PNCOAPRDATE,PNCOARTRNCODE,PADDRUPDATE,PADDRSECCODE,PADDRSRCCODE,ADDRTYPE2,HCUSTSTLINE1,HCUSTSTLINE2,HCUSTCITY,HCUSTSTATE,HCUSTZIPCODE,HCUSTCOUNTRY,HADDRTYPE,HDPVFTNOTE,HDPVIND,HFTNOTE,HLATITUDE,HLONGITUDE,HPRDATE,HURBCODE,HLACSADDRFLAG,HLACSFTNOTE,HLACSRTRNCODE,HADDRUPDATE,HADDRSECCODE,HADDRSRCCODE,ADDRTYPE3,WCUSTSTLINE1,WCUSTSTLINE2,WCUSTCITY,WCUSTSTATE,WCUSTZIPCODE,WCUSTCOUNTRY,WADDRTYPE,WDPVFTNOTE,WDPVIND,WFTNOTE,WLATITUDE,WLONGITUDE,WPRDATE,WURBCODE,WLACSADDRFLAG,WLACSFTNOTE,WLACSRTRNCODE,WADDRUPDATE,WADDRSECCODE,WADDRSRCCODE,HPHTYPE,HPHAREA,HPHNUMBER,HPHUPDATE,HPHSECCODE,HPHSRCCODE,CPHTYPE,CPHAREA,CPHNUMBER,CPHUPDATE,CPHSECCODE,CPHSRCCODE,WPHTYPE,WPHAREA,WPHNUMBER,WPHUPDATE,WPHSECCODE,WPHSRCCODE,GENDER,GENDERUPDATE,GENDERSECCODE,GENDERSRCCODE,PETIND,PETUPDATE,PETSECCODE,PETSRCCODE,DEATHIND,DEATHUPDATE,DEATHSECCODE,DEATHSRCCODE,LOCKIND,LOCKUPDATE,LOCKSECCODE,LOCKSRCCODE,STOREORIG,STOREIND,STOREUPDATE,STORESECCODE,STORESRCCODE,LASTUPDATE,HPHPRIORITY,CPHPRIORITY,WPHPRIORITY from CDI_EMCA_CV_ID where ENTITYID in ("
					+ entRecNo + ")";
			long st = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);
			list = this.jdbcTemplate.query(sql, new EnterpriseHippaRowsMapper(
					sql, st));
			long et = System.currentTimeMillis();
			getWalgreensLogger().log(LoggingFacility.DEBUG,
					"Time taken:" + (et - st) + ":" + sql);
		} catch (DataAccessException we) {
			String msg = "Error while getting value from cdi_emca_cv_id table with ENTITYID:"
					+ entRecNo;
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());
		}
		return list;
	}

	/**
	 * This method is used to get the linkage details.
	 * 
	 * @param eidSet
	 * @return
	 */
	public List<CustomerMasterLinkageVO> getLinkage(Set eidSet) {
		List<CustomerMasterLinkageVO> linkageMap = null;
		String entRecNo = "";
		Iterator itr = eidSet.iterator();
		int i = 0;
		while (itr.hasNext()) {
			if (i == 0) {
				entRecNo = entRecNo + itr.next();
			} else {
				entRecNo = entRecNo + "," + itr.next();
			}

			i++;
		}
		try {
			String sql = "select ENTITYID,SRCCODE,SRCID,MEMSTAT,TRANDATE,REFCODE,REFID from CDI_LINKAGE_CV_ID where ENTITYID in ("
					+ entRecNo + ")";
			getWalgreensLogger().log(LoggingFacility.DEBUG, sql);
			linkageMap = this.jdbcTemplate.query(sql,
					new CustomerMasterLinkageRowsMapper());

		} catch (DataAccessException we) {
			String msg = "Error while getting value from cdi_linkage_cv_id table with MEMRECNO:"
					+ entRecNo;
			msg = msg + we.getMessage();
			getWalgreensLogger().log(LoggingFacility.ERROR, msg);
			throw we;
		} catch (Exception e) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					"Error in fetching the data from DB :" + e.getMessage());
		}
		return linkageMap;
	}

	/**
	 * Referring to the WalgreensLog4JImpl
	 */
	private WalgreensLog4JImpl walgreensLogger;

	/**
	 * @return the walgreensLogger
	 */
	public WalgreensLog4JImpl getWalgreensLogger() {
		return walgreensLogger;
	}

	/**
	 * @param walgreensLogger
	 *            the walgreensLogger to set
	 */
	public void setWalgreensLogger(WalgreensLog4JImpl walgreensLogger) {
		this.walgreensLogger = walgreensLogger;
	}
}
