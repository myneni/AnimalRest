package com.walgreens.cdi.service.impl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterIcunmergeBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterIcunmergeService;
import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterIcunmergeRequest;


public class CustomerMasterIcunmergeService extends BaseService  implements ICustomerMasterIcunmergeService{
	
	private ICustomerMasterIcunmergeBO customerMasterIcunmergeBO;
	

	public boolean icunmergeCustomerMaster(CustomerMasterIcunmergeRequest customerMasterIcunmergeRequest) throws CDIException {
		try{
			return getcustomerMasterIcunmergeBO().icunmergeCustomerMaster(customerMasterIcunmergeRequest);
		} catch (CDIException e) {
			getWalgreensLogger().log(LoggingFacility.ERROR, e.getDetailMessage());
			if(e instanceof BusinessRuleViolationException){
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return false;
			}else{
	            e = ExceptionHandler.processServiceException(Domain.CUSTOMER_MASTER, e);
	            throw e;
			}
	    }		
	}


	/**
	 * @return the searchBO
	 */
	public ICustomerMasterIcunmergeBO getcustomerMasterIcunmergeBO() {
		return customerMasterIcunmergeBO;
	}


	/**
	 * @param searchBO the searchBO to set
	 */
	public void setCustomerMasterIcunmergeBO(ICustomerMasterIcunmergeBO customerMasterIcunmergeBO) {
		this.customerMasterIcunmergeBO = customerMasterIcunmergeBO;
	}
	

}
