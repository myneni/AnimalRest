package com.walgreens.cdi.vo;

/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author 
 * 
 */
public class CustomerMasterLookUpRequest {
 
	private String custFirstName;
	private String custLastName;
	private String custMiddleName;
	private String custSuffix;
	
	
	private String custBirthDttm;
	
	private String custEMail;
	
	private String custStreetLine1;
	private String custStreetLine2;
	private String custCity;
	private String custState;
	private String custZip;
	
	private  String custPhoneArea;
	private  String custPhoneNumber;
	
	//private  String refID;
	private  String minMatchScore;
	private  String maxResponseEntries;
	
	
	public String getCustBirthDttm() {
		return custBirthDttm;
	}
	public void setCustBirthDttm(String custBirthDttm) {
		this.custBirthDttm = custBirthDttm;
	}
	public String getCustCity() {
		return custCity;
	}
	public void setCustCity(String custCity) {
		this.custCity = custCity;
	}

	public String getCustEMail() {
		return custEMail;
	}
	public void setCustEMail(String custEMail) {
		this.custEMail = custEMail;
	}
	public String getCustFirstName() {
		return custFirstName;
	}
	public void setCustFirstName(String custFirstName) {
		this.custFirstName = custFirstName;
	}
	public String getCustLastName() {
		return custLastName;
	}
	public void setCustLastName(String custLastName) {
		this.custLastName = custLastName;
	}
	public String getCustPhoneArea() {
		return custPhoneArea;
	}
	public void setCustPhoneArea(String custPhoneArea) {
		this.custPhoneArea = custPhoneArea;
	}
	public String getCustPhoneNumber() {
		return custPhoneNumber;
	}
	public void setCustPhoneNumber(String custPhoneNumber) {
		this.custPhoneNumber = custPhoneNumber;
	}

	public String getCustState() {
		return custState;
	}
	public void setCustState(String custState) {
		this.custState = custState;
	}
	public String getCustStreetLine1() {
		return custStreetLine1;
	}
	public void setCustStreetLine1(String custStreetLine1) {
		this.custStreetLine1 = custStreetLine1;
	}
	public String getCustStreetLine2() {
		return custStreetLine2;
	}
	public void setCustStreetLine2(String custStreetLine2) {
		this.custStreetLine2 = custStreetLine2;
	}
	public String getCustZip() {
		return custZip;
	}
	public void setCustZip(String custZip) {
		this.custZip = custZip;
	}
	
	public String getMaxResponseEntries() {
		return maxResponseEntries;
	}
	public void setMaxResponseEntries(String maxResponseEntries) {
		this.maxResponseEntries = maxResponseEntries;
	}
	public String getMinMatchScore() {
		return minMatchScore;
	}
	public void setMinMatchScore(String minMatchScore) {
		this.minMatchScore = minMatchScore;
	}
	public String getCustMiddleName() {
		return custMiddleName;
	}
	public void setCustMiddleName(String custMiddleName) {
		this.custMiddleName = custMiddleName;
	}
	public String getCustSuffix() {
		return custSuffix;
	}
	public void setCustSuffix(String custSuffix) {
		this.custSuffix = custSuffix;
	}
	

	
}
