package com.walgreens.cdi.vo.customer.attr;
import com.walgreens.cdi.util.CustomerMasterConstants;


public class CustomerMasterOrigin extends CustomerMasterAttributeStatus{
	//	 (Customer Origin attribute)		
	private String originCode;				//String (0/1)	Composite customer OriginCode (provided by PictureCare Plus).
	private String storeIndicator;			//String (0/1)	Composite customer StoreIndicator (provided by PictureCare Plus).
	
	/**
	 * @return the originCode
	 */
	public String getOriginCode() {
		return originCode;
	}
	/**
	 * @param originCode the originCode to set
	 */
	public void setOriginCode(String custOriginCode) {
		this.originCode = custOriginCode;
	}
	/**
	 * @return the storeIndicator
	 */
	public String getStoreIndicator() {
		return storeIndicator;
	}
	/**
	 * @param storeIndicator the storeIndicator to set
	 */
	public void setStoreIndicator(String custStoreIndicator) {
		this.storeIndicator = custStoreIndicator;
	}
	
    public boolean isNull(){
		
		if(isNull(originCode)&& isNull(storeIndicator))
				return true;
		else
			return false;
	}
	
    private boolean isNull(String str){
    	if(str==null)
			return  true;
		if(str.equalsIgnoreCase("null")||str.equalsIgnoreCase(""))
			return true;
		else
			return false;
	}
	
	public String toString() {
		String str="";
		str = "\nOrigin:\n____________________________________\n"+
		      " OriginCode =" + originCode + "\n"+
			  " StoreIndicator   =" + storeIndicator + "\n" +
			  " lastUpdateDate    =" + getLastUpdateDate() + "\n"+
			  " securityClassCode   =" + getSecurityClassCode() + "\n" +
			  " sourceCode   =" + getSourceCode() + "\n" ;
		
					
         return str;
	}
	
	public String toCompString() {
		String str="";
		 str = CustomerMasterConstants.DELIMITE_ATTR +
		      CustomerMasterConstants.COMP_ATTR_NAME_CUSTORGN + CustomerMasterConstants.DELIMITE_FIELD +
		      	     originCode + CustomerMasterConstants.DELIMITE_FIELD +
					 storeIndicator + CustomerMasterConstants.DELIMITE_FIELD +
					 getLastUpdateDate() + CustomerMasterConstants.DELIMITE_FIELD +
					 getSecurityClassCode()+ CustomerMasterConstants.DELIMITE_FIELD +
					 getSourceCode() + CustomerMasterConstants.DELIMITE_FIELD ;
	
         return str;
	}
	
}
