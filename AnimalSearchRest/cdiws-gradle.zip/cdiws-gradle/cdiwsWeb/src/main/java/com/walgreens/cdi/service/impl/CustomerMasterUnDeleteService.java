package com.walgreens.cdi.service.impl;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterUnDeleteBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterUnDeleteService;
import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterUnDeleteRequest;

/**
 * This service class will handle any exception thrown from BO layer , or else
 * return the Undeletion status of EC member.
 * 
 * @author
 * 
 */

public class CustomerMasterUnDeleteService extends BaseService implements
		ICustomerMasterUnDeleteService {
	private ICustomerMasterUnDeleteBO customerMasterUnDeleteBO;

	/**
	 * This method calls the object customerMasterUnDeleteBO class for returning
	 * the status of the member.
	 * 
	 * @param customerMasterUnDeleteRequest
	 * @return boolean
	 * @throws CDIException
	 */
	public boolean unDeleteCustomerMaster(
			final CustomerMasterUnDeleteRequest customerMasterUnDeleteRequest)
			throws CDIException {
		try {
			return getcustomerMasterUnDeleteBO().unDeleteCustomerMaster(
					customerMasterUnDeleteRequest);
		} catch (CDIException e) {
			if (e instanceof BusinessRuleViolationException) {
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, e);
				return false;
			} else {
				getWalgreensLogger().log(LoggingFacility.ERROR,
						e.getDetailMessage());

				e = ExceptionHandler.processServiceException(
						Domain.CUSTOMER_MASTER, e);
				throw e;
			}
		}
	}

	/**
	 * @return the searchBO
	 */
	public ICustomerMasterUnDeleteBO getcustomerMasterUnDeleteBO() {
		return customerMasterUnDeleteBO;
	}

	/**
	 * @param searchBO
	 *            the searchBO to set
	 */
	public void setCustomerMasterUnDeleteBO(
			final ICustomerMasterUnDeleteBO customerMasterUnDeleteBO) {
		this.customerMasterUnDeleteBO = customerMasterUnDeleteBO;
	}
}
