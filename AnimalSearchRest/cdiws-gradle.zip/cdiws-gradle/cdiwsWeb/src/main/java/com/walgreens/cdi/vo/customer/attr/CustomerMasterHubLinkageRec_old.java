/**
 * 
 */
package com.walgreens.cdi.vo.customer.attr;

import java.util.ArrayList;

/**
 * @author Picketta
 *
 */
public class CustomerMasterHubLinkageRec_old {
	//	 (Linkage of CustEID to Cust Source Records)		
	private ArrayList hubLinkageArrayList;		//Array (1/n)	Linkage array, with occurrences for every active linkage
	/**
	 * For hubLinkageArrayList
	 * 0 = sourceID
	 * 1 = sourceCode
	 * 2 = status ("Active" or "Inactive")
	 */
	private String eid	;								//String (1/1)	Enterprise ID for the requested customer. 
	
	
	/**
	 * 
	 */
	public CustomerMasterHubLinkageRec_old() {
		super();
		hubLinkageArrayList = new ArrayList<String>();
		// TODO Auto-generated constructor stub
	}
	
	@SuppressWarnings("unchecked")
	public void addHubLinkageRecord(String sourceID, String sourceCode, String status){
		String[] linkageRec = {sourceID, sourceCode, status};
		this.hubLinkageArrayList.add(linkageRec);
	}

	/**
	 * @return the eid
	 */
	public String getEid() {
		return eid;
	}

	/**
	 * @param eid the eid to set
	 */
	public void setEid(String custEID) {
		this.eid = custEID;
	}

	/**
	 * @return the hubLinkageArrayList
	 */
	public ArrayList getHubLinkageArrayList() {
		return hubLinkageArrayList;
	}

	/**
	 * @param hubLinkageArrayList the hubLinkageArrayList to set
	 */
	public void setHubLinkageArrayList(ArrayList hubLinkageArrayList) {
		this.hubLinkageArrayList = hubLinkageArrayList;
	}
	
	
}
