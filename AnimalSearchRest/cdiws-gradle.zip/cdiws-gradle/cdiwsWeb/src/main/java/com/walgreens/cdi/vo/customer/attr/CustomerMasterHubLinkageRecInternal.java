/**
 * 
 */
package com.walgreens.cdi.vo.customer.attr;

import java.util.ArrayList;

/**
 * @author Picketta
 *
 */
public class CustomerMasterHubLinkageRecInternal {
	
	private ArrayList<CustomerMasterLinkageDetail> linkageDetail;	
	
	private String eid	;	
	
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public ArrayList<CustomerMasterLinkageDetail> getLinkageDetail() {
		return linkageDetail;
	}
	public void setLinkageDetail(ArrayList<CustomerMasterLinkageDetail> linkageDetail) {
		this.linkageDetail = linkageDetail;
	}
	
	public String toString() {
		String str="";
		str = "\nHubLinkageRec:\n____________________________________\n"+
		      " Eid    =" + eid + "\n";
		if( linkageDetail != null ) 
		{
			Object linkageDetailArray[] =linkageDetail.toArray();
		 
	        for(int i=0;i<linkageDetailArray.length;i++)
	    	  str= str+ i+ ":" +linkageDetailArray[i].toString();
	 	}
		else 
			str= str+ "no linkage \n";	
		
         return str;
	}
	
	public static void main(String[] args) {

	    //create an array list
	    ArrayList al = new ArrayList();
	
	    //Add elements to the array list
	    CustomerMasterLinkageDetail linkage1= new CustomerMasterLinkageDetail();
	    linkage1.setSourceCode("IC");
	    linkage1.setSourceID("111111");
	    linkage1.setRefID("222222");
	    linkage1.setStatus("A");
	    CustomerMasterLinkageDetail linkage2= new CustomerMasterLinkageDetail();
	    linkage2.setSourceCode("EC");
	    linkage2.setSourceID("555555");
	    linkage2.setRefID("66666666");
	    linkage2.setStatus("D");
	    CustomerMasterLinkageDetail linkage3= new CustomerMasterLinkageDetail();
	    linkage3.setSourceCode("PC");
	    linkage3.setSourceID("444444");
	    linkage3.setRefID("777777");
	    linkage3.setStatus("A");
	    al.add(linkage1);
	    al.add(linkage2);
	    al.add(linkage3);
	   

	  //  System.out.println("contents of al : "+ al );
	    Object ia[] = al.toArray();   //get array
	   	String str="";
	    System.out.println("arr length :" + ia.length +", size=" +  al.size()+ "\n");
	    for(int i=0;i<ia.length;i++)
	      str=str+ ia[i].toString() +"\n";

	    System.out.println("link :" + str);
	    
	  }

	} 
	
	
	
	

