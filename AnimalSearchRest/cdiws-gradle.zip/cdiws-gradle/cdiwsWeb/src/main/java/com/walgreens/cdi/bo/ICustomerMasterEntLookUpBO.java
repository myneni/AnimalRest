package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfEntCustomer;

public interface ICustomerMasterEntLookUpBO {
	
		public ArrayOfEntCustomer lookUpCustomerMasterEnt(CustomerMasterEntLookUpRequest customerMasterLookUpRequest) throws SystemException, BusinessRuleViolationException;

		

}
