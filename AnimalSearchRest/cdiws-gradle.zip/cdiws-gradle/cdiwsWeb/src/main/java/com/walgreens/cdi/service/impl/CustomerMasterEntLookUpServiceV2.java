package com.walgreens.cdi.service.impl;

import walgreens.services.LoggingFacility;

import com.walgreens.cdi.bo.ICustomerMasterEnterpriseLookUpBO;
import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.exception.ExceptionHandler;
import com.walgreens.cdi.service.ICustomerMasterEntLookUpServiceV2;
import com.walgreens.cdi.util.Domain;
import com.walgreens.cdi.vo.CustomerMasterEnterpriseLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfEnterpriseCustomer;

public class CustomerMasterEntLookUpServiceV2 extends BaseService
		implements ICustomerMasterEntLookUpServiceV2 {
	private ICustomerMasterEnterpriseLookUpBO customerMasterEnterpriseLookUpBO;
	/**
	 * This service is  exposing lookUpCustomerMasterEnterprise method at service
	 * level.
	 * 
	 * @param CustomerMasterEnterpriseLookUpRequest
	 * @return boolean
	 * @throws CDIException
	 * @author
	 * 
	 */
	public ArrayOfEnterpriseCustomer lookUpCustomerMasterEnterprise(
			CustomerMasterEnterpriseLookUpRequest customerMasterEnterpriseLookUpRequest)
			throws CDIException {

		ArrayOfEnterpriseCustomer arrayEntpriseCustomer = new ArrayOfEnterpriseCustomer();
		try {
			arrayEntpriseCustomer = getCustomerMasterEnterpriseLookUpBO()
					.lookUpCustomerMasterEnterprise(customerMasterEnterpriseLookUpRequest);
		} catch (CDIException exP) {
			getWalgreensLogger().log(LoggingFacility.ERROR,
					exP.getDetailMessage());
			if (exP instanceof BusinessRuleViolationException) {
				ExceptionHandler.processException(Domain.CUSTOMER_MASTER, exP);
				return null;
			} else {
				exP = ExceptionHandler.processServiceException(
						Domain.CUSTOMER_MASTER, exP);
				throw exP;
			}
		}
		return arrayEntpriseCustomer;
	}

	public ICustomerMasterEnterpriseLookUpBO getCustomerMasterEnterpriseLookUpBO() {
		return customerMasterEnterpriseLookUpBO;
	}

	public void setCustomerMasterEnterpriseLookUpBO(
			ICustomerMasterEnterpriseLookUpBO customerMasterEnterpriseLookUpBO) {
		this.customerMasterEnterpriseLookUpBO = customerMasterEnterpriseLookUpBO;
	}

	
}
