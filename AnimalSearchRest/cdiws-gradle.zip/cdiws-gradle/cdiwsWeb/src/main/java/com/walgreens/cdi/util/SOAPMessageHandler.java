package com.walgreens.cdi.util;

import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import javax.xml.soap.SOAPMessage;
import java.io.ByteArrayOutputStream;
import walgreens.services.LoggingFacility;
import walgreens.utils.logging.WalgreensLog4JImpl;
import com.walgreens.cdi.bo.impl.BaseBO;

public class SOAPMessageHandler extends BaseBO implements
		javax.xml.ws.handler.soap.SOAPHandler<SOAPMessageContext> {

	public void close(MessageContext messagecontext) {
	}

	public Set<QName> getHeaders() {
		return null;
	}

	public boolean handleFault(SOAPMessageContext messagecontext) {
		return true;
	}

	public boolean handleRequest(SOAPMessageContext messagecontext) {
		return true;
	}

	public boolean handleMessage(SOAPMessageContext messagecontext) {
		{

			if (messagecontext != null) {
				SOAPMessage msg = ((SOAPMessageContext) messagecontext)
						.getMessage();
				boolean outbound = (Boolean) messagecontext
						.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
				if (outbound) {
					(new WalgreensLog4JImpl()).log(LoggingFacility.DEBUG,
							"SOAP Response ");
					logSOAPMessage(msg, LoggingFacility.DEBUG);

				} else {
					(new WalgreensLog4JImpl()).log(LoggingFacility.INFO,
							"SOAP Request ");
					logSOAPMessage(msg, LoggingFacility.INFO);

				}
			}
		}
		return true;
	}

	private void logSOAPMessage(SOAPMessage msg, int loggingLevel) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			msg.writeTo(baos);
			// Log Enhancement change
			(new WalgreensLog4JImpl()).log(loggingLevel, baos.toString().replaceAll(CustomerMasterConstants.NEXT_LINE_DELIMITER, CustomerMasterConstants.SOAP_MESSAGE_DELIMITER));
		} catch (Exception ex) {
			(new WalgreensLog4JImpl()).log(LoggingFacility.ERROR, "ERROR in log SOAP message");
		}
	}

}