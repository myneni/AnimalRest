package com.walgreens.cdi.vo;

import java.util.List;

import com.walgreens.cdi.vo.customer.CustomerMaster;

public class CustomerMasterLookUpVO {
	
	private CustomerMaster cdiCustomer = new CustomerMaster();
	private String addCriteriaFlag;
	private static boolean pvSearchFlag=true;

	/**
	 * @return the cdiCustomer
	 */
	public CustomerMaster getCdiCustomer() {
		return cdiCustomer;
	}

	/**
	 * @param cdiCustomer the cdiCustomer to set
	 */
	public void setCdiCustomer(CustomerMaster cdiCustomer) {
		this.cdiCustomer = cdiCustomer;
	}

	public String getAddCriteriaFlag() {
		return addCriteriaFlag;
	}

	public void setAddCriteriaFlag(String addCriteriaFlag) {
		this.addCriteriaFlag = addCriteriaFlag;
	}
	/*
	long memRecNo;
	//List<LinkageSetVO> linkageList;
	String compView;	
	String entityID;    
	String cvwType;    //CVWTYPE                         VARCHAR2(2)
	String lName;    //LASTNAME                        VARCHAR2(75)
	String fName;    //FIRSTNAME	              VARCHAR2(30)
	String mName;    //MIDDLENAME	              VARCHAR2(30)
	String preName;    //PREFIXNAME	              VARCHAR2(10)
	String sufName;    //SUFFIXNAME	              VARCHAR2(10)
	String nameUpdate;    //NAMEUPDATE	              VARCHAR2(19)
	String nameSecCode;    //NAMSECCODE	              VARCHAR2(128)
	String namSrcCode;    //NAMSRCCODE	              VARCHAR2(12)
	String birthDate;    //BIRTHDATE	              VARCHAR2(19)
	String birthUpdate;    //BIRTHUPDATE	              VARCHAR2(19)
	String birthSecCode;    //BIRTHSECCODE 	VARCHAR2(128)
	String birthSrcCode;    //BIRTHSRCCODE	VARCHAR2(12)
	String emailType;    //EMAILTYPE	               VARCHAR2(1)
	String email;    //EMAIL	                             VARCHAR2(128)
	String emailUpdate;    //EMAILUPDATE	               VARCHAR2(19)
	String emailSecCode;    //EMAILSECCODE 	VARCHAR2(128)
	String emailSrcCode;    //EMAILSRCCODE	VARCHAR2(12)
	String addrType;    //ADDRTYPE	               VARCHAR2(1)
	String pCustStLine1;    //PCUSTSTLINE1	               VARCHAR2(75)
	String pCustStLine2;    //PCUSTSTLINE2	               VARCHAR2(75)
	String pCustCity;    //PCUSTCITY	               VARCHAR2(30)
	String pCustState;    //PCUSTSTATE	               VARCHAR2(15)
	String pCustZipCode;    //PCUSTZIPCODE	               VARCHAR2(11)
	String pCustCountry;    //PCUSTCOUNTRY	VARCHAR2(30)
	String pAddrType;    //PADDRTYPE	               VARCHAR2(1)
	String pdpvftNote;    //PDPVFTNOTE	               VARCHAR2(128)
	String pDpvInd;    //PDPVIND	               VARCHAR2(4)
	String pFtNote;    //PFTNOTE	               VARCHAR2(128)
	String pAltitude;    //PLATITUDE	               VARCHAR2(11)
	String pLongitude;    //PLONGITUDE	               VARCHAR2(11)
	String prDate;    //PPRDATE	               VARCHAR2(19)
	String pUrbCode;    //PURBCODE	               VARCHAR2(29)
	String pLacsAddrFlag;    //PLACSADDRFLAG	VARCHAR2(4)
	String pLacsFtNote;    //PLACSFTNOTE	               VARCHAR2(2)
	String pLacsRTRNCode;    //VARCHAR2(1)
	String pNcoaActCode;    //VARCHAR2(1)
	String pNcoaAnkCode;    //PNCOAANKCODE	VARCHAR2(2)
	String pNcoaMvDate;    //PNCOAMVDATE	               VARCHAR2(8)
	String pNcoaMvType;    //PNCOAMVTYPE	               VARCHAR2(1)
	String pNncoaNewAddrFlg;    // PNCOANEWADDRFLG	VARCHAR2(4)
	String pNcoaNixFtNote;    //PNCOANIXFTNOTE	VARCHAR2(2)
	String pNCoaPrDate;    //PNCOAPRDATE	              VARCHAR2(30)
	String pNcoaTrnCode;    //PNCOARTRNCODE	VARCHAR2(1)
	String pAddrUpdate;    //PADDRUPDATE	               VARCHAR2(19)
	String pAddrSecCode;    //PADDRSECCODE	VARCHAR2(128)
	String pAddrSrcCode;    //PADDRSRCCODE	VARCHAR2(12)
	String pAddrType2;    //ADDRTYPE2            	VARCHAR2(1)  
	String hCustStLine1;    //HCUSTSTLINE1	              VARCHAR2(75)
	String hCustLine2;    //HCUSTSTLINE2	              VARCHAR2(75)
	String hCustCity;    // HCUSTCITY	              VARCHAR2(30)
	String hCustState;    //HCUSTSTATE	              VARCHAR2(15)
	String hCustZipCode;    // HCUSTZIPCODE 	VARCHAR2(11)
	String hCustCountry;    //HCUSTCOUNTRY	VARCHAR2(30)
	String hAddrType;    // HADDRTYPE	               VARCHAR2(1)
	String hDpvFtNote;    // HDPVFTNOTE	               VARCHAR2(128)
	String hDpvInd;    // HDPVIND	               VARCHAR2(4)
	String hftNote;    // HFTNOTE	               VARCHAR2(128)
	String hAltitude;    // HLATITUDE	               VARCHAR2(11)
	String hLongitude;    // HLONGITUDE	               VARCHAR2(11)
	String hPrDate;    //HPRDATE	               VARCHAR2(30)
	String hUrbCode;    //HURBCODE	               VARCHAR2(29)
	String hLacsAddrFlag;    // HLACSADDRFLAG	VARCHAR2(4)
	String hLacsFtNote;    // HLACSFTNOTE	               VARCHAR2(2)
	String hLacsRtrnCode;    //HLACSRTRNCODE	VARCHAR2(1)
	String hAddrUpdate;    //HADDRUPDATE	               VARCHAR2(19)
	String hAddrSecCode;    //HADDRSECCODE	VARCHAR2(128)
	String hAddrSrcCode;    // HADDRSRCCODE	VARCHAR2(12)
	String addrType3;    // ADDRTYPE3	               VARCHAR2(1)
	String wCustStLine1;    //WCUSTSTLINE1	               VARCHAR2(75)
	String wCustStLine2;    // WCUSTSTLINE2	               VARCHAR2(75)
	String wCustCity;    // WCUSTCITY	               VARCHAR2(30)
	String wCustState;    // WCUSTSTATE	              VARCHAR2(15)
	String wCustZipCode;    //WCUSTZIPCODE	VARCHAR2(11)
	String wCustCountry;    //WCUSTCOUNTRY	VARCHAR2(30)
	String wAddrType;    // WADDRTYPE	               VARCHAR2(1)
	String wDpvFtNote;    // WDPVFTNOTE	               VARCHAR2(128)
	String wDpvInd;    // WDPVIND	               VARCHAR2(4)
	String wFtNote;    // WFTNOTE	               VARCHAR2(128)
	String wLattitude;    //WLATITUDE	               VARCHAR2(11)
	String wLongitude;    //WLONGITUDE	               VARCHAR2(11)
	String wPrDate;    //WPRDATE	               VARCHAR2(30)
	String wUrbCode;    //WURBCODE	               VARCHAR2(29)
	String wLacsAddrFlag;    // ;    //WLACSADDRFLAG	VARCHAR2(4)
	String wLacsFtNote;    // WLACSFTNOTE	               VARCHAR2(2)
	String wLacsRtrnCode;    //WLACSRTRNCODE	VARCHAR2(1)
	String wAddrUpdate;    //WADDRUPDATE 	VARCHAR2(19)
	String wAddrSecCode;    //WADDRSECCODE	VARCHAR2(128)
	String wAddrSrcCode;    //WADDRSRCCODE	VARCHAR2(12)
	String hPhType;    // HPHTYPE	               VARCHAR2(1)
	String hPhArea;    //HPHAREA	               VARCHAR2(5)
	String hPhNumber;    //HPHNUMBER	               VARCHAR2(20)
	String hPhUpdate;    //HPHUPDATE	               VARCHAR2(19)
	String hPhSecCode;    // HPHSECCODE	               VARCHAR2(128)
	String hPhSrcCode;    // HPHSRCCODE	               VARCHAR2(12)
	String cPhType;    // HPHTYPE	               VARCHAR2(1)
	String cPhArea;    //HPHAREA	               VARCHAR2(5)
	String cPhNumber;    //HPHNUMBER	               VARCHAR2(20)
	String cPhUpdate;    //HPHUPDATE	               VARCHAR2(19)
	String cPhSecCode;    // HPHSECCODE	               VARCHAR2(128)
	String cPhSrcCode;    // HPHSRCCODE	               VARCHAR2(12)
	String wPhType;    // HPHTYPE	               VARCHAR2(1)
	String wPhArea;    //HPHAREA	               VARCHAR2(5)
	String wPhNumber;    //HPHNUMBER	               VARCHAR2(20)
	String wPhUpdate;    //HPHUPDATE	               VARCHAR2(19)
	String wPhSecCode;    // HPHSECCODE	               VARCHAR2(128)
	String wPhSrcCode;    // HPHSRCCODE	               VARCHAR2(12)
	String gender;    //	               VARCHAR2(128)
	String genderUpdate;    //GENDERUPDATE	VARCHAR2(19)
	String genderSecCode;    //GENDERSECCODE	VARCHAR2(128)
	String genderSrcCode;    //GENDERSRCCODE	VARCHAR2(12)
	String petInd;    //PETIND	                             VARCHAR2(128)
	String petUpdate;    //PETUPDATE	               VARCHAR2(19)
	String petSecCode;    //PETSECCODE	               VARCHAR2(128)
	String petSrcCode;    // PETSRCCODE	               VARCHAR2(12)
	String deathInd;    // //DEATHIND	               VARCHAR2(128)
	String deathUpdate;    // //DEATHUPDATE 	               VARCHAR2(19)
	String deathSecCode;    ////DEATHSECCODE	VARCHAR2(128)
	String deathSrcCode;    //DEATHSRCCODE	VARCHAR2(12)
	String lockInd;    //LOCKIND	               VARCHAR2(128)
	String lockUpdate;    //LOCKUPDATE 	               VARCHAR2(19)
	String lockSecCode;    // LOCKSECCODE	               VARCHAR2(128)
	String lockSrcCode;    // LOCKSRCCODE	               VARCHAR2(12)
	String storeOrig;    // STOREORIG	               VARCHAR2(50)
	String storeInd;    // STOREIND	               VARCHAR2(50)
	String storeUpdate;    //STOREUPDATE 	               VARCHAR2(19)
	String storeSecCode;    //STORESECCODE	VARCHAR2(128)
	String storeSrcCode;    //STORESRCCODE	VARCHAR2(12)
	String linkageSet;    //LINKAGESET                     VARCHAR2(4000)
	String lastUpdate;    //LASTUPDATE                    VARCHAR2(2) 

	public String getCompView() {
		return compView;    
	}
	public void setCompView(String compView) {
		this.compView = compView;   
	}
	public long getMemRecNo() {
		return memRecNo;    
	}
	public void setMemRecNo(long memRecNo) {
		this.memRecNo = memRecNo;    
	}
	public String getAddrType() {
		return addrType;
	}
	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}
	public String getAddrType3() {
		return addrType3;
	}
	public void setAddrType3(String addrType3) {
		this.addrType3 = addrType3;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getBirthSecCode() {
		return birthSecCode;
	}
	public void setBirthSecCode(String birthSecCode) {
		this.birthSecCode = birthSecCode;
	}
	public String getBirthSrcCode() {
		return birthSrcCode;
	}
	public void setBirthSrcCode(String birthSrcCode) {
		this.birthSrcCode = birthSrcCode;
	}
	public String getBirthUpdate() {
		return birthUpdate;
	}
	public void setBirthUpdate(String birthUpdate) {
		this.birthUpdate = birthUpdate;
	}
	public String getCPhArea() {
		return cPhArea;
	}
	public void setCPhArea(String phArea) {
		cPhArea = phArea;
	}
	public String getCPhNumber() {
		return cPhNumber;
	}
	public void setCPhNumber(String phNumber) {
		cPhNumber = phNumber;
	}
	public String getCPhSecCode() {
		return cPhSecCode;
	}
	public void setCPhSecCode(String phSecCode) {
		cPhSecCode = phSecCode;
	}
	public String getCPhSrcCode() {
		return cPhSrcCode;
	}
	public void setCPhSrcCode(String phSrcCode) {
		cPhSrcCode = phSrcCode;
	}
	public String getCPhType() {
		return cPhType;
	}
	public void setCPhType(String phType) {
		cPhType = phType;
	}
	public String getCPhUpdate() {
		return cPhUpdate;
	}
	public void setCPhUpdate(String phUpdate) {
		cPhUpdate = phUpdate;
	}
	public String getCvwType() {
		return cvwType;
	}
	public void setCvwType(String cvwType) {
		this.cvwType = cvwType;
	}
	public String getDeathInd() {
		return deathInd;
	}
	public void setDeathInd(String deathInd) {
		this.deathInd = deathInd;
	}
	public String getDeathSecCode() {
		return deathSecCode;
	}
	public void setDeathSecCode(String deathSecCode) {
		this.deathSecCode = deathSecCode;
	}
	public String getDeathSrcCode() {
		return deathSrcCode;
	}
	public void setDeathSrcCode(String deathSrcCode) {
		this.deathSrcCode = deathSrcCode;
	}
	public String getDeathUpdate() {
		return deathUpdate;
	}
	public void setDeathUpdate(String deathUpdate) {
		this.deathUpdate = deathUpdate;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmailSecCode() {
		return emailSecCode;
	}
	public void setEmailSecCode(String emailSecCode) {
		this.emailSecCode = emailSecCode;
	}
	public String getEmailSrcCode() {
		return emailSrcCode;
	}
	public void setEmailSrcCode(String emailSrcCode) {
		this.emailSrcCode = emailSrcCode;
	}
	public String getEmailType() {
		return emailType;
	}
	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}
	public String getEmailUpdate() {
		return emailUpdate;
	}
	public void setEmailUpdate(String emailUpdate) {
		this.emailUpdate = emailUpdate;
	}
	public String getFName() {
		return fName;
	}
	public void setFName(String name) {
		fName = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getGenderSecCode() {
		return genderSecCode;
	}
	public void setGenderSecCode(String genderSecCode) {
		this.genderSecCode = genderSecCode;
	}
	public String getGenderSrcCode() {
		return genderSrcCode;
	}
	public void setGenderSrcCode(String genderSrcCode) {
		this.genderSrcCode = genderSrcCode;
	}
	public String getGenderUpdate() {
		return genderUpdate;
	}
	public void setGenderUpdate(String genderUpdate) {
		this.genderUpdate = genderUpdate;
	}
	public String getHAddrSecCode() {
		return hAddrSecCode;
	}
	public void setHAddrSecCode(String addrSecCode) {
		hAddrSecCode = addrSecCode;
	}
	public String getHAddrSrcCode() {
		return hAddrSrcCode;
	}
	public void setHAddrSrcCode(String addrSrcCode) {
		hAddrSrcCode = addrSrcCode;
	}
	public String getHAddrType() {
		return hAddrType;
	}
	public void setHAddrType(String addrType) {
		hAddrType = addrType;
	}
	public String getHAddrUpdate() {
		return hAddrUpdate;
	}
	public void setHAddrUpdate(String addrUpdate) {
		hAddrUpdate = addrUpdate;
	}
	public String getHAltitude() {
		return hAltitude;
	}
	public void setHAltitude(String altitude) {
		hAltitude = altitude;
	}
	public String getHCustCity() {
		return hCustCity;
	}
	public void setHCustCity(String custCity) {
		hCustCity = custCity;
	}
	public String getHCustCountry() {
		return hCustCountry;
	}
	public void setHCustCountry(String custCountry) {
		hCustCountry = custCountry;
	}
	public String getHCustLine2() {
		return hCustLine2;
	}
	public void setHCustLine2(String custLine2) {
		hCustLine2 = custLine2;
	}
	public String getHCustState() {
		return hCustState;
	}
	public void setHCustState(String custState) {
		hCustState = custState;
	}
	public String getHCustStLine1() {
		return hCustStLine1;
	}
	public void setHCustStLine1(String custStLine1) {
		hCustStLine1 = custStLine1;
	}
	public String getHCustZipCode() {
		return hCustZipCode;
	}
	public void setHCustZipCode(String custZipCode) {
		hCustZipCode = custZipCode;
	}
	public String getHDpvFtNote() {
		return hDpvFtNote;
	}
	public void setHDpvFtNote(String dpvFtNote) {
		hDpvFtNote = dpvFtNote;
	}
	public String getHDpvInd() {
		return hDpvInd;
	}
	public void setHDpvInd(String dpvInd) {
		hDpvInd = dpvInd;
	}
	public String getHftNote() {
		return hftNote;
	}
	public void setHftNote(String hftNote) {
		this.hftNote = hftNote;
	}
	public String getHLacsAddrFlag() {
		return hLacsAddrFlag;
	}
	public void setHLacsAddrFlag(String lacsAddrFlag) {
		hLacsAddrFlag = lacsAddrFlag;
	}
	public String getHLacsFtNote() {
		return hLacsFtNote;
	}
	public void setHLacsFtNote(String lacsFtNote) {
		hLacsFtNote = lacsFtNote;
	}
	public String getHLacsRtrnCode() {
		return hLacsRtrnCode;
	}
	public void setHLacsRtrnCode(String lacsRtrnCode) {
		hLacsRtrnCode = lacsRtrnCode;
	}
	public String getHLongitude() {
		return hLongitude;
	}
	public void setHLongitude(String longitude) {
		hLongitude = longitude;
	}
	public String getHPhArea() {
		return hPhArea;
	}
	public void setHPhArea(String phArea) {
		hPhArea = phArea;
	}
	public String getHPhNumber() {
		return hPhNumber;
	}
	public void setHPhNumber(String phNumber) {
		hPhNumber = phNumber;
	}
	public String getHPhSecCode() {
		return hPhSecCode;
	}
	public void setHPhSecCode(String phSecCode) {
		hPhSecCode = phSecCode;
	}
	public String getHPhSrcCode() {
		return hPhSrcCode;
	}
	public void setHPhSrcCode(String phSrcCode) {
		hPhSrcCode = phSrcCode;
	}
	public String getHPhType() {
		return hPhType;
	}
	public void setHPhType(String phType) {
		hPhType = phType;
	}
	public String getHPhUpdate() {
		return hPhUpdate;
	}
	public void setHPhUpdate(String phUpdate) {
		hPhUpdate = phUpdate;
	}
	public String getHPrDate() {
		return hPrDate;
	}
	public void setHPrDate(String prDate) {
		hPrDate = prDate;
	}
	public String getHUrbCode() {
		return hUrbCode;
	}
	public void setHUrbCode(String urbCode) {
		hUrbCode = urbCode;
	}
	public String getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	public String getLinkageSet() {
		return linkageSet;
	}
	public void setLinkageSet(String linkageSet) {
		this.linkageSet = linkageSet;
	}
	public String getLName() {
		return lName;
	}
	public void setLName(String name) {
		lName = name;
	}
	public String getLockInd() {
		return lockInd;
	}
	public void setLockInd(String lockInd) {
		this.lockInd = lockInd;
	}
	public String getLockSecCode() {
		return lockSecCode;
	}
	public void setLockSecCode(String lockSecCode) {
		this.lockSecCode = lockSecCode;
	}
	public String getLockSrcCode() {
		return lockSrcCode;
	}
	public void setLockSrcCode(String lockSrcCode) {
		this.lockSrcCode = lockSrcCode;
	}
	public String getLockUpdate() {
		return lockUpdate;
	}
	public void setLockUpdate(String lockUpdate) {
		this.lockUpdate = lockUpdate;
	}
	public String getMName() {
		return mName;
	}
	public void setMName(String name) {
		mName = name;
	}
	public String getNameSecCode() {
		return nameSecCode;
	}
	public void setNameSecCode(String nameSecCode) {
		this.nameSecCode = nameSecCode;
	}
	public String getNameUpdate() {
		return nameUpdate;
	}
	public void setNameUpdate(String nameUpdate) {
		this.nameUpdate = nameUpdate;
	}
	public String getNamSrcCode() {
		return namSrcCode;
	}
	public void setNamSrcCode(String namSrcCode) {
		this.namSrcCode = namSrcCode;
	}
	public String getPAddrSecCode() {
		return pAddrSecCode;
	}
	public void setPAddrSecCode(String addrSecCode) {
		pAddrSecCode = addrSecCode;
	}
	public String getPAddrSrcCode() {
		return pAddrSrcCode;
	}
	public void setPAddrSrcCode(String addrSrcCode) {
		pAddrSrcCode = addrSrcCode;
	}
	public String getPAddrType() {
		return pAddrType;
	}
	public void setPAddrType(String addrType) {
		pAddrType = addrType;
	}
	public String getPAddrType2() {
		return pAddrType2;
	}
	public void setPAddrType2(String addrType2) {
		pAddrType2 = addrType2;
	}
	public String getPAddrUpdate() {
		return pAddrUpdate;
	}
	public void setPAddrUpdate(String addrUpdate) {
		pAddrUpdate = addrUpdate;
	}
	public String getPAltitude() {
		return pAltitude;
	}
	public void setPAltitude(String altitude) {
		pAltitude = altitude;
	}
	public String getPCustCity() {
		return pCustCity;
	}
	public void setPCustCity(String custCity) {
		pCustCity = custCity;
	}
	public String getPCustCountry() {
		return pCustCountry;
	}
	public void setPCustCountry(String custCountry) {
		pCustCountry = custCountry;
	}
	public String getPCustState() {
		return pCustState;
	}
	public void setPCustState(String custState) {
		pCustState = custState;
	}
	public String getPCustStLine1() {
		return pCustStLine1;
	}
	public void setPCustStLine1(String custStLine1) {
		pCustStLine1 = custStLine1;
	}
	public String getPCustStLine2() {
		return pCustStLine2;
	}
	public void setPCustStLine2(String custStLine2) {
		pCustStLine2 = custStLine2;
	}
	public String getPCustZipCode() {
		return pCustZipCode;
	}
	public void setPCustZipCode(String custZipCode) {
		pCustZipCode = custZipCode;
	}
	public String getPdpvftNote() {
		return pdpvftNote;
	}
	public void setPdpvftNote(String pdpvftNote) {
		this.pdpvftNote = pdpvftNote;
	}
	public String getPDpvInd() {
		return pDpvInd;
	}
	public void setPDpvInd(String dpvInd) {
		pDpvInd = dpvInd;
	}
	public String getPetInd() {
		return petInd;
	}
	public void setPetInd(String petInd) {
		this.petInd = petInd;
	}
	public String getPetSecCode() {
		return petSecCode;
	}
	public void setPetSecCode(String petSecCode) {
		this.petSecCode = petSecCode;
	}
	public String getPetSrcCode() {
		return petSrcCode;
	}
	public void setPetSrcCode(String petSrcCode) {
		this.petSrcCode = petSrcCode;
	}
	public String getPetUpdate() {
		return petUpdate;
	}
	public void setPetUpdate(String petUpdate) {
		this.petUpdate = petUpdate;
	}
	public String getPFtNote() {
		return pFtNote;
	}
	public void setPFtNote(String ftNote) {
		pFtNote = ftNote;
	}
	public String getPLacsAddrFlag() {
		return pLacsAddrFlag;
	}
	public void setPLacsAddrFlag(String lacsAddrFlag) {
		pLacsAddrFlag = lacsAddrFlag;
	}
	public String getPLacsFtNote() {
		return pLacsFtNote;
	}
	public void setPLacsFtNote(String lacsFtNote) {
		pLacsFtNote = lacsFtNote;
	}
	public String getPLacsRTRNCode() {
		return pLacsRTRNCode;
	}
	public void setPLacsRTRNCode(String lacsRTRNCode) {
		pLacsRTRNCode = lacsRTRNCode;
	}
	public String getPLongitude() {
		return pLongitude;
	}
	public void setPLongitude(String longitude) {
		pLongitude = longitude;
	}
	public String getPNcoaActCode() {
		return pNcoaActCode;
	}
	public void setPNcoaActCode(String ncoaActCode) {
		pNcoaActCode = ncoaActCode;
	}
	public String getPNcoaAnkCode() {
		return pNcoaAnkCode;
	}
	public void setPNcoaAnkCode(String ncoaAnkCode) {
		pNcoaAnkCode = ncoaAnkCode;
	}
	public String getPNcoaMvDate() {
		return pNcoaMvDate;
	}
	public void setPNcoaMvDate(String ncoaMvDate) {
		pNcoaMvDate = ncoaMvDate;
	}
	public String getPNcoaMvType() {
		return pNcoaMvType;
	}
	public void setPNcoaMvType(String ncoaMvType) {
		pNcoaMvType = ncoaMvType;
	}
	public String getPNcoaNixFtNote() {
		return pNcoaNixFtNote;
	}
	public void setPNcoaNixFtNote(String ncoaNixFtNote) {
		pNcoaNixFtNote = ncoaNixFtNote;
	}
	public String getPNCoaPrDate() {
		return pNCoaPrDate;
	}
	public void setPNCoaPrDate(String coaPrDate) {
		pNCoaPrDate = coaPrDate;
	}
	public String getPNcoaTrnCode() {
		return pNcoaTrnCode;
	}
	public void setPNcoaTrnCode(String ncoaTrnCode) {
		pNcoaTrnCode = ncoaTrnCode;
	}
	public String getPNncoaNewAddrFlg() {
		return pNncoaNewAddrFlg;
	}
	public void setPNncoaNewAddrFlg(String nncoaNewAddrFlg) {
		pNncoaNewAddrFlg = nncoaNewAddrFlg;
	}
	public String getPrDate() {
		return prDate;
	}
	public void setPrDate(String prDate) {
		this.prDate = prDate;
	}
	public String getPreName() {
		return preName;
	}
	public void setPreName(String preName) {
		this.preName = preName;
	}
	public String getPUrbCode() {
		return pUrbCode;
	}
	public void setPUrbCode(String urbCode) {
		pUrbCode = urbCode;
	}
	public String getStoreInd() {
		return storeInd;
	}
	public void setStoreInd(String storeInd) {
		this.storeInd = storeInd;
	}
	public String getStoreOrig() {
		return storeOrig;
	}
	public void setStoreOrig(String storeOrig) {
		this.storeOrig = storeOrig;
	}
	public String getStoreSecCode() {
		return storeSecCode;
	}
	public void setStoreSecCode(String storeSecCode) {
		this.storeSecCode = storeSecCode;
	}
	public String getStoreSrcCode() {
		return storeSrcCode;
	}
	public void setStoreSrcCode(String storeSrcCode) {
		this.storeSrcCode = storeSrcCode;
	}
	public String getStoreUpdate() {
		return storeUpdate;
	}
	public void setStoreUpdate(String storeUpdate) {
		this.storeUpdate = storeUpdate;
	}
	public String getSufName() {
		return sufName;
	}
	public void setSufName(String sufName) {
		this.sufName = sufName;
	}
	public String getWAddrSecCode() {
		return wAddrSecCode;
	}
	public void setWAddrSecCode(String addrSecCode) {
		wAddrSecCode = addrSecCode;
	}
	public String getWAddrSrcCode() {
		return wAddrSrcCode;
	}
	public void setWAddrSrcCode(String addrSrcCode) {
		wAddrSrcCode = addrSrcCode;
	}
	public String getWAddrType() {
		return wAddrType;
	}
	public void setWAddrType(String addrType) {
		wAddrType = addrType;
	}
	public String getWAddrUpdate() {
		return wAddrUpdate;
	}
	public void setWAddrUpdate(String addrUpdate) {
		wAddrUpdate = addrUpdate;
	}
	public String getWCustCity() {
		return wCustCity;
	}
	public void setWCustCity(String custCity) {
		wCustCity = custCity;
	}
	public String getWCustCountry() {
		return wCustCountry;
	}
	public void setWCustCountry(String custCountry) {
		wCustCountry = custCountry;
	}
	public String getWCustState() {
		return wCustState;
	}
	public void setWCustState(String custState) {
		wCustState = custState;
	}
	public String getWCustStLine1() {
		return wCustStLine1;
	}
	public void setWCustStLine1(String custStLine1) {
		wCustStLine1 = custStLine1;
	}
	public String getWCustStLine2() {
		return wCustStLine2;
	}
	public void setWCustStLine2(String custStLine2) {
		wCustStLine2 = custStLine2;
	}
	public String getWCustZipCode() {
		return wCustZipCode;
	}
	public void setWCustZipCode(String custZipCode) {
		wCustZipCode = custZipCode;
	}
	public String getWDpvFtNote() {
		return wDpvFtNote;
	}
	public void setWDpvFtNote(String dpvFtNote) {
		wDpvFtNote = dpvFtNote;
	}
	public String getWDpvInd() {
		return wDpvInd;
	}
	public void setWDpvInd(String dpvInd) {
		wDpvInd = dpvInd;
	}
	public String getWFtNote() {
		return wFtNote;
	}
	public void setWFtNote(String ftNote) {
		wFtNote = ftNote;
	}
	public String getWLacsAddrFlag() {
		return wLacsAddrFlag;
	}
	public void setWLacsAddrFlag(String lacsAddrFlag) {
		wLacsAddrFlag = lacsAddrFlag;
	}
	public String getWLacsFtNote() {
		return wLacsFtNote;
	}
	public void setWLacsFtNote(String lacsFtNote) {
		wLacsFtNote = lacsFtNote;
	}
	public String getWLacsRtrnCode() {
		return wLacsRtrnCode;
	}
	public void setWLacsRtrnCode(String lacsRtrnCode) {
		wLacsRtrnCode = lacsRtrnCode;
	}
	public String getWLattitude() {
		return wLattitude;
	}
	public void setWLattitude(String lattitude) {
		wLattitude = lattitude;
	}
	public String getWLongitude() {
		return wLongitude;
	}
	public void setWLongitude(String longitude) {
		wLongitude = longitude;
	}
	public String getWPhArea() {
		return wPhArea;
	}
	public void setWPhArea(String phArea) {
		wPhArea = phArea;
	}
	public String getWPhNumber() {
		return wPhNumber;
	}
	public void setWPhNumber(String phNumber) {
		wPhNumber = phNumber;
	}
	public String getWPhSecCode() {
		return wPhSecCode;
	}
	public void setWPhSecCode(String phSecCode) {
		wPhSecCode = phSecCode;
	}
	public String getWPhSrcCode() {
		return wPhSrcCode;
	}
	public void setWPhSrcCode(String phSrcCode) {
		wPhSrcCode = phSrcCode;
	}
	public String getWPhType() {
		return wPhType;
	}
	public void setWPhType(String phType) {
		wPhType = phType;
	}
	public String getWPhUpdate() {
		return wPhUpdate;
	}
	public void setWPhUpdate(String phUpdate) {
		wPhUpdate = phUpdate;
	}
	public String getWPrDate() {
		return wPrDate;
	}
	public void setWPrDate(String prDate) {
		wPrDate = prDate;
	}
	public String getWUrbCode() {
		return wUrbCode;
	}
	public void setWUrbCode(String urbCode) {
		wUrbCode = urbCode;
	}
	public String getEntityID() {
		return entityID;
	}
	public void setEntityID(String entityID) {
		this.entityID = entityID;
	}
	*/

	public static boolean isPvSearchFlag() {
		return pvSearchFlag;
	}

	public static void setPvSearchFlag(boolean pvSearchFlag) {
		CustomerMasterLookUpVO.pvSearchFlag = pvSearchFlag;
	}

}
