package com.walgreens.cdi.vo;

import java.util.ArrayList;

public class CustomerMasterEntMemberIdGenerateResponse {

	private ArrayList<CustomerMasterEntMemberIdGenerateSequence> progCodeResponseArray = new ArrayList<CustomerMasterEntMemberIdGenerateSequence>();

	public ArrayList<CustomerMasterEntMemberIdGenerateSequence> getProgCodeReponseArray() {
		return progCodeResponseArray;
	}

	public void setProgCodeReponseArray(
			ArrayList<CustomerMasterEntMemberIdGenerateSequence> progCodeReponseArray) {
		this.progCodeResponseArray = progCodeReponseArray;
	}

}
