package com.walgreens.cdi.vo;

import java.util.ArrayList;

/**
 * This class would contain all the attributes required to send the Request to
 * the Initiate HUB and get the response back
 * 
 * @author psrivakf
 * 
 */
public class CustomerMasterEnterpriseUpdateResponse {

	private String memIdNum;
	private String memStat;
	private String status;

	private ArrayList<CustomerMasterEnterpriseProgramVO> custProgIdArray = new ArrayList<CustomerMasterEnterpriseProgramVO>();
	private ArrayList<CustomerMasterEnterpriseAttributesVO> custArrayOfAttributes = new ArrayList<CustomerMasterEnterpriseAttributesVO>();

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ArrayList<CustomerMasterEnterpriseProgramVO> getCustProgIdArray() {
		return custProgIdArray;
	}

	public void setCustProgIdArray(
			ArrayList<CustomerMasterEnterpriseProgramVO> custProgIdArray) {
		this.custProgIdArray = custProgIdArray;
	}

	public ArrayList<CustomerMasterEnterpriseAttributesVO> getCustArrayOfAttributes() {
		return custArrayOfAttributes;
	}

	public void setCustArrayOfAttributes(
			ArrayList<CustomerMasterEnterpriseAttributesVO> custArrayOfAttributes) {
		this.custArrayOfAttributes = custArrayOfAttributes;
	}

	public String getMemIdNum() {
		return memIdNum;
	}

	public void setMemIdNum(String memIdNum) {
		this.memIdNum = memIdNum;
	}

	public String getMemStat() {
		return memStat;
	}

	public void setMemStat(String memStat) {
		this.memStat = memStat;
	}

}
