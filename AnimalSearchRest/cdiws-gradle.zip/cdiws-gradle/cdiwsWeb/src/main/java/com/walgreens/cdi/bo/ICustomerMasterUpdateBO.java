package com.walgreens.cdi.bo;

import com.walgreens.cdi.exception.BusinessRuleViolationException;
import com.walgreens.cdi.exception.SystemException;
import com.walgreens.cdi.vo.CustomerMasterUpdateRequest;
/**
 * This bo is an interface for exposing updateCustomerMaster and validateRequestObject at BO level.
 * 
 *
 */
public interface ICustomerMasterUpdateBO {

	/**
	 * This method would have  logic for Insert/Update Member.
	 * Implementation will be done in Implementation class
	 */
	public boolean updateCustomerMaster(
			CustomerMasterUpdateRequest customerMasterUpdateRequest)
			throws SystemException, BusinessRuleViolationException;

	
	/**
	 * This method would have validation logic for Insert/Update Member.
	 * Implementation will be done in Implementation class
	 */
	public void validateRequestObject(
			CustomerMasterUpdateRequest customerMasterUpdateRequest)
			throws BusinessRuleViolationException;

}
