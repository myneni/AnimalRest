package com.walgreens.cdi.service;

import com.walgreens.cdi.exception.CDIException;
import com.walgreens.cdi.vo.CustomerMasterEntLookUpRequest;
import com.walgreens.cdi.vo.customer.ArrayOfEntCustomer;

public interface ICustomerMasterEntLookUpService {
	
	public ArrayOfEntCustomer lookUpCustomerMasterEnt(CustomerMasterEntLookUpRequest loyaltySearchRequest) throws CDIException;
	
	
}
