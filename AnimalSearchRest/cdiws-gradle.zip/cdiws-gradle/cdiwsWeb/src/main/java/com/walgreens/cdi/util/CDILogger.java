package com.walgreens.cdi.util;

import java.util.Date;

import walgreens.utils.logging.WalgreensLog4JImpl;

import com.walgreens.cdi.vo.TrackingInfoVO;

public class CDILogger {

    private WalgreensLog4JImpl walgreensLogger;

    private TrackingInfoVO trackingInfoProxyBean;


    /**
     * @return the trackingInfoProxyBean
     */
    public TrackingInfoVO getTrackingInfoProxyBean() {
        return trackingInfoProxyBean;
    }


    /**
     * @param trackingInfoProxyBean
     *            the trackingInfoProxyBean to set
     */
    public void setTrackingInfoProxyBean(TrackingInfoVO trackingInfoProxyBean) {
        this.trackingInfoProxyBean = trackingInfoProxyBean;
    }


    public WalgreensLog4JImpl getWalgreensLogger() {
        return walgreensLogger;
    }


    public void setWalgreensLogger(WalgreensLog4JImpl walgreensLogger) {
        this.walgreensLogger = walgreensLogger;
    }


    public void log(int level, String message) {
        if (getTrackingInfoProxyBean() != null) {
            String msgToLog = getTrackingInfoProxyBean().getApplicationID()
                    + "|" + getTrackingInfoProxyBean().getMessageID() + "|"
                    + getTrackingInfoProxyBean().getCorrelationID() + "|"
                    + message;
            getWalgreensLogger().log(level, msgToLog);
        } else if (getWalgreensLogger() != null) {
            getWalgreensLogger().log(level, message);
        }
    }


    public void log(int level, String message1, String message2) {
        if (getTrackingInfoProxyBean() != null) {
            String msgToLog = "[" + new Date().toString() + "]" + "\t"+"|"
                    + getTrackingInfoProxyBean().getApplicationID() + "|"
                    + getTrackingInfoProxyBean().getMessageID() + "|"
                    + getTrackingInfoProxyBean().getCorrelationID() + "|"
                    + message1;
            getWalgreensLogger().log(level, "\n", message2);
            getWalgreensLogger().log(level, msgToLog, message2);
        } else if (getWalgreensLogger() != null) {
            getWalgreensLogger().log(level, message1, message2);
        }
    }
    
    public void log(String message) {
        if (getTrackingInfoProxyBean() != null) {
            String msgToLog = getTrackingInfoProxyBean().getApplicationID()
                    + "|" + getTrackingInfoProxyBean().getMessageID() + "|"
                    + getTrackingInfoProxyBean().getCorrelationID() + "|"
                    + message;
            getWalgreensLogger().log(1, msgToLog);
        } else if (getWalgreensLogger() != null) {
            getWalgreensLogger().log(1, message);
        }
    }

}
