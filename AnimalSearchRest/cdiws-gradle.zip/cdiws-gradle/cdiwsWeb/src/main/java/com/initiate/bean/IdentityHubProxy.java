package com.initiate.bean;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;

public class IdentityHubProxy{

    protected Descriptor _descriptor;

    public class Descriptor {
        private com.initiate.bean.IdentityHubService _service = null;
        private com.initiate.bean.IdentityHubPort _proxy = null;
        private Dispatch<Source> _dispatch = null;

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new com.initiate.bean.IdentityHubService(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            _service = new com.initiate.bean.IdentityHubService();
            initCommon();
        }

        private void initCommon() {
            _proxy = _service.getIdentityHub();
        }

        public com.initiate.bean.IdentityHubPort getProxy() {
            return _proxy;
        }

        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("urn:bean.initiate.com", "IdentityHub");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = (BindingProvider) _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public IdentityHubProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
    }

    public IdentityHubProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }

    public FederatedResult searchAndMatchFederated(MemberSearchRequest fedSearchReq) {
        return _getDescriptor().getProxy().searchAndMatchFederated(fedSearchReq);
    }

    public FederatedResult matchMemberFederated(MemberMatchRequest fedmatchMatchReq) {
        return _getDescriptor().getProxy().matchMemberFederated(fedmatchMatchReq);
    }

    public FederatedResult searchMemberFederated(MemberSearchRequest fedSearchReq) {
        return _getDescriptor().getProxy().searchMemberFederated(fedSearchReq);
    }

    public FederatedResult getMemberFederated(MemberGetRequest fedGetReq) {
        return _getDescriptor().getProxy().getMemberFederated(fedGetReq);
    }

    public ArrayOfMember putMember(MemberPutRequest memPutReq) {
        return _getDescriptor().getProxy().putMember(memPutReq);
    }

    public ArrayOfMember putMemberQual(MemberPutQualRequest memPutQualReq) {
        return _getDescriptor().getProxy().putMemberQual(memPutQualReq);
    }

    public ArrayOfMember getMember(MemberGetRequest memGetReq) {
        return _getDescriptor().getProxy().getMember(memGetReq);
    }

    public ArrayOfMember searchMember(MemberSearchRequest memSrchReq) {
        return _getDescriptor().getProxy().searchMember(memSrchReq);
    }

    public ArrayOfMember matchMember(MemberMatchRequest memMatchReq) {
        return _getDescriptor().getProxy().matchMember(memMatchReq);
    }

    public ArrayOfMember compareMember(MemberCompareRequest memCompReq) {
        return _getDescriptor().getProxy().compareMember(memCompReq);
    }

    public boolean deleteMember(MemberDeleteRequest memDelReq) {
        return _getDescriptor().getProxy().deleteMember(memDelReq);
    }

    public boolean undeleteMember(MemberUndeleteRequest memUndelReq) {
        return _getDescriptor().getProxy().undeleteMember(memUndelReq);
    }

    public boolean dropMember(MemberDropRequest memDropReq) {
        return _getDescriptor().getProxy().dropMember(memDropReq);
    }

    public boolean mergeMember(MemberMergeRequest memMergeReq) {
        return _getDescriptor().getProxy().mergeMember(memMergeReq);
    }

    public boolean unmergeMember(MemberUnmergeRequest memUnmergeReq) {
        return _getDescriptor().getProxy().unmergeMember(memUnmergeReq);
    }

    public boolean postItMemberNote(MemberPostItRequest memPostItReq) {
        return _getDescriptor().getProxy().postItMemberNote(memPostItReq);
    }

    public ArrayOfMember scoreMembers(MemberScoreRequest memScoreReq) {
        return _getDescriptor().getProxy().scoreMembers(memScoreReq);
    }

    public ArrayOfMember getTask(TaskGetRequest tskGetReq) {
        return _getDescriptor().getProxy().getTask(tskGetReq);
    }

    public ArrayOfMember searchTask(TaskSearchRequest tskSearchReq) {
        return _getDescriptor().getProxy().searchTask(tskSearchReq);
    }

    public boolean putTask(TaskPutRequest tskPutReq) {
        return _getDescriptor().getProxy().putTask(tskPutReq);
    }

    public ArrayOfMember getEia(EiaGetRequest eiaGetReq) {
        return _getDescriptor().getProxy().getEia(eiaGetReq);
    }

    public boolean putEia(EiaPutRequest eiaPutReq) {
        return _getDescriptor().getProxy().putEia(eiaPutReq);
    }

    public ArrayOfMember searchEia(EiaSearchRequest eiaSearchReq) {
        return _getDescriptor().getProxy().searchEia(eiaSearchReq);
    }

    public ArrayOfDictionary getDictionary(DictionaryGetRequest dicGetReq) {
        return _getDescriptor().getProxy().getDictionary(dicGetReq);
    }

    public boolean putDictionary(DictionaryPutRequest dicPutReq) {
        return _getDescriptor().getProxy().putDictionary(dicPutReq);
    }

    public ArrayOfSegDefWs getSegmentDef(SegmentDefGetRequest segDefReq) {
        return _getDescriptor().getProxy().getSegmentDef(segDefReq);
    }

    public ArrayOfDictionary getUserInfo(UserInfoGetRequest userGetReq) {
        return _getDescriptor().getProxy().getUserInfo(userGetReq);
    }

    public ArrayOfDictionary getGroupInfo(GroupInfoGetRequest groupGetReq) {
        return _getDescriptor().getProxy().getGroupInfo(groupGetReq);
    }

    public ArrayOfDictionary getApplicationInfo(AppInfoGetRequest appGetReq) {
        return _getDescriptor().getProxy().getApplicationInfo(appGetReq);
    }

    public ArrayOfDictionary getNetworkInfo(NetInfoGetRequest netGetReq) {
        return _getDescriptor().getProxy().getNetworkInfo(netGetReq);
    }

    public ArrayOfDictionary getEngineInfo(EngInfoGetRequest engGetReq) {
        return _getDescriptor().getProxy().getEngineInfo(engGetReq);
    }

    public boolean putEngineInfo(EngInfoPutRequest engPutReq) {
        return _getDescriptor().getProxy().putEngineInfo(engPutReq);
    }

    public ArrayOfRelLinkWs getRelationships(RelationshipGetRequest relGetReq) {
        return _getDescriptor().getProxy().getRelationships(relGetReq);
    }

    public ArrayOfRelationshipSearchMapEntry searchRelationships(RelationshipSearchRequest relSearchReq) {
        return _getDescriptor().getProxy().searchRelationships(relSearchReq);
    }

    public ArrayOfRelationshipSearchCountMapEntry searchRelationshipCounts(RelationshipSearchCountRequest relSearchCountReq) {
        return _getDescriptor().getProxy().searchRelationshipCounts(relSearchCountReq);
    }

    public ArrayOfRelLinkWs putRelationships(RelationshipPutRequest relPutReq) {
        return _getDescriptor().getProxy().putRelationships(relPutReq);
    }

    public boolean deleteRelationships(RelationshipDeleteRequest relDeleteReq) {
        return _getDescriptor().getProxy().deleteRelationships(relDeleteReq);
    }

    public ArrayOfXsdLong getRelationshipPathToRoot(RelationshipPathToRootRequest relPathToRootReq) {
        return _getDescriptor().getProxy().getRelationshipPathToRoot(relPathToRootReq);
    }

    public ArrayOfRelXtskWs getRelationshipTasks(RelationshipTaskGetRequest relTaskGetReq) {
        return _getDescriptor().getProxy().getRelationshipTasks(relTaskGetReq);
    }

    public ArrayOfRelXtskWs searchRelationshipTasks(RelationshipTaskSearchRequest relTaskSearchReq) {
        return _getDescriptor().getProxy().searchRelationshipTasks(relTaskSearchReq);
    }

    public ArrayOfRelXtskWs resolveRelationshipTasks(RelationshipTaskResolveRequest relTaskResolveReq) {
        return _getDescriptor().getProxy().resolveRelationshipTasks(relTaskResolveReq);
    }

    public boolean deleteRelationshipTasks(RelationshipTaskDeleteRequest relTaskDeleteReq) {
        return _getDescriptor().getProxy().deleteRelationshipTasks(relTaskDeleteReq);
    }

}